﻿// Decompiled with JetBrains decompiler
// Type: VRageMath.CurveLoopType
// Assembly: VRage.Math, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9DA630D2-11CA-4233-BDDE-0D91FCC9F835
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Math.dll

namespace VRageMath
{
  public enum CurveLoopType
  {
    Constant,
    Cycle,
    CycleOffset,
    Oscillate,
    Linear,
  }
}
