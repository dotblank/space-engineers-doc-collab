﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: Extension]
[assembly: AssemblyTitle("VRage.Math")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Keen Software House")]
[assembly: AssemblyProduct("VRage.Math")]
[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: AssemblyTrademark("VRAGE")]
[assembly: ComVisible(false)]
[assembly: Guid("b688daeb-6941-4b0f-9aba-1d8646a89ced")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
