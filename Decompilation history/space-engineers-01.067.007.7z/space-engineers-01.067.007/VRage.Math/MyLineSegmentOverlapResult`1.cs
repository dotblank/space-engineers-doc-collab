﻿// Decompiled with JetBrains decompiler
// Type: VRageMath.MyLineSegmentOverlapResult`1
// Assembly: VRage.Math, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9DA630D2-11CA-4233-BDDE-0D91FCC9F835
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Math.dll

using System.Collections.Generic;

namespace VRageMath
{
  public struct MyLineSegmentOverlapResult<T>
  {
    public static MyLineSegmentOverlapResult<T>.MyLineSegmentOverlapResultComparer DistanceComparer = new MyLineSegmentOverlapResult<T>.MyLineSegmentOverlapResultComparer();
    public double Distance;
    public T Element;

    public class MyLineSegmentOverlapResultComparer : IComparer<MyLineSegmentOverlapResult<T>>
    {
      public int Compare(MyLineSegmentOverlapResult<T> x, MyLineSegmentOverlapResult<T> y)
      {
        return x.Distance.CompareTo(y.Distance);
      }
    }
  }
}
