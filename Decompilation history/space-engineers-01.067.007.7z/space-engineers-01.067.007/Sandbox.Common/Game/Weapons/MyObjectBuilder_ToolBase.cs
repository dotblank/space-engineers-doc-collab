﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Game.Weapons.MyObjectBuilder_ToolBase
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 65B9437C-6443-4388-AFE3-5DD75CE6625F
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;

namespace Sandbox.Game.Weapons
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_ToolBase : MyObjectBuilder_DeviceBase
  {
  }
}
