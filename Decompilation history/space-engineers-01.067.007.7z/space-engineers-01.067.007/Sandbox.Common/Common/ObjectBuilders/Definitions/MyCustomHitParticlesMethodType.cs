﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.Definitions.MyCustomHitParticlesMethodType
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 65B9437C-6443-4388-AFE3-5DD75CE6625F
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

namespace Sandbox.Common.ObjectBuilders.Definitions
{
  public enum MyCustomHitParticlesMethodType
  {
    Unknown = -1,
    Biochem = 0,
    EMP = 1,
    Basic = 2,
    BasicSmall = 3,
    Piercing = 4,
    Explosive = 5,
    HighSpeed = 6,
  }
}
