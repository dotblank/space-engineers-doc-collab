﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: Guid("29613bf2-9a4d-46f5-a737-53a0f78dcec5")]
[assembly: AssemblyProduct("Sandbox")]
[assembly: AssemblyTrademark("VRAGE")]
[assembly: ComVisible(false)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Extension]
[assembly: AssemblyCompany("Keen Software House")]
[assembly: AssemblyTitle("Sandbox.Common")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
