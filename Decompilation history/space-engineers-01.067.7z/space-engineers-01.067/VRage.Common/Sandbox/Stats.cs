﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Stats
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Stats;
using VRageRender;

namespace Sandbox
{
  public static class Stats
  {
    public static readonly MyStats Timing = new MyStats();
    public static readonly MyStats Generic = MyRenderStats.Generic;
    public static readonly MyStats Network = new MyStats();
    public static Stats.MyPerAppLifetime PerAppLifetime;

    static Stats()
    {
      MyRenderStats.SetColumn(MyRenderStats.ColumnEnum.Left, Stats.Timing, Stats.Generic, Stats.Network);
    }

    public struct MyPerAppLifetime
    {
      public int MyModelsCount;
      public int MyModelsMeshesCount;
      public int MyModelsVertexesCount;
      public int MyModelsTrianglesCount;
    }
  }
}
