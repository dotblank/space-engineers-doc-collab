﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.MyNamedEnum`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using ProtoBuf;
using System;
using System.Globalization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using VRage;

namespace Sandbox.Common
{
  [ProtoContract]
  public struct MyNamedEnum<T> : IXmlSerializable where T : struct, IConvertible
  {
    [XmlIgnore]
    [ProtoMember(1)]
    private int m_enumInt;
    private T EnumType;

    public MyNamedEnum(T s)
    {
      this.EnumType = s;
      this.m_enumInt = ((IConvertible) s).ToInt32((IFormatProvider) CultureInfo.InvariantCulture);
    }

    public MyNamedEnum(int i)
    {
      this.EnumType = default (T);
      this.m_enumInt = 0;
      this.CreateFromInt(i);
    }

    public static implicit operator T(MyNamedEnum<T> f)
    {
      return f.EnumType;
    }

    public static implicit operator MyNamedEnum<T>(T f)
    {
      return new MyNamedEnum<T>(f);
    }

    public static implicit operator int(MyNamedEnum<T> f)
    {
      return f.m_enumInt;
    }

    public static implicit operator MyNamedEnum<T>(int f)
    {
      return new MyNamedEnum<T>(f);
    }

    private void CreateFromString(string s)
    {
      if (!Enum.TryParse<T>(s, out this.EnumType))
        this.EnumType = (T) Enum.ToObject(typeof (T), MyStringUtils.GetHash(s, 0));
      this.m_enumInt = ((IConvertible) this.EnumType).ToInt32((IFormatProvider) CultureInfo.InvariantCulture);
    }

    private void CreateFromInt(int i)
    {
      this.m_enumInt = i;
      this.EnumType = (T) Enum.ToObject(typeof (T), i);
    }

    public XmlSchema GetSchema()
    {
      return (XmlSchema) null;
    }

    public void ReadXml(XmlReader reader)
    {
      int num = (int) reader.MoveToContent();
      this.CreateFromString(reader.ReadElementContentAsString());
    }

    public void WriteXml(XmlWriter writer)
    {
      writer.WriteValue(this.EnumType.ToString());
    }

    [ProtoAfterDeserialization]
    private void OnProtoDeserialize()
    {
      this.CreateFromInt(this.m_enumInt);
    }
  }
}
