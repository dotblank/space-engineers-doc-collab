﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: Guid("d8785c7a-77ef-4dfb-8a45-b1e90f17c2fa")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Extension]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("VRAGE")]
[assembly: AssemblyTitle("VRage.Common")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("Keen Software House")]
[assembly: AssemblyProduct("VRage.Common")]
[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
