﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.ConvexSeparatingDistanceUtil
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using VRageMath;

namespace BulletXNA
{
  public class ConvexSeparatingDistanceUtil
  {
    private Quaternion m_ornA;
    private Quaternion m_ornB;
    private IndexedVector3 m_posA;
    private IndexedVector3 m_posB;
    private IndexedVector3 m_separatingNormal;
    private float m_boundingRadiusA;
    private float m_boundingRadiusB;
    private float m_separatingDistance;

    public ConvexSeparatingDistanceUtil(float boundingRadiusA, float boundingRadiusB)
    {
      this.m_boundingRadiusA = boundingRadiusA;
      this.m_boundingRadiusB = boundingRadiusB;
      this.m_separatingDistance = 0.0f;
    }

    public float GetConservativeSeparatingDistance()
    {
      return this.m_separatingDistance;
    }

    public void UpdateSeparatingDistance(ref IndexedMatrix transA, ref IndexedMatrix transB)
    {
      IndexedVector3 pos1_1 = transA._origin;
      IndexedVector3 pos1_2 = transB._origin;
      Quaternion rotation1 = transA.GetRotation();
      Quaternion rotation2 = transB.GetRotation();
      if ((double) this.m_separatingDistance > 0.0)
      {
        IndexedVector3 linVel1;
        IndexedVector3 angVel1;
        TransformUtil.CalculateVelocityQuaternion(ref this.m_posA, ref pos1_1, ref this.m_ornA, ref rotation1, 1f, out linVel1, out angVel1);
        IndexedVector3 linVel2;
        IndexedVector3 angVel2;
        TransformUtil.CalculateVelocityQuaternion(ref this.m_posB, ref pos1_2, ref this.m_ornB, ref rotation2, 1f, out linVel2, out angVel2);
        float num1 = (float) ((double) angVel1.Length() * (double) this.m_boundingRadiusA + (double) angVel2.Length() * (double) this.m_boundingRadiusB);
        IndexedVector3 indexedVector3 = linVel2 - linVel1;
        float num2 = IndexedVector3.Dot(linVel2 - linVel1, this.m_separatingNormal);
        if ((double) num2 < 0.0)
          num2 = 0.0f;
        this.m_separatingDistance -= num1 + num2;
      }
      this.m_posA = pos1_1;
      this.m_posB = pos1_2;
      this.m_ornA = rotation1;
      this.m_ornB = rotation2;
    }

    private void InitSeparatingDistance(ref IndexedVector3 separatingVector, float separatingDistance, ref IndexedMatrix transA, ref IndexedMatrix transB)
    {
      this.m_separatingNormal = separatingVector;
      this.m_separatingDistance = separatingDistance;
      IndexedVector3 indexedVector3_1 = transA._origin;
      IndexedVector3 indexedVector3_2 = transB._origin;
      Quaternion rotation1 = transA.GetRotation();
      Quaternion rotation2 = transB.GetRotation();
      this.m_posA = indexedVector3_1;
      this.m_posB = indexedVector3_2;
      this.m_ornA = rotation1;
      this.m_ornB = rotation2;
    }
  }
}
