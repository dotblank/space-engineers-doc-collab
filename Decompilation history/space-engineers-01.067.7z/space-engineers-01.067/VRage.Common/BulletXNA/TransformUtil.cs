﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.TransformUtil
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System;
using System.Collections.Generic;
using VRageMath;

namespace BulletXNA
{
  public static class TransformUtil
  {
    public static float ANGULAR_MOTION_THRESHOLD = 0.7853982f;

    public static IList<float> FloatToList(float f)
    {
      IList<float> list = (IList<float>) new List<float>();
      list.Add(f);
      return list;
    }

    public static IList<float> VectorToList(IndexedVector3 vector)
    {
      return TransformUtil.VectorToList(ref vector);
    }

    public static IList<float> VectorToList(ref IndexedVector3 vector)
    {
      IList<float> list = (IList<float>) new List<float>();
      list.Add(vector.X);
      list.Add(vector.Y);
      list.Add(vector.Z);
      return list;
    }

    public static IList<IndexedVector3> VectorsFromList(IList<float> list)
    {
      IList<IndexedVector3> list1 = (IList<IndexedVector3>) new List<IndexedVector3>();
      int num = list.Count / 3;
      for (int index = 0; index < num; ++index)
      {
        IndexedVector3 indexedVector3 = new IndexedVector3(list[3 * index], list[3 * index + 1], list[3 * index + 2]);
        list1.Add(indexedVector3);
      }
      return list1;
    }

    public static void PlaneSpace1(ref IndexedVector3 n, out IndexedVector3 p, out IndexedVector3 q)
    {
      if ((double) Math.Abs(n.Z) > 0.70710676908493)
      {
        float a = (float) ((double) n.Y * (double) n.Y + (double) n.Z * (double) n.Z);
        float num = MathUtil.RecipSqrt(a);
        p = new IndexedVector3(0.0f, -n.Z * num, n.Y * num);
        q = new IndexedVector3(a * num, -n.X * p.Z, n.X * p.Y);
      }
      else
      {
        float a = (float) ((double) n.X * (double) n.X + (double) n.Y * (double) n.Y);
        float num = MathUtil.RecipSqrt(a);
        p = new IndexedVector3(-n.Y * num, n.X * num, 0.0f);
        q = new IndexedVector3(-n.Z * p.Y, n.Z * p.X, a * num);
      }
    }

    public static IndexedVector3 AabbSupport(ref IndexedVector3 halfExtents, ref IndexedVector3 supportDir)
    {
      return new IndexedVector3((double) supportDir.X < 0.0 ? -halfExtents.X : halfExtents.X, (double) supportDir.Y < 0.0 ? -halfExtents.Y : halfExtents.Y, (double) supportDir.Z < 0.0 ? -halfExtents.Z : halfExtents.Z);
    }

    public static void IntegrateTransform(IndexedMatrix curTrans, IndexedVector3 linvel, IndexedVector3 angvel, float timeStep, out IndexedMatrix predictedTransform)
    {
      TransformUtil.IntegrateTransform(ref curTrans, ref linvel, ref angvel, timeStep, out predictedTransform);
    }

    public static void IntegrateTransform(ref IndexedMatrix curTrans, ref IndexedVector3 linvel, ref IndexedVector3 angvel, float timeStep, out IndexedMatrix predictedTransform)
    {
      predictedTransform = IndexedMatrix.CreateTranslation(curTrans._origin + linvel * timeStep);
      float num = angvel.Length();
      if ((double) num * (double) timeStep > (double) TransformUtil.ANGULAR_MOTION_THRESHOLD)
        num = TransformUtil.ANGULAR_MOTION_THRESHOLD / timeStep;
      IndexedVector3 indexedVector3 = (double) num >= 1.0 / 1000.0 ? angvel * ((float) Math.Sin(0.5 * (double) num * (double) timeStep) / num) : angvel * (float) (0.5 * (double) timeStep - (double) timeStep * (double) timeStep * (double) timeStep * 0.0208333339542151 * (double) num * (double) num);
      Quaternion q = new Quaternion(indexedVector3.X, indexedVector3.Y, indexedVector3.Z, (float) Math.Cos((double) num * (double) timeStep * 0.5)) * curTrans.GetRotation();
      q.Normalize();
      IndexedMatrix fromQuaternion = IndexedMatrix.CreateFromQuaternion(q);
      predictedTransform._basis = fromQuaternion._basis;
    }

    public static void CalculateVelocityQuaternion(ref IndexedVector3 pos0, ref IndexedVector3 pos1, ref Quaternion orn0, ref Quaternion orn1, float timeStep, out IndexedVector3 linVel, out IndexedVector3 angVel)
    {
      linVel = (pos1 - pos0) / timeStep;
      if (orn0 != orn1)
      {
        IndexedVector3 axis;
        float angle;
        TransformUtil.CalculateDiffAxisAngleQuaternion(ref orn0, ref orn1, out axis, out angle);
        angVel = axis * (angle / timeStep);
      }
      else
        angVel = IndexedVector3.Zero;
    }

    public static void CalculateDiffAxisAngleQuaternion(ref Quaternion orn0, ref Quaternion orn1a, out IndexedVector3 axis, out float angle)
    {
      Quaternion quat = MathUtil.QuatFurthest(ref orn0, ref orn1a) * MathUtil.QuaternionInverse(ref orn0);
      quat.Normalize();
      angle = MathUtil.QuatAngle(ref quat);
      axis = new IndexedVector3(quat.X, quat.Y, quat.Z);
      if ((double) axis.LengthSquared() < 1.4210854715202E-14)
        axis = new IndexedVector3(1f, 0.0f, 0.0f);
      else
        axis.Normalize();
    }

    public static void CalculateVelocity(ref IndexedMatrix transform0, ref IndexedMatrix transform1, float timeStep, out IndexedVector3 linVel, out IndexedVector3 angVel)
    {
      linVel = (transform1._origin - transform0._origin) / timeStep;
      MathUtil.SanityCheckVector(ref linVel);
      IndexedVector3 axis;
      float angle;
      TransformUtil.CalculateDiffAxisAngle(ref transform0, ref transform1, out axis, out angle);
      angVel = axis * (angle / timeStep);
      MathUtil.SanityCheckVector(ref angVel);
    }

    public static void CalculateDiffAxisAngle(ref IndexedMatrix transform0, ref IndexedMatrix transform1, out IndexedVector3 axis, out float angle)
    {
      IndexedBasisMatrix a = transform1._basis * transform0._basis.Inverse();
      Quaternion rot = Quaternion.Identity;
      TransformUtil.GetRotation(ref a, out rot);
      rot.Normalize();
      angle = MathUtil.QuatAngle(ref rot);
      axis = new IndexedVector3(rot.X, rot.Y, rot.Z);
      if ((double) axis.LengthSquared() < 1.4210854715202E-14)
        axis = new IndexedVector3(1f, 0.0f, 0.0f);
      else
        axis.Normalize();
    }

    public static void GetRotation(ref IndexedBasisMatrix a, out Quaternion rot)
    {
      rot = a.GetRotation();
    }

    public static Quaternion GetRotation(ref IndexedBasisMatrix a)
    {
      return a.GetRotation();
    }
  }
}
