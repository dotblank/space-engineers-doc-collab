﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.MathUtil
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System;
using System.IO;
using System.Runtime.InteropServices;
using VRageMath;

namespace BulletXNA
{
  public static class MathUtil
  {
    public static IndexedVector3 MAX_VECTOR = new IndexedVector3(1E+18f);
    public static IndexedVector3 MIN_VECTOR = new IndexedVector3(-1E+18f);
    public const float SIMD_EPSILON = 1.192093E-07f;
    public const float SIMDSQRT12 = 0.7071068f;
    public const float BT_LARGE_FLOAT = 1E+18f;
    public const float SIMD_2_PI = 6.283185f;
    public const float SIMD_PI = 3.141593f;
    public const float SIMD_HALF_PI = 1.570796f;
    public const float SIMD_QUARTER_PI = 0.7853982f;
    public const float SIMD_INFINITY = 3.402823E+38f;
    public const float SIMD_RADS_PER_DEG = 0.01745329f;
    public const float SIMD_DEGS_PER_RAD = 57.29578f;

    public static float[,] BasisMatrixToFloatArray(ref IndexedBasisMatrix m)
    {
      return new float[3, 3]
      {
        {
          m._Row0.X,
          m._Row0.Y,
          m._Row0.Z
        },
        {
          m._Row1.X,
          m._Row1.Y,
          m._Row1.Z
        },
        {
          m._Row2.X,
          m._Row2.Y,
          m._Row2.Z
        }
      };
    }

    public static void FloatArrayToBasisMatrix(float[,] f, ref IndexedBasisMatrix m)
    {
      m._Row0 = new IndexedVector3(f[0, 0], f[0, 1], f[0, 2]);
      m._Row1 = new IndexedVector3(f[1, 0], f[1, 1], f[1, 2]);
      m._Row2 = new IndexedVector3(f[2, 0], f[2, 1], f[2, 2]);
    }

    public static void InverseTransform(ref IndexedMatrix m, ref IndexedVector3 v, out IndexedVector3 o)
    {
      IndexedVector3 indexedVector3 = v - m._origin;
      o = m._basis.Transpose() * indexedVector3;
    }

    public static IndexedVector3 InverseTransform(ref IndexedMatrix m, ref IndexedVector3 v)
    {
      IndexedVector3 indexedVector3 = v - m._origin;
      return m._basis.Transpose() * indexedVector3;
    }

    public static float FSel(float a, float b, float c)
    {
      if ((double) a < 0.0)
        return c;
      else
        return b;
    }

    public static int MaxAxis(ref IndexedVector3 a)
    {
      if ((double) a.X >= (double) a.Y)
        return (double) a.X >= (double) a.Z ? 0 : 2;
      else
        return (double) a.Y >= (double) a.Z ? 1 : 2;
    }

    public static int MaxAxis(Vector4 a)
    {
      return MathUtil.MaxAxis(ref a);
    }

    public static int MaxAxis(ref Vector4 a)
    {
      int num1 = -1;
      float num2 = -1E+18f;
      if ((double) a.X > (double) num2)
      {
        num1 = 0;
        num2 = a.X;
      }
      if ((double) a.Y > (double) num2)
      {
        num1 = 1;
        num2 = a.Y;
      }
      if ((double) a.Z > (double) num2)
      {
        num1 = 2;
        num2 = a.Z;
      }
      if ((double) a.W > (double) num2)
        num1 = 3;
      return num1;
    }

    public static int ClosestAxis(ref Vector4 a)
    {
      return MathUtil.MaxAxis(MathUtil.AbsoluteVector4(ref a));
    }

    public static Vector4 AbsoluteVector4(ref Vector4 vec)
    {
      return new Vector4(Math.Abs(vec.X), Math.Abs(vec.Y), Math.Abs(vec.Z), Math.Abs(vec.W));
    }

    public static float VectorComponent(Vector4 v, int i)
    {
      return MathUtil.VectorComponent(ref v, i);
    }

    public static float VectorComponent(ref Vector4 v, int i)
    {
      switch (i)
      {
        case 0:
          return v.X;
        case 1:
          return v.Y;
        case 2:
          return v.Z;
        case 3:
          return v.W;
        default:
          return 0.0f;
      }
    }

    public static void VectorComponent(ref Vector4 v, int i, float f)
    {
      switch (i)
      {
        case 0:
          v.X = f;
          break;
        case 1:
          v.Y = f;
          break;
        case 2:
          v.Z = f;
          break;
        case 3:
          v.W = f;
          break;
      }
    }

    public static float Vector3Triple(ref IndexedVector3 a, ref IndexedVector3 b, ref IndexedVector3 c)
    {
      return (float) ((double) a.X * ((double) b.Y * (double) c.Z - (double) b.Z * (double) c.Y) + (double) a.Y * ((double) b.Z * (double) c.X - (double) b.X * (double) c.Z) + (double) a.Z * ((double) b.X * (double) c.Y - (double) b.Y * (double) c.X));
    }

    public static int GetQuantized(float x)
    {
      if ((double) x < 0.0)
        return (int) ((double) x - 0.5);
      else
        return (int) ((double) x + 0.5);
    }

    public static void VectorClampMax(ref IndexedVector3 input, ref IndexedVector3 bounds)
    {
      input.X = Math.Min(input.X, bounds.X);
      input.Y = Math.Min(input.Y, bounds.Y);
      input.Z = Math.Min(input.Z, bounds.Z);
    }

    public static void VectorClampMin(ref IndexedVector3 input, ref IndexedVector3 bounds)
    {
      input.X = Math.Max(input.X, bounds.X);
      input.Y = Math.Max(input.Y, bounds.Y);
      input.Z = Math.Max(input.Z, bounds.Z);
    }

    public static void VectorMin(IndexedVector3 input, ref IndexedVector3 output)
    {
      MathUtil.VectorMin(ref input, ref output);
    }

    public static void VectorMin(ref IndexedVector3 input, ref IndexedVector3 output)
    {
      output.X = Math.Min(input.X, output.X);
      output.Y = Math.Min(input.Y, output.Y);
      output.Z = Math.Min(input.Z, output.Z);
    }

    public static void VectorMin(ref IndexedVector3 input1, ref IndexedVector3 input2, out IndexedVector3 output)
    {
      output = new IndexedVector3(Math.Min(input1.X, input2.X), Math.Min(input1.Y, input2.Y), Math.Min(input1.Z, input2.Z));
    }

    public static void VectorMax(IndexedVector3 input, ref IndexedVector3 output)
    {
      MathUtil.VectorMax(ref input, ref output);
    }

    public static void VectorMax(ref IndexedVector3 input, ref IndexedVector3 output)
    {
      output.X = Math.Max(input.X, output.X);
      output.Y = Math.Max(input.Y, output.Y);
      output.Z = Math.Max(input.Z, output.Z);
    }

    public static void VectorMax(ref IndexedVector3 input1, ref IndexedVector3 input2, out IndexedVector3 output)
    {
      output = new IndexedVector3(Math.Max(input1.X, input2.X), Math.Max(input1.Y, input2.Y), Math.Max(input1.Z, input2.Z));
    }

    public static float RecipSqrt(float a)
    {
      return (float) (1.0 / Math.Sqrt((double) a));
    }

    public static bool CompareFloat(float val1, float val2)
    {
      return (double) Math.Abs(val1 - val2) <= 1.19209289550781E-07;
    }

    public static bool FuzzyZero(float val)
    {
      return (double) Math.Abs(val) <= 1.19209289550781E-07;
    }

    public static uint Select(uint condition, uint valueIfConditionNonZero, uint valueIfConditionZero)
    {
      uint num1 = (uint) (((int) condition | -(int) condition) >> 31);
      uint num2 = ~num1;
      return (uint) ((int) valueIfConditionNonZero & (int) num1 | (int) valueIfConditionZero & (int) num2);
    }

    public static Quaternion ShortestArcQuat(IndexedVector3 axisInA, IndexedVector3 axisInB)
    {
      return MathUtil.ShortestArcQuat(ref axisInA, ref axisInB);
    }

    public static Quaternion ShortestArcQuat(ref IndexedVector3 axisInA, ref IndexedVector3 axisInB)
    {
      IndexedVector3 indexedVector3 = IndexedVector3.Cross(axisInA, axisInB);
      float num1 = IndexedVector3.Dot(axisInA, axisInB);
      if ((double) num1 < -0.99999988079071)
        return new Quaternion(0.0f, 1f, 0.0f, 0.0f);
      float num2 = (float) Math.Sqrt((1.0 + (double) num1) * 2.0);
      float num3 = 1f / num2;
      return new Quaternion(indexedVector3.X * num3, indexedVector3.Y * num3, indexedVector3.Z * num3, num2 * 0.5f);
    }

    public static float QuatAngle(ref Quaternion quat)
    {
      return 2f * (float) Math.Acos((double) quat.W);
    }

    public static Quaternion QuatFurthest(ref Quaternion input1, ref Quaternion input2)
    {
      Quaternion quaternion1 = input1 - input2;
      Quaternion quaternion2 = input1 + input2;
      if ((double) Quaternion.Dot(quaternion1, quaternion1) > (double) Quaternion.Dot(quaternion2, quaternion2))
        return input2;
      else
        return -input2;
    }

    public static IndexedVector3 QuatRotate(Quaternion rotation, IndexedVector3 v)
    {
      return MathUtil.QuatRotate(ref rotation, ref v);
    }

    public static IndexedVector3 QuatRotate(ref Quaternion rotation, ref IndexedVector3 v)
    {
      Quaternion quaternion = MathUtil.QuatVectorMultiply(ref rotation, ref v) * MathUtil.QuaternionInverse(ref rotation);
      return new IndexedVector3(quaternion.X, quaternion.Y, quaternion.Z);
    }

    public static Quaternion QuatVectorMultiply(ref Quaternion q, ref IndexedVector3 w)
    {
      return new Quaternion((float) ((double) q.W * (double) w.X + (double) q.Y * (double) w.Z - (double) q.Z * (double) w.Y), (float) ((double) q.W * (double) w.Y + (double) q.Z * (double) w.X - (double) q.X * (double) w.Z), (float) ((double) q.W * (double) w.Z + (double) q.X * (double) w.Y - (double) q.Y * (double) w.X), (float) (-(double) q.X * (double) w.X - (double) q.Y * (double) w.Y - (double) q.Z * (double) w.Z));
    }

    public static void GetSkewSymmetricMatrix(ref IndexedVector3 vecin, out IndexedVector3 v0, out IndexedVector3 v1, out IndexedVector3 v2)
    {
      v0 = new IndexedVector3(0.0f, -vecin.Z, vecin.Y);
      v1 = new IndexedVector3(vecin.Z, 0.0f, -vecin.X);
      v2 = new IndexedVector3(-vecin.Y, vecin.X, 0.0f);
    }

    public static void SanityCheckVector(IndexedVector3 v)
    {
    }

    public static void ZeroCheckVector(IndexedVector3 v)
    {
    }

    public static void ZeroCheckVector(ref IndexedVector3 v)
    {
    }

    public static void SanityCheckVector(ref IndexedVector3 v)
    {
    }

    public static void SanityCheckFloat(float f)
    {
    }

    public static float GetMatrixElem(IndexedBasisMatrix mat, int index)
    {
      int index1 = index % 3;
      int index2 = index / 3;
      return mat[index1, index2];
    }

    public static float GetMatrixElem(ref IndexedBasisMatrix mat, int index)
    {
      int index1 = index % 3;
      int index2 = index / 3;
      return mat[index1, index2];
    }

    public static bool MatrixToEulerXYZ(ref IndexedBasisMatrix mat, out IndexedVector3 xyz)
    {
      float matrixElem1 = MathUtil.GetMatrixElem(ref mat, 0);
      float matrixElem2 = MathUtil.GetMatrixElem(ref mat, 1);
      float matrixElem3 = MathUtil.GetMatrixElem(ref mat, 2);
      float matrixElem4 = MathUtil.GetMatrixElem(ref mat, 3);
      float matrixElem5 = MathUtil.GetMatrixElem(ref mat, 4);
      float matrixElem6 = MathUtil.GetMatrixElem(ref mat, 5);
      double num1 = (double) MathUtil.GetMatrixElem(ref mat, 6);
      double num2 = (double) MathUtil.GetMatrixElem(ref mat, 7);
      float matrixElem7 = MathUtil.GetMatrixElem(ref mat, 8);
      float num3 = matrixElem3;
      if ((double) num3 < 1.0)
      {
        if ((double) num3 > -1.0)
        {
          xyz = new IndexedVector3((float) Math.Atan2(-(double) matrixElem6, (double) matrixElem7), (float) Math.Asin((double) matrixElem3), (float) Math.Atan2(-(double) matrixElem2, (double) matrixElem1));
          return true;
        }
        else
        {
          xyz = new IndexedVector3((float) -Math.Atan2((double) matrixElem4, (double) matrixElem5), -1.570796f, 0.0f);
          return false;
        }
      }
      else
      {
        xyz = new IndexedVector3((float) Math.Atan2((double) matrixElem4, (double) matrixElem5), 1.570796f, 0.0f);
        return false;
      }
    }

    public static Quaternion QuaternionInverse(Quaternion q)
    {
      return MathUtil.QuaternionInverse(ref q);
    }

    public static Quaternion QuaternionInverse(ref Quaternion q)
    {
      return new Quaternion(-q.X, -q.Y, -q.Z, q.W);
    }

    public static Quaternion QuaternionMultiply(Quaternion a, Quaternion b)
    {
      return MathUtil.QuaternionMultiply(ref a, ref b);
    }

    public static Quaternion QuaternionMultiply(ref Quaternion a, ref Quaternion b)
    {
      return a * b;
    }

    public static float NormalizeAngle(float angleInRadians)
    {
      angleInRadians %= 6.283185f;
      if ((double) angleInRadians < -3.14159274101257)
        return angleInRadians + 6.283185f;
      if ((double) angleInRadians > 3.14159274101257)
        return angleInRadians - 6.283185f;
      else
        return angleInRadians;
    }

    public static float DegToRadians(float degrees)
    {
      return (float) ((double) degrees / 360.0 * 6.28318548202515);
    }

    public static IndexedVector3 Interpolate3(IndexedVector3 v0, IndexedVector3 v1, float rt)
    {
      float num = 1f - rt;
      return new IndexedVector3((float) ((double) num * (double) v0.X + (double) rt * (double) v1.X), (float) ((double) num * (double) v0.Y + (double) rt * (double) v1.Y), (float) ((double) num * (double) v0.Z + (double) rt * (double) v1.Z));
    }

    public static IndexedVector3 Interpolate3(ref IndexedVector3 v0, ref IndexedVector3 v1, float rt)
    {
      float num = 1f - rt;
      return new IndexedVector3((float) ((double) num * (double) v0.X + (double) rt * (double) v1.X), (float) ((double) num * (double) v0.Y + (double) rt * (double) v1.Y), (float) ((double) num * (double) v0.Z + (double) rt * (double) v1.Z));
    }

    public static IndexedMatrix SetEulerZYX(float eulerX, float eulerY, float eulerZ)
    {
      IndexedMatrix identity = IndexedMatrix.Identity;
      identity._basis.SetEulerZYX(eulerX, eulerY, eulerZ);
      return identity;
    }

    public static IndexedVector3 Vector4ToVector3(Vector4 v4)
    {
      return new IndexedVector3(v4.X, v4.Y, v4.Z);
    }

    public static IndexedVector3 Vector4ToVector3(ref Vector4 v4)
    {
      return new IndexedVector3(v4.X, v4.Y, v4.Z);
    }

    public static void PrintQuaternion(TextWriter writer, Quaternion q)
    {
      writer.Write(string.Format("{{X:{0:0.00000000} Y:{1:0.00000000} Z:{2:0.00000000} W:{3:0.00000000}}}", (object) q.X, (object) q.Y, (object) q.Z, (object) q.W));
    }

    public static void PrintVector3(TextWriter writer, IndexedVector3 v)
    {
      writer.WriteLine(string.Format("{{X:{0:0.00000000} Y:{1:0.00000000} Z:{2:0.00000000}}}", (object) v.X, (object) v.Y, (object) v.Z));
    }

    public static void PrintVector3(TextWriter writer, string name, IndexedVector3 v)
    {
      writer.WriteLine(string.Format("[{0}] {{X:{1:0.00000000} Y:{2:0.00000000} Z:{3:0.00000000}}}", (object) name, (object) v.X, (object) v.Y, (object) v.Z));
    }

    public static void PrintVector4(TextWriter writer, Vector4 v)
    {
      writer.WriteLine(string.Format("{{X:{0:0.00000000} Y:{1:0.00000000} Z:{2:0.00000000} W:{3:0.00000000}}}", (object) v.X, (object) v.Y, (object) v.Z, (object) v.W));
    }

    public static void PrintVector4(TextWriter writer, string name, Vector4 v)
    {
      writer.WriteLine(string.Format("[{0}] {{X:{1:0.00000000} Y:{2:0.00000000} Z:{3:0.00000000} W:{4:0.00000000}}}", (object) name, (object) v.X, (object) v.Y, (object) v.Z, (object) v.W));
    }

    public static void PrintMatrix(TextWriter writer, IndexedMatrix m)
    {
      MathUtil.PrintMatrix(writer, (string) null, m);
    }

    public static void PrintMatrix(TextWriter writer, string name, IndexedMatrix m)
    {
      if (writer == null)
        return;
      if (name != null)
        writer.WriteLine(name);
      MathUtil.PrintVector3(writer, "Right       ", m._basis.GetColumn(0));
      MathUtil.PrintVector3(writer, "Up          ", m._basis.GetColumn(1));
      MathUtil.PrintVector3(writer, "Backward    ", m._basis.GetColumn(2));
      MathUtil.PrintVector3(writer, "Translation ", m._origin);
    }

    public static void PrintMatrix(TextWriter writer, IndexedBasisMatrix m)
    {
      MathUtil.PrintMatrix(writer, (string) null, m);
    }

    public static void PrintMatrix(TextWriter writer, string name, IndexedBasisMatrix m)
    {
      if (writer == null)
        return;
      if (name != null)
        writer.WriteLine(name);
      MathUtil.PrintVector3(writer, "Right       ", m.GetColumn(0));
      MathUtil.PrintVector3(writer, "Up          ", m.GetColumn(1));
      MathUtil.PrintVector3(writer, "Backward    ", m.GetColumn(2));
      MathUtil.PrintVector3(writer, "Translation ", IndexedVector3.Zero);
    }

    public static bool IsAlmostZero(Vector3 v)
    {
      return (double) Math.Abs(v.X) <= 1E-06 && (double) Math.Abs(v.Y) <= 1E-06 && (double) Math.Abs(v.Z) <= 1E-06;
    }

    public static bool IsAlmostZero(ref Vector3 v)
    {
      return (double) Math.Abs(v.X) <= 1E-06 && (double) Math.Abs(v.Y) <= 1E-06 && (double) Math.Abs(v.Z) <= 1E-06;
    }

    public static bool IsAlmostZero(IndexedVector3 v)
    {
      return (double) Math.Abs(v.X) <= 1E-06 && (double) Math.Abs(v.Y) <= 1E-06 && (double) Math.Abs(v.Z) <= 1E-06;
    }

    public static bool IsAlmostZero(ref IndexedVector3 v)
    {
      return (double) Math.Abs(v.X) <= 1E-06 && (double) Math.Abs(v.Y) <= 1E-06 && (double) Math.Abs(v.Z) <= 1E-06;
    }

    public static IndexedVector3 Vector3Lerp(ref IndexedVector3 a, ref IndexedVector3 b, float t)
    {
      return new IndexedVector3(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);
    }

    public static float Vector3Distance2XZ(IndexedVector3 x, IndexedVector3 y)
    {
      return (new IndexedVector3(x.X, 0.0f, x.Z) - new IndexedVector3(y.X, 0.0f, y.Z)).LengthSquared();
    }

    public static void PrintMatrix(TextWriter writer, Matrix m)
    {
      MathUtil.PrintMatrix(writer, (string) null, m);
    }

    public static void PrintMatrix(TextWriter writer, string name, Matrix m)
    {
      if (writer == null)
        return;
      if (name != null)
        writer.WriteLine(name);
      MathUtil.PrintVector3(writer, "Right       ", m.Right);
      MathUtil.PrintVector3(writer, "Up          ", m.Up);
      MathUtil.PrintVector3(writer, "Backward    ", m.Backward);
      MathUtil.PrintVector3(writer, "Translation ", m.Translation);
    }

    public static void PrintVector3(TextWriter writer, Vector3 v)
    {
      writer.WriteLine(string.Format("{{X:{0:0.00000000} Y:{1:0.00000000} Z:{2:0.00000000}}}", (object) v.X, (object) v.Y, (object) v.Z));
    }

    public static void PrintVector3(TextWriter writer, string name, Vector3 v)
    {
      writer.WriteLine(string.Format("[{0}] {{X:{1:0.00000000} Y:{2:0.00000000} Z:{3:0.00000000}}}", (object) name, (object) v.X, (object) v.Y, (object) v.Z));
    }

    public static float NextAfter(float x, float y)
    {
      if (float.IsNaN(x) || float.IsNaN(y))
        return x + y;
      if ((double) x == (double) y)
        return y;
      MathUtil.FloatIntUnion floatIntUnion;
      floatIntUnion.i = 0;
      floatIntUnion.f = x;
      if ((double) x == 0.0)
      {
        floatIntUnion.i = 1;
        if ((double) y <= 0.0)
          return -floatIntUnion.f;
        else
          return floatIntUnion.f;
      }
      else
      {
        if ((double) x > 0.0 == (double) y > (double) x)
          ++floatIntUnion.i;
        else
          --floatIntUnion.i;
        return floatIntUnion.f;
      }
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct FloatIntUnion
    {
      [FieldOffset(0)]
      public int i;
      [FieldOffset(0)]
      public float f;
    }
  }
}
