﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.AabbUtil2
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System;

namespace BulletXNA
{
  public static class AabbUtil2
  {
    public static void AabbExpand(ref IndexedVector3 aabbMin, ref IndexedVector3 aabbMax, ref IndexedVector3 expansionMin, ref IndexedVector3 expansionMax)
    {
      aabbMin = aabbMin + expansionMin;
      aabbMax = aabbMax + expansionMax;
    }

    public static bool TestPointAgainstAabb2(ref IndexedVector3 aabbMin1, ref IndexedVector3 aabbMax1, ref IndexedVector3 point)
    {
      bool flag1 = true;
      bool flag2 = (double) aabbMin1.X <= (double) point.X && (double) aabbMax1.X >= (double) point.X && flag1;
      bool flag3 = (double) aabbMin1.Z <= (double) point.Z && (double) aabbMax1.Z >= (double) point.Z && flag2;
      return (double) aabbMin1.Y <= (double) point.Y && (double) aabbMax1.Y >= (double) point.Y && flag3;
    }

    public static bool TestAabbAgainstAabb2(ref IndexedVector3 aabbMin1, ref IndexedVector3 aabbMax1, ref IndexedVector3 aabbMin2, ref IndexedVector3 aabbMax2)
    {
      bool flag1 = true;
      bool flag2 = (double) aabbMin1.X <= (double) aabbMax2.X && (double) aabbMax1.X >= (double) aabbMin2.X && flag1;
      bool flag3 = (double) aabbMin1.Z <= (double) aabbMax2.Z && (double) aabbMax1.Z >= (double) aabbMin2.Z && flag2;
      return (double) aabbMin1.Y <= (double) aabbMax2.Y && (double) aabbMax1.Y >= (double) aabbMin2.Y && flag3;
    }

    public static bool TestTriangleAgainstAabb2(ref IndexedVector3 vertices0, ref IndexedVector3 vertices1, ref IndexedVector3 vertices2, ref IndexedVector3 aabbMin, ref IndexedVector3 aabbMax)
    {
      return (double) Math.Min(Math.Min(vertices0.X, vertices1.X), vertices2.X) <= (double) aabbMax.X && (double) Math.Max(Math.Max(vertices0.X, vertices1.X), vertices2.X) >= (double) aabbMin.X && ((double) Math.Min(Math.Min(vertices0.Z, vertices1.Z), vertices2.Z) <= (double) aabbMax.Z && (double) Math.Max(Math.Max(vertices0.Z, vertices1.Z), vertices2.Z) >= (double) aabbMin.Z) && ((double) Math.Min(Math.Min(vertices0.Y, vertices1.Y), vertices2.Y) <= (double) aabbMax.Y && (double) Math.Max(Math.Max(vertices0.Y, vertices1.Y), vertices2.Y) >= (double) aabbMin.Y);
    }

    public static int Outcode(ref IndexedVector3 p, ref IndexedVector3 halfExtent)
    {
      return ((double) p.X < -(double) halfExtent.X ? 1 : 0) | ((double) p.X > (double) halfExtent.X ? 8 : 0) | ((double) p.Y < -(double) halfExtent.Y ? 2 : 0) | ((double) p.Y > (double) halfExtent.Y ? 16 : 0) | ((double) p.Z < -(double) halfExtent.Z ? 4 : 0) | ((double) p.Z > (double) halfExtent.Z ? 32 : 0);
    }

    public static bool RayAabb2(ref IndexedVector3 rayFrom, ref IndexedVector3 rayInvDirection, bool[] raySign, IndexedVector3[] bounds, out float tmin, float lambda_min, float lambda_max)
    {
      tmin = (bounds[raySign[0] ? 1 : 0].X - rayFrom.X) * rayInvDirection.X;
      float num1 = (bounds[1 - (raySign[0] ? 1 : 0)].X - rayFrom.X) * rayInvDirection.X;
      float num2 = (bounds[raySign[1] ? 1 : 0].Y - rayFrom.Y) * rayInvDirection.Y;
      float num3 = (bounds[1 - (raySign[1] ? 1 : 0)].Y - rayFrom.Y) * rayInvDirection.Y;
      if ((double) tmin > (double) num3 || (double) num2 > (double) num1)
        return false;
      if ((double) num2 > (double) tmin)
        tmin = num2;
      if ((double) num3 < (double) num1)
        num1 = num3;
      float num4 = (bounds[raySign[2] ? 1 : 0].Z - rayFrom.Z) * rayInvDirection.Z;
      float num5 = (bounds[1 - (raySign[2] ? 1 : 0)].Z - rayFrom.Z) * rayInvDirection.Z;
      if ((double) tmin > (double) num5 || (double) num4 > (double) num1)
        return false;
      if ((double) num4 > (double) tmin)
        tmin = num4;
      if ((double) num5 < (double) num1)
        num1 = num5;
      if ((double) tmin < (double) lambda_max)
        return (double) num1 > (double) lambda_min;
      else
        return false;
    }

    public static bool RayAabb(IndexedVector3 rayFrom, IndexedVector3 rayTo, ref IndexedVector3 aabbMin, ref IndexedVector3 aabbMax, ref float param, out IndexedVector3 normal)
    {
      return AabbUtil2.RayAabb(ref rayFrom, ref rayTo, ref aabbMin, ref aabbMax, ref param, out normal);
    }

    public static bool RayAabb(ref IndexedVector3 rayFrom, ref IndexedVector3 rayTo, ref IndexedVector3 aabbMin, ref IndexedVector3 aabbMax, ref float param, out IndexedVector3 normal)
    {
      IndexedVector3 halfExtent = (aabbMax - aabbMin) * 0.5f;
      IndexedVector3 indexedVector3_1 = (aabbMax + aabbMin) * 0.5f;
      IndexedVector3 p1 = rayFrom - indexedVector3_1;
      IndexedVector3 p2 = rayTo - indexedVector3_1;
      int num1 = AabbUtil2.Outcode(ref p1, ref halfExtent);
      int num2 = AabbUtil2.Outcode(ref p2, ref halfExtent);
      if ((num1 & num2) == 0)
      {
        float num3 = 0.0f;
        float val1 = param;
        IndexedVector3 indexedVector3_2 = p2 - p1;
        float num4 = 1f;
        IndexedVector3 zero = IndexedVector3.Zero;
        int num5 = 1;
        for (int index1 = 0; index1 < 2; ++index1)
        {
          for (int index2 = 0; index2 != 3; ++index2)
          {
            if ((num1 & num5) != 0)
            {
              float num6 = (float) (-(double) p1[index2] - (double) halfExtent[index2] * (double) num4) / indexedVector3_2[index2];
              if ((double) num3 <= (double) num6)
              {
                num3 = num6;
                zero = IndexedVector3.Zero;
                zero[index2] = num4;
              }
            }
            else if ((num2 & num5) != 0)
            {
              float val2 = (float) (-(double) p1[index2] - (double) halfExtent[index2] * (double) num4) / indexedVector3_2[index2];
              val1 = Math.Min(val1, val2);
            }
            num5 <<= 1;
          }
          num4 = -1f;
        }
        if ((double) num3 <= (double) val1)
        {
          param = num3;
          normal = zero;
          return true;
        }
      }
      param = 0.0f;
      normal = IndexedVector3.Zero;
      return false;
    }

    public static bool TestQuantizedAabbAgainstQuantizedAabb(ref UShortVector3 aabbMin1, ref UShortVector3 aabbMax1, ref UShortVector3 aabbMin2, ref UShortVector3 aabbMax2)
    {
      bool flag1 = true;
      bool flag2 = (int) aabbMin1.X <= (int) aabbMax2.X && (int) aabbMax1.X >= (int) aabbMin2.X && flag1;
      bool flag3 = (int) aabbMin1.Z <= (int) aabbMax2.Z && (int) aabbMax1.Z >= (int) aabbMin2.Z && flag2;
      return (int) aabbMin1.Y <= (int) aabbMax2.Y && (int) aabbMax1.Y >= (int) aabbMin2.Y && flag3;
    }

    public static void TransformAabb(IndexedVector3 halfExtents, float margin, ref IndexedMatrix t, out IndexedVector3 aabbMinOut, out IndexedVector3 aabbMaxOut)
    {
      AabbUtil2.TransformAabb(ref halfExtents, margin, ref t, out aabbMinOut, out aabbMaxOut);
    }

    public static void TransformAabb(ref IndexedVector3 halfExtents, float margin, ref IndexedMatrix t, out IndexedVector3 aabbMinOut, out IndexedVector3 aabbMaxOut)
    {
      IndexedVector3 v = halfExtents + new IndexedVector3(margin);
      IndexedBasisMatrix indexedBasisMatrix = t._basis.Absolute();
      IndexedVector3 indexedVector3_1 = t._origin;
      IndexedVector3 indexedVector3_2 = new IndexedVector3(indexedBasisMatrix[0].Dot(ref v), indexedBasisMatrix[1].Dot(ref v), indexedBasisMatrix[2].Dot(ref v));
      aabbMinOut = indexedVector3_1 - indexedVector3_2;
      aabbMaxOut = indexedVector3_1 + indexedVector3_2;
    }

    public static void TransformAabb(IndexedVector3 localAabbMin, IndexedVector3 localAabbMax, float margin, ref IndexedMatrix trans, out IndexedVector3 aabbMinOut, out IndexedVector3 aabbMaxOut)
    {
      IndexedVector3 v = -0.5f * (localAabbMax - localAabbMin) + new IndexedVector3(margin);
      IndexedVector3 indexedVector3_1 = 0.5f * (localAabbMax + localAabbMin);
      IndexedBasisMatrix indexedBasisMatrix = trans._basis.Absolute();
      IndexedVector3 indexedVector3_2 = trans * indexedVector3_1;
      IndexedVector3 indexedVector3_3 = new IndexedVector3(indexedBasisMatrix[0].Dot(ref v), indexedBasisMatrix[1].Dot(ref v), indexedBasisMatrix[2].Dot(ref v));
      aabbMinOut = indexedVector3_2 - indexedVector3_3;
      aabbMaxOut = indexedVector3_2 + indexedVector3_3;
    }

    public static void TransformAabb(ref IndexedVector3 localAabbMin, ref IndexedVector3 localAabbMax, float margin, ref IndexedMatrix trans, out IndexedVector3 aabbMinOut, out IndexedVector3 aabbMaxOut)
    {
      IndexedVector3 v = 0.5f * (localAabbMax - localAabbMin) + new IndexedVector3(margin);
      IndexedVector3 indexedVector3_1 = 0.5f * (localAabbMax + localAabbMin);
      IndexedBasisMatrix indexedBasisMatrix = trans._basis.Absolute();
      IndexedVector3 indexedVector3_2 = trans * indexedVector3_1;
      IndexedVector3 indexedVector3_3 = new IndexedVector3(indexedBasisMatrix[0].Dot(ref v), indexedBasisMatrix[1].Dot(ref v), indexedBasisMatrix[2].Dot(ref v));
      aabbMinOut = indexedVector3_2 - indexedVector3_3;
      aabbMaxOut = indexedVector3_2 + indexedVector3_3;
    }
  }
}
