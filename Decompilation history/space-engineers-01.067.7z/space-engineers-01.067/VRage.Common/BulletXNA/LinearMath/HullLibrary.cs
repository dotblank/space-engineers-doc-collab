﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.HullLibrary
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA;
using System;
using System.Collections.Generic;
using VRageMath;

namespace BulletXNA.LinearMath
{
  public class HullLibrary
  {
    public IList<HullTriangle> m_tris = (IList<HullTriangle>) new List<HullTriangle>();
    public IList<int> m_vertexIndexMapping = (IList<int>) new List<int>();
    public const float PAPERWIDTH = 0.001f;
    public const float planetestepsilon = 0.001f;
    public const float EPSILON = 1E-06f;

    public static int MaxDirFiltered(IList<IndexedVector3> p, int count, ref IndexedVector3 dir, IList<int> allow)
    {
      int index1 = -1;
      for (int index2 = 0; index2 < count; ++index2)
      {
        if (allow[index2] != 0 && (index1 == -1 || (double) IndexedVector3.Dot(p[index2], dir) > (double) IndexedVector3.Dot(p[index1], dir)))
          index1 = index2;
      }
      return index1;
    }

    public static IndexedVector3 Orth(ref IndexedVector3 v)
    {
      IndexedVector3 v1 = IndexedVector3.Cross(v, new IndexedVector3(0.0f, 0.0f, 1f));
      IndexedVector3 v2 = IndexedVector3.Cross(v, new IndexedVector3(0.0f, 1f, 0.0f));
      if ((double) v1.Length() > (double) v2.Length())
        return IndexedVector3.Normalize(v1);
      else
        return IndexedVector3.Normalize(v2);
    }

    public static int MaxDirSterId(IList<IndexedVector3> p, int count, IndexedVector3 dir, IList<int> allow)
    {
      return HullLibrary.MaxDirSterId(p, count, ref dir, allow);
    }

    public static int MaxDirSterId(IList<IndexedVector3> p, int count, ref IndexedVector3 dir, IList<int> allow)
    {
      int num1;
      for (num1 = -1; num1 == -1; num1 = -1)
      {
        int index = HullLibrary.MaxDirFiltered(p, count, ref dir, allow);
        if (allow[index] == 3)
          return index;
        IndexedVector3 v = HullLibrary.Orth(ref dir);
        IndexedVector3 indexedVector3 = IndexedVector3.Cross(v, dir);
        int num2 = -1;
        float num3 = 0.0f;
        while ((double) num3 <= 360.0)
        {
          float num4 = (float) Math.Sin(Math.PI / 180.0 * (double) num3);
          float num5 = (float) Math.Cos(Math.PI / 180.0 * (double) num3);
          IndexedVector3 dir1 = dir + (v * num4 + indexedVector3 * num5) * 0.025f;
          int num6 = HullLibrary.MaxDirFiltered(p, count, ref dir1, allow);
          if (num2 == index && num6 == index)
          {
            allow[index] = 3;
            return index;
          }
          else
          {
            if (num2 != -1 && num2 != num6)
            {
              int num7 = num2;
              float num8 = num3 - 40f;
              while ((double) num8 <= (double) num3)
              {
                float num9 = (float) Math.Sin(Math.PI / 180.0 * (double) num8);
                float num10 = (float) Math.Cos(Math.PI / 180.0 * (double) num8);
                IndexedVector3 dir2 = dir + (v * num9 + indexedVector3 * num10) * 0.025f;
                int num11 = HullLibrary.MaxDirFiltered(p, count, ref dir2, allow);
                if (num7 == index && num11 == index)
                {
                  allow[index] = 3;
                  return index;
                }
                else
                {
                  num7 = num11;
                  num8 += 5f;
                }
              }
            }
            num2 = num6;
            num3 += 45f;
          }
        }
        allow[index] = 0;
      }
      return num1;
    }

    public bool Above(IList<IndexedVector3> vertices, int3 t, IndexedVector3 p, float epsilon)
    {
      return this.Above(vertices, t, ref p, epsilon);
    }

    public bool Above(IList<IndexedVector3> vertices, int3 t, ref IndexedVector3 p, float epsilon)
    {
      return (double) IndexedVector3.Dot(HullLibrary.TriNormal(vertices[t.At(0)], vertices[t.At(1)], vertices[t.At(2)]), p - vertices[t.At(0)]) > (double) epsilon;
    }

    public bool HasEdge(int3 t, int a, int b)
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        if (t.At(index1) == a && t.At(index2) == b)
          return true;
      }
      return false;
    }

    public bool HasVert(int3 t, int v)
    {
      if (t.At(0) != v && t.At(1) != v)
        return t.At(2) == v;
      else
        return true;
    }

    public int ShareEdge(int3 a, int3 b)
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        if (this.HasEdge(a, b.At(index2), b.At(index1)))
          return 1;
      }
      return 0;
    }

    public void B2bFix(HullTriangle s, HullTriangle t)
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        int index3 = (index1 + 2) % 3;
        int num1 = s.At(index2);
        int num2 = s.At(index3);
        this.m_tris[s.Neib(num1, num2)].Neib(num2, num1, t.Neib(num2, num1));
        this.m_tris[t.Neib(num2, num1)].Neib(num1, num2, s.Neib(num1, num2));
      }
    }

    private void RemoveB2b(HullTriangle s, HullTriangle t)
    {
      this.B2bFix(s, t);
      this.DeAllocateTriangle(s);
      this.DeAllocateTriangle(t);
    }

    private void CheckIt(HullTriangle t)
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        int index3 = (index1 + 2) % 3;
        t.At(index2);
        t.At(index3);
      }
    }

    public HullTriangle AllocateTriangle(int a, int b, int c)
    {
      HullTriangle hullTriangle = new HullTriangle(a, b, c);
      hullTriangle.id = this.m_tris.Count;
      this.m_tris.Add(hullTriangle);
      return hullTriangle;
    }

    public void DeAllocateTriangle(HullTriangle tri)
    {
      this.m_tris[tri.id] = (HullTriangle) null;
    }

    public void Extrude(HullTriangle t0, int v)
    {
      int3 int3 = (int3) t0;
      int count = this.m_tris.Count;
      HullTriangle hullTriangle1 = this.AllocateTriangle(v, int3.At(1), int3.At(2));
      hullTriangle1.n = new int3(t0.n.At(0), count + 1, count + 2);
      this.m_tris[t0.n.At(0)].Neib(int3.At(1), int3.At(2), count);
      HullTriangle hullTriangle2 = this.AllocateTriangle(v, int3.At(2), int3.At(0));
      hullTriangle2.n = new int3(t0.n.At(1), count + 2, count);
      this.m_tris[t0.n.At(1)].Neib(int3.At(2), int3.At(0), count + 1);
      HullTriangle hullTriangle3 = this.AllocateTriangle(v, int3.At(0), int3.At(1));
      hullTriangle3.n = new int3(t0.n.At(2), count, count + 1);
      this.m_tris[t0.n.At(2)].Neib(int3.At(0), int3.At(1), count + 2);
      this.CheckIt(hullTriangle1);
      this.CheckIt(hullTriangle2);
      this.CheckIt(hullTriangle3);
      if (this.HasVert((int3) this.m_tris[hullTriangle1.n.At(0)], v))
        this.RemoveB2b(hullTriangle1, this.m_tris[hullTriangle1.n.At(0)]);
      if (this.HasVert((int3) this.m_tris[hullTriangle2.n.At(0)], v))
        this.RemoveB2b(hullTriangle2, this.m_tris[hullTriangle2.n.At(0)]);
      if (this.HasVert((int3) this.m_tris[hullTriangle3.n.At(0)], v))
        this.RemoveB2b(hullTriangle3, this.m_tris[hullTriangle3.n.At(0)]);
      this.DeAllocateTriangle(t0);
    }

    public HullTriangle Extrudable(float epsilon)
    {
      HullTriangle hullTriangle = (HullTriangle) null;
      for (int index = 0; index < this.m_tris.Count; ++index)
      {
        if (hullTriangle == null || this.m_tris[index] != null && (double) hullTriangle.rise < (double) this.m_tris[index].rise)
          hullTriangle = this.m_tris[index];
      }
      if ((double) hullTriangle.rise <= (double) epsilon)
        return (HullTriangle) null;
      else
        return hullTriangle;
    }

    public int4 FindSimplex(IList<IndexedVector3> verts, int verts_count, IList<int> allow)
    {
      IndexedVector3[] indexedVector3Array = new IndexedVector3[3];
      indexedVector3Array[0] = new IndexedVector3(0.01f, 0.02f, 1f);
      int _x = HullLibrary.MaxDirSterId(verts, verts_count, indexedVector3Array[0], allow);
      int _y = HullLibrary.MaxDirSterId(verts, verts_count, -indexedVector3Array[0], allow);
      indexedVector3Array[0] = verts[_x] - verts[_y];
      if (_x == _y || indexedVector3Array[0] == IndexedVector3.Zero)
        return new int4(-1, -1, -1, -1);
      indexedVector3Array[1] = IndexedVector3.Cross(new IndexedVector3(1f, 0.02f, 0.0f), indexedVector3Array[0]);
      indexedVector3Array[2] = IndexedVector3.Cross(new IndexedVector3(-0.02f, 1f, 0.0f), indexedVector3Array[0]);
      if ((double) indexedVector3Array[1].Length() > (double) indexedVector3Array[2].Length())
      {
        indexedVector3Array[1].Normalize();
      }
      else
      {
        indexedVector3Array[1] = indexedVector3Array[2];
        indexedVector3Array[1].Normalize();
      }
      int _z = HullLibrary.MaxDirSterId(verts, verts_count, indexedVector3Array[1], allow);
      if (_z == _x || _z == _y)
        _z = HullLibrary.MaxDirSterId(verts, verts_count, -indexedVector3Array[1], allow);
      if (_z == _x || _z == _y)
        return new int4(-1, -1, -1, -1);
      indexedVector3Array[1] = verts[_z] - verts[_x];
      indexedVector3Array[2] = IndexedVector3.Normalize(IndexedVector3.Cross(indexedVector3Array[1], indexedVector3Array[0]));
      int _w = HullLibrary.MaxDirSterId(verts, verts_count, indexedVector3Array[2], allow);
      if (_w == _x || _w == _y || _w == _z)
        _w = HullLibrary.MaxDirSterId(verts, verts_count, -indexedVector3Array[2], allow);
      if (_w == _x || _w == _y || _w == _z)
        return new int4(-1, -1, -1, -1);
      if ((double) IndexedVector3.Dot(verts[_w] - verts[_x], IndexedVector3.Cross(verts[_y] - verts[_x], verts[_z] - verts[_x])) < 0.0)
      {
        int num = _z;
        _z = _w;
        _w = num;
      }
      return new int4(_x, _y, _z, _w);
    }

    public int CalcHullGen(IList<IndexedVector3> verts, int verts_count, int vlimit)
    {
      if (verts_count < 4)
        return 0;
      if (vlimit == 0)
        vlimit = 1000000000;
      IndexedVector3 output1 = MathUtil.MAX_VECTOR;
      IndexedVector3 output2 = MathUtil.MIN_VECTOR;
      IList<int> list = (IList<int>) new List<int>(verts_count);
      IList<int> allow = (IList<int>) new List<int>(verts_count);
      for (int index = 0; index < verts_count; ++index)
      {
        allow.Add(1);
        list.Add(0);
        MathUtil.VectorMin(verts[index], ref output1);
        MathUtil.VectorMax(verts[index], ref output2);
      }
      float epsilon = (output2 - output1).Length() * (1.0 / 1000.0);
      int4 simplex = this.FindSimplex(verts, verts_count, allow);
      if (simplex.x == -1)
        return 0;
      IndexedVector3 p = (verts[simplex.At(0)] + verts[simplex.At(1)] + verts[simplex.At(2)] + verts[simplex.At(3)]) / 4f;
      HullTriangle t1 = this.AllocateTriangle(simplex.At(2), simplex.At(3), simplex.At(1));
      t1.n = new int3(2, 3, 1);
      HullTriangle t2 = this.AllocateTriangle(simplex.At(3), simplex.At(2), simplex.At(0));
      t2.n = new int3(3, 2, 0);
      HullTriangle t3 = this.AllocateTriangle(simplex.At(0), simplex.At(1), simplex.At(3));
      t3.n = new int3(0, 1, 3);
      HullTriangle t4 = this.AllocateTriangle(simplex.At(1), simplex.At(0), simplex.At(2));
      t4.n = new int3(1, 0, 2);
      list[simplex.At(0)] = list[simplex.At(1)] = list[simplex.At(2)] = list[simplex.At(3)] = 1;
      this.CheckIt(t1);
      this.CheckIt(t2);
      this.CheckIt(t3);
      this.CheckIt(t4);
      for (int index = 0; index < this.m_tris.Count; ++index)
      {
        HullTriangle hullTriangle = this.m_tris[index];
        IndexedVector3 indexedVector3 = HullLibrary.TriNormal(verts[hullTriangle.At(0)], verts[hullTriangle.At(1)], verts[hullTriangle.At(2)]);
        hullTriangle.vmax = HullLibrary.MaxDirSterId(verts, verts_count, indexedVector3, allow);
        hullTriangle.rise = IndexedVector3.Dot(indexedVector3, verts[hullTriangle.vmax] - verts[hullTriangle.At(0)]);
      }
      vlimit -= 4;
      HullTriangle hullTriangle1;
      for (; vlimit > 0 && (hullTriangle1 = this.Extrudable(epsilon)) != null; --vlimit)
      {
        int v = hullTriangle1.vmax;
        list[v] = 1;
        int count1 = this.m_tris.Count;
        while (count1-- > 0)
        {
          if (this.m_tris[count1] != null)
          {
            int3 t5 = (int3) this.m_tris[count1];
            if (this.Above(verts, t5, verts[v], 0.01f * epsilon))
              this.Extrude(this.m_tris[count1], v);
          }
        }
        int count2 = this.m_tris.Count;
        while (count2-- > 0)
        {
          if (this.m_tris[count2] != null)
          {
            if (this.HasVert((int3) this.m_tris[count2], v))
            {
              int3 t5 = (int3) this.m_tris[count2];
              if (this.Above(verts, t5, p, 0.01f * epsilon) || (double) IndexedVector3.Cross(verts[t5.At(1)] - verts[t5.At(0)], verts[t5.At(2)] - verts[t5.At(1)]).Length() < (double) epsilon * (double) epsilon * 0.100000001490116)
              {
                this.Extrude(this.m_tris[this.m_tris[count2].n.At(0)], v);
                count2 = this.m_tris.Count;
              }
            }
            else
              break;
          }
        }
        int count3 = this.m_tris.Count;
        while (count3-- != 0)
        {
          HullTriangle hullTriangle2 = this.m_tris[count3];
          if (hullTriangle2 != null)
          {
            if (hullTriangle2.vmax < 0)
            {
              IndexedVector3 indexedVector3 = HullLibrary.TriNormal(verts[hullTriangle2.At(0)], verts[hullTriangle2.At(1)], verts[hullTriangle2.At(2)]);
              hullTriangle2.vmax = HullLibrary.MaxDirSterId(verts, verts_count, indexedVector3, allow);
              if (list[hullTriangle2.vmax] != 0)
                hullTriangle2.vmax = -1;
              else
                hullTriangle2.rise = IndexedVector3.Dot(indexedVector3, verts[hullTriangle2.vmax] - verts[hullTriangle2.At(0)]);
            }
            else
              break;
          }
        }
      }
      return 1;
    }

    public int CalcHull(IList<IndexedVector3> verts, int verts_count, IList<int> tris_out, ref int tris_count, int vlimit)
    {
      if (this.CalcHullGen(verts, verts_count, vlimit) == 0)
        return 0;
      IList<int> list = (IList<int>) new List<int>();
      for (int index1 = 0; index1 < this.m_tris.Count; ++index1)
      {
        if (this.m_tris[index1] != null)
        {
          for (int index2 = 0; index2 < 3; ++index2)
            list.Add(this.m_tris[index1].At(index2));
          this.DeAllocateTriangle(this.m_tris[index1]);
        }
      }
      tris_count = list.Count / 3;
      tris_out.Clear();
      for (int index = 0; index < list.Count; ++index)
        tris_out.Add(list[index]);
      this.m_tris.Clear();
      return 1;
    }

    public bool ComputeHull(int vcount, IList<IndexedVector3> vertices, PHullResult result, int vlimit)
    {
      int tris_count = 0;
      if (this.CalcHull(vertices, vcount, result.m_Indices, ref tris_count, vlimit) == 0)
        return false;
      result.mIndexCount = tris_count * 3;
      result.mFaceCount = tris_count;
      result.mVertices = vertices;
      result.mVcount = vcount;
      return true;
    }

    public void ReleaseHull(PHullResult result)
    {
      if (result.m_Indices.Count != 0)
        result.m_Indices.Clear();
      result.mVcount = 0;
      result.mIndexCount = 0;
      result.mVertices.Clear();
    }

    public HullError CreateConvexHull(HullDesc desc, HullResult result)
    {
      HullError hullError = HullError.QE_FAIL;
      PHullResult result1 = new PHullResult();
      int capacity = desc.mVcount;
      if (capacity < 8)
        capacity = 8;
      IList<IndexedVector3> vertices = (IList<IndexedVector3>) new List<IndexedVector3>(capacity);
      for (int index = 0; index < capacity; ++index)
        vertices.Add(IndexedVector3.Zero);
      IndexedVector3 scale = new IndexedVector3(1f);
      int vcount = 0;
      if (this.CleanupVertices(desc.mVcount, desc.mVertices, desc.mVertexStride, ref vcount, vertices, desc.mNormalEpsilon, ref scale))
      {
        for (int index = 0; index < vcount; ++index)
        {
          IndexedVector3 indexedVector3 = vertices[index];
          indexedVector3.X *= scale.X;
          indexedVector3.Y *= scale.Y;
          indexedVector3.Z *= scale.Z;
          vertices[index] = indexedVector3;
        }
        if (this.ComputeHull(vcount, vertices, result1, desc.mMaxVertices))
        {
          IList<IndexedVector3> overts = (IList<IndexedVector3>) new ObjectArray<IndexedVector3>(result1.mVcount);
          this.BringOutYourDead(result1.mVertices, result1.mVcount, overts, ref vcount, result1.m_Indices, result1.mIndexCount);
          hullError = HullError.QE_OK;
          if (desc.HasHullFlag(HullFlag.QF_TRIANGLES))
          {
            result.mPolygons = false;
            result.mNumOutputVertices = vcount;
            result.m_OutputVertices.Clear();
            result.mNumFaces = result1.mFaceCount;
            result.mNumIndices = result1.mIndexCount;
            result.m_Indices.Clear();
            for (int index = 0; index < vcount; ++index)
              result.m_OutputVertices.Add(overts[index]);
            if (desc.HasHullFlag(HullFlag.QF_REVERSE_ORDER))
            {
              IList<int> list1 = result1.m_Indices;
              IList<int> list2 = result.m_Indices;
              for (int index1 = 0; index1 < result1.mFaceCount; ++index1)
              {
                int index2 = index1 * 3;
                list2.Add(list1[index2 + 2]);
                list2.Add(list1[index2 + 1]);
                list2.Add(list1[index2]);
              }
            }
            else
            {
              for (int index = 0; index < result1.mIndexCount; ++index)
                result.m_Indices.Add(result1.m_Indices[index]);
            }
          }
          else
          {
            result.mPolygons = true;
            result.mNumOutputVertices = vcount;
            result.m_OutputVertices.Clear();
            result.mNumFaces = result1.mFaceCount;
            result.mNumIndices = result1.mIndexCount + result1.mFaceCount;
            result.m_Indices.Clear();
            for (int index = 0; index < vcount; ++index)
              result.m_OutputVertices.Add(overts[index]);
            IList<int> list1 = result1.m_Indices;
            IList<int> list2 = result.m_Indices;
            for (int index1 = 0; index1 < result1.mFaceCount; ++index1)
            {
              int index2 = index1 * 3;
              list2[0] = 3;
              if (desc.HasHullFlag(HullFlag.QF_REVERSE_ORDER))
              {
                list2.Add(list1[index2 + 2]);
                list2.Add(list1[index2 + 1]);
                list2.Add(list1[index2]);
              }
              else
              {
                list2.Add(list1[index2]);
                list2.Add(list1[index2 + 1]);
                list2.Add(list1[index2 + 2]);
              }
            }
          }
          this.ReleaseHull(result1);
        }
      }
      return hullError;
    }

    public HullError ReleaseResult(HullResult result)
    {
      if (result.m_OutputVertices.Count != 0)
      {
        result.mNumOutputVertices = 0;
        result.m_OutputVertices.Clear();
      }
      if (result.m_Indices.Count != 0)
      {
        result.mNumIndices = 0;
        result.m_Indices.Clear();
      }
      return HullError.QE_OK;
    }

    public static void AddPoint(ref int vcount, IList<IndexedVector3> p, float x, float y, float z)
    {
      IndexedVector3 indexedVector3 = p[vcount];
      ++vcount;
    }

    public float GetDist(float px, float py, float pz, ref IndexedVector3 p2)
    {
      float num1 = px - p2.X;
      float num2 = py - p2.Y;
      float num3 = pz - p2.Z;
      return (float) ((double) num1 * (double) num1 + (double) num2 * (double) num2 + (double) num3 * (double) num3);
    }

    public bool CleanupVertices(int svcount, IList<IndexedVector3> svertices, int stride, ref int vcount, IList<IndexedVector3> vertices, float normalepsilon, ref IndexedVector3 scale)
    {
      if (svcount == 0)
        return false;
      this.m_vertexIndexMapping.Clear();
      vcount = 0;
      IndexedVector3 indexedVector3_1 = new IndexedVector3();
      scale = new IndexedVector3(1f);
      IndexedVector3 output1 = MathUtil.MAX_VECTOR;
      IndexedVector3 output2 = MathUtil.MIN_VECTOR;
      for (int index = 0; index < svcount; ++index)
      {
        IndexedVector3 input = svertices[index];
        MathUtil.VectorMin(ref input, ref output1);
        MathUtil.VectorMax(ref input, ref output2);
        svertices[index] = input;
      }
      IndexedVector3 indexedVector3_2 = output2 - output1;
      IndexedVector3 indexedVector3_3 = indexedVector3_2 * 0.5f + output1;
      if ((double) indexedVector3_2.X < 9.99999997475243E-07 || (double) indexedVector3_2.Y < 9.99999997475243E-07 || ((double) indexedVector3_2.Z < 9.99999997475243E-07 || svcount < 3))
      {
        float num = float.MaxValue;
        if ((double) indexedVector3_2.X > 9.99999997475243E-07 && (double) indexedVector3_2.X < (double) num)
          num = indexedVector3_2.X;
        if ((double) indexedVector3_2.Y > 9.99999997475243E-07 && (double) indexedVector3_2.Y < (double) num)
          num = indexedVector3_2.Y;
        if ((double) indexedVector3_2.Z > 9.99999997475243E-07 && (double) indexedVector3_2.Z < (double) num)
          num = indexedVector3_2.Z;
        if ((double) num == 3.40282346638529E+38)
        {
          indexedVector3_2 = new IndexedVector3(0.01f);
        }
        else
        {
          if ((double) indexedVector3_2.X < 9.99999997475243E-07)
            indexedVector3_2.X = num * 0.05f;
          if ((double) indexedVector3_2.Y < 9.99999997475243E-07)
            indexedVector3_2.Y = num * 0.05f;
          if ((double) indexedVector3_2.Z < 9.99999997475243E-07)
            indexedVector3_2.Z = num * 0.05f;
        }
        float x1 = indexedVector3_3.X - indexedVector3_2.X;
        float x2 = indexedVector3_3.X + indexedVector3_2.X;
        float y1 = indexedVector3_3.Y - indexedVector3_2.Y;
        float y2 = indexedVector3_3.Y + indexedVector3_2.Y;
        float z1 = indexedVector3_3.Z - indexedVector3_2.Z;
        float z2 = indexedVector3_3.Z + indexedVector3_2.Z;
        HullLibrary.AddPoint(ref vcount, vertices, x1, y1, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y1, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y2, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y2, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y1, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y1, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y2, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y2, z2);
        return true;
      }
      else
      {
        if ((double) scale.LengthSquared() > 0.0)
        {
          scale = indexedVector3_2;
          indexedVector3_1.X = 1f / indexedVector3_2.X;
          indexedVector3_1.Y = 1f / indexedVector3_2.Y;
          indexedVector3_1.Z = 1f / indexedVector3_2.Z;
          indexedVector3_3 *= indexedVector3_1;
        }
        for (int index1 = 0; index1 < svcount; ++index1)
        {
          IndexedVector3 indexedVector3_4 = svertices[index1];
          if ((double) scale.LengthSquared() > 0.0)
          {
            indexedVector3_4.X *= indexedVector3_1.X;
            indexedVector3_4.Y *= indexedVector3_1.Y;
            indexedVector3_4.Z *= indexedVector3_1.Z;
          }
          int index2;
          for (index2 = 0; index2 < vcount; ++index2)
          {
            IndexedVector3 indexedVector3_5 = vertices[index2];
            IndexedVector3 indexedVector3_6 = (indexedVector3_5 - indexedVector3_4).Absolute();
            if ((double) indexedVector3_6.X < (double) normalepsilon && (double) indexedVector3_6.Y < (double) normalepsilon && (double) indexedVector3_6.Z < (double) normalepsilon)
            {
              if ((double) (indexedVector3_4 - indexedVector3_3).LengthSquared() > (double) (indexedVector3_5 - indexedVector3_3).LengthSquared())
              {
                vertices[index2] = indexedVector3_4;
                break;
              }
              else
                break;
            }
          }
          if (index2 == vcount)
          {
            vertices[vcount] = indexedVector3_4;
            ++vcount;
          }
          this.m_vertexIndexMapping.Add(index2);
        }
        float[] numArray1 = new float[3]
        {
          float.MaxValue,
          float.MaxValue,
          float.MaxValue
        };
        float[] numArray2 = new float[3]
        {
          float.MinValue,
          float.MinValue,
          float.MinValue
        };
        for (int index = 0; index < vcount; ++index)
        {
          IndexedVector3 indexedVector3_4 = vertices[index];
          if ((double) indexedVector3_4.X < (double) numArray1[0])
            numArray1[0] = indexedVector3_4.X;
          if ((double) indexedVector3_4.X > (double) numArray2[0])
            numArray2[0] = indexedVector3_4.X;
          if ((double) indexedVector3_4.Y < (double) numArray1[1])
            numArray1[1] = indexedVector3_4.Y;
          if ((double) indexedVector3_4.Y > (double) numArray2[1])
            numArray2[1] = indexedVector3_4.Y;
          if ((double) indexedVector3_4.Z < (double) numArray1[2])
            numArray1[2] = indexedVector3_4.Z;
          if ((double) indexedVector3_4.Z > (double) numArray2[2])
            numArray2[2] = indexedVector3_4.Z;
        }
        float num1 = numArray2[0] - numArray1[0];
        float num2 = numArray2[1] - numArray1[1];
        float num3 = numArray2[2] - numArray1[2];
        if ((double) num1 >= 9.99999997475243E-07 && (double) num2 >= 9.99999997475243E-07 && ((double) num3 >= 9.99999997475243E-07 && vcount >= 3))
          return true;
        float num4 = num1 * 0.5f + numArray1[0];
        float num5 = num2 * 0.5f + numArray1[1];
        float num6 = num3 * 0.5f + numArray1[2];
        float num7 = float.MaxValue;
        if ((double) num1 >= 9.99999997475243E-07 && (double) num1 < (double) num7)
          num7 = num1;
        if ((double) num2 >= 9.99999997475243E-07 && (double) num2 < (double) num7)
          num7 = num2;
        if ((double) num3 >= 9.99999997475243E-07 && (double) num3 < (double) num7)
          num7 = num3;
        if ((double) num7 == 3.40282346638529E+38)
        {
          double num8;
          num3 = (float) (num8 = 0.00999999977648258);
          num2 = (float) num8;
          num1 = (float) num8;
        }
        else
        {
          if ((double) num1 < 9.99999997475243E-07)
            num1 = num7 * 0.05f;
          if ((double) num2 < 9.99999997475243E-07)
            num2 = num7 * 0.05f;
          if ((double) num3 < 9.99999997475243E-07)
            num3 = num7 * 0.05f;
        }
        float x1 = num4 - num1;
        float x2 = num4 + num1;
        float y1 = num5 - num2;
        float y2 = num5 + num2;
        float z1 = num6 - num3;
        float z2 = num6 + num3;
        vcount = 0;
        HullLibrary.AddPoint(ref vcount, vertices, x1, y1, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y1, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y2, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y2, z1);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y1, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y1, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x2, y2, z2);
        HullLibrary.AddPoint(ref vcount, vertices, x1, y2, z2);
        return true;
      }
    }

    public void BringOutYourDead(IList<IndexedVector3> verts, int vcount, IList<IndexedVector3> overts, ref int ocount, IList<int> indices, int indexcount)
    {
      IList<int> list1 = (IList<int>) new ObjectArray<int>(this.m_vertexIndexMapping.Count);
      for (int index = 0; index < this.m_vertexIndexMapping.Count; ++index)
        list1[index] = this.m_vertexIndexMapping[index];
      IList<int> list2 = (IList<int>) new ObjectArray<int>(vcount);
      ocount = 0;
      for (int index1 = 0; index1 < indexcount; ++index1)
      {
        int index2 = indices[index1];
        if (list2[index2] != 0)
        {
          indices[index1] = list2[index2] - 1;
        }
        else
        {
          indices[index1] = ocount;
          overts[ocount] = verts[index2];
          for (int index3 = 0; index3 < this.m_vertexIndexMapping.Count; ++index3)
          {
            if (list1[index3] == index2)
              this.m_vertexIndexMapping[index3] = ocount;
          }
          ++ocount;
          list2[index2] = ocount;
        }
      }
    }

    public static IndexedVector3 ThreePlaneIntersection(Plane p0, Plane p1, Plane p2)
    {
      IndexedVector3 indexedVector3_1 = new IndexedVector3(p0.Normal);
      IndexedVector3 indexedVector3_2 = new IndexedVector3(p1.Normal);
      IndexedVector3 indexedVector3_3 = new IndexedVector3(p2.Normal);
      IndexedVector3 b = IndexedVector3.Cross(indexedVector3_2, indexedVector3_3);
      IndexedVector3 indexedVector3_4 = IndexedVector3.Cross(indexedVector3_3, indexedVector3_1);
      IndexedVector3 indexedVector3_5 = IndexedVector3.Cross(indexedVector3_1, indexedVector3_2);
      float num = -1f / IndexedVector3.Dot(indexedVector3_1, b);
      return (b * p0.D + indexedVector3_4 * p1.D + indexedVector3_5 * p2.D) * num;
    }

    public static IndexedVector3 PlaneLineIntersection(ref Plane plane, ref IndexedVector3 p0, ref IndexedVector3 p1)
    {
      IndexedVector3 b = p1 - p0;
      float num1 = IndexedVector3.Dot(plane.Normal, b);
      float num2 = (float) -((double) plane.D + (double) IndexedVector3.Dot(plane.Normal, p0)) / num1;
      return p0 + b * num2;
    }

    public static IndexedVector3 PlaneProject(ref Plane plane, ref IndexedVector3 point)
    {
      return point - new IndexedVector3(plane.Normal) * (IndexedVector3.Dot(point, plane.Normal) + plane.D);
    }

    public static IndexedVector3 TriNormal(IndexedVector3 v0, IndexedVector3 v1, IndexedVector3 v2)
    {
      return HullLibrary.TriNormal(ref v0, ref v1, ref v2);
    }

    public static IndexedVector3 TriNormal(ref IndexedVector3 v0, ref IndexedVector3 v1, ref IndexedVector3 v2)
    {
      IndexedVector3 indexedVector3 = IndexedVector3.Cross(v1 - v0, v2 - v1);
      float num = indexedVector3.Length();
      if ((double) num == 0.0)
        return new IndexedVector3(1f, 0.0f, 0.0f);
      else
        return indexedVector3 * (1f / num);
    }

    public static float DistanceBetweenLines(ref IndexedVector3 ustart, ref IndexedVector3 udir, ref IndexedVector3 vstart, ref IndexedVector3 vdir, ref IndexedVector3? upoint, ref IndexedVector3? vpoint)
    {
      IndexedVector3 indexedVector3 = IndexedVector3.Cross(udir, vdir);
      indexedVector3.Normalize();
      float num1 = Math.Abs(-IndexedVector3.Dot(indexedVector3, ustart) - -IndexedVector3.Dot(indexedVector3, vstart));
      if (upoint.HasValue)
      {
        Plane plane = new Plane();
        plane.Normal = IndexedVector3.Cross(vdir, indexedVector3).ToVector3();
        double num2 = (double) plane.Normal.Normalize();
        plane.D = -IndexedVector3.Dot(plane.Normal, vstart);
        IndexedVector3 p1 = ustart + udir;
        upoint = new IndexedVector3?(HullLibrary.PlaneLineIntersection(ref plane, ref ustart, ref p1));
      }
      if (vpoint.HasValue)
      {
        Plane plane = new Plane();
        plane.Normal = IndexedVector3.Cross(udir, indexedVector3).ToVector3();
        double num2 = (double) plane.Normal.Normalize();
        plane.D = -IndexedVector3.Dot(plane.Normal, ustart);
        IndexedVector3 p1 = vstart + vdir;
        vpoint = new IndexedVector3?(HullLibrary.PlaneLineIntersection(ref plane, ref vstart, ref p1));
      }
      return num1;
    }

    public static PlaneIntersectType PlaneTest(ref Plane p, ref IndexedVector3 v)
    {
      float num1 = 0.0001f;
      float num2 = IndexedVector3.Dot(v, p.Normal) + p.D;
      return (double) num2 > (double) num1 ? PlaneIntersectType.OVER : ((double) num2 < -(double) num1 ? PlaneIntersectType.UNDER : PlaneIntersectType.COPLANAR);
    }

    public static PlaneIntersectType SplitTest(ConvexH convex, ref Plane plane)
    {
      PlaneIntersectType planeIntersectType = PlaneIntersectType.COPLANAR;
      for (int index = 0; index < convex.vertices.Count; ++index)
      {
        IndexedVector3 v = convex.vertices[index];
        planeIntersectType |= HullLibrary.PlaneTest(ref plane, ref v);
      }
      return planeIntersectType;
    }
  }
}
