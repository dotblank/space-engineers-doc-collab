﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.IndexedBasisMatrix
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace BulletXNA.LinearMath
{
  public struct IndexedBasisMatrix
  {
    private static IndexedBasisMatrix _identity = new IndexedBasisMatrix(1f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0.0f, 0.0f, 1f);
    public IndexedVector3 _Row0;
    public IndexedVector3 _Row1;
    public IndexedVector3 _Row2;

    public static IndexedBasisMatrix Identity
    {
      get
      {
        return IndexedBasisMatrix._identity;
      }
    }

    public float this[int i, int j]
    {
      get
      {
        switch (i)
        {
          case 0:
            switch (j)
            {
              case 0:
                return this._Row0.X;
              case 1:
                return this._Row0.Y;
              case 2:
                return this._Row0.Z;
            }
          case 1:
            switch (j)
            {
              case 0:
                return this._Row1.X;
              case 1:
                return this._Row1.Y;
              case 2:
                return this._Row1.Z;
            }
          case 2:
            switch (j)
            {
              case 0:
                return this._Row2.X;
              case 1:
                return this._Row2.Y;
              case 2:
                return this._Row2.Z;
            }
        }
        return 0.0f;
      }
      set
      {
        switch (i)
        {
          case 0:
            switch (j)
            {
              case 0:
                this._Row0.X = value;
                return;
              case 1:
                this._Row0.Y = value;
                return;
              case 2:
                this._Row0.Z = value;
                return;
              default:
                return;
            }
          case 1:
            switch (j)
            {
              case 0:
                this._Row1.X = value;
                return;
              case 1:
                this._Row1.Y = value;
                return;
              case 2:
                this._Row1.Z = value;
                return;
              default:
                return;
            }
          case 2:
            switch (j)
            {
              case 0:
                this._Row2.X = value;
                return;
              case 1:
                this._Row2.Y = value;
                return;
              case 2:
                this._Row2.Z = value;
                return;
              default:
                return;
            }
        }
      }
    }

    public IndexedVector3 this[int i]
    {
      get
      {
        switch (i)
        {
          case 0:
            return this._Row0;
          case 1:
            return this._Row1;
          case 2:
            return this._Row2;
          default:
            return IndexedVector3.Zero;
        }
      }
      set
      {
        switch (i)
        {
          case 0:
            this._Row0 = value;
            break;
          case 1:
            this._Row1 = value;
            break;
          case 2:
            this._Row2 = value;
            break;
        }
      }
    }

    public IndexedBasisMatrix(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
    {
      this._Row0 = new IndexedVector3(m11, m12, m13);
      this._Row1 = new IndexedVector3(m21, m22, m23);
      this._Row2 = new IndexedVector3(m31, m32, m33);
    }

    public IndexedBasisMatrix(IndexedVector3 row0, IndexedVector3 row1, IndexedVector3 row2)
    {
      this._Row0 = row0;
      this._Row1 = row1;
      this._Row2 = row2;
    }

    public IndexedBasisMatrix(ref IndexedVector3 row0, ref IndexedVector3 row1, ref IndexedVector3 row2)
    {
      this._Row0 = row0;
      this._Row1 = row1;
      this._Row2 = row2;
    }

    public IndexedBasisMatrix(Quaternion q)
    {
      float num1 = 2f / q.LengthSquared();
      float num2 = q.X * num1;
      float num3 = q.Y * num1;
      float num4 = q.Z * num1;
      float num5 = q.W * num2;
      float num6 = q.W * num3;
      float num7 = q.W * num4;
      float num8 = q.X * num2;
      float num9 = q.X * num3;
      float num10 = q.X * num4;
      float num11 = q.Y * num3;
      float num12 = q.Y * num4;
      float num13 = q.Z * num4;
      this._Row0 = new IndexedVector3((float) (1.0 - ((double) num11 + (double) num13)), num9 - num7, num10 + num6);
      this._Row1 = new IndexedVector3(num9 + num7, (float) (1.0 - ((double) num8 + (double) num13)), num12 - num5);
      this._Row2 = new IndexedVector3(num10 - num6, num12 + num5, (float) (1.0 - ((double) num8 + (double) num11)));
    }

    public IndexedBasisMatrix(ref Quaternion q)
    {
      float num1 = 2f / q.LengthSquared();
      float num2 = q.X * num1;
      float num3 = q.Y * num1;
      float num4 = q.Z * num1;
      float num5 = q.W * num2;
      float num6 = q.W * num3;
      float num7 = q.W * num4;
      float num8 = q.X * num2;
      float num9 = q.X * num3;
      float num10 = q.X * num4;
      float num11 = q.Y * num3;
      float num12 = q.Y * num4;
      float num13 = q.Z * num4;
      this._Row0 = new IndexedVector3((float) (1.0 - ((double) num11 + (double) num13)), num9 - num7, num10 + num6);
      this._Row1 = new IndexedVector3(num9 + num7, (float) (1.0 - ((double) num8 + (double) num13)), num12 - num5);
      this._Row2 = new IndexedVector3(num10 - num6, num12 + num5, (float) (1.0 - ((double) num8 + (double) num11)));
    }

    public static bool operator ==(IndexedBasisMatrix matrix1, IndexedBasisMatrix matrix2)
    {
      if (matrix1._Row0 == matrix2._Row0 && matrix1._Row1 == matrix2._Row1)
        return matrix1._Row2 == matrix2._Row2;
      else
        return false;
    }

    public static bool operator !=(IndexedBasisMatrix matrix1, IndexedBasisMatrix matrix2)
    {
      if (!(matrix1._Row0 != matrix2._Row0) && !(matrix1._Row1 != matrix2._Row1))
        return matrix1._Row2 != matrix2._Row2;
      else
        return true;
    }

    public static IndexedVector3 operator *(IndexedBasisMatrix m, IndexedVector3 v)
    {
      return new IndexedVector3(m._Row0.Dot(ref v), m._Row1.Dot(ref v), m._Row2.Dot(ref v));
    }

    public static IndexedVector3 operator *(IndexedVector3 v, IndexedBasisMatrix m)
    {
      return new IndexedVector3(m.TDotX(ref v), m.TDotY(ref v), m.TDotZ(ref v));
    }

    public static IndexedBasisMatrix operator *(IndexedBasisMatrix m1, IndexedBasisMatrix m2)
    {
      return new IndexedBasisMatrix(m2.TDotX(ref m1._Row0), m2.TDotY(ref m1._Row0), m2.TDotZ(ref m1._Row0), m2.TDotX(ref m1._Row1), m2.TDotY(ref m1._Row1), m2.TDotZ(ref m1._Row1), m2.TDotX(ref m1._Row2), m2.TDotY(ref m1._Row2), m2.TDotZ(ref m1._Row2));
    }

    public IndexedBasisMatrix Scaled(IndexedVector3 s)
    {
      return new IndexedBasisMatrix(this._Row0.X * s.X, this._Row0.Y * s.Y, this._Row0.Z * s.Z, this._Row1.X * s.X, this._Row1.Y * s.Y, this._Row1.Z * s.Z, this._Row2.X * s.X, this._Row2.Y * s.Y, this._Row2.Z * s.Z);
    }

    public IndexedBasisMatrix Scaled(ref IndexedVector3 s)
    {
      return new IndexedBasisMatrix(this._Row0.X * s.X, this._Row0.Y * s.Y, this._Row0.Z * s.Z, this._Row1.X * s.X, this._Row1.Y * s.Y, this._Row1.Z * s.Z, this._Row2.X * s.X, this._Row2.Y * s.Y, this._Row2.Z * s.Z);
    }

    public void SetValue(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
    {
      this[0] = new IndexedVector3(m11, m12, m13);
      this[1] = new IndexedVector3(m21, m22, m23);
      this[2] = new IndexedVector3(m31, m32, m33);
    }

    public IndexedVector3 GetColumn(int i)
    {
      return new IndexedVector3(this._Row0[i], this._Row1[i], this._Row2[i]);
    }

    public IndexedVector3 GetRow(int i)
    {
      switch (i)
      {
        case 0:
          return this._Row0;
        case 1:
          return this._Row1;
        case 2:
          return this._Row2;
        default:
          return IndexedVector3.Zero;
      }
    }

    public override bool Equals(object obj)
    {
      if (!(obj is IndexedBasisMatrix))
        return false;
      IndexedBasisMatrix indexedBasisMatrix = (IndexedBasisMatrix) obj;
      if (this._Row0.Equals(indexedBasisMatrix._Row0) && this._Row1.Equals(indexedBasisMatrix._Row1))
        return this._Row2.Equals(indexedBasisMatrix._Row2);
      else
        return false;
    }

    public static IndexedBasisMatrix Transpose(IndexedBasisMatrix IndexedMatrix)
    {
      return new IndexedBasisMatrix(IndexedMatrix._Row0.X, IndexedMatrix._Row1.X, IndexedMatrix._Row2.X, IndexedMatrix._Row0.Y, IndexedMatrix._Row1.Y, IndexedMatrix._Row2.Y, IndexedMatrix._Row0.Z, IndexedMatrix._Row1.Z, IndexedMatrix._Row2.Z);
    }

    public static void Transpose(ref IndexedBasisMatrix IndexedMatrix, out IndexedBasisMatrix result)
    {
      result = new IndexedBasisMatrix(IndexedMatrix._Row0.X, IndexedMatrix._Row1.X, IndexedMatrix._Row2.X, IndexedMatrix._Row0.Y, IndexedMatrix._Row1.Y, IndexedMatrix._Row2.Y, IndexedMatrix._Row0.Z, IndexedMatrix._Row1.Z, IndexedMatrix._Row2.Z);
    }

    public void SetEulerZYX(float eulerX, float eulerY, float eulerZ)
    {
      float num1 = (float) Math.Cos((double) eulerX);
      float num2 = (float) Math.Cos((double) eulerY);
      float num3 = (float) Math.Cos((double) eulerZ);
      float num4 = (float) Math.Sin((double) eulerX);
      float num5 = (float) Math.Sin((double) eulerY);
      float num6 = (float) Math.Sin((double) eulerZ);
      float num7 = num1 * num3;
      float num8 = num1 * num6;
      float num9 = num4 * num3;
      float num10 = num4 * num6;
      this.SetValue(num2 * num3, num5 * num9 - num8, num5 * num7 + num10, num2 * num6, num5 * num10 + num7, num5 * num8 - num9, -num5, num2 * num4, num2 * num1);
    }

    public float TDotX(ref IndexedVector3 v)
    {
      return (float) ((double) this._Row0.X * (double) v.X + (double) this._Row1.X * (double) v.Y + (double) this._Row2.X * (double) v.Z);
    }

    public float TDotY(ref IndexedVector3 v)
    {
      return (float) ((double) this._Row0.Y * (double) v.X + (double) this._Row1.Y * (double) v.Y + (double) this._Row2.Y * (double) v.Z);
    }

    public float TDotZ(ref IndexedVector3 v)
    {
      return (float) ((double) this._Row0.Z * (double) v.X + (double) this._Row1.Z * (double) v.Y + (double) this._Row2.Z * (double) v.Z);
    }

    public IndexedBasisMatrix Inverse()
    {
      IndexedVector3 v = new IndexedVector3(this.Cofac(1, 1, 2, 2), this.Cofac(1, 2, 2, 0), this.Cofac(1, 0, 2, 1));
      float num = 1f / this[0].Dot(v);
      return new IndexedBasisMatrix(v.X * num, this.Cofac(0, 2, 2, 1) * num, this.Cofac(0, 1, 1, 2) * num, v.Y * num, this.Cofac(0, 0, 2, 2) * num, this.Cofac(0, 2, 1, 0) * num, v.Z * num, this.Cofac(0, 1, 2, 0) * num, this.Cofac(0, 0, 1, 1) * num);
    }

    public float Cofac(int r1, int c1, int r2, int c2)
    {
      return (float) ((double) this[r1][c1] * (double) this[r2][c2] - (double) this[r1][c2] * (double) this[r2][c1]);
    }

    public IndexedBasisMatrix TransposeTimes(IndexedBasisMatrix m)
    {
      return new IndexedBasisMatrix((float) ((double) this._Row0.X * (double) m._Row0.X + (double) this._Row1.X * (double) m._Row1.X + (double) this._Row2.X * (double) m._Row2.X), (float) ((double) this._Row0.X * (double) m._Row0.Y + (double) this._Row1.X * (double) m._Row1.Y + (double) this._Row2.X * (double) m._Row2.Y), (float) ((double) this._Row0.X * (double) m._Row0.Z + (double) this._Row1.X * (double) m._Row1.Z + (double) this._Row2.X * (double) m._Row2.Z), (float) ((double) this._Row0.Y * (double) m._Row0.X + (double) this._Row1.Y * (double) m._Row1.X + (double) this._Row2.Y * (double) m._Row2.X), (float) ((double) this._Row0.Y * (double) m._Row0.Y + (double) this._Row1.Y * (double) m._Row1.Y + (double) this._Row2.Y * (double) m._Row2.Y), (float) ((double) this._Row0.Y * (double) m._Row0.Z + (double) this._Row1.Y * (double) m._Row1.Z + (double) this._Row2.Y * (double) m._Row2.Z), (float) ((double) this._Row0.Z * (double) m._Row0.X + (double) this._Row1.Z * (double) m._Row1.X + (double) this._Row2.Z * (double) m._Row2.X), (float) ((double) this._Row0.Z * (double) m._Row0.Y + (double) this._Row1.Z * (double) m._Row1.Y + (double) this._Row2.Z * (double) m._Row2.Y), (float) ((double) this._Row0.Z * (double) m._Row0.Z + (double) this._Row1.Z * (double) m._Row1.Z + (double) this._Row2.Z * (double) m._Row2.Z));
    }

    public IndexedBasisMatrix TransposeTimes(ref IndexedBasisMatrix m)
    {
      return new IndexedBasisMatrix((float) ((double) this._Row0.X * (double) m._Row0.X + (double) this._Row1.X * (double) m._Row1.X + (double) this._Row2.X * (double) m._Row2.X), (float) ((double) this._Row0.X * (double) m._Row0.Y + (double) this._Row1.X * (double) m._Row1.Y + (double) this._Row2.X * (double) m._Row2.Y), (float) ((double) this._Row0.X * (double) m._Row0.Z + (double) this._Row1.X * (double) m._Row1.Z + (double) this._Row2.X * (double) m._Row2.Z), (float) ((double) this._Row0.Y * (double) m._Row0.X + (double) this._Row1.Y * (double) m._Row1.X + (double) this._Row2.Y * (double) m._Row2.X), (float) ((double) this._Row0.Y * (double) m._Row0.Y + (double) this._Row1.Y * (double) m._Row1.Y + (double) this._Row2.Y * (double) m._Row2.Y), (float) ((double) this._Row0.Y * (double) m._Row0.Z + (double) this._Row1.Y * (double) m._Row1.Z + (double) this._Row2.Y * (double) m._Row2.Z), (float) ((double) this._Row0.Z * (double) m._Row0.X + (double) this._Row1.Z * (double) m._Row1.X + (double) this._Row2.Z * (double) m._Row2.X), (float) ((double) this._Row0.Z * (double) m._Row0.Y + (double) this._Row1.Z * (double) m._Row1.Y + (double) this._Row2.Z * (double) m._Row2.Y), (float) ((double) this._Row0.Z * (double) m._Row0.Z + (double) this._Row1.Z * (double) m._Row1.Z + (double) this._Row2.Z * (double) m._Row2.Z));
    }

    public IndexedBasisMatrix TimesTranspose(IndexedBasisMatrix m)
    {
      return new IndexedBasisMatrix(this._Row0.Dot(m._Row0), this._Row0.Dot(m._Row1), this._Row0.Dot(m._Row2), this._Row1.Dot(m._Row0), this._Row1.Dot(m._Row1), this._Row1.Dot(m._Row2), this._Row2.Dot(m._Row0), this._Row2.Dot(m._Row1), this._Row2.Dot(m._Row2));
    }

    public IndexedBasisMatrix Transpose()
    {
      return new IndexedBasisMatrix(this._Row0.X, this._Row1.X, this._Row2.X, this._Row0.Y, this._Row1.Y, this._Row2.Y, this._Row0.Z, this._Row1.Z, this._Row2.Z);
    }

    public IndexedBasisMatrix Absolute()
    {
      return new IndexedBasisMatrix(this._Row0.Abs(), this._Row1.Abs(), this._Row2.Abs());
    }

    public Quaternion GetRotation()
    {
      float num1 = this._Row0.X + this._Row1.Y + this._Row2.Z;
      IndexedVector3 indexedVector3 = new IndexedVector3();
      float w;
      if ((double) num1 > 0.0)
      {
        float num2 = (float) Math.Sqrt((double) num1 + 1.0);
        w = num2 * 0.5f;
        float num3 = 0.5f / num2;
        indexedVector3[0] = (this._Row2.Y - this._Row1.Z) * num3;
        indexedVector3[1] = (this._Row0.Z - this._Row2.X) * num3;
        indexedVector3[2] = (this._Row1.X - this._Row0.Y) * num3;
      }
      else
      {
        int index1 = (double) this._Row0.X < (double) this._Row1.Y ? ((double) this._Row1.Y < (double) this._Row2.Z ? 2 : 1) : ((double) this._Row0.X < (double) this._Row2.Z ? 2 : 0);
        int index2 = (index1 + 1) % 3;
        int index3 = (index1 + 2) % 3;
        float num2 = (float) Math.Sqrt((double) this[index1][index1] - (double) this[index2][index2] - (double) this[index3][index3] + 1.0);
        indexedVector3[index1] = num2 * 0.5f;
        float num3 = 0.5f / num2;
        w = (this[index3][index2] - this[index2][index3]) * num3;
        indexedVector3[index2] = (this[index2][index1] + this[index1][index2]) * num3;
        indexedVector3[index3] = (this[index3][index1] + this[index1][index3]) * num3;
      }
      return new Quaternion(indexedVector3[0], indexedVector3[1], indexedVector3[2], w);
    }

    public void SetRotation(Quaternion q)
    {
      float num1 = 2f / q.LengthSquared();
      float num2 = q.X * num1;
      float num3 = q.Y * num1;
      float num4 = q.Z * num1;
      float num5 = q.W * num2;
      float num6 = q.W * num3;
      float num7 = q.W * num4;
      float num8 = q.X * num2;
      float num9 = q.X * num3;
      float num10 = q.X * num4;
      float num11 = q.Y * num3;
      float num12 = q.Y * num4;
      float num13 = q.Z * num4;
      this.SetValue((float) (1.0 - ((double) num11 + (double) num13)), num9 - num7, num10 + num6, num9 + num7, (float) (1.0 - ((double) num8 + (double) num13)), num12 - num5, num10 - num6, num12 + num5, (float) (1.0 - ((double) num8 + (double) num11)));
    }

    public void SetRotation(ref Quaternion q)
    {
      float num1 = 2f / q.LengthSquared();
      float num2 = q.X * num1;
      float num3 = q.Y * num1;
      float num4 = q.Z * num1;
      float num5 = q.W * num2;
      float num6 = q.W * num3;
      float num7 = q.W * num4;
      float num8 = q.X * num2;
      float num9 = q.X * num3;
      float num10 = q.X * num4;
      float num11 = q.Y * num3;
      float num12 = q.Y * num4;
      float num13 = q.Z * num4;
      this.SetValue((float) (1.0 - ((double) num11 + (double) num13)), num9 - num7, num10 + num6, num9 + num7, (float) (1.0 - ((double) num8 + (double) num13)), num12 - num5, num10 - num6, num12 + num5, (float) (1.0 - ((double) num8 + (double) num11)));
    }

    public void Diagonalize(out IndexedMatrix rot, float threshold, int maxSteps)
    {
      rot = IndexedMatrix.Identity;
      for (int index1 = maxSteps; index1 > 0; --index1)
      {
        int index2 = 0;
        int index3 = 1;
        int index4 = 2;
        float num1 = Math.Abs(this[0][1]);
        float num2 = Math.Abs(this[0][2]);
        if ((double) num2 > (double) num1)
        {
          index3 = 2;
          index4 = 1;
          num1 = num2;
        }
        float num3 = Math.Abs(this[1][2]);
        if ((double) num3 > (double) num1)
        {
          index2 = 1;
          index3 = 2;
          index4 = 0;
          num1 = num3;
        }
        float num4 = threshold * (Math.Abs(this[0][0]) + Math.Abs(this[1][1]) + Math.Abs(this[2][2]));
        if ((double) num1 <= (double) num4)
        {
          if ((double) num1 <= 1.19209289550781E-07 * (double) num4)
            break;
          index1 = 1;
        }
        float num5 = this[index2][index3];
        float num6 = (float) (((double) this[index3][index3] - (double) this[index2][index2]) / (2.0 * (double) num5));
        float num7 = num6 * num6;
        float num8;
        float num9;
        float num10;
        if ((double) num7 * (double) num7 < 83886080.0)
        {
          num8 = (double) num6 >= 0.0 ? 1f / (num6 + (float) Math.Sqrt(1.0 + (double) num7)) : (float) (1.0 / ((double) num6 - Math.Sqrt(1.0 + (double) num7)));
          num9 = 1f / (float) Math.Sqrt(1.0 + (double) num8 * (double) num8);
          num10 = num9 * num8;
        }
        else
        {
          num8 = (float) (1.0 / ((double) num6 * (2.0 + 0.5 / (double) num7)));
          num9 = (float) (1.0 - 0.5 * (double) num8 * (double) num8);
          num10 = num9 * num8;
        }
        this[index2, index3] = 0.0f;
        this[index3, index2] = 0.0f;
        this[index2, index2] -= num8 * num5;
        this[index3, index3] += num8 * num5;
        float num11 = this[index4][index2];
        float num12 = this[index4][index3];
        this[index4, index2] = this[index2, index4] = (float) ((double) num9 * (double) num11 - (double) num10 * (double) num12);
        this[index4, index3] = this[index3, index4] = (float) ((double) num9 * (double) num12 + (double) num10 * (double) num11);
        for (int index5 = 0; index5 < 3; ++index5)
        {
          float num13 = this[index5, index2];
          float num14 = this[index5, index3];
          this[index5, index2] = (float) ((double) num9 * (double) num13 - (double) num10 * (double) num14);
          this[index5, index3] = (float) ((double) num9 * (double) num14 + (double) num10 * (double) num13);
        }
      }
    }

    public override int GetHashCode()
    {
      return (this._Row0.GetHashCode() * 397 ^ this._Row1.GetHashCode()) * 397 ^ this._Row2.GetHashCode();
    }
  }
}
