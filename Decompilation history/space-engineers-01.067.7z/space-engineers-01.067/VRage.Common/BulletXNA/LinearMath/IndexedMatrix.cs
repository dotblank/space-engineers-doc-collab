﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.IndexedMatrix
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace BulletXNA.LinearMath
{
  public struct IndexedMatrix : IEquatable<IndexedMatrix>
  {
    private static IndexedMatrix _identity = new IndexedMatrix(1f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0.0f, 0.0f, 1f, 0.0f, 0.0f, 0.0f);
    public IndexedBasisMatrix _basis;
    public IndexedVector3 _origin;

    public static IndexedMatrix Identity
    {
      get
      {
        return IndexedMatrix._identity;
      }
    }

    public IndexedMatrix(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33, float m41, float m42, float m43)
    {
      this._basis = new IndexedBasisMatrix(m11, m12, m13, m21, m22, m23, m31, m32, m33);
      this._origin = new IndexedVector3(m41, m42, m43);
    }

    public IndexedMatrix(IndexedBasisMatrix basis, IndexedVector3 origin)
    {
      this._basis = basis;
      this._origin = origin;
    }

    public IndexedMatrix(Matrix m)
    {
      this._origin = new IndexedVector3(m.Translation);
      this._basis = new IndexedBasisMatrix(new IndexedVector3(m.Right), new IndexedVector3(m.Up), new IndexedVector3(m.Backward));
    }

    public static implicit operator Matrix(IndexedMatrix im)
    {
      Matrix matrix = Matrix.Identity;
      matrix.Right = im._basis.GetColumn(0).ToVector3();
      matrix.Up = im._basis.GetColumn(1).ToVector3();
      matrix.Backward = im._basis.GetColumn(2).ToVector3();
      matrix.Translation = im._origin.ToVector3();
      return matrix;
    }

    public static implicit operator IndexedMatrix(Matrix m)
    {
      return new IndexedMatrix()
      {
        _origin = new IndexedVector3(m.Translation),
        _basis = new IndexedBasisMatrix(new IndexedVector3(m.Right), new IndexedVector3(m.Up), new IndexedVector3(m.Backward))
      };
    }

    public static bool operator ==(IndexedMatrix matrix1, IndexedMatrix matrix2)
    {
      if (matrix1._basis == matrix2._basis)
        return matrix1._origin == matrix2._origin;
      else
        return false;
    }

    public static bool operator !=(IndexedMatrix matrix1, IndexedMatrix matrix2)
    {
      if (!(matrix1._basis != matrix2._basis))
        return matrix1._origin != matrix2._origin;
      else
        return true;
    }

    public static IndexedVector3 operator *(IndexedMatrix matrix1, IndexedVector3 v)
    {
      return new IndexedVector3(matrix1._basis._Row0.Dot(ref v) + matrix1._origin.X, matrix1._basis._Row1.Dot(ref v) + matrix1._origin.Y, matrix1._basis._Row2.Dot(ref v) + matrix1._origin.Z);
    }

    public static IndexedMatrix operator *(IndexedMatrix matrix1, IndexedMatrix matrix2)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis = matrix1._basis * matrix2._basis;
      indexedMatrix._origin = matrix1 * matrix2._origin;
      return indexedMatrix;
    }

    public static IndexedMatrix operator /(IndexedMatrix matrix1, IndexedMatrix matrix2)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = matrix1._basis._Row0 / matrix2._basis._Row0;
      indexedMatrix._basis._Row1 = matrix1._basis._Row1 / matrix2._basis._Row1;
      indexedMatrix._basis._Row2 = matrix1._basis._Row2 / matrix2._basis._Row2;
      indexedMatrix._origin = matrix1._origin / matrix2._origin;
      return indexedMatrix;
    }

    public static IndexedMatrix operator /(IndexedMatrix matrix1, float divider)
    {
      float num = 1f / divider;
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = matrix1._basis._Row0 * num;
      indexedMatrix._basis._Row1 = matrix1._basis._Row1 * num;
      indexedMatrix._basis._Row2 = matrix1._basis._Row2 * num;
      indexedMatrix._origin = matrix1._origin * num;
      return indexedMatrix;
    }

    public Matrix ToMatrix()
    {
      Matrix matrix = Matrix.Identity;
      matrix.Right = this._basis.GetColumn(0).ToVector3();
      matrix.Up = this._basis.GetColumn(1).ToVector3();
      matrix.Backward = this._basis.GetColumn(2).ToVector3();
      matrix.Translation = this._origin.ToVector3();
      return matrix;
    }

    public Matrix ToMatrixProjection()
    {
      Matrix matrix = Matrix.Identity;
      matrix.Right = this._basis.GetColumn(0).ToVector3();
      matrix.Up = this._basis.GetColumn(1).ToVector3();
      matrix.Backward = this._basis.GetColumn(2).ToVector3();
      matrix.Translation = this._origin.ToVector3();
      matrix.M34 = -1f;
      matrix.M44 = 0.0f;
      return matrix;
    }

    public static IndexedMatrix CreateLookAt(IndexedVector3 cameraPosition, IndexedVector3 cameraTarget, IndexedVector3 cameraUpVector)
    {
      IndexedVector3 row2 = IndexedVector3.Normalize(cameraPosition - cameraTarget);
      IndexedVector3 row0 = IndexedVector3.Normalize(IndexedVector3.Cross(cameraUpVector, row2));
      IndexedVector3 row1 = IndexedVector3.Cross(row2, row0);
      IndexedMatrix identity = IndexedMatrix.Identity;
      identity._basis = new IndexedBasisMatrix(ref row0, ref row1, ref row2);
      identity._origin = new IndexedVector3(-IndexedVector3.Dot(row0, cameraPosition), -IndexedVector3.Dot(row1, cameraPosition), -IndexedVector3.Dot(row2, cameraPosition));
      return identity;
    }

    public static IndexedMatrix CreatePerspectiveFieldOfView(float fieldOfView, float aspectRatio, float nearPlaneDistance, float farPlaneDistance)
    {
      float m22 = 1f / (float) Math.Tan((double) fieldOfView * 0.5);
      float m11 = m22 / aspectRatio;
      IndexedMatrix identity = IndexedMatrix.Identity;
      identity._basis = new IndexedBasisMatrix(m11, 0.0f, 0.0f, 0.0f, m22, 0.0f, 0.0f, 0.0f, farPlaneDistance / (nearPlaneDistance - farPlaneDistance));
      identity._origin = new IndexedVector3(0.0f, 0.0f, (float) ((double) nearPlaneDistance * (double) farPlaneDistance / ((double) nearPlaneDistance - (double) farPlaneDistance)));
      return identity;
    }

    public static IndexedMatrix CreateTranslation(IndexedVector3 position)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      indexedMatrix._origin = position;
      return indexedMatrix;
    }

    public static void CreateTranslation(ref IndexedVector3 position, out IndexedMatrix result)
    {
      result._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      result._origin = position;
    }

    public static IndexedMatrix CreateTranslation(float xPosition, float yPosition, float zPosition)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      indexedMatrix._origin = new IndexedVector3(xPosition, yPosition, zPosition);
      return indexedMatrix;
    }

    public static void CreateTranslation(float xPosition, float yPosition, float zPosition, out IndexedMatrix result)
    {
      result._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      result._origin = new IndexedVector3(xPosition, yPosition, zPosition);
    }

    public static IndexedMatrix CreateScale(float xScale, float yScale, float zScale)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(xScale, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, yScale, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, zScale);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateScale(float xScale, float yScale, float zScale, out IndexedMatrix result)
    {
      result._basis._Row0 = new IndexedVector3(xScale, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, yScale, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, zScale);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public static IndexedMatrix CreateScale(IndexedVector3 scales)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(scales.X, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, scales.Y, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, scales.Z);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateScale(ref IndexedVector3 scales, out IndexedMatrix result)
    {
      result._basis._Row0 = new IndexedVector3(scales.X, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, scales.Y, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, scales.Z);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public static IndexedMatrix CreateScale(float scale)
    {
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(scale, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, scale, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, scale);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateScale(float scale, out IndexedMatrix result)
    {
      result._basis._Row0 = new IndexedVector3(scale, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, scale, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, scale);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public static IndexedMatrix CreateRotationX(float radians)
    {
      float num = (float) Math.Cos((double) radians);
      float z = (float) Math.Sin((double) radians);
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, num, z);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, -z, num);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateRotationX(float radians, out IndexedMatrix result)
    {
      float num = (float) Math.Cos((double) radians);
      float z = (float) Math.Sin((double) radians);
      result._basis._Row0 = new IndexedVector3(1f, 0.0f, 0.0f);
      result._basis._Row1 = new IndexedVector3(0.0f, num, z);
      result._basis._Row2 = new IndexedVector3(0.0f, -z, num);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public static IndexedMatrix CreateRotationY(float radians)
    {
      float num = (float) Math.Cos((double) radians);
      float x = (float) Math.Sin((double) radians);
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(num, 0.0f, -x);
      indexedMatrix._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(x, 0.0f, num);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateRotationY(float radians, out IndexedMatrix result)
    {
      float num = (float) Math.Cos((double) radians);
      float x = (float) Math.Sin((double) radians);
      result._basis._Row0 = new IndexedVector3(num, 0.0f, -x);
      result._basis._Row1 = new IndexedVector3(0.0f, 1f, 0.0f);
      result._basis._Row2 = new IndexedVector3(x, 0.0f, num);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public static IndexedMatrix CreateRotationZ(float radians)
    {
      float num = (float) Math.Cos((double) radians);
      float y = (float) Math.Sin((double) radians);
      IndexedMatrix indexedMatrix;
      indexedMatrix._basis._Row0 = new IndexedVector3(num, y, 0.0f);
      indexedMatrix._basis._Row1 = new IndexedVector3(-y, num, 0.0f);
      indexedMatrix._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      indexedMatrix._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
      return indexedMatrix;
    }

    public static void CreateRotationZ(float radians, out IndexedMatrix result)
    {
      float num = (float) Math.Cos((double) radians);
      float y = (float) Math.Sin((double) radians);
      result._basis._Row0 = new IndexedVector3(num, y, 0.0f);
      result._basis._Row1 = new IndexedVector3(-y, num, 0.0f);
      result._basis._Row2 = new IndexedVector3(0.0f, 0.0f, 1f);
      result._origin = new IndexedVector3(0.0f, 0.0f, 0.0f);
    }

    public bool Equals(IndexedMatrix other)
    {
      if (this._basis.Equals((object) other._basis))
        return this._origin.Equals(other._origin);
      else
        return false;
    }

    public override bool Equals(object obj)
    {
      bool flag = false;
      if (obj is IndexedMatrix)
        flag = this.Equals((IndexedMatrix) obj);
      return flag;
    }

    public override int GetHashCode()
    {
      return this._basis.GetHashCode() + this._origin.GetHashCode();
    }

    public IndexedMatrix Inverse()
    {
      IndexedBasisMatrix basis = this._basis.Transpose();
      return new IndexedMatrix(basis, basis * -this._origin);
    }

    public IndexedVector3 InvXform(IndexedVector3 inVec)
    {
      return this._basis.Transpose() * (inVec - this._origin);
    }

    public IndexedVector3 InvXform(ref IndexedVector3 inVec)
    {
      return this._basis.Transpose() * (inVec - this._origin);
    }

    public IndexedMatrix InverseTimes(ref IndexedMatrix t)
    {
      IndexedVector3 indexedVector3 = t._origin - this._origin;
      return new IndexedMatrix(this._basis.TransposeTimes(t._basis), indexedVector3 * this._basis);
    }

    public Quaternion GetRotation()
    {
      return this._basis.GetRotation();
    }

    public static IndexedMatrix CreateFromQuaternion(Quaternion q)
    {
      IndexedMatrix indexedMatrix = new IndexedMatrix();
      indexedMatrix._basis.SetRotation(ref q);
      return indexedMatrix;
    }

    public static IndexedMatrix CreateFromQuaternion(ref Quaternion q)
    {
      IndexedMatrix indexedMatrix = new IndexedMatrix();
      indexedMatrix._basis.SetRotation(ref q);
      return indexedMatrix;
    }
  }
}
