﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.HullDesc
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;

namespace BulletXNA.LinearMath
{
  public class HullDesc
  {
    public IList<IndexedVector3> mVertices = (IList<IndexedVector3>) new List<IndexedVector3>();
    public HullFlag mFlags;
    public int mVcount;
    public int mVertexStride;
    public float mNormalEpsilon;
    public int mMaxVertices;
    public int mMaxFaces;

    public HullDesc()
    {
      this.mFlags = HullFlag.QF_TRIANGLES;
      this.mVcount = 0;
      this.mNormalEpsilon = 1.0 / 1000.0;
      this.mMaxVertices = 4096;
      this.mMaxFaces = 4096;
    }

    public HullDesc(HullFlag flag, int vcount, IList<IndexedVector3> vertices)
    {
      this.mFlags = flag;
      this.mVcount = vcount;
      this.mVertices = vertices;
      this.mNormalEpsilon = 1.0 / 1000.0;
      this.mMaxVertices = 4096;
    }

    public bool HasHullFlag(HullFlag flag)
    {
      return (this.mFlags & flag) != (HullFlag) 0;
    }

    private void SetHullFlag(HullFlag flag)
    {
      this.mFlags |= flag;
    }

    private void ClearHullFlag(HullFlag flag)
    {
      this.mFlags &= ~flag;
    }
  }
}
