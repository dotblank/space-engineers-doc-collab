﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.IndexedVector3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace BulletXNA.LinearMath
{
  public struct IndexedVector3
  {
    private static IndexedVector3 _zero = new IndexedVector3();
    private static IndexedVector3 _one = new IndexedVector3(1f);
    private static IndexedVector3 _up = new IndexedVector3(0.0f, 1f, 0.0f);
    public float X;
    public float Y;
    public float Z;

    public float this[int i]
    {
      get
      {
        switch (i)
        {
          case 0:
            return this.X;
          case 1:
            return this.Y;
          case 2:
            return this.Z;
          default:
            return 0.0f;
        }
      }
      set
      {
        switch (i)
        {
          case 0:
            this.X = value;
            break;
          case 1:
            this.Y = value;
            break;
          case 2:
            this.Z = value;
            break;
        }
      }
    }

    public static IndexedVector3 Zero
    {
      get
      {
        return IndexedVector3._zero;
      }
    }

    public static IndexedVector3 One
    {
      get
      {
        return IndexedVector3._one;
      }
    }

    public static IndexedVector3 Up
    {
      get
      {
        return IndexedVector3._up;
      }
    }

    public static IndexedVector3 Down
    {
      get
      {
        return -IndexedVector3._up;
      }
    }

    public IndexedVector3(float x, float y, float z)
    {
      this.X = x;
      this.Y = y;
      this.Z = z;
    }

    public IndexedVector3(float x)
    {
      this.X = x;
      this.Y = x;
      this.Z = x;
    }

    public IndexedVector3(IndexedVector3 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public IndexedVector3(ref IndexedVector3 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public IndexedVector3(ref Vector3 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public IndexedVector3(Vector3 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public IndexedVector3(ref Vector4 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public IndexedVector3(Vector4 v)
    {
      this.X = v.X;
      this.Y = v.Y;
      this.Z = v.Z;
    }

    public static implicit operator Vector3(IndexedVector3 v)
    {
      return new Vector3(v.X, v.Y, v.Z);
    }

    public static implicit operator IndexedVector3(Vector3 v)
    {
      return new IndexedVector3(v.X, v.Y, v.Z);
    }

    public static IndexedVector3 operator +(IndexedVector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X + value2.X;
      indexedVector3.Y = value1.Y + value2.Y;
      indexedVector3.Z = value1.Z + value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator +(Vector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X + value2.X;
      indexedVector3.Y = value1.Y + value2.Y;
      indexedVector3.Z = value1.Z + value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator +(IndexedVector3 value1, Vector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X + value2.X;
      indexedVector3.Y = value1.Y + value2.Y;
      indexedVector3.Z = value1.Z + value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator -(Vector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X - value2.X;
      indexedVector3.Y = value1.Y - value2.Y;
      indexedVector3.Z = value1.Z - value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator -(IndexedVector3 value1, Vector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X - value2.X;
      indexedVector3.Y = value1.Y - value2.Y;
      indexedVector3.Z = value1.Z - value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator -(IndexedVector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X - value2.X;
      indexedVector3.Y = value1.Y - value2.Y;
      indexedVector3.Z = value1.Z - value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator *(IndexedVector3 value, float scaleFactor)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value.X * scaleFactor;
      indexedVector3.Y = value.Y * scaleFactor;
      indexedVector3.Z = value.Z * scaleFactor;
      return indexedVector3;
    }

    public static IndexedVector3 operator /(IndexedVector3 value, float scaleFactor)
    {
      float num = 1f / scaleFactor;
      IndexedVector3 indexedVector3;
      indexedVector3.X = value.X * num;
      indexedVector3.Y = value.Y * num;
      indexedVector3.Z = value.Z * num;
      return indexedVector3;
    }

    public static IndexedVector3 operator *(float scaleFactor, IndexedVector3 value)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value.X * scaleFactor;
      indexedVector3.Y = value.Y * scaleFactor;
      indexedVector3.Z = value.Z * scaleFactor;
      return indexedVector3;
    }

    public static IndexedVector3 operator -(IndexedVector3 value)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = -value.X;
      indexedVector3.Y = -value.Y;
      indexedVector3.Z = -value.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator *(IndexedVector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X * value2.X;
      indexedVector3.Y = value1.Y * value2.Y;
      indexedVector3.Z = value1.Z * value2.Z;
      return indexedVector3;
    }

    public static IndexedVector3 operator /(IndexedVector3 value1, IndexedVector3 value2)
    {
      IndexedVector3 indexedVector3;
      indexedVector3.X = value1.X / value2.X;
      indexedVector3.Y = value1.Y / value2.Y;
      indexedVector3.Z = value1.Z / value2.Z;
      return indexedVector3;
    }

    public static bool operator ==(IndexedVector3 value1, IndexedVector3 value2)
    {
      if ((double) value1.X == (double) value2.X && (double) value1.Y == (double) value2.Y)
        return (double) value1.Z == (double) value2.Z;
      else
        return false;
    }

    public static bool operator !=(IndexedVector3 value1, IndexedVector3 value2)
    {
      if ((double) value1.X == (double) value2.X && (double) value1.Y == (double) value2.Y)
        return (double) value1.Z != (double) value2.Z;
      else
        return true;
    }

    public float Length()
    {
      return (float) Math.Sqrt((double) this.X * (double) this.X + (double) this.Y * (double) this.Y + (double) this.Z * (double) this.Z);
    }

    public float LengthSquared()
    {
      return (float) ((double) this.X * (double) this.X + (double) this.Y * (double) this.Y + (double) this.Z * (double) this.Z);
    }

    public Vector3 ToVector3()
    {
      return new Vector3(this.X, this.Y, this.Z);
    }

    public void ToVector3(out Vector3 result)
    {
      result = new Vector3(this.X, this.Y, this.Z);
    }

    public void Abs(out IndexedVector3 result)
    {
      result.X = Math.Abs(this.X);
      result.Y = Math.Abs(this.Y);
      result.Z = Math.Abs(this.Z);
    }

    public IndexedVector3 Abs()
    {
      return new IndexedVector3(Math.Abs(this.X), Math.Abs(this.Y), Math.Abs(this.Z));
    }

    public IndexedVector3 Absolute()
    {
      return new IndexedVector3(Math.Abs(this.X), Math.Abs(this.Y), Math.Abs(this.Z));
    }

    public void Normalize()
    {
      float num = 1f / (float) Math.Sqrt((double) this.X * (double) this.X + (double) this.Y * (double) this.Y + (double) this.Z * (double) this.Z);
      this.X *= num;
      this.Y *= num;
      this.Z *= num;
    }

    public IndexedVector3 Normalized()
    {
      float num = 1f / (float) Math.Sqrt((double) this.X * (double) this.X + (double) this.Y * (double) this.Y + (double) this.Z * (double) this.Z);
      return new IndexedVector3(this.X * num, this.Y * num, this.Z * num);
    }

    public static void Transform(IndexedVector3[] source, ref IndexedMatrix t, IndexedVector3[] dest)
    {
      for (int index = 0; index < source.Length; ++index)
        dest[index] = t * source[index];
    }

    public static IndexedVector3 Normalize(IndexedVector3 v)
    {
      float num = 1f / (float) Math.Sqrt((double) v.X * (double) v.X + (double) v.Y * (double) v.Y + (double) v.Z * (double) v.Z);
      return new IndexedVector3(v.X * num, v.Y * num, v.Z * num);
    }

    public static IndexedVector3 Normalize(ref IndexedVector3 v)
    {
      float num = 1f / (float) Math.Sqrt((double) v.X * (double) v.X + (double) v.Y * (double) v.Y + (double) v.Z * (double) v.Z);
      return new IndexedVector3(v.X * num, v.Y * num, v.Z * num);
    }

    public IndexedVector3 Cross(ref IndexedVector3 v)
    {
      return new IndexedVector3((float) ((double) this.Y * (double) v.Z - (double) this.Z * (double) v.Y), (float) ((double) this.Z * (double) v.X - (double) this.X * (double) v.Z), (float) ((double) this.X * (double) v.Y - (double) this.Y * (double) v.X));
    }

    public IndexedVector3 Cross(IndexedVector3 v)
    {
      return new IndexedVector3((float) ((double) this.Y * (double) v.Z - (double) this.Z * (double) v.Y), (float) ((double) this.Z * (double) v.X - (double) this.X * (double) v.Z), (float) ((double) this.X * (double) v.Y - (double) this.Y * (double) v.X));
    }

    public static IndexedVector3 Cross(IndexedVector3 v, IndexedVector3 v2)
    {
      return new IndexedVector3((float) ((double) v.Y * (double) v2.Z - (double) v.Z * (double) v2.Y), (float) ((double) v.Z * (double) v2.X - (double) v.X * (double) v2.Z), (float) ((double) v.X * (double) v2.Y - (double) v.Y * (double) v2.X));
    }

    public static IndexedVector3 Cross(ref IndexedVector3 v, ref IndexedVector3 v2)
    {
      return new IndexedVector3((float) ((double) v.Y * (double) v2.Z - (double) v.Z * (double) v2.Y), (float) ((double) v.Z * (double) v2.X - (double) v.X * (double) v2.Z), (float) ((double) v.X * (double) v2.Y - (double) v.Y * (double) v2.X));
    }

    public static float Dot(IndexedVector3 a, IndexedVector3 b)
    {
      return (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static float Dot(ref IndexedVector3 a, ref IndexedVector3 b)
    {
      return (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static void Dot(ref IndexedVector3 a, ref IndexedVector3 b, out float r)
    {
      r = (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static float Dot(ref IndexedVector3 a, ref Vector3 b)
    {
      return (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static float Dot(IndexedVector3 a, Vector3 b)
    {
      return (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static float Dot(Vector3 a, IndexedVector3 b)
    {
      return (float) ((double) a.X * (double) b.X + (double) a.Y * (double) b.Y + (double) a.Z * (double) b.Z);
    }

    public static void Multiply(ref IndexedVector3 output, ref IndexedVector3 value1, ref IndexedVector3 value2)
    {
      output.X = value1.X * value2.X;
      output.Y = value1.Y * value2.Y;
      output.Z = value1.Z * value2.Z;
    }

    public static void Subtract(ref IndexedVector3 output, ref IndexedVector3 value1, ref IndexedVector3 value2)
    {
      output.X = value1.X - value2.X;
      output.Y = value1.Y - value2.Y;
      output.Z = value1.Z - value2.Z;
    }

    public float[] ToFloatArray()
    {
      return new float[3]
      {
        this.X,
        this.Y,
        this.Z
      };
    }

    public static void Lerp(ref IndexedVector3 a, ref IndexedVector3 b, float t, out IndexedVector3 c)
    {
      c = new IndexedVector3(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);
    }

    public static IndexedVector3 Lerp(ref IndexedVector3 a, ref IndexedVector3 b, float t)
    {
      return new IndexedVector3(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);
    }

    public bool Equals(IndexedVector3 other)
    {
      if ((double) this.X == (double) other.X && (double) this.Y == (double) other.Y)
        return (double) this.Z == (double) other.Z;
      else
        return false;
    }

    public override bool Equals(object obj)
    {
      bool flag = false;
      if (obj is IndexedVector3)
        flag = this.Equals((IndexedVector3) obj);
      return flag;
    }

    public float Dot(ref IndexedVector3 v)
    {
      return (float) ((double) this.X * (double) v.X + (double) this.Y * (double) v.Y + (double) this.Z * (double) v.Z);
    }

    public float Dot(IndexedVector3 v)
    {
      return (float) ((double) this.X * (double) v.X + (double) this.Y * (double) v.Y + (double) this.Z * (double) v.Z);
    }

    public float Triple(ref IndexedVector3 b, ref IndexedVector3 c)
    {
      return (float) ((double) this.X * ((double) b.Y * (double) c.Z - (double) b.Z * (double) c.Y) + (double) this.Y * ((double) b.Z * (double) c.X - (double) b.X * (double) c.Z) + (double) this.Z * ((double) b.X * (double) c.Y - (double) b.Y * (double) c.X));
    }

    public void SetMin(ref IndexedVector3 v)
    {
      if ((double) v.X < (double) this.X)
        this.X = v.X;
      if ((double) v.Y < (double) this.Y)
        this.Y = v.Y;
      if ((double) v.Z >= (double) this.Z)
        return;
      this.Z = v.Z;
    }

    public void SetMax(ref IndexedVector3 v)
    {
      if ((double) v.X > (double) this.X)
        this.X = v.X;
      if ((double) v.Y > (double) this.Y)
        this.Y = v.Y;
      if ((double) v.Z <= (double) this.Z)
        return;
      this.Z = v.Z;
    }

    public int MaxAxis()
    {
      if ((double) this.X >= (double) this.Y)
        return (double) this.X >= (double) this.Z ? 0 : 2;
      else
        return (double) this.Y >= (double) this.Z ? 1 : 2;
    }

    public int MinAxis()
    {
      if ((double) this.X >= (double) this.Y)
        return (double) this.X >= (double) this.Z ? 2 : 1;
      else
        return (double) this.Y >= (double) this.Z ? 2 : 0;
    }

    public override int GetHashCode()
    {
      return (this.X.GetHashCode() * 397 ^ this.Y.GetHashCode()) * 397 ^ this.Z.GetHashCode();
    }
  }
}
