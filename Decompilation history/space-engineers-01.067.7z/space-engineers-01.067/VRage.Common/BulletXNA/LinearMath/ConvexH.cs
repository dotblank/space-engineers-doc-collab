﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.ConvexH
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace BulletXNA.LinearMath
{
  public class ConvexH
  {
    public IList<IndexedVector3> vertices = (IList<IndexedVector3>) new ObjectArray<IndexedVector3>();
    public IList<ConvexH.HalfEdge> edges = (IList<ConvexH.HalfEdge>) new ObjectArray<ConvexH.HalfEdge>();
    public IList<Plane> facets = (IList<Plane>) new ObjectArray<Plane>();

    private ConvexH()
    {
    }

    public ConvexH(int vertices_size, int edges_size, int facets_size)
    {
    }

    public class HalfEdge
    {
      public short ea;
      public byte v;
      public byte p;

      public HalfEdge()
      {
      }

      private HalfEdge(short _ea, byte _v, byte _p)
      {
        this.ea = _ea;
        this.v = _v;
        this.p = _p;
      }
    }
  }
}
