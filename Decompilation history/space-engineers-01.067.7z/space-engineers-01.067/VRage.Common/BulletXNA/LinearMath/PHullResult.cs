﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.PHullResult
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;

namespace BulletXNA.LinearMath
{
  public class PHullResult
  {
    public IList<IndexedVector3> mVertices = (IList<IndexedVector3>) new List<IndexedVector3>();
    public IList<int> m_Indices = (IList<int>) new List<int>();
    public int mVcount;
    public int mIndexCount;
    public int mFaceCount;

    public PHullResult()
    {
      this.mVcount = 0;
      this.mIndexCount = 0;
      this.mFaceCount = 0;
    }
  }
}
