﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.int3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace BulletXNA.LinearMath
{
  public class int3
  {
    public int x;
    public int y;
    public int z;

    public int3()
    {
    }

    public int3(int _x, int _y, int _z)
    {
      this.x = _x;
      this.y = _y;
      this.z = _z;
    }

    public override bool Equals(object obj)
    {
      int3 int3 = (int3) obj;
      return this.x == int3.x && this.y == int3.y && this.z == int3.z;
    }

    public override int GetHashCode()
    {
      return (this.x.GetHashCode() * 397 ^ this.y.GetHashCode()) * 397 ^ this.z.GetHashCode();
    }

    public int At(int index)
    {
      if (index == 0)
        return this.x;
      if (index == 1)
        return this.y;
      if (index == 2)
        return this.z;
      else
        return -1;
    }

    public void At(int index, int value)
    {
      if (index == 0)
        this.x = value;
      else if (index == 1)
      {
        this.y = value;
      }
      else
      {
        if (index != 2)
          return;
        this.z = value;
      }
    }
  }
}
