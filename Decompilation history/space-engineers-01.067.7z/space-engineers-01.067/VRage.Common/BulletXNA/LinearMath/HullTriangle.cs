﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.HullTriangle
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace BulletXNA.LinearMath
{
  public class HullTriangle : int3
  {
    public int3 n;
    public int id;
    public int vmax;
    public float rise;

    public HullTriangle(int a, int b, int c)
      : base(a, b, c)
    {
      this.n = new int3(-1, -1, -1);
      this.vmax = -1;
      this.rise = 0.0f;
    }

    public int Neib(int a, int b)
    {
      int num = -1;
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        int index3 = (index1 + 2) % 3;
        if (this.At(index1) == a && this.At(index2) == b || this.At(index1) == b && this.At(index2) == a)
          return this.n.At(index3);
      }
      return num;
    }

    public void Neib(int a, int b, int value)
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        int index2 = (index1 + 1) % 3;
        int index3 = (index1 + 2) % 3;
        if (this.At(index1) == a && this.At(index2) == b)
        {
          this.n.At(index3, value);
          break;
        }
        else if (this.At(index1) == b && this.At(index2) == a)
        {
          this.n.At(index3, value);
          break;
        }
      }
    }
  }
}
