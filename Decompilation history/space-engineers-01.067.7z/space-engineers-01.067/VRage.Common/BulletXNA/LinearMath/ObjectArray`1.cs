﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.LinearMath.ObjectArray`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace BulletXNA.LinearMath
{
  public class ObjectArray<T> : IList<T>, ICollection<T>, IEnumerable<T>, IList, ICollection, IEnumerable where T : new()
  {
    private static T[] _emptyArray = new T[0];
    private const int _defaultCapacity = 4;
    private T[] _items;
    private int _size;
    private object _syncRoot;
    private int _version;

    public int Capacity
    {
      get
      {
        return this._items.Length;
      }
      set
      {
        if (value == this._items.Length)
          return;
        if (value < this._size)
          throw new Exception("ExceptionResource ArgumentOutOfRange_SmallCapacity");
        if (value > 0)
        {
          T[] objArray = new T[value];
          if (this._size > 0)
            Array.Copy((Array) this._items, 0, (Array) objArray, 0, this._size);
          this._items = objArray;
        }
        else
          this._items = ObjectArray<T>._emptyArray;
      }
    }

    public int Count
    {
      get
      {
        return this._size;
      }
    }

    public T this[int index]
    {
      get
      {
        int num = index + 1 - this._size;
        for (int index1 = 0; index1 < num; ++index1)
          this.Add(new T());
        if (index >= this._size)
          throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException()");
        else
          return this._items[index];
      }
      set
      {
        int num = index + 1 - this._size;
        for (int index1 = 0; index1 < num; ++index1)
          this.Add(new T());
        if (index >= this._size)
          throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException()");
        this._items[index] = value;
        ++this._version;
      }
    }

    bool ICollection<T>.IsReadOnly
    {
      get
      {
        return false;
      }
    }

    bool ICollection.IsSynchronized
    {
      get
      {
        return false;
      }
    }

    object ICollection.SyncRoot
    {
      get
      {
        if (this._syncRoot == null)
          Interlocked.CompareExchange(ref this._syncRoot, new object(), (object) null);
        return this._syncRoot;
      }
    }

    bool IList.IsFixedSize
    {
      get
      {
        return false;
      }
    }

    bool IList.IsReadOnly
    {
      get
      {
        return false;
      }
    }

    object IList.this[int index]
    {
      get
      {
        int num = index + 1 - this._size;
        for (int index1 = 0; index1 < num; ++index1)
          this.Add(new T());
        return (object) this[index];
      }
      set
      {
        int num = index + 1 - this._size;
        for (int index1 = 0; index1 < num; ++index1)
          this.Add(new T());
        ObjectArray<T>.VerifyValueType(value);
        this[index] = (T) value;
      }
    }

    public ObjectArray()
    {
      this._items = ObjectArray<T>._emptyArray;
    }

    public ObjectArray(IEnumerable<T> collection)
    {
      if (collection == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.collection");
      ICollection<T> collection1 = collection as ICollection<T>;
      if (collection1 != null)
      {
        int count = collection1.Count;
        this._items = new T[count];
        collection1.CopyTo(this._items, 0);
        this._size = count;
      }
      else
      {
        this._size = 0;
        this._items = new T[4];
        foreach (T obj in collection)
          this.Add(obj);
      }
    }

    public ObjectArray(int capacity)
    {
      if (capacity < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.capacity, ExceptionResource.ArgumentOutOfRange_SmallCapacity");
      this._items = new T[capacity];
    }

    public T[] GetRawArray()
    {
      return this._items;
    }

    public void Add(T item)
    {
      if (this._size == this._items.Length)
        this.EnsureCapacity(this._size + 1);
      this._items[this._size++] = item;
      ++this._version;
    }

    public ReadOnlyCollection<T> AsReadOnly()
    {
      return new ReadOnlyCollection<T>((IList<T>) this);
    }

    public void Swap(int index0, int index1)
    {
      T obj = this._items[index0];
      this._items[index0] = this._items[index1];
      this._items[index1] = obj;
    }

    public void Resize(int newsize)
    {
      this.Resize(newsize, true);
    }

    public void Resize(int newsize, bool allocate)
    {
      int count = this.Count;
      if (newsize < count)
      {
        if (allocate)
        {
          for (int index = newsize; index < count; ++index)
            this._items[index] = new T();
        }
        else
        {
          for (int index = newsize; index < count; ++index)
            this._items[index] = default (T);
        }
      }
      else
      {
        if (newsize > this.Count)
          this.Capacity = newsize;
        if (allocate)
        {
          for (int index = count; index < newsize; ++index)
            this._items[index] = new T();
        }
      }
      this._size = newsize;
    }

    public int BinarySearch(T item)
    {
      return this.BinarySearch(0, this.Count, item, (IComparer<T>) null);
    }

    public int BinarySearch(T item, IComparer<T> comparer)
    {
      return this.BinarySearch(0, this.Count, item, comparer);
    }

    public int BinarySearch(int index, int count, T item, IComparer<T> comparer)
    {
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      else
        return Array.BinarySearch<T>(this._items, index, count, item, comparer);
    }

    public void Clear()
    {
      if (this._size > 0)
      {
        Array.Clear((Array) this._items, 0, this._size);
        this._size = 0;
      }
      ++this._version;
    }

    public bool Contains(T item)
    {
      if ((object) item == null)
      {
        for (int index = 0; index < this._size; ++index)
        {
          if ((object) this._items[index] == null)
            return true;
        }
        return false;
      }
      else
      {
        EqualityComparer<T> @default = EqualityComparer<T>.Default;
        for (int index = 0; index < this._size; ++index)
        {
          if (@default.Equals(this._items[index], item))
            return true;
        }
        return false;
      }
    }

    public ObjectArray<TOutput> ConvertAll<TOutput>(Converter<T, TOutput> converter) where TOutput : new()
    {
      if (converter == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.converter");
      ObjectArray<TOutput> objectArray = new ObjectArray<TOutput>(this._size);
      for (int index = 0; index < this._size; ++index)
        objectArray._items[index] = converter(this._items[index]);
      objectArray._size = this._size;
      return objectArray;
    }

    public void CopyTo(T[] array)
    {
      this.CopyTo(array, 0);
    }

    public void CopyTo(T[] array, int arrayIndex)
    {
      Array.Copy((Array) this._items, 0, (Array) array, arrayIndex, this._size);
    }

    public void CopyTo(int index, T[] array, int arrayIndex, int count)
    {
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      Array.Copy((Array) this._items, index, (Array) array, arrayIndex, count);
    }

    private void EnsureCapacity(int min)
    {
      if (this._items.Length >= min)
        return;
      int num = this._items.Length == 0 ? 4 : this._items.Length * 2;
      if (num < min)
        num = min;
      this.Capacity = num;
    }

    public bool Exists(Predicate<T> match)
    {
      return this.FindIndex(match) != -1;
    }

    public T Find(Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      for (int index = 0; index < this._size; ++index)
      {
        if (match(this._items[index]))
          return this._items[index];
      }
      return default (T);
    }

    public ObjectArray<T> FindAll(Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      ObjectArray<T> objectArray = new ObjectArray<T>();
      for (int index = 0; index < this._size; ++index)
      {
        if (match(this._items[index]))
          objectArray.Add(this._items[index]);
      }
      return objectArray;
    }

    public int FindIndex(Predicate<T> match)
    {
      return this.FindIndex(0, this._size, match);
    }

    public int FindIndex(int startIndex, Predicate<T> match)
    {
      return this.FindIndex(startIndex, this._size - startIndex, match);
    }

    public int FindIndex(int startIndex, int count, Predicate<T> match)
    {
      if (startIndex > this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.startIndex, ExceptionResource.ArgumentOutOfRange_Index");
      if (count < 0 || startIndex > this._size - count)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_Count");
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      int num = startIndex + count;
      for (int index = startIndex; index < num; ++index)
      {
        if (match(this._items[index]))
          return index;
      }
      return -1;
    }

    public T FindLast(Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      for (int index = this._size - 1; index >= 0; --index)
      {
        if (match(this._items[index]))
          return this._items[index];
      }
      return default (T);
    }

    public int FindLastIndex(Predicate<T> match)
    {
      return this.FindLastIndex(this._size - 1, this._size, match);
    }

    public int FindLastIndex(int startIndex, Predicate<T> match)
    {
      return this.FindLastIndex(startIndex, startIndex + 1, match);
    }

    public int FindLastIndex(int startIndex, int count, Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      if (this._size == 0)
      {
        if (startIndex != -1)
          throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.startIndex, ExceptionResource.ArgumentOutOfRange_Index");
      }
      else if (startIndex >= this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.startIndex, ExceptionResource.ArgumentOutOfRange_Index");
      if (count < 0 || startIndex - count + 1 < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_Count");
      int num = startIndex - count;
      for (int index = startIndex; index > num; --index)
      {
        if (match(this._items[index]))
          return index;
      }
      return -1;
    }

    public void ForEach(Action<T> action)
    {
      if (action == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      for (int index = 0; index < this._size; ++index)
        action(this._items[index]);
    }

    public ObjectArray<T> GetRange(int index, int count)
    {
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      ObjectArray<T> objectArray = new ObjectArray<T>(count);
      Array.Copy((Array) this._items, index, (Array) objectArray._items, 0, count);
      objectArray._size = count;
      return objectArray;
    }

    public int IndexOf(T item)
    {
      return Array.IndexOf<T>(this._items, item, 0, this._size);
    }

    public int IndexOf(T item, int index)
    {
      if (index > this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.index, ExceptionResource.ArgumentOutOfRange_Index");
      else
        return Array.IndexOf<T>(this._items, item, index, this._size - index);
    }

    public int IndexOf(T item, int index, int count)
    {
      if (index > this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.index, ExceptionResource.ArgumentOutOfRange_Index");
      if (count < 0 || index > this._size - count)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_Count");
      else
        return Array.IndexOf<T>(this._items, item, index, count);
    }

    public void Insert(int index, T item)
    {
      if (index > this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.index, ExceptionResource.ArgumentOutOfRange_ListInsert");
      if (this._size == this._items.Length)
        this.EnsureCapacity(this._size + 1);
      if (index < this._size)
        Array.Copy((Array) this._items, index, (Array) this._items, index + 1, this._size - index);
      this._items[index] = item;
      ++this._size;
      ++this._version;
    }

    private static bool IsCompatibleObject(object value)
    {
      return value is T || value == null && !typeof (T).IsValueType;
    }

    public int LastIndexOf(T item)
    {
      return this.LastIndexOf(item, this._size - 1, this._size);
    }

    public int LastIndexOf(T item, int index)
    {
      if (index >= this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument.index, ExceptionResource.ArgumentOutOfRange_Index");
      else
        return this.LastIndexOf(item, index, index + 1);
    }

    public int LastIndexOf(T item, int index, int count)
    {
      if (this._size == 0)
        return -1;
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (index >= this._size || count > index + 1)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index >= this._size) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_BiggerThanCollection");
      else
        return Array.LastIndexOf<T>(this._items, item, index, count);
    }

    public bool RemoveQuick(T item)
    {
      int index = this.IndexOf(item);
      if (index < 0)
        return false;
      if (this._size > 0)
        this._items[index] = this._items[this._size - 1];
      --this._size;
      return true;
    }

    public bool RemoveAtQuick(int index)
    {
      if (index < 0)
        return false;
      if (this._size > 0)
        this._items[index] = this._items[this._size - 1];
      --this._size;
      return true;
    }

    public bool Remove(T item)
    {
      int index = this.IndexOf(item);
      if (index < 0)
        return false;
      this.RemoveAt(index);
      return true;
    }

    public int RemoveAll(Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      int index1 = 0;
      while (index1 < this._size && !match(this._items[index1]))
        ++index1;
      if (index1 >= this._size)
        return 0;
      int index2 = index1 + 1;
      while (index2 < this._size)
      {
        while (index2 < this._size && match(this._items[index2]))
          ++index2;
        if (index2 < this._size)
          this._items[index1++] = this._items[index2++];
      }
      Array.Clear((Array) this._items, index1, this._size - index1);
      int num = this._size - index1;
      this._size = index1;
      ++this._version;
      return num;
    }

    public void RemoveAt(int index)
    {
      if (index >= this._size)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException");
      --this._size;
      if (index < this._size)
        Array.Copy((Array) this._items, index + 1, (Array) this._items, index, this._size - index);
      this._items[this._size] = default (T);
      ++this._version;
    }

    public void RemoveRange(int index, int count)
    {
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      if (count <= 0)
        return;
      this._size -= count;
      if (index < this._size)
        Array.Copy((Array) this._items, index + count, (Array) this._items, index, this._size - index);
      Array.Clear((Array) this._items, this._size, count);
      ++this._version;
    }

    public void Reverse()
    {
      this.Reverse(0, this.Count);
    }

    public void Reverse(int index, int count)
    {
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      Array.Reverse((Array) this._items, index, count);
      ++this._version;
    }

    public void Sort()
    {
      this.Sort(0, this.Count, (IComparer<T>) null);
    }

    public void Sort(IComparer<T> comparer)
    {
      this.Sort(0, this.Count, comparer);
    }

    public void Sort(Comparison<T> comparison)
    {
      if (comparison == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      if (this._size <= 0)
        return;
      Array.Sort<T>(this._items, 0, this._size, (IComparer<T>) new ObjectArray<T>.FunctorComparer(comparison));
    }

    public void Sort(int index, int count, IComparer<T> comparer)
    {
      if (index < 0 || count < 0)
        throw new Exception("ThrowHelper.ThrowArgumentOutOfRangeException((index < 0) ? ExceptionArgument.index : ExceptionArgument.count, ExceptionResource.ArgumentOutOfRange_NeedNonNegNum");
      if (this._size - index < count)
        throw new Exception("ExceptionResource  - Offlen");
      Array.Sort<T>(this._items, index, count, comparer);
      ++this._version;
    }

    IEnumerator<T> IEnumerable<T>.GetEnumerator()
    {
      return (IEnumerator<T>) new ObjectArray<T>.Enumerator(this);
    }

    void ICollection.CopyTo(Array array, int arrayIndex)
    {
      if (array != null)
      {
        if (array.Rank != 1)
          throw new Exception("ThrowHelper.ThrowArgumentException(ExceptionResource.Arg_RankMultiDimNotSupported");
      }
      try
      {
        Array.Copy((Array) this._items, 0, array, arrayIndex, this._size);
      }
      catch (ArrayTypeMismatchException ex)
      {
        throw new Exception("ThrowHelper.ThrowArgumentException(ExceptionResource.Argument_InvalidArrayType");
      }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      return (IEnumerator) new ObjectArray<T>.Enumerator(this);
    }

    int IList.Add(object item)
    {
      ObjectArray<T>.VerifyValueType(item);
      this.Add((T) item);
      return this.Count - 1;
    }

    bool IList.Contains(object item)
    {
      if (ObjectArray<T>.IsCompatibleObject(item))
        return this.Contains((T) item);
      else
        return false;
    }

    int IList.IndexOf(object item)
    {
      if (ObjectArray<T>.IsCompatibleObject(item))
        return this.IndexOf((T) item);
      else
        return -1;
    }

    void IList.Insert(int index, object item)
    {
      ObjectArray<T>.VerifyValueType(item);
      this.Insert(index, (T) item);
    }

    void IList.Remove(object item)
    {
      if (!ObjectArray<T>.IsCompatibleObject(item))
        return;
      this.Remove((T) item);
    }

    public T[] ToArray()
    {
      T[] objArray = new T[this._size];
      Array.Copy((Array) this._items, 0, (Array) objArray, 0, this._size);
      return objArray;
    }

    public void TrimExcess()
    {
      if (this._size >= (int) ((double) this._items.Length * 0.9))
        return;
      this.Capacity = this._size;
    }

    public bool TrueForAll(Predicate<T> match)
    {
      if (match == null)
        throw new Exception("ThrowHelper.ThrowArgumentNullException(ExceptionArgument.match");
      for (int index = 0; index < this._size; ++index)
      {
        if (!match(this._items[index]))
          return false;
      }
      return true;
    }

    private static void VerifyValueType(object value)
    {
      if (!ObjectArray<T>.IsCompatibleObject(value))
        throw new Exception("ThrowHelper.ThrowWrongValueTypeArgumentException(value, typeof(T)");
    }

    private void checkAndGrow(int newSize)
    {
      int num = newSize + 1 - this._size;
      for (int index = 0; index < num; ++index)
        this.Add(new T());
    }

    public struct Enumerator : IEnumerator<T>, IDisposable, IEnumerator
    {
      private ObjectArray<T> list;
      private int index;
      private int version;
      private T current;

      public T Current
      {
        get
        {
          return this.current;
        }
      }

      object IEnumerator.Current
      {
        get
        {
          if (this.index == 0 || this.index == this.list._size + 1)
            throw new Exception("InvalidOperation EnumOpCantHappen");
          else
            return (object) this.Current;
        }
      }

      internal Enumerator(ObjectArray<T> list)
      {
        this.list = list;
        this.index = 0;
        this.version = list._version;
        this.current = default (T);
      }

      public void Dispose()
      {
      }

      public bool MoveNext()
      {
        ObjectArray<T> objectArray = this.list;
        if (this.version != objectArray._version || this.index >= objectArray._size)
          return this.MoveNextRare();
        this.current = objectArray._items[this.index];
        ++this.index;
        return true;
      }

      private bool MoveNextRare()
      {
        if (this.version != this.list._version)
          throw new Exception("InvalidOperation EnumFailedVersion");
        this.index = this.list._size + 1;
        this.current = default (T);
        return false;
      }

      void IEnumerator.Reset()
      {
        if (this.version != this.list._version)
          throw new Exception("InvalidOperation EnumFailedVersion");
        this.index = 0;
        this.current = default (T);
      }
    }

    internal sealed class FunctorComparer : IComparer<T>
    {
      private Comparer<T> c;
      private Comparison<T> comparison;

      public FunctorComparer(Comparison<T> comparison)
      {
        this.c = Comparer<T>.Default;
        this.comparison = comparison;
      }

      public int Compare(T x, T y)
      {
        return this.comparison(x, y);
      }
    }
  }
}
