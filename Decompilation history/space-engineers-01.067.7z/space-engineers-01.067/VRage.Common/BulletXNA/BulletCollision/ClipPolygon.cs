﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.ClipPolygon
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using VRageMath;

namespace BulletXNA.BulletCollision
{
  public class ClipPolygon
  {
    public static float DistancePointPlane(ref Vector4 plane, ref IndexedVector3 point)
    {
      return point.Dot(new IndexedVector3(plane.X, plane.Y, plane.Z)) - plane.W;
    }

    public static void VecBlend(ref IndexedVector3 vr, ref IndexedVector3 va, ref IndexedVector3 vb, float blend_factor)
    {
      vr = (1f - blend_factor) * va + blend_factor * vb;
    }

    public static void PlaneClipPolygonCollect(ref IndexedVector3 point0, ref IndexedVector3 point1, float dist0, float dist1, ObjectArray<IndexedVector3> clipped, ref int clipped_count)
    {
      bool flag1 = (double) dist0 > 1.19209289550781E-07;
      bool flag2 = (double) dist1 > 1.19209289550781E-07;
      if (flag2 != flag1)
      {
        float blend_factor = (float) (-(double) dist0 / ((double) dist1 - (double) dist0));
        ClipPolygon.VecBlend(ref clipped.GetRawArray()[clipped_count], ref point0, ref point1, blend_factor);
        ++clipped_count;
      }
      if (flag2)
        return;
      clipped[clipped_count] = point1;
      ++clipped_count;
    }

    public static int PlaneClipPolygon(ref Vector4 plane, ObjectArray<IndexedVector3> polygon_points, int polygon_point_count, ObjectArray<IndexedVector3> clipped)
    {
      int clipped_count = 0;
      IndexedVector3[] rawArray = polygon_points.GetRawArray();
      float dist1_1 = ClipPolygon.DistancePointPlane(ref plane, ref rawArray[0]);
      if ((double) dist1_1 <= 1.19209289550781E-07)
      {
        clipped[clipped_count] = polygon_points[0];
        ++clipped_count;
      }
      float dist0 = dist1_1;
      for (int index = 1; index < polygon_point_count; ++index)
      {
        float dist1_2 = ClipPolygon.DistancePointPlane(ref plane, ref rawArray[index]);
        ClipPolygon.PlaneClipPolygonCollect(ref rawArray[index - 1], ref rawArray[index], dist0, dist1_2, clipped, ref clipped_count);
        dist0 = dist1_2;
      }
      ClipPolygon.PlaneClipPolygonCollect(ref rawArray[polygon_point_count - 1], ref rawArray[0], dist0, dist1_1, clipped, ref clipped_count);
      return clipped_count;
    }

    public static int PlaneClipTriangle(ref Vector4 plane, ref IndexedVector3 point0, ref IndexedVector3 point1, ref IndexedVector3 point2, ObjectArray<IndexedVector3> clipped)
    {
      int clipped_count = 0;
      float dist1_1 = ClipPolygon.DistancePointPlane(ref plane, ref point0);
      if ((double) dist1_1 <= 1.19209289550781E-07)
      {
        clipped[clipped_count] = point0;
        ++clipped_count;
      }
      float dist0_1 = dist1_1;
      float dist1_2 = ClipPolygon.DistancePointPlane(ref plane, ref point1);
      ClipPolygon.PlaneClipPolygonCollect(ref point0, ref point1, dist0_1, dist1_2, clipped, ref clipped_count);
      float dist0_2 = dist1_2;
      float dist1_3 = ClipPolygon.DistancePointPlane(ref plane, ref point2);
      ClipPolygon.PlaneClipPolygonCollect(ref point1, ref point2, dist0_2, dist1_3, clipped, ref clipped_count);
      float dist0_3 = dist1_3;
      ClipPolygon.PlaneClipPolygonCollect(ref point2, ref point0, dist0_3, dist1_1, clipped, ref clipped_count);
      return clipped_count;
    }
  }
}
