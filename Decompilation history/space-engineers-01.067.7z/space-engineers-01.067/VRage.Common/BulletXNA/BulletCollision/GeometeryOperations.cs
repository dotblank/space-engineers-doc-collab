﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.GeometeryOperations
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using VRageMath;

namespace BulletXNA.BulletCollision
{
  public class GeometeryOperations
  {
    public static void bt_edge_plane(ref IndexedVector3 e1, ref IndexedVector3 e2, ref IndexedVector3 normal, out Vector4 plane)
    {
      IndexedVector3 v = (e2 - e1).Cross(ref normal);
      v.Normalize();
      plane = new Vector4(v.ToVector3(), e2.Dot(ref v));
    }
  }
}
