﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.GImpactBvh
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;

namespace BulletXNA.BulletCollision
{
  public class GImpactBvh
  {
    protected BvhTree m_box_tree;
    protected IPrimitiveManagerBase m_primitive_manager;

    public GImpactBvh()
    {
      this.m_primitive_manager = (IPrimitiveManagerBase) null;
    }

    public GImpactBvh(IPrimitiveManagerBase primitive_manager)
    {
      this.m_primitive_manager = primitive_manager;
    }

    protected void Refit()
    {
      int nodeCount = this.GetNodeCount();
      while (nodeCount-- != 0)
      {
        if (this.IsLeafNode(nodeCount))
        {
          AABB primbox;
          this.m_primitive_manager.GetPrimitiveBox(this.GetNodeData(nodeCount), out primbox);
          this.SetNodeBound(nodeCount, ref primbox);
        }
        else
        {
          AABB bound1 = new AABB();
          bound1.Invalidate();
          int leftNode = this.GetLeftNode(nodeCount);
          AABB bound2;
          if (leftNode != 0)
          {
            this.GetNodeBound(leftNode, out bound2);
            bound1.Merge(ref bound2);
          }
          int rightNode = this.GetRightNode(nodeCount);
          if (rightNode != 0)
          {
            this.GetNodeBound(rightNode, out bound2);
            bound1.Merge(ref bound2);
          }
          this.SetNodeBound(nodeCount, ref bound1);
        }
      }
    }

    public AABB GetGlobalBox()
    {
      AABB bound;
      this.GetNodeBound(0, out bound);
      return bound;
    }

    public void SetPrimitiveManager(IPrimitiveManagerBase primitive_manager)
    {
      this.m_primitive_manager = primitive_manager;
    }

    public IPrimitiveManagerBase GetPrimitiveManager()
    {
      return this.m_primitive_manager;
    }

    public void Update()
    {
      this.Refit();
    }

    public void BuildSet()
    {
      GIM_BVH_DATA_ARRAY primitive_boxes = new GIM_BVH_DATA_ARRAY();
      primitive_boxes.Capacity = this.m_primitive_manager.GetPrimitiveCount();
      for (int prim_index = 0; prim_index < primitive_boxes.Count; ++prim_index)
      {
        this.m_primitive_manager.GetPrimitiveBox(prim_index, out primitive_boxes.GetRawArray()[prim_index].m_bound);
        primitive_boxes.GetRawArray()[prim_index].m_data = prim_index;
      }
      this.m_box_tree.BuildTree(primitive_boxes);
    }

    public bool BoxQuery(ref AABB box, ObjectArray<int> collided_results)
    {
      int nodeindex = 0;
      int nodeCount = this.GetNodeCount();
      while (nodeindex < nodeCount)
      {
        AABB bound = new AABB();
        this.GetNodeBound(nodeindex, out bound);
        bool flag1 = bound.HasCollision(ref box);
        bool flag2 = this.IsLeafNode(nodeindex);
        if (flag2 && flag1)
          collided_results.Add(this.GetNodeData(nodeindex));
        if (flag1 || flag2)
          ++nodeindex;
        else
          nodeindex += this.GetEscapeNodeIndex(nodeindex);
      }
      return collided_results.Count > 0;
    }

    public bool BoxQueryTrans(ref AABB box, ref IndexedMatrix transform, ObjectArray<int> collided_results)
    {
      AABB box1 = box;
      box1.ApplyTransform(ref transform);
      return this.BoxQuery(ref box1, collided_results);
    }

    public bool RayQuery(ref IndexedVector3 ray_dir, ref IndexedVector3 ray_origin, ObjectArray<int> collided_results)
    {
      int nodeindex = 0;
      int nodeCount = this.GetNodeCount();
      while (nodeindex < nodeCount)
      {
        AABB bound = new AABB();
        this.GetNodeBound(nodeindex, out bound);
        bool flag1 = bound.CollideRay(ref ray_origin, ref ray_dir);
        bool flag2 = this.IsLeafNode(nodeindex);
        if (flag2 && flag1)
          collided_results.Add(this.GetNodeData(nodeindex));
        if (flag1 || flag2)
          ++nodeindex;
        else
          nodeindex += this.GetEscapeNodeIndex(nodeindex);
      }
      return collided_results.Count > 0;
    }

    public bool HasHierarchy()
    {
      return true;
    }

    public bool IsTrimesh()
    {
      return this.m_primitive_manager.IsTrimesh();
    }

    public int GetNodeCount()
    {
      return this.m_box_tree.GetNodeCount();
    }

    public bool IsLeafNode(int nodeindex)
    {
      return this.m_box_tree.IsLeafNode(nodeindex);
    }

    public int GetNodeData(int nodeindex)
    {
      return this.m_box_tree.GetNodeData(nodeindex);
    }

    public void GetNodeBound(int nodeindex, out AABB bound)
    {
      this.m_box_tree.GetNodeBound(nodeindex, out bound);
    }

    public void SetNodeBound(int nodeindex, ref AABB bound)
    {
      this.m_box_tree.SetNodeBound(nodeindex, ref bound);
    }

    public int GetLeftNode(int nodeindex)
    {
      return this.m_box_tree.GetLeftNode(nodeindex);
    }

    public int GetRightNode(int nodeindex)
    {
      return this.m_box_tree.GetRightNode(nodeindex);
    }

    public int GetEscapeNodeIndex(int nodeindex)
    {
      return this.m_box_tree.GetEscapeNodeIndex(nodeindex);
    }

    public void GetNodeTriangle(int nodeindex, PrimitiveTriangle triangle)
    {
      this.m_primitive_manager.GetPrimitiveTriangle(this.GetNodeData(nodeindex), triangle);
    }

    public static float GetAverageTreeCollisionTime()
    {
      return 0.0f;
    }

    public static void FindCollision(GImpactBvh boxset1, ref IndexedMatrix trans1, GImpactBvh boxset2, ref IndexedMatrix trans2, PairSet collision_pairs)
    {
      if (boxset1.GetNodeCount() == 0 || boxset2.GetNodeCount() == 0)
        return;
      BT_BOX_BOX_TRANSFORM_CACHE trans_cache_1to0 = new BT_BOX_BOX_TRANSFORM_CACHE();
      trans_cache_1to0.CalcFromHomogenic(ref trans1, ref trans2);
      GImpactBvh.FindCollisionPairsRecursive(boxset1, boxset2, collision_pairs, trans_cache_1to0, 0, 0, true);
    }

    public static bool NodeCollision(GImpactBvh boxset0, GImpactBvh boxset1, ref BT_BOX_BOX_TRANSFORM_CACHE trans_cache_1to0, int node0, int node1, bool complete_primitive_tests)
    {
      AABB bound1;
      boxset0.GetNodeBound(node0, out bound1);
      AABB bound2;
      boxset1.GetNodeBound(node1, out bound2);
      return bound1.OverlappingTransCache(ref bound2, ref trans_cache_1to0, complete_primitive_tests);
    }

    public static void FindCollisionPairsRecursive(GImpactBvh boxset0, GImpactBvh boxset1, PairSet collision_pairs, BT_BOX_BOX_TRANSFORM_CACHE trans_cache_1to0, int node0, int node1, bool complete_primitive_tests)
    {
      if (!GImpactBvh.NodeCollision(boxset0, boxset1, ref trans_cache_1to0, node0, node1, complete_primitive_tests))
        return;
      if (boxset0.IsLeafNode(node0))
      {
        if (boxset1.IsLeafNode(node1))
        {
          collision_pairs.PushPair(boxset0.GetNodeData(node0), boxset1.GetNodeData(node1));
        }
        else
        {
          GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, node0, boxset1.GetLeftNode(node1), false);
          GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, node0, boxset1.GetRightNode(node1), false);
        }
      }
      else if (boxset1.IsLeafNode(node1))
      {
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetLeftNode(node0), node1, false);
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetRightNode(node0), node1, false);
      }
      else
      {
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetLeftNode(node0), boxset1.GetLeftNode(node1), false);
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetLeftNode(node0), boxset1.GetRightNode(node1), false);
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetRightNode(node0), boxset1.GetLeftNode(node1), false);
        GImpactBvh.FindCollisionPairsRecursive(boxset0, boxset1, collision_pairs, trans_cache_1to0, boxset0.GetRightNode(node0), boxset1.GetRightNode(node1), false);
      }
    }
  }
}
