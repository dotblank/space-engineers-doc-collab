﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.GIM_TRIANGLE_CONTACT
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using VRageMath;

namespace BulletXNA.BulletCollision
{
  public class GIM_TRIANGLE_CONTACT
  {
    public IndexedVector3[] m_points = new IndexedVector3[16];
    public const int MAX_TRI_CLIPPING = 16;
    public float m_penetration_depth;
    public int m_point_count;
    public Vector4 m_separating_normal;

    public GIM_TRIANGLE_CONTACT()
    {
    }

    public GIM_TRIANGLE_CONTACT(GIM_TRIANGLE_CONTACT other)
    {
      this.CopyFrom(other);
    }

    public void CopyFrom(GIM_TRIANGLE_CONTACT other)
    {
      this.m_penetration_depth = other.m_penetration_depth;
      this.m_separating_normal = other.m_separating_normal;
      this.m_point_count = other.m_point_count;
      int index = this.m_point_count;
      while (index-- != 0)
        this.m_points[index] = other.m_points[index];
    }

    public void MergePoints(ref Vector4 plane, float margin, ObjectArray<IndexedVector3> points, int point_count)
    {
      this.m_point_count = 0;
      this.m_penetration_depth = -1000f;
      int[] numArray = new int[16];
      for (int index = 0; index < point_count; ++index)
      {
        float num = -ClipPolygon.DistancePointPlane(ref plane, ref points.GetRawArray()[index]) + margin;
        if ((double) num >= 0.0)
        {
          if ((double) num > (double) this.m_penetration_depth)
          {
            this.m_penetration_depth = num;
            numArray[0] = index;
            this.m_point_count = 1;
          }
          else if ((double) num + 1.19209289550781E-07 >= (double) this.m_penetration_depth)
          {
            numArray[this.m_point_count] = index;
            ++this.m_point_count;
          }
        }
      }
      for (int index = 0; index < this.m_point_count; ++index)
        this.m_points[index] = points[numArray[index]];
    }
  }
}
