﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.BvhTree
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA;
using BulletXNA.LinearMath;

namespace BulletXNA.BulletCollision
{
  public class BvhTree
  {
    protected GIM_BVH_TREE_NODE_ARRAY m_node_array = new GIM_BVH_TREE_NODE_ARRAY();
    protected int m_num_nodes;

    public BvhTree()
    {
      this.m_num_nodes = 0;
    }

    protected int SortAndCalcSplittingIndex(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex, int splitAxis)
    {
      int index1 = startIndex;
      int num1 = endIndex - startIndex;
      IndexedVector3 zero = IndexedVector3.Zero;
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min);
        zero += indexedVector3;
      }
      float num2 = (zero * (1f / (float) num1))[splitAxis];
      for (int index0 = startIndex; index0 < endIndex; ++index0)
      {
        if ((double) (0.5f * (primitive_boxes[index0].m_bound.m_max + primitive_boxes[index0].m_bound.m_min))[splitAxis] > (double) num2)
        {
          primitive_boxes.Swap(index0, index1);
          ++index1;
        }
      }
      int num3 = num1 / 3;
      if (index1 <= startIndex + num3 || index1 >= endIndex - 1 - num3)
        index1 = startIndex + (num1 >> 1);
      return index1;
    }

    protected int CalcSplittingAxis(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex)
    {
      IndexedVector3 zero1 = IndexedVector3.Zero;
      IndexedVector3 zero2 = IndexedVector3.Zero;
      int num = endIndex - startIndex;
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min);
        zero1 += indexedVector3;
      }
      IndexedVector3 indexedVector3_1 = zero1 * (1f / (float) num);
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3_2 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min) - indexedVector3_1;
        IndexedVector3 indexedVector3_3 = indexedVector3_2 * indexedVector3_2;
        zero2 += indexedVector3_3;
      }
      IndexedVector3 a = zero2 * (float) (1.0 / ((double) num - 1.0));
      return MathUtil.MaxAxis(ref a);
    }

    protected void BuildSubTree(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex)
    {
      int nodeindex = this.m_num_nodes;
      ++this.m_num_nodes;
      if (endIndex - startIndex == 1)
      {
        this.SetNodeBound(nodeindex, ref primitive_boxes.GetRawArray()[startIndex].m_bound);
        this.m_node_array[nodeindex].SetDataIndex(primitive_boxes[startIndex].m_data);
      }
      else
      {
        int splitAxis = this.CalcSplittingAxis(primitive_boxes, startIndex, endIndex);
        int num = this.SortAndCalcSplittingIndex(primitive_boxes, startIndex, endIndex, splitAxis);
        AABB bound = new AABB();
        bound.Invalidate();
        for (int index = startIndex; index < endIndex; ++index)
          bound.Merge(ref primitive_boxes.GetRawArray()[index].m_bound);
        this.SetNodeBound(nodeindex, ref bound);
        this.BuildSubTree(primitive_boxes, startIndex, num);
        this.BuildSubTree(primitive_boxes, num, endIndex);
        this.m_node_array[nodeindex].SetEscapeIndex(this.m_num_nodes - nodeindex);
      }
    }

    public void BuildTree(GIM_BVH_DATA_ARRAY primitive_boxes)
    {
      this.m_num_nodes = 0;
      this.m_node_array.Capacity = primitive_boxes.Count * 2;
      this.BuildSubTree(primitive_boxes, 0, primitive_boxes.Count);
    }

    public void ClearNodes()
    {
      this.m_node_array.Clear();
      this.m_num_nodes = 0;
    }

    public int GetNodeCount()
    {
      return this.m_num_nodes;
    }

    public bool IsLeafNode(int nodeindex)
    {
      return this.m_node_array[nodeindex].IsLeafNode();
    }

    public int GetNodeData(int nodeindex)
    {
      return this.m_node_array[nodeindex].GetDataIndex();
    }

    public void GetNodeBound(int nodeindex, out AABB bound)
    {
      bound = this.m_node_array[nodeindex].m_bound;
    }

    public void SetNodeBound(int nodeindex, ref AABB bound)
    {
      this.m_node_array[nodeindex].m_bound = bound;
    }

    public int GetLeftNode(int nodeindex)
    {
      return nodeindex + 1;
    }

    public int GetRightNode(int nodeindex)
    {
      if (this.m_node_array[nodeindex + 1].IsLeafNode())
        return nodeindex + 2;
      else
        return nodeindex + 1 + this.m_node_array[nodeindex + 1].GetEscapeIndex();
    }

    public int GetEscapeNodeIndex(int nodeindex)
    {
      return this.m_node_array[nodeindex].GetEscapeIndex();
    }
  }
}
