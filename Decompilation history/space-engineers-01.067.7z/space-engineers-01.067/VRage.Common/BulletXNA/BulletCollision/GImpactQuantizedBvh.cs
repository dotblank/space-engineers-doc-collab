﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.GImpactQuantizedBvh
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System.IO;

namespace BulletXNA.BulletCollision
{
  public class GImpactQuantizedBvh
  {
    protected QuantizedBvhTree m_box_tree;
    protected IPrimitiveManagerBase m_primitive_manager;
    protected int m_size;

    public int Size
    {
      get
      {
        return this.m_size;
      }
    }

    public GImpactQuantizedBvh()
    {
      this.m_box_tree = new QuantizedBvhTree();
    }

    public GImpactQuantizedBvh(IPrimitiveManagerBase primitive_manager)
    {
      this.m_primitive_manager = primitive_manager;
      this.m_box_tree = new QuantizedBvhTree();
    }

    private static bool QuantizedNodeCollision(GImpactQuantizedBvh boxset0, GImpactQuantizedBvh boxset1, BT_BOX_BOX_TRANSFORM_CACHE trans_cache_1to0, int node0, int node1, bool complete_primitive_tests)
    {
      AABB bound1;
      boxset0.GetNodeBound(node0, out bound1);
      AABB bound2;
      boxset1.GetNodeBound(node1, out bound2);
      return bound1.OverlappingTransCache(ref bound2, ref trans_cache_1to0, complete_primitive_tests);
    }

    public byte[] Save()
    {
      return this.m_box_tree.Save();
    }

    public void Load(byte[] byteArray)
    {
      this.m_box_tree.Load(byteArray);
      this.m_size = byteArray.Length;
    }

    public AABB GetGlobalBox()
    {
      AABB bound;
      this.GetNodeBound(0, out bound);
      return bound;
    }

    public void SetPrimitiveManager(IPrimitiveManagerBase primitive_manager)
    {
      this.m_primitive_manager = primitive_manager;
    }

    public IPrimitiveManagerBase GetPrimitiveManager()
    {
      return this.m_primitive_manager;
    }

    public void BuildSet()
    {
      int primitiveCount = this.m_primitive_manager.GetPrimitiveCount();
      GIM_BVH_DATA_ARRAY primitive_boxes = new GIM_BVH_DATA_ARRAY(primitiveCount);
      primitive_boxes.Resize(primitiveCount);
      GIM_BVH_DATA[] rawArray = primitive_boxes.GetRawArray();
      for (int prim_index = 0; prim_index < primitiveCount; ++prim_index)
      {
        this.m_primitive_manager.GetPrimitiveBox(prim_index, out rawArray[prim_index].m_bound);
        rawArray[prim_index].m_data = prim_index;
      }
      this.m_box_tree.BuildTree(primitive_boxes);
    }

    public bool BoxQuery(ref AABB box, ObjectArray<int> collided_results)
    {
      return this.BoxQuery(ref box, collided_results, false);
    }

    public bool BoxQuery(ref AABB box, ObjectArray<int> collided_results, bool graphics)
    {
      int num1 = 0;
      int nodeCount = this.GetNodeCount();
      StreamWriter streamWriter1 = BulletGlobals.g_streamWriter;
      UShortVector3 quantizedpoint1;
      this.m_box_tree.QuantizePoint(out quantizedpoint1, ref box.m_min);
      UShortVector3 quantizedpoint2;
      this.m_box_tree.QuantizePoint(out quantizedpoint2, ref box.m_max);
      while (num1 < nodeCount)
      {
        bool flag1 = this.m_box_tree.TestQuantizedBoxOverlap(num1, ref quantizedpoint1, ref quantizedpoint2);
        bool flag2 = this.IsLeafNode(num1);
        StreamWriter streamWriter2 = BulletGlobals.g_streamWriter;
        if (flag2 && flag1)
        {
          foreach (int num2 in this.GetNodeData(num1))
            collided_results.Add(num2);
        }
        if (flag1 || flag2)
          ++num1;
        else
          num1 += this.GetEscapeNodeIndex(num1);
      }
      return collided_results.Count > 0;
    }

    public bool BoxQueryTrans(ref AABB box, ref IndexedMatrix transform, ObjectArray<int> collided_results)
    {
      AABB box1 = box;
      box1.ApplyTransform(ref transform);
      return this.BoxQuery(ref box1, collided_results);
    }

    public bool RayQueryClosest(ref IndexedVector3 ray_dir, ref IndexedVector3 ray_origin, ProcessCollisionHandler handler)
    {
      int nodeindex = 0;
      int nodeCount = this.GetNodeCount();
      float num = float.PositiveInfinity;
      while (nodeindex < nodeCount)
      {
        AABB bound;
        this.GetNodeBound(nodeindex, out bound);
        float? nullable1 = bound.CollideRayDistance(ref ray_origin, ref ray_dir);
        bool flag1 = this.IsLeafNode(nodeindex);
        bool flag2 = nullable1.HasValue && (double) nullable1.Value < (double) num;
        if (flag2 && flag1)
        {
          foreach (int triangleIndex in this.GetNodeData(nodeindex))
          {
            float? nullable2 = handler(triangleIndex);
            if (nullable2.HasValue && (double) nullable2.Value < (double) num)
              num = nullable2.Value;
          }
        }
        if (flag2 || flag1)
          ++nodeindex;
        else
          nodeindex += this.GetEscapeNodeIndex(nodeindex);
      }
      return (double) num != double.PositiveInfinity;
    }

    public bool RayQuery(ref IndexedVector3 ray_dir, ref IndexedVector3 ray_origin, ProcessCollisionHandler handler)
    {
      int nodeindex = 0;
      int nodeCount = this.GetNodeCount();
      bool flag1 = false;
      while (nodeindex < nodeCount)
      {
        AABB bound;
        this.GetNodeBound(nodeindex, out bound);
        bool flag2 = bound.CollideRay(ref ray_origin, ref ray_dir);
        bool flag3 = this.IsLeafNode(nodeindex);
        if (flag3 && flag2)
        {
          foreach (int triangleIndex in this.GetNodeData(nodeindex))
          {
            float? nullable = handler(triangleIndex);
            flag1 = true;
          }
        }
        if (flag2 || flag3)
          ++nodeindex;
        else
          nodeindex += this.GetEscapeNodeIndex(nodeindex);
      }
      return flag1;
    }

    public bool HasHierarchy()
    {
      return true;
    }

    public bool IsTrimesh()
    {
      return this.m_primitive_manager.IsTrimesh();
    }

    public int GetNodeCount()
    {
      return this.m_box_tree.GetNodeCount();
    }

    public bool IsLeafNode(int nodeindex)
    {
      return this.m_box_tree.IsLeafNode(nodeindex);
    }

    public int[] GetNodeData(int nodeindex)
    {
      return this.m_box_tree.GetNodeData(nodeindex);
    }

    public void GetNodeBound(int nodeindex, out AABB bound)
    {
      this.m_box_tree.GetNodeBound(nodeindex, out bound);
    }

    public void SetNodeBound(int nodeindex, ref AABB bound)
    {
      this.m_box_tree.SetNodeBound(nodeindex, ref bound);
    }

    public int GetLeftNode(int nodeindex)
    {
      return this.m_box_tree.GetLeftNode(nodeindex);
    }

    public int GetRightNode(int nodeindex)
    {
      return this.m_box_tree.GetRightNode(nodeindex);
    }

    public int GetEscapeNodeIndex(int nodeindex)
    {
      return this.m_box_tree.GetEscapeNodeIndex(nodeindex);
    }

    public static float GetAverageTreeCollisionTime()
    {
      return 1f;
    }
  }
}
