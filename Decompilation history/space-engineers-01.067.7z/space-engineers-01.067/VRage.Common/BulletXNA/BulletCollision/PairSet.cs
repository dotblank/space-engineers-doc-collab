﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.PairSet
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;

namespace BulletXNA.BulletCollision
{
  public class PairSet : ObjectArray<GIM_PAIR>
  {
    public PairSet()
      : base(32)
    {
    }

    public void PushPair(int index1, int index2)
    {
      this.Add(new GIM_PAIR(index1, index2));
    }

    public void PushPairInv(int index1, int index2)
    {
      this.Add(new GIM_PAIR(index2, index1));
    }
  }
}
