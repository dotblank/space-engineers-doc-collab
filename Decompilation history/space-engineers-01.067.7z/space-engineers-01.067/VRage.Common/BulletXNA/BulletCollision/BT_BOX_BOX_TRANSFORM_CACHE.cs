﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.BT_BOX_BOX_TRANSFORM_CACHE
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System;

namespace BulletXNA.BulletCollision
{
  public struct BT_BOX_BOX_TRANSFORM_CACHE
  {
    public IndexedVector3 m_T1to0;
    public IndexedBasisMatrix m_R1to0;
    public IndexedBasisMatrix m_AR;

    public void CalcAbsoluteMatrix()
    {
      for (int index1 = 0; index1 < 3; ++index1)
      {
        for (int index2 = 0; index2 < 3; ++index2)
          this.m_AR[index1, index2] = 1E-06f + Math.Abs(this.m_R1to0[index1, index2]);
      }
    }

    public void CalcFromHomogenic(ref IndexedMatrix trans0, ref IndexedMatrix trans1)
    {
      IndexedMatrix indexedMatrix = trans0.Inverse() * trans1;
      this.m_T1to0 = indexedMatrix._origin;
      this.m_R1to0 = indexedMatrix._basis;
      this.CalcAbsoluteMatrix();
    }

    public void CalcFromFullInvert(ref IndexedMatrix trans0, ref IndexedMatrix trans1)
    {
      this.m_R1to0 = trans0._basis.Inverse();
      this.m_T1to0 = this.m_R1to0 * -trans0._origin;
      this.m_T1to0 += this.m_R1to0 * trans1._origin;
      this.m_R1to0 *= trans1._basis;
      this.CalcAbsoluteMatrix();
    }

    public IndexedVector3 Transform(ref IndexedVector3 point)
    {
      return new IndexedVector3(this.m_R1to0[0].Dot(ref point) + this.m_T1to0.X, this.m_R1to0[1].Dot(ref point) + this.m_T1to0.Y, this.m_R1to0[2].Dot(ref point) + this.m_T1to0.Z);
    }
  }
}
