﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.BT_QUANTIZED_BVH_NODE
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;

namespace BulletXNA.BulletCollision
{
  public class BT_QUANTIZED_BVH_NODE
  {
    public UShortVector3 m_quantizedAabbMin;
    public UShortVector3 m_quantizedAabbMax;
    public int[] m_escapeIndexOrDataIndex;

    public bool IsLeafNode()
    {
      return this.m_escapeIndexOrDataIndex[0] >= 0;
    }

    public int GetEscapeIndex()
    {
      if (this.m_escapeIndexOrDataIndex != null)
        return -this.m_escapeIndexOrDataIndex[0];
      else
        return 0;
    }

    public void SetEscapeIndex(int index)
    {
      this.m_escapeIndexOrDataIndex = new int[1]
      {
        -index
      };
    }

    public void SetDataIndices(int[] indices)
    {
      this.m_escapeIndexOrDataIndex = indices;
    }

    public int[] GetDataIndices()
    {
      return this.m_escapeIndexOrDataIndex;
    }

    public bool TestQuantizedBoxOverlapp(ref UShortVector3 quantizedMin, ref UShortVector3 quantizedMax)
    {
      return (int) this.m_quantizedAabbMin.X <= (int) quantizedMax.X && (int) this.m_quantizedAabbMax.X >= (int) quantizedMin.X && ((int) this.m_quantizedAabbMin.Y <= (int) quantizedMax.Y && (int) this.m_quantizedAabbMax.Y >= (int) quantizedMin.Y) && ((int) this.m_quantizedAabbMin.Z <= (int) quantizedMax.Z && (int) this.m_quantizedAabbMax.Z >= (int) quantizedMin.Z);
    }
  }
}
