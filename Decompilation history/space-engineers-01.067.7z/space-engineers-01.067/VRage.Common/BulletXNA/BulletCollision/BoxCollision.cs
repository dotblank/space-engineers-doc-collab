﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.BoxCollision
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using System;

namespace BulletXNA.BulletCollision
{
  public class BoxCollision
  {
    public const float BOX_PLANE_EPSILON = 1E-06f;

    public static bool BT_GREATER(float x, float y)
    {
      return (double) Math.Abs(x) > (double) y;
    }

    public static float BT_MAX(float a, float b)
    {
      return Math.Max(a, b);
    }

    public static float BT_MIN(float a, float b)
    {
      return Math.Min(a, b);
    }

    public static float BT_MAX3(float a, float b, float c)
    {
      return Math.Max(a, Math.Max(b, c));
    }

    public static float BT_MIN3(float a, float b, float c)
    {
      return Math.Min(a, Math.Min(b, c));
    }

    public static bool TEST_CROSS_EDGE_BOX_MCR(ref IndexedVector3 edge, ref IndexedVector3 absolute_edge, ref IndexedVector3 pointa, ref IndexedVector3 pointb, ref IndexedVector3 _extend, int i_dir_0, int i_dir_1, int i_comp_0, int i_comp_1)
    {
      float num1 = -edge[i_dir_0];
      float num2 = edge[i_dir_1];
      float num3 = (float) ((double) pointa[i_comp_0] * (double) num1 + (double) pointa[i_comp_1] * (double) num2);
      float num4 = (float) ((double) pointb[i_comp_0] * (double) num1 + (double) pointb[i_comp_1] * (double) num2);
      if ((double) num3 > (double) num4)
      {
        float num5 = num3 + num4;
        num4 = num5 - num4;
        num3 = num5 - num4;
      }
      float num6 = absolute_edge[i_dir_0];
      float num7 = absolute_edge[i_dir_1];
      float num8 = (float) ((double) _extend[i_comp_0] * (double) num6 + (double) _extend[i_comp_1] * (double) num7);
      return (double) num3 <= (double) num8 && -(double) num8 <= (double) num4;
    }

    public static bool TEST_CROSS_EDGE_BOX_X_AXIS_MCR(ref IndexedVector3 edge, ref IndexedVector3 absolute_edge, ref IndexedVector3 pointa, ref IndexedVector3 pointb, ref IndexedVector3 _extend)
    {
      return BoxCollision.TEST_CROSS_EDGE_BOX_MCR(ref edge, ref absolute_edge, ref pointa, ref pointb, ref _extend, 2, 1, 1, 2);
    }

    public static bool TEST_CROSS_EDGE_BOX_Y_AXIS_MCR(ref IndexedVector3 edge, ref IndexedVector3 absolute_edge, ref IndexedVector3 pointa, ref IndexedVector3 pointb, ref IndexedVector3 _extend)
    {
      return BoxCollision.TEST_CROSS_EDGE_BOX_MCR(ref edge, ref absolute_edge, ref pointa, ref pointb, ref _extend, 0, 2, 2, 0);
    }

    public static bool TEST_CROSS_EDGE_BOX_Z_AXIS_MCR(ref IndexedVector3 edge, ref IndexedVector3 absolute_edge, ref IndexedVector3 pointa, ref IndexedVector3 pointb, ref IndexedVector3 _extend)
    {
      return BoxCollision.TEST_CROSS_EDGE_BOX_MCR(ref edge, ref absolute_edge, ref pointa, ref pointb, ref _extend, 1, 0, 0, 1);
    }

    private bool CompareTransformsEqual(ref IndexedMatrix t1, ref IndexedMatrix t2)
    {
      return t1.Equals(t2);
    }
  }
}
