﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.AABB
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA;
using BulletXNA.LinearMath;
using System;
using VRageMath;

namespace BulletXNA.BulletCollision
{
  public struct AABB
  {
    public IndexedVector3 m_min;
    public IndexedVector3 m_max;

    public AABB(ref IndexedVector3 V1, ref IndexedVector3 V2, ref IndexedVector3 V3)
    {
      this.m_min = new IndexedVector3();
      this.m_max = new IndexedVector3();
      this.m_min.X = BoxCollision.BT_MIN3(V1.X, V2.X, V3.X);
      this.m_min.Y = BoxCollision.BT_MIN3(V1.Y, V2.Y, V3.Y);
      this.m_min.Z = BoxCollision.BT_MIN3(V1.Z, V2.Z, V3.Z);
      this.m_max.X = BoxCollision.BT_MAX3(V1.X, V2.X, V3.X);
      this.m_max.Y = BoxCollision.BT_MAX3(V1.Y, V2.Y, V3.Y);
      this.m_max.Z = BoxCollision.BT_MAX3(V1.Z, V2.Z, V3.Z);
    }

    public AABB(ref IndexedVector3 V1, ref IndexedVector3 V2, ref IndexedVector3 V3, float margin)
    {
      this.m_min = new IndexedVector3();
      this.m_max = new IndexedVector3();
      this.m_min.X = BoxCollision.BT_MIN3(V1.X, V2.X, V3.X);
      this.m_min.Y = BoxCollision.BT_MIN3(V1.Y, V2.Y, V3.Y);
      this.m_min.Z = BoxCollision.BT_MIN3(V1.Z, V2.Z, V3.Z);
      this.m_max.X = BoxCollision.BT_MAX3(V1.X, V2.X, V3.X);
      this.m_max.Y = BoxCollision.BT_MAX3(V1.Y, V2.Y, V3.Y);
      this.m_max.Z = BoxCollision.BT_MAX3(V1.Z, V2.Z, V3.Z);
      this.m_min.X -= margin;
      this.m_min.Y -= margin;
      this.m_min.Z -= margin;
      this.m_max.X += margin;
      this.m_max.Y += margin;
      this.m_max.Z += margin;
    }

    public AABB(ref IndexedVector3 min, ref IndexedVector3 max)
    {
      this.m_min = min;
      this.m_max = max;
    }

    public AABB(ref Vector3 min, ref Vector3 max)
    {
      this.m_min = (IndexedVector3) min;
      this.m_max = (IndexedVector3) max;
    }

    public AABB(ref AABB other)
    {
      this.m_max = other.m_max;
      this.m_min = other.m_min;
    }

    public AABB(ref AABB other, float margin)
    {
      this.m_max = other.m_max;
      this.m_min = other.m_min;
      this.m_min.X -= margin;
      this.m_min.Y -= margin;
      this.m_min.Z -= margin;
      this.m_max.X += margin;
      this.m_max.Y += margin;
      this.m_max.Z += margin;
    }

    public void Invalidate()
    {
      this.m_min.X = float.MaxValue;
      this.m_min.Y = float.MaxValue;
      this.m_min.Z = float.MaxValue;
      this.m_max.X = float.MinValue;
      this.m_max.Y = float.MinValue;
      this.m_max.Z = float.MinValue;
    }

    public void IncrementMargin(float margin)
    {
      this.m_min.X -= margin;
      this.m_min.Y -= margin;
      this.m_min.Z -= margin;
      this.m_max.X += margin;
      this.m_max.Y += margin;
      this.m_max.Z += margin;
    }

    public void CopyWithMargin(ref AABB other, float margin)
    {
      this.m_min.X = other.m_min.X - margin;
      this.m_min.Y = other.m_min.Y - margin;
      this.m_min.Z = other.m_min.Z - margin;
      this.m_max.X = other.m_max.X + margin;
      this.m_max.Y = other.m_max.Y + margin;
      this.m_max.Z = other.m_max.Z + margin;
    }

    public void CalcFromTriangle(ref IndexedVector3 V1, ref IndexedVector3 V2, ref IndexedVector3 V3)
    {
      this.m_min.X = BoxCollision.BT_MIN3(V1.X, V2.X, V3.X);
      this.m_min.Y = BoxCollision.BT_MIN3(V1.Y, V2.Y, V3.Y);
      this.m_min.Z = BoxCollision.BT_MIN3(V1.Z, V2.Z, V3.Z);
      this.m_max.X = BoxCollision.BT_MAX3(V1.X, V2.X, V3.X);
      this.m_max.Y = BoxCollision.BT_MAX3(V1.Y, V2.Y, V3.Y);
      this.m_max.Z = BoxCollision.BT_MAX3(V1.Z, V2.Z, V3.Z);
    }

    public void CalcFromTriangleMargin(ref IndexedVector3 V1, ref IndexedVector3 V2, ref IndexedVector3 V3, float margin)
    {
      this.m_min.X = BoxCollision.BT_MIN3(V1.X, V2.X, V3.X);
      this.m_min.Y = BoxCollision.BT_MIN3(V1.Y, V2.Y, V3.Y);
      this.m_min.Z = BoxCollision.BT_MIN3(V1.Z, V2.Z, V3.Z);
      this.m_max.X = BoxCollision.BT_MAX3(V1.X, V2.X, V3.X);
      this.m_max.Y = BoxCollision.BT_MAX3(V1.Y, V2.Y, V3.Y);
      this.m_max.Z = BoxCollision.BT_MAX3(V1.Z, V2.Z, V3.Z);
      this.m_min.X -= margin;
      this.m_min.Y -= margin;
      this.m_min.Z -= margin;
      this.m_max.X += margin;
      this.m_max.Y += margin;
      this.m_max.Z += margin;
    }

    public void ApplyTransform(ref IndexedMatrix trans)
    {
      IndexedVector3 indexedVector3_1 = (this.m_max + this.m_min) * 0.5f;
      IndexedVector3 indexedVector3_2 = this.m_max - indexedVector3_1;
      IndexedVector3 indexedVector3_3 = trans * indexedVector3_1;
      IndexedVector3 indexedVector3_4 = new IndexedVector3(indexedVector3_2.Dot(trans._basis.GetRow(0).Absolute()), indexedVector3_2.Dot(trans._basis.GetRow(1).Absolute()), indexedVector3_2.Dot(trans._basis.GetRow(2).Absolute()));
      this.m_min = indexedVector3_3 - indexedVector3_4;
      this.m_max = indexedVector3_3 + indexedVector3_4;
    }

    public void ApplyTransformTransCache(ref BT_BOX_BOX_TRANSFORM_CACHE trans)
    {
      IndexedVector3 point = (this.m_max + this.m_min) * 0.5f;
      IndexedVector3 indexedVector3_1 = this.m_max - point;
      IndexedVector3 indexedVector3_2 = trans.Transform(ref point);
      trans.m_R1to0.Absolute();
      IndexedVector3 indexedVector3_3 = new IndexedVector3(indexedVector3_1.Dot(trans.m_R1to0.GetRow(0).Absolute()), indexedVector3_1.Dot(trans.m_R1to0.GetRow(1).Absolute()), indexedVector3_1.Dot(trans.m_R1to0.GetRow(2).Absolute()));
      this.m_min = indexedVector3_2 - indexedVector3_3;
      this.m_max = indexedVector3_2 + indexedVector3_3;
    }

    public void Merge(AABB box)
    {
      this.Merge(ref box);
    }

    public void Merge(ref AABB box)
    {
      this.m_min.X = BoxCollision.BT_MIN(this.m_min.X, box.m_min.X);
      this.m_min.Y = BoxCollision.BT_MIN(this.m_min.Y, box.m_min.Y);
      this.m_min.Z = BoxCollision.BT_MIN(this.m_min.Z, box.m_min.Z);
      this.m_max.X = BoxCollision.BT_MAX(this.m_max.X, box.m_max.X);
      this.m_max.Y = BoxCollision.BT_MAX(this.m_max.Y, box.m_max.Y);
      this.m_max.Z = BoxCollision.BT_MAX(this.m_max.Z, box.m_max.Z);
    }

    public void MergePoint(ref IndexedVector3 point)
    {
      this.m_min.X = BoxCollision.BT_MIN(this.m_min.X, point.X);
      this.m_min.Y = BoxCollision.BT_MIN(this.m_min.Y, point.Y);
      this.m_min.Z = BoxCollision.BT_MIN(this.m_min.Z, point.Z);
      this.m_max.X = BoxCollision.BT_MAX(this.m_max.X, point.X);
      this.m_max.Y = BoxCollision.BT_MAX(this.m_max.Y, point.Y);
      this.m_max.Z = BoxCollision.BT_MAX(this.m_max.Z, point.Z);
    }

    public void GetCenterExtend(out IndexedVector3 center, out IndexedVector3 extend)
    {
      center = new IndexedVector3((this.m_max + this.m_min) * 0.5f);
      extend = new IndexedVector3(this.m_max - center);
    }

    public void FindIntersection(ref AABB other, ref AABB intersection)
    {
      intersection.m_min.X = BoxCollision.BT_MAX(other.m_min.X, this.m_min.X);
      intersection.m_min.Y = BoxCollision.BT_MAX(other.m_min.Y, this.m_min.Y);
      intersection.m_min.Z = BoxCollision.BT_MAX(other.m_min.Z, this.m_min.Z);
      intersection.m_max.X = BoxCollision.BT_MIN(other.m_max.X, this.m_max.X);
      intersection.m_max.Y = BoxCollision.BT_MIN(other.m_max.Y, this.m_max.Y);
      intersection.m_max.Z = BoxCollision.BT_MIN(other.m_max.Z, this.m_max.Z);
    }

    public bool HasCollision(ref AABB other)
    {
      return (double) this.m_min.X <= (double) other.m_max.X && (double) this.m_max.X >= (double) other.m_min.X && ((double) this.m_min.Y <= (double) other.m_max.Y && (double) this.m_max.Y >= (double) other.m_min.Y) && ((double) this.m_min.Z <= (double) other.m_max.Z && (double) this.m_max.Z >= (double) other.m_min.Z);
    }

    public bool CollideRay(ref IndexedVector3 vorigin, ref IndexedVector3 vdir)
    {
      IndexedVector3 center;
      IndexedVector3 extend;
      this.GetCenterExtend(out center, out extend);
      float x1 = vorigin.X - center.X;
      if (BoxCollision.BT_GREATER(x1, extend.X) && (double) x1 * (double) vdir.X >= 0.0)
        return false;
      float x2 = vorigin.Y - center.Y;
      if (BoxCollision.BT_GREATER(x2, extend.Y) && (double) x2 * (double) vdir.Y >= 0.0)
        return false;
      float x3 = vorigin.Z - center.Z;
      return (!BoxCollision.BT_GREATER(x3, extend.Z) || (double) x3 * (double) vdir.Z < 0.0) && ((double) Math.Abs((float) ((double) vdir.Y * (double) x3 - (double) vdir.Z * (double) x2)) <= (double) extend.Y * (double) Math.Abs(vdir.Z) + (double) extend.Z * (double) Math.Abs(vdir.Y) && (double) Math.Abs((float) ((double) vdir.Z * (double) x1 - (double) vdir.X * (double) x3)) <= (double) extend.X * (double) Math.Abs(vdir.Z) + (double) extend.Z * (double) Math.Abs(vdir.X)) && (double) Math.Abs((float) ((double) vdir.X * (double) x2 - (double) vdir.Y * (double) x1)) <= (double) extend.X * (double) Math.Abs(vdir.Y) + (double) extend.Y * (double) Math.Abs(vdir.X);
    }

    public float? CollideRayDistance(ref IndexedVector3 origin, ref IndexedVector3 direction)
    {
      IndexedVector3 indexedVector3 = new IndexedVector3(1f / direction.X, 1f / direction.Y, 1f / direction.Z);
      float val1_1 = (this.m_min.X - origin.X) * indexedVector3.X;
      float val2_1 = (this.m_max.X - origin.X) * indexedVector3.X;
      float val1_2 = (this.m_min.Y - origin.Y) * indexedVector3.Y;
      float val2_2 = (this.m_max.Y - origin.Y) * indexedVector3.Y;
      float val1_3 = (this.m_min.Z - origin.Z) * indexedVector3.Z;
      float val2_3 = (this.m_max.Z - origin.Z) * indexedVector3.Z;
      float num1 = Math.Max(Math.Max(Math.Min(val1_1, val2_1), Math.Min(val1_2, val2_2)), Math.Min(val1_3, val2_3));
      float num2 = Math.Min(Math.Min(Math.Max(val1_1, val2_1), Math.Max(val1_2, val2_2)), Math.Max(val1_3, val2_3));
      float num3;
      if ((double) num2 < 0.0)
      {
        num3 = num2;
        return new float?();
      }
      else
      {
        if ((double) num1 <= (double) num2)
          return new float?(num1);
        num3 = num2;
        return new float?();
      }
    }

    public void ProjectionInterval(ref Vector4 direction, out float vmin, out float vmax)
    {
      IndexedVector3 direction1 = new IndexedVector3(direction.X, direction.Y, direction.Z);
      this.ProjectionInterval(ref direction1, out vmin, out vmax);
    }

    public void ProjectionInterval(ref IndexedVector3 direction, out float vmin, out float vmax)
    {
      IndexedVector3 v = (this.m_max + this.m_min) * 0.5f;
      IndexedVector3 indexedVector3 = this.m_max - v;
      float num1 = direction.Dot(ref v);
      float num2 = indexedVector3.Dot(direction.Absolute());
      vmin = num1 - num2;
      vmax = num1 + num2;
    }

    public BT_PLANE_INTERSECTION_TYPE PlaneClassify(ref Vector4 plane)
    {
      float vmin;
      float vmax;
      this.ProjectionInterval(ref plane, out vmin, out vmax);
      if ((double) plane.W > (double) vmax + 9.99999997475243E-07)
        return BT_PLANE_INTERSECTION_TYPE.BT_CONST_BACK_PLANE;
      return (double) plane.W + 9.99999997475243E-07 >= (double) vmin ? BT_PLANE_INTERSECTION_TYPE.BT_CONST_COLLIDE_PLANE : BT_PLANE_INTERSECTION_TYPE.BT_CONST_FRONT_PLANE;
    }

    public bool OverlappingTransConservative(ref AABB box, ref IndexedMatrix trans1_to_0)
    {
      AABB other = box;
      other.ApplyTransform(ref trans1_to_0);
      return this.HasCollision(ref other);
    }

    public bool OverlappingTransConservative2(ref AABB box, BT_BOX_BOX_TRANSFORM_CACHE trans1_to_0)
    {
      AABB other = box;
      other.ApplyTransformTransCache(ref trans1_to_0);
      return this.HasCollision(ref other);
    }

    public bool OverlappingTransCache(ref AABB box, ref BT_BOX_BOX_TRANSFORM_CACHE transcache, bool fulltest)
    {
      IndexedVector3 center1;
      IndexedVector3 extend1;
      this.GetCenterExtend(out center1, out extend1);
      IndexedVector3 center2;
      IndexedVector3 extend2;
      box.GetCenterExtend(out center2, out extend2);
      IndexedVector3 vec3 = new IndexedVector3(0.0f, 0.0f, 0.0f);
      for (int index = 0; index < 3; ++index)
      {
        vec3[index] = transcache.m_R1to0[index].Dot(ref center2) + transcache.m_T1to0[index] - center1[index];
        float y = transcache.m_AR[index].Dot(ref extend2) + extend1[index];
        if (BoxCollision.BT_GREATER(vec3[index], y))
          return false;
      }
      for (int colindex = 0; colindex < 3; ++colindex)
      {
        if (BoxCollision.BT_GREATER(AABB.Mat3DotCol(ref transcache.m_R1to0, ref vec3, colindex), AABB.Mat3DotCol(ref transcache.m_AR, ref extend1, colindex) + extend2[colindex]))
          return false;
      }
      if (fulltest)
      {
        float[,] numArray1 = MathUtil.BasisMatrixToFloatArray(ref transcache.m_R1to0);
        float[,] numArray2 = MathUtil.BasisMatrixToFloatArray(ref transcache.m_AR);
        for (int index1 = 0; index1 < 3; ++index1)
        {
          int index2 = (index1 + 1) % 3;
          int index3 = (index1 + 2) % 3;
          int index4 = index1 == 0 ? 1 : 0;
          int index5 = index1 == 2 ? 1 : 2;
          for (int index6 = 0; index6 < 3; ++index6)
          {
            int index7 = index6 == 2 ? 1 : 2;
            int index8 = index6 == 0 ? 1 : 0;
            if (BoxCollision.BT_GREATER((float) ((double) vec3[index3] * (double) numArray1[index2, index6] - (double) vec3[index2] * (double) numArray1[index3, index6]), (float) ((double) extend1[index4] * (double) numArray2[index5, index6] + (double) extend1[index5] * (double) numArray2[index4, index6] + (double) extend2[index8] * (double) numArray2[index1, index7] + (double) extend2[index7] * (double) numArray2[index1, index8])))
              return false;
          }
        }
      }
      return true;
    }

    public static float Mat3DotCol(ref IndexedBasisMatrix mat, ref IndexedVector3 vec3, int colindex)
    {
      return (float) ((double) vec3[0] * (double) mat[0, colindex] + (double) vec3[1] * (double) mat[1, colindex] + (double) vec3[2] * (double) mat[2, colindex]);
    }

    public static float Mat3DotCol(IndexedBasisMatrix mat, ref IndexedVector3 vec3, int colindex)
    {
      return (float) ((double) vec3[0] * (double) mat[0, colindex] + (double) vec3[1] * (double) mat[1, colindex] + (double) vec3[2] * (double) mat[2, colindex]);
    }

    public bool CollidePlane(ref Vector4 plane)
    {
      return this.PlaneClassify(ref plane) == BT_PLANE_INTERSECTION_TYPE.BT_CONST_COLLIDE_PLANE;
    }

    public bool CollideTriangleExact(ref IndexedVector3 p1, ref IndexedVector3 p2, ref IndexedVector3 p3, ref Vector4 triangle_plane)
    {
      if (!this.CollidePlane(ref triangle_plane))
        return false;
      IndexedVector3 center;
      IndexedVector3 extend;
      this.GetCenterExtend(out center, out extend);
      IndexedVector3 indexedVector3_1 = p1 - center;
      IndexedVector3 indexedVector3_2 = p2 - center;
      IndexedVector3 indexedVector3_3 = p3 - center;
      IndexedVector3 edge1 = indexedVector3_2 - indexedVector3_1;
      IndexedVector3 absolute_edge1 = edge1.Absolute();
      BoxCollision.TEST_CROSS_EDGE_BOX_X_AXIS_MCR(ref edge1, ref absolute_edge1, ref indexedVector3_1, ref indexedVector3_3, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Y_AXIS_MCR(ref edge1, ref absolute_edge1, ref indexedVector3_1, ref indexedVector3_3, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Z_AXIS_MCR(ref edge1, ref absolute_edge1, ref indexedVector3_1, ref indexedVector3_3, ref extend);
      IndexedVector3 edge2 = indexedVector3_3 - indexedVector3_2;
      IndexedVector3 absolute_edge2 = edge2.Absolute();
      BoxCollision.TEST_CROSS_EDGE_BOX_X_AXIS_MCR(ref edge2, ref absolute_edge2, ref indexedVector3_2, ref indexedVector3_1, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Y_AXIS_MCR(ref edge2, ref absolute_edge2, ref indexedVector3_2, ref indexedVector3_1, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Z_AXIS_MCR(ref edge2, ref absolute_edge2, ref indexedVector3_2, ref indexedVector3_1, ref extend);
      IndexedVector3 edge3 = indexedVector3_1 - indexedVector3_3;
      IndexedVector3 absolute_edge3 = edge3.Absolute();
      BoxCollision.TEST_CROSS_EDGE_BOX_X_AXIS_MCR(ref edge3, ref absolute_edge3, ref indexedVector3_3, ref indexedVector3_2, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Y_AXIS_MCR(ref edge3, ref absolute_edge3, ref indexedVector3_3, ref indexedVector3_2, ref extend);
      BoxCollision.TEST_CROSS_EDGE_BOX_Z_AXIS_MCR(ref edge3, ref absolute_edge3, ref indexedVector3_3, ref indexedVector3_2, ref extend);
      return true;
    }
  }
}
