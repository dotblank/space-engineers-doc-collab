﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.PrimitiveTriangle
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.LinearMath;
using VRageMath;

namespace BulletXNA.BulletCollision
{
  public class PrimitiveTriangle
  {
    public IndexedVector3[] m_vertices = new IndexedVector3[3];
    public Vector4 m_plane;
    public float m_margin;

    public PrimitiveTriangle()
    {
      this.m_margin = 0.01f;
    }

    public void BuildTriPlane()
    {
      IndexedVector3 b = IndexedVector3.Cross(this.m_vertices[1] - this.m_vertices[0], this.m_vertices[2] - this.m_vertices[0]);
      b.Normalize();
      this.m_plane = new Vector4(b.ToVector3(), IndexedVector3.Dot(this.m_vertices[0], b));
    }

    public bool OverlapTestConservative(PrimitiveTriangle other)
    {
      float num = this.m_margin + other.m_margin;
      return ((double) (ClipPolygon.DistancePointPlane(ref this.m_plane, ref other.m_vertices[0]) - num) <= 0.0 || (double) (ClipPolygon.DistancePointPlane(ref this.m_plane, ref other.m_vertices[1]) - num) <= 0.0 || (double) (ClipPolygon.DistancePointPlane(ref this.m_plane, ref other.m_vertices[2]) - num) <= 0.0) && ((double) (ClipPolygon.DistancePointPlane(ref other.m_plane, ref this.m_vertices[0]) - num) <= 0.0 || (double) (ClipPolygon.DistancePointPlane(ref other.m_plane, ref this.m_vertices[1]) - num) <= 0.0 || (double) (ClipPolygon.DistancePointPlane(ref other.m_plane, ref this.m_vertices[2]) - num) <= 0.0);
    }

    public void GetEdgePlane(int edge_index, out Vector4 plane)
    {
      IndexedVector3 e1 = this.m_vertices[edge_index];
      IndexedVector3 e2 = this.m_vertices[(edge_index + 1) % 3];
      IndexedVector3 normal = new IndexedVector3(this.m_plane.X, this.m_plane.Y, this.m_plane.Z);
      GeometeryOperations.bt_edge_plane(ref e1, ref e2, ref normal, out plane);
    }

    public void ApplyTransform(ref IndexedMatrix t)
    {
      IndexedVector3.Transform(this.m_vertices, ref t, this.m_vertices);
    }

    public int ClipTriangle(PrimitiveTriangle other, ObjectArray<IndexedVector3> clipped_points)
    {
      ObjectArray<IndexedVector3> objectArray1 = new ObjectArray<IndexedVector3>(16);
      Vector4 plane;
      this.GetEdgePlane(0, out plane);
      int polygon_point_count1 = ClipPolygon.PlaneClipTriangle(ref plane, ref other.m_vertices[0], ref other.m_vertices[1], ref other.m_vertices[2], objectArray1);
      if (polygon_point_count1 == 0)
        return 0;
      ObjectArray<IndexedVector3> objectArray2 = new ObjectArray<IndexedVector3>(16);
      this.GetEdgePlane(1, out plane);
      int polygon_point_count2 = ClipPolygon.PlaneClipPolygon(ref plane, objectArray1, polygon_point_count1, objectArray2);
      if (polygon_point_count2 == 0)
        return 0;
      this.GetEdgePlane(2, out plane);
      return ClipPolygon.PlaneClipPolygon(ref plane, objectArray2, polygon_point_count2, clipped_points);
    }

    public bool FindTriangleCollisionClipMethod(PrimitiveTriangle other, GIM_TRIANGLE_CONTACT contacts)
    {
      float margin = this.m_margin + other.m_margin;
      ObjectArray<IndexedVector3> objectArray = new ObjectArray<IndexedVector3>(16);
      GIM_TRIANGLE_CONTACT other1 = new GIM_TRIANGLE_CONTACT();
      other1.m_separating_normal = this.m_plane;
      int point_count1 = this.ClipTriangle(other, objectArray);
      if (point_count1 == 0)
        return false;
      other1.MergePoints(ref other1.m_separating_normal, margin, objectArray, point_count1);
      if (other1.m_point_count == 0)
        return false;
      other1.m_separating_normal *= -1f;
      GIM_TRIANGLE_CONTACT other2 = new GIM_TRIANGLE_CONTACT();
      other2.m_separating_normal = other.m_plane;
      int point_count2 = other.ClipTriangle(this, objectArray);
      if (point_count2 == 0)
        return false;
      other2.MergePoints(ref other2.m_separating_normal, margin, objectArray, point_count2);
      if (other2.m_point_count == 0)
        return false;
      if ((double) other2.m_penetration_depth < (double) other1.m_penetration_depth)
        contacts.CopyFrom(other2);
      else
        contacts.CopyFrom(other1);
      return true;
    }
  }
}
