﻿// Decompiled with JetBrains decompiler
// Type: BulletXNA.BulletCollision.QuantizedBvhTree
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA;
using BulletXNA.LinearMath;
using System.IO;

namespace BulletXNA.BulletCollision
{
  public class QuantizedBvhTree
  {
    public const int MAX_INDICES_PER_NODE = 6;
    protected int m_num_nodes;
    protected GIM_QUANTIZED_BVH_NODE_ARRAY m_node_array;
    protected AABB m_global_bound;
    protected IndexedVector3 m_bvhQuantization;

    public QuantizedBvhTree()
    {
      this.m_num_nodes = 0;
      this.m_node_array = new GIM_QUANTIZED_BVH_NODE_ARRAY();
    }

    public QuantizedBvhTree(int defaultCapacity)
    {
      this.m_num_nodes = 0;
      this.m_node_array = new GIM_QUANTIZED_BVH_NODE_ARRAY(defaultCapacity);
    }

    private static void WriteIndexedVector3(IndexedVector3 vector, BinaryWriter bw)
    {
      bw.Write(vector.X);
      bw.Write(vector.Y);
      bw.Write(vector.Z);
    }

    private static IndexedVector3 ReadIndexedVector3(BinaryReader br)
    {
      return new IndexedVector3(br.ReadSingle(), br.ReadSingle(), br.ReadSingle());
    }

    private static void WriteUShortVector3(UShortVector3 vector, BinaryWriter bw)
    {
      bw.Write(vector.X);
      bw.Write(vector.Y);
      bw.Write(vector.Z);
    }

    private static UShortVector3 ReadUShortVector3(BinaryReader br)
    {
      return new UShortVector3()
      {
        X = br.ReadUInt16(),
        Y = br.ReadUInt16(),
        Z = br.ReadUInt16()
      };
    }

    public byte[] Save()
    {
      using (MemoryStream memoryStream = new MemoryStream())
      {
        using (BinaryWriter bw = new BinaryWriter((Stream) memoryStream))
        {
          bw.Write(this.m_num_nodes);
          QuantizedBvhTree.WriteIndexedVector3(this.m_global_bound.m_min, bw);
          QuantizedBvhTree.WriteIndexedVector3(this.m_global_bound.m_max, bw);
          QuantizedBvhTree.WriteIndexedVector3(this.m_bvhQuantization, bw);
          for (int index1 = 0; index1 < this.m_num_nodes; ++index1)
          {
            bw.Write(this.m_node_array[index1].m_escapeIndexOrDataIndex.Length);
            for (int index2 = 0; index2 < this.m_node_array[index1].m_escapeIndexOrDataIndex.Length; ++index2)
              bw.Write(this.m_node_array[index1].m_escapeIndexOrDataIndex[index2]);
            QuantizedBvhTree.WriteUShortVector3(this.m_node_array[index1].m_quantizedAabbMin, bw);
            QuantizedBvhTree.WriteUShortVector3(this.m_node_array[index1].m_quantizedAabbMax, bw);
          }
          return memoryStream.ToArray();
        }
      }
    }

    public void Load(byte[] byteArray)
    {
      using (MemoryStream memoryStream = new MemoryStream(byteArray))
      {
        using (BinaryReader br = new BinaryReader((Stream) memoryStream))
        {
          this.m_num_nodes = br.ReadInt32();
          IndexedVector3 min = QuantizedBvhTree.ReadIndexedVector3(br);
          IndexedVector3 max = QuantizedBvhTree.ReadIndexedVector3(br);
          this.m_global_bound = new AABB(ref min, ref max);
          this.m_bvhQuantization = QuantizedBvhTree.ReadIndexedVector3(br);
          this.m_node_array = new GIM_QUANTIZED_BVH_NODE_ARRAY(this.m_num_nodes);
          for (int index1 = 0; index1 < this.m_num_nodes; ++index1)
          {
            int length = br.ReadInt32();
            BT_QUANTIZED_BVH_NODE quantizedBvhNode = new BT_QUANTIZED_BVH_NODE();
            quantizedBvhNode.m_escapeIndexOrDataIndex = new int[length];
            for (int index2 = 0; index2 < length; ++index2)
              quantizedBvhNode.m_escapeIndexOrDataIndex[index2] = br.ReadInt32();
            quantizedBvhNode.m_quantizedAabbMin = QuantizedBvhTree.ReadUShortVector3(br);
            quantizedBvhNode.m_quantizedAabbMax = QuantizedBvhTree.ReadUShortVector3(br);
            this.m_node_array.Add(quantizedBvhNode);
          }
        }
      }
    }

    protected void CalcQuantization(GIM_BVH_DATA_ARRAY primitive_boxes)
    {
      this.CalcQuantization(primitive_boxes, 1f);
    }

    protected void CalcQuantization(GIM_BVH_DATA_ARRAY primitive_boxes, float boundMargin)
    {
      AABB aabb = new AABB();
      aabb.Invalidate();
      int count = primitive_boxes.Count;
      for (int index = 0; index < count; ++index)
        aabb.Merge(ref primitive_boxes.GetRawArray()[index].m_bound);
      GImpactQuantization.CalcQuantizationParameters(out this.m_global_bound.m_min, out this.m_global_bound.m_max, out this.m_bvhQuantization, ref aabb.m_min, ref aabb.m_max, boundMargin);
    }

    protected int SortAndCalcSplittingIndex(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex, int splitAxis)
    {
      int index1 = startIndex;
      int num1 = endIndex - startIndex;
      IndexedVector3 zero = IndexedVector3.Zero;
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min);
        zero += indexedVector3;
      }
      float num2 = (zero * (1f / (float) num1))[splitAxis];
      for (int index0 = startIndex; index0 < endIndex; ++index0)
      {
        if ((double) (0.5f * (primitive_boxes[index0].m_bound.m_max + primitive_boxes[index0].m_bound.m_min))[splitAxis] > (double) num2)
        {
          primitive_boxes.Swap(index0, index1);
          ++index1;
        }
      }
      int num3 = num1 / 3;
      if (index1 <= startIndex + num3 || index1 >= endIndex - 1 - num3)
        index1 = startIndex + (num1 >> 1);
      return index1;
    }

    protected int CalcSplittingAxis(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex)
    {
      IndexedVector3 zero1 = IndexedVector3.Zero;
      IndexedVector3 zero2 = IndexedVector3.Zero;
      int num = endIndex - startIndex;
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min);
        zero1 += indexedVector3;
      }
      IndexedVector3 indexedVector3_1 = zero1 * (1f / (float) num);
      for (int index = startIndex; index < endIndex; ++index)
      {
        IndexedVector3 indexedVector3_2 = 0.5f * (primitive_boxes[index].m_bound.m_max + primitive_boxes[index].m_bound.m_min) - indexedVector3_1;
        IndexedVector3 indexedVector3_3 = indexedVector3_2 * indexedVector3_2;
        zero2 += indexedVector3_3;
      }
      IndexedVector3 a = zero2 * (float) (1.0 / ((double) num - 1.0));
      return MathUtil.MaxAxis(ref a);
    }

    protected void BuildSubTree(GIM_BVH_DATA_ARRAY primitive_boxes, int startIndex, int endIndex)
    {
      int nodeindex = this.m_num_nodes;
      ++this.m_num_nodes;
      if (endIndex - startIndex <= 6)
      {
        int length = endIndex - startIndex;
        int[] indices = new int[length];
        AABB bound = new AABB();
        bound.Invalidate();
        for (int index = 0; index < length; ++index)
        {
          indices[index] = primitive_boxes[startIndex + index].m_data;
          bound.Merge(primitive_boxes.GetRawArray()[startIndex + index].m_bound);
        }
        this.SetNodeBound(nodeindex, ref bound);
        this.m_node_array[nodeindex].SetDataIndices(indices);
        StreamWriter streamWriter = BulletGlobals.g_streamWriter;
      }
      else
      {
        int splitAxis = this.CalcSplittingAxis(primitive_boxes, startIndex, endIndex);
        int num = this.SortAndCalcSplittingIndex(primitive_boxes, startIndex, endIndex, splitAxis);
        AABB bound = new AABB();
        bound.Invalidate();
        for (int index = startIndex; index < endIndex; ++index)
          bound.Merge(ref primitive_boxes.GetRawArray()[index].m_bound);
        this.SetNodeBound(nodeindex, ref bound);
        this.BuildSubTree(primitive_boxes, startIndex, num);
        this.BuildSubTree(primitive_boxes, num, endIndex);
        this.m_node_array.GetRawArray()[nodeindex].SetEscapeIndex(this.m_num_nodes - nodeindex);
        StreamWriter streamWriter = BulletGlobals.g_streamWriter;
      }
    }

    public void BuildTree(GIM_BVH_DATA_ARRAY primitive_boxes)
    {
      this.CalcQuantization(primitive_boxes);
      this.m_num_nodes = 0;
      this.m_node_array.Resize(primitive_boxes.Count * 2);
      this.BuildSubTree(primitive_boxes, 0, primitive_boxes.Count);
    }

    public void QuantizePoint(out UShortVector3 quantizedpoint, ref IndexedVector3 point)
    {
      GImpactQuantization.QuantizeClamp(out quantizedpoint, ref point, ref this.m_global_bound.m_min, ref this.m_global_bound.m_max, ref this.m_bvhQuantization);
    }

    public bool TestQuantizedBoxOverlap(int node_index, ref UShortVector3 quantizedMin, ref UShortVector3 quantizedMax)
    {
      return this.m_node_array[node_index].TestQuantizedBoxOverlapp(ref quantizedMin, ref quantizedMax);
    }

    public void ClearNodes()
    {
      this.m_node_array.Clear();
      this.m_num_nodes = 0;
    }

    public int GetNodeCount()
    {
      return this.m_num_nodes;
    }

    public bool IsLeafNode(int nodeindex)
    {
      return this.m_node_array[nodeindex].IsLeafNode();
    }

    public int[] GetNodeData(int nodeindex)
    {
      return this.m_node_array[nodeindex].GetDataIndices();
    }

    public void GetNodeBound(int nodeindex, out AABB bound)
    {
      bound.m_min = GImpactQuantization.Unquantize(ref this.m_node_array.GetRawArray()[nodeindex].m_quantizedAabbMin, ref this.m_global_bound.m_min, ref this.m_bvhQuantization);
      bound.m_max = GImpactQuantization.Unquantize(ref this.m_node_array.GetRawArray()[nodeindex].m_quantizedAabbMax, ref this.m_global_bound.m_min, ref this.m_bvhQuantization);
    }

    public void SetNodeBound(int nodeindex, ref AABB bound)
    {
      GImpactQuantization.QuantizeClamp(out this.m_node_array.GetRawArray()[nodeindex].m_quantizedAabbMin, ref bound.m_min, ref this.m_global_bound.m_min, ref this.m_global_bound.m_max, ref this.m_bvhQuantization);
      GImpactQuantization.QuantizeClamp(out this.m_node_array.GetRawArray()[nodeindex].m_quantizedAabbMax, ref bound.m_max, ref this.m_global_bound.m_min, ref this.m_global_bound.m_max, ref this.m_bvhQuantization);
    }

    public int GetLeftNode(int nodeindex)
    {
      return nodeindex + 1;
    }

    public int GetRightNode(int nodeindex)
    {
      if (this.m_node_array[nodeindex + 1].IsLeafNode())
        return nodeindex + 2;
      else
        return nodeindex + 1 + this.m_node_array[nodeindex + 1].GetEscapeIndex();
    }

    public int GetEscapeNodeIndex(int nodeindex)
    {
      return this.m_node_array[nodeindex].GetEscapeIndex();
    }
  }
}
