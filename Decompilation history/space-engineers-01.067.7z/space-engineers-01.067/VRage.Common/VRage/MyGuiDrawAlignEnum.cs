﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyGuiDrawAlignEnum
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage
{
  public enum MyGuiDrawAlignEnum
  {
    HORISONTAL_LEFT_AND_VERTICAL_TOP,
    HORISONTAL_LEFT_AND_VERTICAL_CENTER,
    HORISONTAL_LEFT_AND_VERTICAL_BOTTOM,
    HORISONTAL_CENTER_AND_VERTICAL_CENTER,
    HORISONTAL_CENTER_AND_VERTICAL_TOP,
    HORISONTAL_CENTER_AND_VERTICAL_BOTTOM,
    HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM,
    HORISONTAL_RIGHT_AND_VERTICAL_CENTER,
    HORISONTAL_RIGHT_AND_VERTICAL_TOP,
  }
}
