﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyRenderThread
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using SharpDX;
using SharpDX.Windows;
using System;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using VRage.Collections;
using VRage.Stats;
using VRage.Win32;
using VRageRender;

namespace VRage
{
  public class MyRenderThread
  {
    private int m_newQuality = -1;
    private MyConcurrentQueue<Action> m_invokeQueue = new MyConcurrentQueue<Action>(16);
    private readonly MyGameTimer m_timer;
    private MyTimeSpan m_messageProcessingStart;
    private volatile bool m_stopped;
    private IMyRenderWindow m_renderWindow;
    private MyRenderQualityEnum m_currentQuality;
    private Control m_form;
    private MyRenderDeviceSettings m_settings;
    private MyRenderDeviceSettings? m_newSettings;
    public readonly Thread SystemThread;

    public int CurrentAdapter
    {
      get
      {
        return this.m_settings.AdapterOrdinal;
      }
    }

    public MyRenderDeviceSettings CurrentSettings
    {
      get
      {
        return this.m_settings;
      }
    }

    public event Action BeforeDraw;

    public event SizeChangedHandler SizeChanged;

    private MyRenderThread(MyGameTimer timer, bool separateThread)
    {
      this.m_timer = timer;
      if (separateThread)
      {
        this.SystemThread = new Thread(new ParameterizedThreadStart(this.RenderThreadStart));
        this.SystemThread.IsBackground = true;
        this.SystemThread.Name = "Render thread";
        this.SystemThread.CurrentCulture = CultureInfo.InvariantCulture;
        this.SystemThread.CurrentUICulture = CultureInfo.InvariantCulture;
      }
      else
        this.SystemThread = Thread.CurrentThread;
    }

    public static MyRenderThread Start(MyGameTimer timer, InitHandler initHandler, MyRenderDeviceSettings? settingsToTry, MyRenderQualityEnum renderQuality)
    {
      MyRenderThread myRenderThread = new MyRenderThread(timer, true);
      myRenderThread.SystemThread.Start((object) new MyRenderThread.StartParams()
      {
        InitHandler = initHandler,
        SettingsToTry = settingsToTry,
        RenderQuality = renderQuality
      });
      return myRenderThread;
    }

    public static MyRenderThread StartSync(MyGameTimer timer, IMyRenderWindow renderWindow, MyRenderDeviceSettings? settingsToTry, MyRenderQualityEnum renderQuality)
    {
      MyRenderThread renderThread = new MyRenderThread(timer, false);
      renderThread.m_renderWindow = renderWindow;
      renderThread.m_settings = MyRenderProxy.CreateDevice(renderThread, renderWindow.Handle, settingsToTry);
      MyRenderProxy.SendCreatedDeviceSettings(renderThread.m_settings);
      renderThread.m_currentQuality = renderQuality;
      renderThread.m_form = Control.FromHandle(renderWindow.Handle);
      renderThread.LoadContent();
      renderThread.UpdateSize(new MyWindowModeEnum?());
      return renderThread;
    }

    public void TickSync()
    {
      Application.DoEvents();
      this.RenderCallback();
    }

    public void Invoke(Action action)
    {
      this.m_invokeQueue.Enqueue(action);
    }

    public void SwitchSettings(MyRenderDeviceSettings settings)
    {
      this.m_newSettings = new MyRenderDeviceSettings?(settings);
    }

    public void SwitchQuality(MyRenderQualityEnum quality)
    {
      this.m_newQuality = (int) quality;
    }

    public void Exit()
    {
      this.m_stopped = true;
      if (this.SystemThread != null)
      {
        try
        {
          if (!this.m_form.IsDisposed)
            this.m_form.Invoke((Delegate) new Action(this.OnExit));
        }
        catch
        {
        }
        if (Thread.CurrentThread == this.SystemThread)
          return;
        this.SystemThread.Join();
      }
      else
      {
        this.UnloadContent();
        MyRenderProxy.DisposeDevice();
      }
    }

    private void OnExit()
    {
      this.m_form.Dispose();
    }

    private void RenderThreadStart(object param)
    {
      ProfilerShort.Autocommit = false;
      MyRenderThread.StartParams startParams = (MyRenderThread.StartParams) param;
      this.m_renderWindow = startParams.InitHandler();
      Control control = Control.FromHandle(this.m_renderWindow.Handle);
      this.m_settings = MyRenderProxy.CreateDevice(this, this.m_renderWindow.Handle, startParams.SettingsToTry);
      MyRenderProxy.SendCreatedDeviceSettings(this.m_settings);
      this.m_currentQuality = startParams.RenderQuality;
      this.m_form = control;
      this.LoadContent();
      this.UpdateSize(new MyWindowModeEnum?());
      RenderLoop.Run(this.m_form, new RenderLoop.RenderCallback(this.RenderCallback), false);
      this.UnloadContent();
      MyRenderProxy.DisposeDevice();
    }

    private void RenderCallback()
    {
      if (!(this.m_messageProcessingStart != MyTimeSpan.Zero))
        ;
      Action instance;
      while (this.m_invokeQueue.TryDequeue(out instance))
        instance();
      this.ApplySettingsChanges();
      MyRenderStats.Generic.WriteFormat("Available GPU memory: {0} MB", (float) ((double) MyRenderProxy.GetAvailableTextureMemory() / 1024.0 / 1024.0), MyStatTypeEnum.CurrentValue, 300, 2, -1);
      MyRenderProxy.BeforeRender(new MyTimeSpan?(this.m_timer.Elapsed));
      this.m_renderWindow.BeforeDraw();
      Action action = this.BeforeDraw;
      if (action != null)
        action();
      MyRenderDeviceCooperativeLevel cooperativeLevel = MyRenderProxy.TestDeviceCooperativeLevel();
      if (!this.m_renderWindow.DrawEnabled)
        MyRenderProxy.ProcessMessages();
      else if (cooperativeLevel == MyRenderDeviceCooperativeLevel.Ok)
      {
        this.Draw();
      }
      else
      {
        MyRenderProxy.ProcessMessages();
        if (cooperativeLevel == MyRenderDeviceCooperativeLevel.Lost)
          Thread.Sleep(20);
        else if (cooperativeLevel == MyRenderDeviceCooperativeLevel.NotReset)
        {
          Thread.Sleep(20);
          this.DeviceReset();
        }
      }
      MyRenderProxy.AfterRender();
      if (cooperativeLevel == MyRenderDeviceCooperativeLevel.Ok)
      {
        if (this.m_renderWindow.DrawEnabled)
        {
          try
          {
            MyRenderProxy.Present();
          }
          catch (MyDeviceLostException ex)
          {
          }
        }
      }
      this.m_messageProcessingStart = this.m_timer.Elapsed;
    }

    private void ApplySettingsChanges()
    {
      if (MyRenderProxy.TestDeviceCooperativeLevel() != MyRenderDeviceCooperativeLevel.Ok)
        return;
      int num = Interlocked.Exchange(ref this.m_newQuality, -1);
      if (num != -1)
        this.m_currentQuality = (MyRenderQualityEnum) num;
      if (this.m_newSettings.HasValue && MyRenderProxy.SettingsChanged(this.m_newSettings.Value))
      {
        this.m_settings = this.m_newSettings.Value;
        this.m_newSettings = new MyRenderDeviceSettings?();
        this.UnloadContent();
        MyRenderProxy.ApplySettings(this.m_settings);
        this.LoadContent();
        this.UpdateSize(new MyWindowModeEnum?());
      }
      else
      {
        if (num == -1)
          return;
        MyRenderProxy.ReloadContent(this.m_currentQuality);
      }
    }

    private void LoadContent()
    {
      MyRenderProxy.LoadContent(this.m_currentQuality);
    }

    public void UpdateSize(MyWindowModeEnum? customMode = null)
    {
      switch (customMode.HasValue ? (int) customMode.Value : (int) this.m_settings.WindowMode)
      {
        case 0:
          this.m_renderWindow.OnModeChanged(MyWindowModeEnum.Window, this.m_settings.BackBufferWidth, this.m_settings.BackBufferHeight);
          break;
        case 1:
          WinApi.DEVMODE devMode = new WinApi.DEVMODE();
          WinApi.EnumDisplaySettings((string) null, -2, ref devMode);
          this.m_renderWindow.OnModeChanged(MyWindowModeEnum.FullscreenWindow, devMode.dmPelsWidth, devMode.dmPelsHeight);
          break;
        case 2:
          this.m_renderWindow.OnModeChanged(MyWindowModeEnum.Fullscreen, this.m_settings.BackBufferWidth, this.m_settings.BackBufferHeight);
          break;
      }
      SizeChangedHandler sizeChangedHandler = this.SizeChanged;
      if (sizeChangedHandler == null)
        return;
      sizeChangedHandler(MyRenderProxy.BackBufferResolution.X, MyRenderProxy.BackBufferResolution.Y, MyRenderProxy.MainViewport);
    }

    private void UnloadContent()
    {
      MyRenderProxy.UnloadContent();
    }

    private void DeviceReset()
    {
      this.UnloadContent();
      if (!MyRenderProxy.ResetDevice())
        return;
      this.LoadContent();
    }

    private void Draw()
    {
      MyRenderProxy.DrawBegin();
      MyRenderProxy.ClearBackbuffer(new ColorBGRA(0.0f));
      MyRenderProxy.ClearLargeMessages();
      MyRenderProxy.Draw();
      MyRenderProxy.DrawEnd();
    }

    private class StartParams
    {
      public InitHandler InitHandler;
      public MyRenderDeviceSettings? SettingsToTry;
      public MyRenderQualityEnum RenderQuality;
    }
  }
}
