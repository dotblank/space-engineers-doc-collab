﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Models.MySphere
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRage.Common.Noise;

namespace VRage.Common.Noise.Models
{
  internal class MySphere : IMyModule
  {
    public IMyModule Module { get; set; }

    public MySphere(IMyModule module)
    {
      this.Module = module;
    }

    protected void LatLonToXYZ(double lat, double lon, out double x, out double y, out double z)
    {
      double num = Math.Cos(Math.PI / 180.0 * lat);
      x = Math.Cos(Math.PI / 180.0 * lon) * num;
      y = Math.Sin(Math.PI / 180.0 * lat);
      z = Math.Sin(Math.PI / 180.0 * lon) * num;
    }

    public double GetValue(double x)
    {
      throw new NotImplementedException();
    }

    public double GetValue(double latitude, double longitude)
    {
      double x;
      double y;
      double z;
      this.LatLonToXYZ(latitude, longitude, out x, out y, out z);
      return this.Module.GetValue(x, y, z);
    }

    public double GetValue(double x, double y, double z)
    {
      throw new NotImplementedException();
    }
  }
}
