﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Combiners.MyPower
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRage.Common.Noise;

namespace VRage.Common.Noise.Combiners
{
  public class MyPower : IMyModule
  {
    private double powerOffset;

    public IMyModule Base { get; set; }

    public IMyModule Power { get; set; }

    public MyPower(IMyModule baseModule, IMyModule powerModule, double powerOffset = 0.0)
    {
      this.Base = baseModule;
      this.Power = powerModule;
      this.powerOffset = powerOffset;
    }

    public double GetValue(double x)
    {
      return Math.Pow(this.Base.GetValue(x), this.powerOffset + this.Power.GetValue(x));
    }

    public double GetValue(double x, double y)
    {
      return Math.Pow(this.Base.GetValue(x, y), this.powerOffset + this.Power.GetValue(x, y));
    }

    public double GetValue(double x, double y, double z)
    {
      return Math.Pow(this.Base.GetValue(x, y, z), this.powerOffset + this.Power.GetValue(x, y, z));
    }
  }
}
