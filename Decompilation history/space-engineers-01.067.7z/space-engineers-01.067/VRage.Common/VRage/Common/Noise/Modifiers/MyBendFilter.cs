﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Modifiers.MyBendFilter
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Noise;

namespace VRage.Common.Noise.Modifiers
{
  public class MyBendFilter : IMyModule
  {
    private double m_rangeSizeInverted;
    private double m_clampingMin;
    private double m_clampingMax;

    public IMyModule Module { get; set; }

    public double OutOfRangeMin { get; set; }

    public double OutOfRangeMax { get; set; }

    public double ClampingMin
    {
      get
      {
        return this.m_clampingMin;
      }
      set
      {
        this.m_clampingMin = value;
        this.m_rangeSizeInverted = 1.0 / (this.m_clampingMax - this.m_clampingMin);
      }
    }

    public double ClampingMax
    {
      get
      {
        return this.m_clampingMax;
      }
      set
      {
        this.m_clampingMax = value;
        this.m_rangeSizeInverted = 1.0 / (this.m_clampingMax - this.m_clampingMin);
      }
    }

    public MyBendFilter(IMyModule module, double clampRangeMin, double clampRangeMax, double outOfRangeMin, double outOfRangeMax)
    {
      this.Module = module;
      this.m_rangeSizeInverted = 1.0 / (clampRangeMax - clampRangeMin);
      this.m_clampingMin = clampRangeMin;
      this.m_clampingMax = clampRangeMax;
      this.OutOfRangeMin = outOfRangeMin;
      this.OutOfRangeMax = outOfRangeMax;
    }

    public double GetValue(double x)
    {
      return this.expandRange(this.Module.GetValue(x));
    }

    public double GetValue(double x, double y)
    {
      return this.expandRange(this.Module.GetValue(x, y));
    }

    public double GetValue(double x, double y, double z)
    {
      return this.expandRange(this.Module.GetValue(x, y, z));
    }

    private double expandRange(double value)
    {
      if (value < this.m_clampingMin)
        return this.OutOfRangeMin;
      if (value > this.m_clampingMax)
        return this.OutOfRangeMax;
      else
        return (value - this.m_clampingMin) * this.m_rangeSizeInverted;
    }
  }
}
