﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Modifiers.MyExponent
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRage.Common.Noise;

namespace VRage.Common.Noise.Modifiers
{
  public class MyExponent : IMyModule
  {
    public double Exponent { get; set; }

    public IMyModule Module { get; set; }

    public MyExponent(IMyModule module, double exponent = 2.0)
    {
      this.Exponent = exponent;
      this.Module = module;
    }

    public double GetValue(double x)
    {
      return Math.Pow((this.Module.GetValue(x) + 1.0) * 0.5, this.Exponent) * 2.0 - 1.0;
    }

    public double GetValue(double x, double y)
    {
      return Math.Pow((this.Module.GetValue(x, y) + 1.0) * 0.5, this.Exponent) * 2.0 - 1.0;
    }

    public double GetValue(double x, double y, double z)
    {
      return Math.Pow((this.Module.GetValue(x, y, z) + 1.0) * 0.5, this.Exponent) * 2.0 - 1.0;
    }
  }
}
