﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.MyRNG
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common.Noise
{
  public struct MyRNG
  {
    private const uint MAX_MASK = 2147483647U;
    private const float MAX_MASK_FLOAT = 2.147484E+09f;
    public uint Seed;

    public MyRNG(int seed = 1)
    {
      this.Seed = (uint) seed;
    }

    public uint NextInt()
    {
      return this.Gen();
    }

    public float NextFloat()
    {
      return (float) this.Gen() / (float) int.MaxValue;
    }

    public int NextIntRange(float min, float max)
    {
      return (int) ((double) min + ((double) max - (double) min) * (double) this.NextFloat() + 0.5);
    }

    public float NextFloatRange(float min, float max)
    {
      return min + (max - min) * this.NextFloat();
    }

    private uint Gen()
    {
      return this.Seed = (uint) ((int) this.Seed * 16807 & int.MaxValue);
    }
  }
}
