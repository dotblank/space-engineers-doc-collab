﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.MyCylinders
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace VRage.Common.Noise
{
  internal class MyCylinders : IMyModule
  {
    public double Frequency { get; set; }

    public MyCylinders(double frequnecy = 1.0)
    {
      this.Frequency = frequnecy;
    }

    public double GetValue(double x)
    {
      x *= this.Frequency;
      double n = Math.Sqrt(x * x + x * x);
      int num = MathHelper.Floor(n);
      double val1 = n - (double) num;
      double val2 = 1.0 - val1;
      return 1.0 - Math.Min(val1, val2) * 4.0;
    }

    public double GetValue(double x, double z)
    {
      x *= this.Frequency;
      z *= this.Frequency;
      double n = Math.Sqrt(x * x + z * z);
      int num = MathHelper.Floor(n);
      double val1 = n - (double) num;
      double val2 = 1.0 - val1;
      return 1.0 - Math.Min(val1, val2) * 4.0;
    }

    public double GetValue(double x, double y, double z)
    {
      throw new NotImplementedException();
    }
  }
}
