﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Patterns.MyConstant
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Noise;

namespace VRage.Common.Noise.Patterns
{
  public class MyConstant : IMyModule
  {
    public double Constant { get; set; }

    public MyConstant(double constant)
    {
      this.Constant = constant;
    }

    public double GetValue(double x)
    {
      return this.Constant;
    }

    public double GetValue(double x, double y)
    {
      return this.Constant;
    }

    public double GetValue(double x, double y, double z)
    {
      return this.Constant;
    }
  }
}
