﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Patterns.MySphere
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Noise;

namespace VRage.Common.Noise.Patterns
{
  public class MySphere : IMyModule
  {
    private double m_outerRadiusBlendingSqrDist;
    private double m_innerRadius;
    private double m_innerRadiusSqr;
    private double m_outerRadius;
    private double m_outerRadiusSqr;

    public double InnerRadius
    {
      get
      {
        return this.m_innerRadius;
      }
      set
      {
        this.m_innerRadius = value;
        this.m_innerRadiusSqr = value * value;
        this.UpdateBlendingDistnace();
      }
    }

    public double OuterRadius
    {
      get
      {
        return this.m_outerRadius;
      }
      set
      {
        this.m_outerRadius = value;
        this.m_outerRadiusSqr = value * value;
        this.UpdateBlendingDistnace();
      }
    }

    public MySphere(double innerRadius, double outerRadius)
    {
      this.InnerRadius = innerRadius;
      this.OuterRadius = outerRadius;
    }

    private void UpdateBlendingDistnace()
    {
      this.m_outerRadiusBlendingSqrDist = this.m_outerRadiusSqr - this.m_innerRadiusSqr;
    }

    public double GetValue(double x)
    {
      return this.ClampDistanceToRadius(x * x);
    }

    public double GetValue(double x, double y)
    {
      return this.ClampDistanceToRadius(x * x + y * y);
    }

    public double GetValue(double x, double y, double z)
    {
      return this.ClampDistanceToRadius(x * x + y * y + z * z);
    }

    private double ClampDistanceToRadius(double distanceSqr)
    {
      if (distanceSqr >= this.m_outerRadiusSqr)
        return 0.0;
      if (distanceSqr < this.m_innerRadiusSqr)
        return 1.0;
      else
        return 1.0 - (distanceSqr - this.m_innerRadiusSqr) / this.m_outerRadiusBlendingSqrDist;
    }
  }
}
