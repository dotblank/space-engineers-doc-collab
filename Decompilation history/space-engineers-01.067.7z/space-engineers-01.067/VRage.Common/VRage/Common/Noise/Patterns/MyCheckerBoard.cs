﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Patterns.MyCheckerBoard
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Noise;
using VRageMath;

namespace VRage.Common.Noise.Patterns
{
  public class MyCheckerBoard : IMyModule
  {
    public double GetValue(double x)
    {
      return (MathHelper.Floor(x) & 1) != 1 ? 1.0 : -1.0;
    }

    public double GetValue(double x, double y)
    {
      return (MathHelper.Floor(x) & 1 ^ MathHelper.Floor(y) & 1) != 1 ? 1.0 : -1.0;
    }

    public double GetValue(double x, double y, double z)
    {
      return (MathHelper.Floor(x) & 1 ^ MathHelper.Floor(y) & 1 ^ MathHelper.Floor(z) & 1) != 1 ? 1.0 : -1.0;
    }
  }
}
