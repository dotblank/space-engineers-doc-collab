﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Noise.Patterns.MyRing
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRage.Common.Noise;

namespace VRage.Common.Noise.Patterns
{
  public class MyRing : IMyModule
  {
    private double m_thickness;
    private double m_thicknessSqr;

    public double Radius { get; set; }

    public double Thickness
    {
      get
      {
        return this.m_thickness;
      }
      set
      {
        this.m_thickness = value;
        this.m_thicknessSqr = value * value;
      }
    }

    public MyRing(double radius, double thickness)
    {
      this.Radius = radius;
      this.Thickness = thickness;
    }

    public double GetValue(double x)
    {
      double num = Math.Sqrt(x * x) - this.Radius;
      return this.clampToRing(num * num);
    }

    public double GetValue(double x, double y)
    {
      double num = Math.Sqrt(x * x + y * y) - this.Radius;
      return this.clampToRing(num * num);
    }

    public double GetValue(double x, double y, double z)
    {
      if (Math.Abs(z) >= this.Thickness)
        return 0.0;
      double num1 = Math.Sqrt(x * x + y * y);
      if (Math.Abs(num1 - this.Radius) >= this.Thickness)
        return 0.0;
      double num2 = x / num1 * this.Radius - x;
      double num3 = y / num1 * this.Radius - y;
      return this.clampToRing(num2 * num2 + num3 * num3 + z * z);
    }

    private double clampToRing(double squareDstFromRing)
    {
      if (squareDstFromRing < this.m_thicknessSqr)
        return 1.0 - squareDstFromRing / this.m_thicknessSqr;
      else
        return 0.0;
    }
  }
}
