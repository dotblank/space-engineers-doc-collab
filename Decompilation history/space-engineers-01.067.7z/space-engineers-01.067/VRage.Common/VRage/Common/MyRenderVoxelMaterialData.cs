﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyRenderVoxelMaterialData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common
{
  public struct MyRenderVoxelMaterialData
  {
    public byte Index;
    public string DiffuseXZ;
    public string NormalXZ;
    public string DiffuseY;
    public string NormalY;
    public float SpecularShininess;
    public float SpecularPower;
    public string ColorMetalXZnY;
    public string ColorMetalY;
    public string NormalGlossXZnY;
    public string NormalGlossY;
    public string ExtXZnY;
    public string ExtY;
    public string LowFrequencyColorMetalXZnY;
    public string LowFrequencyColorMetalY;
    public string LowFrequencyNormalGlossXZnY;
    public string LowFrequencyNormalGlossY;
    public string LowFrequencyExtXZnY;
    public string LowFrequencyExtY;
    public float HighFrequencyScale;
    public float LowFrequencyScale;
    public string ExtensionTextureArray1;
    public string ExtensionTextureArray2;
    public float ExtensionDensity;
    public Vector2 ExtensionScale;
    public float ExtensionRandomRescaleMult;
  }
}
