﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MySpectator
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common
{
  public class MySpectator
  {
    public Vector3D ThirdPersonCameraDelta = new Vector3D(-10.0, 10.0, -10.0);
    protected float m_speedMode = 0.1f;
    protected MatrixD m_orientation = MatrixD.Identity;
    protected bool m_rotationEnabled = true;
    public const float DEFAULT_SPECTATOR_SPEED = 0.1f;
    public const float MIN_SPECTATOR_SPEED = 0.0001f;
    public const float MAX_SPECTATOR_SPEED = 150f;
    public static MySpectator Static;
    public MySpectatorCameraMovementEnum SpectatorCameraMovement;
    private Vector3D m_position;
    private Vector3D m_target;
    private float m_orbitY;
    private float m_orbitX;

    public bool IsInFirstPersonView { get; set; }

    public bool ForceFirstPersonCamera { get; set; }

    public Vector3D Position
    {
      get
      {
        return this.m_position;
      }
      set
      {
        MyUtils.AssertIsValid(value);
        this.m_position = value;
      }
    }

    public float SpeedMode
    {
      get
      {
        return this.m_speedMode;
      }
      set
      {
        this.m_speedMode = value;
      }
    }

    public Vector3D Target
    {
      get
      {
        return this.m_target;
      }
      set
      {
        this.m_target = value;
        if (this.SpectatorCameraMovement == MySpectatorCameraMovementEnum.Orbit)
          return;
        this.UpdateOrientation();
      }
    }

    public MatrixD Orientation
    {
      get
      {
        return this.m_orientation;
      }
    }

    public MySpectator()
    {
      MySpectator.Static = this;
    }

    public void UpdateOrientation()
    {
      Vector3D vector3D1 = MyVRageUtils.Normalize(this.Target - this.Position);
      Vector3D vector3D2 = vector3D1.LengthSquared() > 0.0 ? vector3D1 : Vector3D.Forward;
      Vector3D vec = Vector3D.Cross(vector3D2, Vector3D.Up);
      Vector3D vector1 = vec.LengthSquared() > 0.0 ? MyVRageUtils.Normalize(vec) : Vector3D.Right;
      Vector3D vector3D3 = MyVRageUtils.Normalize(Vector3D.Cross(vector1, vector3D2));
      this.m_orientation = MatrixD.Identity;
      this.m_orientation.Forward = vector3D2;
      this.m_orientation.Right = vector1;
      this.m_orientation.Up = vector3D3;
    }

    public void Rotate(Vector2 rotationIndicator, float rollIndicator)
    {
      this.MoveAndRotate(Vector3.Zero, rotationIndicator, rollIndicator);
    }

    public void RotateStopped()
    {
      this.MoveAndRotateStopped();
    }

    public virtual void MoveAndRotate(Vector3 moveIndicator, Vector2 rotationIndicator, float rollIndicator)
    {
      Vector3D position1 = this.Position;
      moveIndicator *= this.m_speedMode;
      float num1 = 0.1f;
      float num2 = 1.0 / 400.0;
      Vector3D position2 = (Vector3D) moveIndicator * (double) num1;
      switch (this.SpectatorCameraMovement)
      {
        case MySpectatorCameraMovementEnum.UserControlled:
          if (this.m_rotationEnabled)
          {
            if ((double) rollIndicator != 0.0)
            {
              float angle = MathHelper.Clamp((float) ((double) rollIndicator * (double) this.m_speedMode * 0.100000001490116), -0.02f, 0.02f);
              Vector3D xOut;
              Vector3D yOut;
              MyUtils.VectorPlaneRotation(this.m_orientation.Up, this.m_orientation.Right, out xOut, out yOut, angle);
              this.m_orientation.Right = yOut;
              this.m_orientation.Up = xOut;
            }
            if ((double) rotationIndicator.X != 0.0)
            {
              Vector3D xOut;
              Vector3D yOut;
              MyUtils.VectorPlaneRotation(this.m_orientation.Up, this.m_orientation.Forward, out xOut, out yOut, rotationIndicator.X * num2);
              this.m_orientation.Up = xOut;
              this.m_orientation.Forward = yOut;
            }
            if ((double) rotationIndicator.Y != 0.0)
            {
              Vector3D xOut;
              Vector3D yOut;
              MyUtils.VectorPlaneRotation(this.m_orientation.Right, this.m_orientation.Forward, out xOut, out yOut, -rotationIndicator.Y * num2);
              this.m_orientation.Right = xOut;
              this.m_orientation.Forward = yOut;
            }
          }
          this.Position += Vector3D.Transform(position2, this.m_orientation);
          break;
        case MySpectatorCameraMovementEnum.Orbit:
          this.m_orbitY += rotationIndicator.Y * 0.01f;
          this.m_orbitX += rotationIndicator.X * 0.01f;
          Vector3D position3 = Vector3D.Transform(this.Position - this.Target, (MatrixD) Matrix.Invert((Matrix) this.m_orientation));
          rotationIndicator *= 0.01f;
          MatrixD matrix = MatrixD.CreateRotationX((double) this.m_orbitX) * MatrixD.CreateRotationY((double) this.m_orbitY) * MatrixD.CreateRotationZ((double) rollIndicator);
          this.Position = this.Target + Vector3D.Transform(position3, matrix);
          Vector3D vector3D = this.m_orientation.Right * position2.X + this.m_orientation.Up * position2.Y;
          this.Target += vector3D;
          this.Position += vector3D;
          this.Position += this.m_orientation.Forward * -position2.Z;
          this.m_orientation = matrix;
          break;
      }
    }

    public virtual void MoveAndRotateStopped()
    {
    }

    public MatrixD GetViewMatrix()
    {
      return MatrixD.Invert(MatrixD.CreateWorld(this.Position, this.m_orientation.Forward, this.m_orientation.Up));
    }

    public void SetViewMatrix(MatrixD viewMatrix)
    {
      MyUtils.AssertIsValid(viewMatrix);
      MatrixD matrixD = MatrixD.Invert(viewMatrix);
      this.Position = matrixD.Translation;
      this.m_orientation = MatrixD.Identity;
      this.m_orientation.Right = matrixD.Right;
      this.m_orientation.Up = matrixD.Up;
      this.m_orientation.Forward = matrixD.Forward;
    }

    public void EnableRotation()
    {
      this.m_rotationEnabled = true;
    }

    public void DisableRotation()
    {
      this.m_rotationEnabled = false;
    }

    public void ResetSpectatorView()
    {
      this.Position = Vector3D.Zero;
      this.m_orientation = MatrixD.Identity;
    }
  }
}
