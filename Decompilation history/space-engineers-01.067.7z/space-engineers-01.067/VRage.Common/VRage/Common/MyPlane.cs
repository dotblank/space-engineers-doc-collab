﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyPlane
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Utils;
using VRageMath;
using VRageRender;

namespace VRage.Common
{
  public struct MyPlane
  {
    public Vector3 Point;
    public Vector3 Normal;

    public MyPlane(Vector3 point, Vector3 normal)
    {
      this.Point = point;
      this.Normal = normal;
    }

    public MyPlane(ref Vector3 point, ref Vector3 normal)
    {
      this.Point = point;
      this.Normal = normal;
    }

    public MyPlane(ref MyTriangle_Vertexes triangle)
    {
      this.Point = triangle.Vertex0;
      this.Normal = MyVRageUtils.Normalize(Vector3.Cross(triangle.Vertex1 - triangle.Vertex0, triangle.Vertex2 - triangle.Vertex0));
    }

    public float GetPlaneDistance()
    {
      return (float) -((double) this.Normal.X * (double) this.Point.X + (double) this.Normal.Y * (double) this.Point.Y + (double) this.Normal.Z * (double) this.Point.Z);
    }
  }
}
