﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Voxels.MyStorageDataCache
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Voxels
{
  public class MyStorageDataCache
  {
    private const int m_sX = 2;
    private byte[] m_data;
    private int m_sZ;
    private int m_sY;
    private Vector3I m_size3d;
    private int m_sizeLinear;

    public byte[] Data
    {
      get
      {
        return this.m_data;
      }
    }

    public int SizeLinear
    {
      get
      {
        return this.m_sizeLinear;
      }
    }

    public int StepLinear
    {
      get
      {
        return 2;
      }
    }

    public Vector3I Size3D
    {
      get
      {
        return this.m_size3d;
      }
    }

    public void Resize(Vector3I start, Vector3I end)
    {
      this.Resize(end - start + 1);
    }

    public void Resize(Vector3I size3D)
    {
      this.m_size3d = size3D;
      int num = size3D.Size();
      this.m_sY = size3D.X * 2;
      this.m_sZ = size3D.Y * this.m_sY;
      this.m_sizeLinear = num * this.StepLinear;
      if (this.m_data != null && this.m_data.Length >= this.m_sizeLinear)
        return;
      this.m_data = new byte[MathHelper.GetNearestBiggerPowerOfTwo(this.m_sizeLinear)];
    }

    public byte Get(MyStorageDataTypeEnum type, ref Vector3I p)
    {
      return this.m_data[(int) (p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ + type)];
    }

    public byte Get(MyStorageDataTypeEnum type, int linearIdx)
    {
      return this.m_data[(int) (linearIdx + type)];
    }

    public byte Get(MyStorageDataTypeEnum type, int x, int y, int z)
    {
      return this.m_data[(int) (x * 2 + y * this.m_sY + z * this.m_sZ + type)];
    }

    public void Set(MyStorageDataTypeEnum type, ref Vector3I p, byte value)
    {
      this.m_data[(int) (p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ + type)] = value;
    }

    public void Content(ref Vector3I p, byte content)
    {
      this.m_data[p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ] = content;
    }

    public void Content(int linearIdx, byte content)
    {
      this.m_data[linearIdx] = content;
    }

    public byte Content(ref Vector3I p)
    {
      return this.m_data[p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ];
    }

    public byte Content(int x, int y, int z)
    {
      return this.m_data[x * 2 + y * this.m_sY + z * this.m_sZ];
    }

    public byte Content(int linearIdx)
    {
      return this.m_data[linearIdx];
    }

    public void Material(ref Vector3I p, byte materialIdx)
    {
      this.m_data[p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ + 1] = materialIdx;
    }

    public byte Material(ref Vector3I p)
    {
      return this.m_data[p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ + 1];
    }

    public byte Material(int linearIdx)
    {
      return this.m_data[linearIdx + 1];
    }

    public void Material(int linearIdx, byte materialIdx)
    {
      this.m_data[linearIdx + 1] = materialIdx;
    }

    public int ComputeLinear(ref Vector3I p)
    {
      return p.X * 2 + p.Y * this.m_sY + p.Z * this.m_sZ;
    }

    public bool WrinkleVoxelContent(ref Vector3I p, float wrinkleWeightAdd, float wrinkleWeightRemove)
    {
      int num1 = int.MinValue;
      int num2 = int.MaxValue;
      int num3 = (int) ((double) wrinkleWeightAdd * (double) byte.MaxValue);
      int num4 = (int) ((double) wrinkleWeightRemove * (double) byte.MaxValue);
      for (int index1 = -1; index1 <= 1; ++index1)
      {
        Vector3I p1;
        p1.Z = index1 + p.Z;
        if ((uint) p1.Z < (uint) this.m_size3d.Z)
        {
          for (int index2 = -1; index2 <= 1; ++index2)
          {
            p1.Y = index2 + p.Y;
            if ((uint) p1.Y < (uint) this.m_size3d.Y)
            {
              for (int index3 = -1; index3 <= 1; ++index3)
              {
                p1.X = index3 + p.X;
                if ((uint) p1.X < (uint) this.m_size3d.X)
                {
                  byte num5 = this.Content(ref p1);
                  num1 = Math.Max(num1, (int) num5);
                  num2 = Math.Min(num2, (int) num5);
                }
              }
            }
          }
        }
      }
      if (num2 == num1)
        return false;
      int num6 = (int) this.Content(ref p);
      byte content = (byte) MyVRageUtils.GetClampInt(num6 + MyVRageUtils.GetRandomInt(num3 + num4) - num4, num2, num1);
      if ((int) content == num6)
        return false;
      this.Content(ref p, content);
      return true;
    }

    public void BlockFillContent(Vector3I min, Vector3I max, byte content)
    {
      Vector3I p;
      for (p.Z = min.Z; p.Z <= max.Z; ++p.Z)
      {
        for (p.Y = min.Y; p.Y <= max.Y; ++p.Y)
        {
          for (p.X = min.X; p.X <= max.X; ++p.X)
            this.Content(ref p, content);
        }
      }
    }

    public void BlockFillMaterial(Vector3I min, Vector3I max, byte materialIdx)
    {
      Vector3I p;
      for (p.Z = min.Z; p.Z <= max.Z; ++p.Z)
      {
        for (p.Y = min.Y; p.Y <= max.Y; ++p.Y)
        {
          for (p.X = min.X; p.X <= max.X; ++p.X)
            this.Material(ref p, materialIdx);
        }
      }
    }

    public bool ContainsIsoSurface()
    {
      int index1 = 0;
      bool flag1 = (int) this.m_data[index1] < (int) sbyte.MaxValue;
      int index2 = index1 + this.StepLinear;
      while (index2 < this.m_sizeLinear)
      {
        bool flag2 = (int) this.m_data[index2] < (int) sbyte.MaxValue;
        if (flag1 != flag2)
          return true;
        index2 += this.StepLinear;
      }
      return false;
    }

    public bool ContainsVoxelsAboveIsoLevel()
    {
      int index = 0;
      while (index < this.m_sizeLinear)
      {
        if ((int) this.m_data[index] > (int) sbyte.MaxValue)
          return true;
        index += this.StepLinear;
      }
      return false;
    }

    [Conditional("DEBUG")]
    private void AssertPosition(ref Vector3I position)
    {
    }

    [Conditional("DEBUG")]
    private void AssertPosition(int x, int y, int z)
    {
    }

    public void ClearContent(byte p)
    {
      int index = 0;
      while (index < this.m_sizeLinear)
      {
        this.m_data[index] = p;
        index += this.StepLinear;
      }
    }

    public void ClearMaterials(byte p)
    {
      int index = 1;
      while (index < this.m_sizeLinear)
      {
        this.m_data[index] = p;
        index += this.StepLinear;
      }
    }

    public struct MortonEnumerator : IEnumerator<byte>, IDisposable, IEnumerator
    {
      private MyStorageDataTypeEnum m_type;
      private MyStorageDataCache m_source;
      private int m_maxMortonCode;
      private int m_mortonCode;
      private Vector3I m_pos;
      private byte m_current;

      public byte Current
      {
        get
        {
          return this.m_current;
        }
      }

      object IEnumerator.Current
      {
        get
        {
          return (object) this.m_current;
        }
      }

      public MortonEnumerator(MyStorageDataCache source, MyStorageDataTypeEnum type)
      {
        this.m_type = type;
        this.m_source = source;
        this.m_maxMortonCode = source.Size3D.Size();
        this.m_mortonCode = -1;
        this.m_pos = new Vector3I();
        this.m_current = (byte) 0;
      }

      public void Dispose()
      {
      }

      public bool MoveNext()
      {
        ++this.m_mortonCode;
        if (this.m_mortonCode >= this.m_maxMortonCode)
          return false;
        MyMortonCode3D.Decode(this.m_mortonCode, out this.m_pos);
        this.m_current = this.m_source.Get(this.m_type, ref this.m_pos);
        return true;
      }

      public void Reset()
      {
        this.m_mortonCode = -1;
        this.m_current = (byte) 0;
      }
    }
  }
}
