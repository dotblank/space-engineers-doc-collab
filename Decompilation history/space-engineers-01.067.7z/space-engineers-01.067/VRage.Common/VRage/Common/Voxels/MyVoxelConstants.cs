﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Voxels.MyVoxelConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace VRage.Common.Voxels
{
  public static class MyVoxelConstants
  {
    public static readonly Vector3 VOXEL_SIZE_VECTOR = new Vector3(1f, 1f, 1f);
    public static readonly Vector3 VOXEL_SIZE_VECTOR_HALF = MyVoxelConstants.VOXEL_SIZE_VECTOR / 2f;
    public static readonly float VOXEL_RADIUS = MyVoxelConstants.VOXEL_SIZE_VECTOR_HALF.Length();
    public static readonly Vector3 GEOMETRY_CELL_SIZE_VECTOR_IN_METRES = new Vector3(8f);
    public static readonly int GEOMETRY_CELL_CACHE_SIZE = Environment.Is64BitProcess ? 262144 : 78643;
    public static readonly Vector3 RENDER_CELL_SIZE_VECTOR_IN_METRES = new Vector3(32f);
    public const string FILE_EXTENSION = ".vx2";
    public const int PREALLOCATED_CELL_CONTENTS_COUNT = 120000;
    public const byte VOXEL_ISO_LEVEL = (byte) 127;
    public const byte VOXEL_CONTENT_EMPTY = (byte) 0;
    public const byte VOXEL_CONTENT_FULL = (byte) 255;
    public const float VOXEL_CONTENT_FULL_FLOAT = 255f;
    public const float VOXEL_SIZE_IN_METRES = 1f;
    public const float VOXEL_VOLUME_IN_METERS = 1f;
    public const float VOXEL_SIZE_IN_METRES_HALF = 0.5f;
    public const int DATA_CELL_SIZE_IN_VOXELS_BITS = 3;
    public const int DATA_CELL_SIZE_IN_VOXELS = 8;
    public const int DATA_CELL_SIZE_IN_VOXELS_MASK = 7;
    public const int DATA_CELL_SIZE_IN_VOXELS_TOTAL = 512;
    public const int DATA_CELL_CONTENT_SUM_TOTAL = 130560;
    public const float DATA_CELL_SIZE_IN_METRES = 8f;
    public const int GEOMETRY_CELL_SIZE_IN_VOXELS_BITS = 3;
    public const int GEOMETRY_CELL_SIZE_IN_VOXELS = 8;
    public const int GEOMETRY_CELL_SIZE_IN_VOXELS_TOTAL = 512;
    public const int GEOMETRY_CELL_MAX_TRIANGLES_COUNT = 2560;
    public const float GEOMETRY_CELL_SIZE_IN_METRES = 8f;
    public const float GEOMETRY_CELL_SIZE_IN_METRES_HALF = 4f;
    public const int RENDER_CELL_SIZE_IN_GEOMETRY_CELLS_BITS = 2;
    public const int RENDER_CELL_SIZE_IN_GEOMETRY_CELLS = 4;
    public const int RENDER_CELL_SIZE_IN_GEOMETRY_CELLS_TOTAL = 64;
    public const int RENDER_CELL_SIZE_IN_VOXELS = 32;
    public const float RENDER_CELL_SIZE_IN_METRES = 32f;
    public const float RENDER_CELL_SIZE_IN_METRES_HALF = 16f;
    public const int RENDER_CELL_CACHE_SIZE = 16384;
    public const float DEFAULT_WRINKLE_WEIGHT_ADD = 0.5f;
    public const float DEFAULT_WRINKLE_WEIGHT_REMOVE = 0.45f;
  }
}
