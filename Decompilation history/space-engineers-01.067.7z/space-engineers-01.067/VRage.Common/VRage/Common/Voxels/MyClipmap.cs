﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Voxels.MyClipmap
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRage.Collections;
using VRage.Common;
using VRageMath;
using VRageRender;

namespace VRage.Common.Voxels
{
  public class MyClipmap
  {
    public static uint DebugClipmapMostDetailedLod = 0U;
    private static readonly float[] m_lodRanges = new float[17];
    private static MyBinaryHeap<short, MyClipmap.UpdateQueueItem> m_updateQueue = new MyBinaryHeap<short, MyClipmap.UpdateQueueItem>(128, (IComparer<short>) new MyClipmap.UpdateFrameComparer());
    private static HashSet<MyClipmap> m_toRemove = new HashSet<MyClipmap>();
    private static HashSet<MyClipmap> m_notReady = new HashSet<MyClipmap>();
    private readonly MyClipmap.LodLevel[] m_lodLevels = new MyClipmap.LodLevel[16];
    private Vector3D m_lastClippingPosition = Vector3D.PositiveInfinity;
    private bool m_updateClipping = true;
    private uint m_lastMostDetailedLod;
    private readonly MyClipmap.RequestCollector m_requestCollector;
    private readonly MyClipmap.UpdateQueueItem m_updateQueueItem;
    private readonly IMyClipmapCellHandler m_cellHandler;
    private Vector3I m_sizeLod0;
    private BoundingBoxD m_localAABB;
    private BoundingBoxD m_worldAABB;
    private MatrixD m_worldMatrix;
    private MatrixD m_invWorldMatrix;
    private static short m_currentFrameIdx;

    static MyClipmap()
    {
      MyClipmap.m_lodRanges = new float[17];
      MyClipmap.UpdateLodRanges(MyRenderConstants.m_renderQualityProfiles[0].LodClipmapRanges);
    }

    public MyClipmap(uint id, MatrixD worldMatrix, Vector3I sizeLod0, IMyClipmapCellHandler cellProvider)
    {
      this.m_worldMatrix = worldMatrix;
      MatrixD.Invert(ref this.m_worldMatrix, out this.m_invWorldMatrix);
      this.m_sizeLod0 = sizeLod0;
      this.m_localAABB = new BoundingBoxD(Vector3D.Zero, new Vector3D(sizeLod0 * 32f));
      for (int lodIndex = 0; lodIndex < this.m_lodLevels.Length; ++lodIndex)
        this.m_lodLevels[lodIndex] = new MyClipmap.LodLevel(this, lodIndex, (this.m_sizeLod0 - 1 >> lodIndex) + 1);
      this.m_updateQueueItem = new MyClipmap.UpdateQueueItem(this);
      this.m_requestCollector = new MyClipmap.RequestCollector(id);
      this.m_cellHandler = cellProvider;
    }

    public void UpdateWorldAABB(out BoundingBoxD worldAabb)
    {
      worldAabb = this.m_localAABB.Transform(ref this.m_worldMatrix);
      this.m_worldAABB = worldAabb;
    }

    public void UpdateWorldMatrix(ref MatrixD worldMatrix, bool sortCellsIntoCullObjects)
    {
      this.m_worldMatrix = worldMatrix;
      MatrixD.Invert(ref this.m_worldMatrix, out this.m_invWorldMatrix);
      foreach (MyClipmap.LodLevel lodLevel in this.m_lodLevels)
        lodLevel.UpdateWorldMatrices(sortCellsIntoCullObjects);
      this.m_updateClipping = true;
    }

    public void LoadContent()
    {
      this.m_updateClipping = true;
    }

    public void UnloadContent()
    {
      foreach (MyClipmap.LodLevel lodLevel in this.m_lodLevels)
        lodLevel.UnloadContent();
      this.m_updateClipping = true;
    }

    public void InvalidateRange(Vector3I minCellLod0, Vector3I maxCellLod0)
    {
      if (minCellLod0 == Vector3I.Zero && maxCellLod0 == this.m_sizeLod0 - 1)
      {
        for (int index = 0; index < this.m_lodLevels.Length; ++index)
          this.m_lodLevels[index].InvalidateAll();
      }
      else
      {
        for (int index = 0; index < this.m_lodLevels.Length; ++index)
          this.m_lodLevels[index].InvalidateRange(minCellLod0 >> index, maxCellLod0 >> index);
      }
      this.m_updateClipping = true;
    }

    public void UpdateCell(MyRenderMessageUpdateClipmapCell msg)
    {
      this.m_lodLevels[msg.Cell.Lod].SetCellMesh(msg);
      this.m_requestCollector.RequestFulfilled(msg.Cell.PackId32());
      this.m_updateClipping = true;
    }

    private void Update(ref Vector3D cameraPos, float farPlaneDistance)
    {
      if ((int) this.m_lastMostDetailedLod != (int) MyClipmap.DebugClipmapMostDetailedLod)
        this.m_updateClipping = true;
      this.m_lastMostDetailedLod = MyClipmap.DebugClipmapMostDetailedLod;
      for (uint index = 0U; index < MyClipmap.DebugClipmapMostDetailedLod; ++index)
        this.m_lodLevels[(IntPtr) index].UnloadContent();
      Vector3D result;
      Vector3D.Transform(ref cameraPos, ref this.m_invWorldMatrix, out result);
      if (!this.m_updateClipping && Vector3D.DistanceSquared(result, this.m_lastClippingPosition) > 256.0)
        this.m_updateClipping = true;
      if (this.m_updateClipping)
      {
        for (int index = this.m_lodLevels.Length - 1; (long) index >= (long) MyClipmap.DebugClipmapMostDetailedLod; --index)
          this.m_lodLevels[index].DoClipping(result, farPlaneDistance, this.m_requestCollector);
        for (int index = this.m_lodLevels.Length - 1; (long) index >= (long) MyClipmap.DebugClipmapMostDetailedLod; --index)
          this.m_lodLevels[index].KeepOrDiscardClippedCells(this.m_requestCollector);
        this.m_lastClippingPosition = result;
        this.m_updateClipping = false;
      }
      for (int index = this.m_lodLevels.Length - 1; (long) index >= (long) MyClipmap.DebugClipmapMostDetailedLod; --index)
        this.m_lodLevels[index].UpdateCellsInScene(result);
      this.m_requestCollector.Submit();
      if (!this.m_requestCollector.SentRequestsEmpty)
        return;
      MyClipmap.m_notReady.Remove(this);
    }

    public static bool UpdateLodRanges(float[] lodDistances)
    {
      MyClipmap.m_lodRanges[0] = 0.0f;
      int index1 = 1;
      for (int index2 = Math.Min(MyClipmap.m_lodRanges.Length, lodDistances.Length + 1); index1 < index2; ++index1)
        MyClipmap.m_lodRanges[index1] = lodDistances[index1 - 1];
      for (; index1 < MyClipmap.m_lodRanges.Length; ++index1)
        MyClipmap.m_lodRanges[index1] = MyClipmap.m_lodRanges[index1 - 1] * 3f;
      return true;
    }

    public static void ComputeLodViewBounds(int lod, out float min, out float max)
    {
      min = MyClipmap.m_lodRanges[lod];
      max = MyClipmap.m_lodRanges[lod + 1] + 8f + (float) (4 << lod);
    }

    public static void AddToUpdate(Vector3D cameraPos, MyClipmap clipmap)
    {
      if (MyClipmap.m_toRemove.Contains(clipmap))
        MyClipmap.m_toRemove.Remove(clipmap);
      else
        MyClipmap.m_updateQueue.Insert(clipmap.m_updateQueueItem, MyClipmap.ComputeNextUpdateFrame(ref cameraPos, clipmap));
      MyClipmap.m_notReady.Add(clipmap);
    }

    public static void RemoveFromUpdate(MyClipmap clipmap)
    {
      MyClipmap.m_toRemove.Add(clipmap);
      MyClipmap.m_notReady.Remove(clipmap);
    }

    private static short ComputeNextUpdateFrame(ref Vector3D cameraPos, MyClipmap clipmap)
    {
      double num1 = clipmap.m_worldAABB.Distance(cameraPos);
      if (num1 < (double) MyClipmap.m_lodRanges[1])
        ;
      short num2 = num1 >= (double) MyClipmap.m_lodRanges[2] ? (num1 >= (double) MyClipmap.m_lodRanges[5] ? (short) 100 : (short) 25) : (short) 10;
      return (short) ((int) MyClipmap.m_currentFrameIdx + (int) num2);
    }

    public static void UpdateQueued(Vector3D cameraPos, float farPlaneDistance)
    {
      ++MyClipmap.m_currentFrameIdx;
      MyClipmap.UpdateLodRanges(MyRenderConstants.RenderQualityProfile.LodClipmapRanges);
      int count = MyClipmap.m_notReady.Count;
      int num1 = 0;
      int num2 = MyClipmap.m_updateQueue.Count / 53;
      while (MyClipmap.m_updateQueue.Count > 0)
      {
        MyClipmap.UpdateQueueItem updateQueueItem = MyClipmap.m_updateQueue.Min();
        if (MyClipmap.m_toRemove.Contains(updateQueueItem.Clipmap))
        {
          MyClipmap.m_toRemove.Remove(updateQueueItem.Clipmap);
          MyClipmap.m_updateQueue.RemoveMin();
        }
        else if ((int) (short) ((int) updateQueueItem.HeapKey - (int) MyClipmap.m_currentFrameIdx) <= 0)
        {
          ++num1;
          BoundingBoxD worldAabb;
          updateQueueItem.Clipmap.UpdateWorldAABB(out worldAabb);
          updateQueueItem.Clipmap.Update(ref cameraPos, farPlaneDistance);
          MyClipmap.m_updateQueue.ModifyDown(updateQueueItem, MyClipmap.ComputeNextUpdateFrame(ref cameraPos, updateQueueItem.Clipmap));
          if (num1 > num2)
            break;
        }
        else
          break;
      }
      if (count == MyClipmap.m_notReady.Count || MyClipmap.m_notReady.Count != 0)
        return;
      MyRenderProxy.SendClipmapsReady();
    }

    private enum CellState
    {
      Invalid,
      Pending,
      Loaded,
    }

    private class CellData
    {
      public MyClipmap.CellState State;
      public ContainmentType NearResult;
      public ContainmentType FarResult;
      public IMyClipmapCell Cell;
      public bool InScene;
      public bool WasLoaded;
    }

    private class LodLevel
    {
      private Dictionary<uint, MyClipmap.CellData> m_storedCellData = new Dictionary<uint, MyClipmap.CellData>();
      private Dictionary<uint, MyClipmap.CellData> m_nonEmptyCells = new Dictionary<uint, MyClipmap.CellData>();
      private Dictionary<uint, MyClipmap.CellData> m_cellDataSwap = new Dictionary<uint, MyClipmap.CellData>();
      private Dictionary<uint, MyClipmap.CellData> m_clippedCells = new Dictionary<uint, MyClipmap.CellData>();
      private float m_nearDistance;
      private float m_farDistance;
      private bool m_fitsInFrustum;
      private int m_lodIndex;
      private Vector3I m_lodSizeMinusOne;
      private MyClipmap m_parent;

      internal LodLevel(MyClipmap parent, int lodIndex, Vector3I lodSize)
      {
        this.m_parent = parent;
        this.m_lodIndex = lodIndex;
        this.m_lodSizeMinusOne = lodSize - 1;
      }

      internal void UnloadContent()
      {
        foreach (MyClipmap.CellData cellData in this.m_nonEmptyCells.Values)
        {
          if (cellData.InScene)
            this.m_parent.m_cellHandler.RemoveFromScene(cellData.Cell);
          this.m_parent.m_cellHandler.DeleteCell(cellData.Cell);
        }
        this.m_nonEmptyCells.Clear();
        this.m_storedCellData.Clear();
      }

      internal void InvalidateRange(Vector3I lodMin, Vector3I lodMax)
      {
        MyCellCoord myCellCoord = new MyCellCoord(this.m_lodIndex, lodMin);
        Vector3I.RangeIterator rangeIterator = new Vector3I.RangeIterator(ref lodMin, ref lodMax);
        while (rangeIterator.IsValid())
        {
          MyClipmap.CellData cellData;
          if (this.m_storedCellData.TryGetValue(myCellCoord.PackId32(), out cellData))
            cellData.State = MyClipmap.CellState.Invalid;
          rangeIterator.GetNext(out myCellCoord.CoordInLod);
        }
      }

      internal void InvalidateAll()
      {
        foreach (MyClipmap.CellData cellData in this.m_storedCellData.Values)
          cellData.State = MyClipmap.CellState.Invalid;
      }

      internal void SetCellMesh(MyRenderMessageUpdateClipmapCell msg)
      {
        uint key = msg.Cell.PackId32();
        MyClipmap.CellData data;
        if (!this.m_storedCellData.TryGetValue(key, out data))
          return;
        if (data.Cell == null && msg.Batches.Count != 0)
        {
          data.Cell = this.m_parent.m_cellHandler.CreateCell(msg.Cell, ref this.m_parent.m_worldMatrix);
          this.m_nonEmptyCells[key] = data;
        }
        else if (data.Cell != null && msg.Batches.Count == 0)
        {
          this.RemoveFromScene(key, data);
          this.m_nonEmptyCells.Remove(key);
          this.m_parent.m_cellHandler.DeleteCell(data.Cell);
          data.Cell = (IMyClipmapCell) null;
        }
        if (data.Cell != null)
          data.Cell.UpdateMesh(msg);
        data.State = MyClipmap.CellState.Loaded;
        data.WasLoaded = true;
      }

      internal void DoClipping(Vector3D localPosition, float farPlaneDistance, MyClipmap.RequestCollector collector)
      {
        MyClipmap.ComputeLodViewBounds(this.m_lodIndex, out this.m_nearDistance, out this.m_farDistance);
        BoundingSphereD nearClipSphere = new BoundingSphereD(localPosition, (double) this.m_nearDistance);
        BoundingSphereD farClipSphere = new BoundingSphereD(localPosition, (double) this.m_farDistance);
        this.m_fitsInFrustum = (double) farPlaneDistance * 1.25 > (double) this.m_nearDistance;
        if (this.m_fitsInFrustum)
        {
          Vector3D localPosition1 = localPosition - (double) this.m_farDistance;
          Vector3D localPosition2 = localPosition + (double) this.m_farDistance;
          Vector3I vector3I1;
          MyVoxelCoordSystems.LocalPositionToRenderCellCoord(ref localPosition1, out vector3I1);
          Vector3I vector3I2;
          MyVoxelCoordSystems.LocalPositionToRenderCellCoord(ref localPosition2, out vector3I2);
          Vector3I.Max(ref vector3I1, ref Vector3I.Zero, out vector3I1);
          Vector3I.Max(ref vector3I2, ref Vector3I.Zero, out vector3I2);
          vector3I1 >>= this.m_lodIndex;
          Vector3I result = vector3I2 >> this.m_lodIndex;
          Vector3I.Min(ref vector3I1, ref this.m_lodSizeMinusOne, out vector3I1);
          Vector3I.Min(ref result, ref this.m_lodSizeMinusOne, out result);
          MyClipmap.LodLevel parentLod;
          MyClipmap.LodLevel childLod;
          this.GetNearbyLodLevels(out parentLod, out childLod);
          MyCellCoord myCellCoord = new MyCellCoord(this.m_lodIndex, ref vector3I1);
          Vector3I.RangeIterator rangeIterator = new Vector3I.RangeIterator(ref vector3I1, ref result);
          while (rangeIterator.IsValid())
          {
            if (MyClipmap.LodLevel.WasAncestorCellLoaded(parentLod, ref myCellCoord))
            {
              ContainmentType nearClipRes;
              ContainmentType farClipRes;
              MyClipmap.LodLevel.TestClipSpheres(ref myCellCoord, ref nearClipSphere, ref farClipSphere, out nearClipRes, out farClipRes);
              uint key = myCellCoord.PackId32();
              MyClipmap.CellData cellData;
              if (farClipRes == ContainmentType.Disjoint)
              {
                if (this.m_storedCellData.TryGetValue(key, out cellData))
                {
                  this.m_storedCellData.Remove(key);
                  cellData.NearResult = nearClipRes;
                  cellData.FarResult = farClipRes;
                  this.m_clippedCells.Add(key, cellData);
                }
              }
              else
              {
                if (this.m_storedCellData.TryGetValue(key, out cellData))
                  this.m_storedCellData.Remove(key);
                else
                  cellData = new MyClipmap.CellData();
                cellData.NearResult = nearClipRes;
                cellData.FarResult = farClipRes;
                if (cellData.State == MyClipmap.CellState.Invalid)
                {
                  collector.AddRequest(myCellCoord.PackId32(), cellData.WasLoaded);
                  cellData.State = MyClipmap.CellState.Pending;
                }
                this.m_cellDataSwap.Add(key, cellData);
              }
            }
            rangeIterator.GetNext(out myCellCoord.CoordInLod);
          }
        }
        foreach (KeyValuePair<uint, MyClipmap.CellData> keyValuePair in this.m_storedCellData)
        {
          MyClipmap.CellData cellData = keyValuePair.Value;
          cellData.NearResult = ContainmentType.Disjoint;
          cellData.FarResult = ContainmentType.Disjoint;
          this.m_clippedCells.Add(keyValuePair.Key, cellData);
        }
        this.m_storedCellData.Clear();
        MyUtils.Swap<Dictionary<uint, MyClipmap.CellData>>(ref this.m_storedCellData, ref this.m_cellDataSwap);
      }

      private static void TestClipSpheres(ref MyCellCoord cell, ref BoundingSphereD nearClipSphere, ref BoundingSphereD farClipSphere, out ContainmentType nearClipRes, out ContainmentType farClipRes)
      {
        BoundingBoxD localAABB;
        MyVoxelCoordSystems.RenderCellCoordToLocalAABB(ref cell, out localAABB);
        localAABB.Inflate(1.0 * (double) (1 << cell.Lod));
        nearClipSphere.Contains(ref localAABB, out nearClipRes);
        farClipSphere.Contains(ref localAABB, out farClipRes);
      }

      internal void KeepOrDiscardClippedCells(MyClipmap.RequestCollector collector)
      {
        MyClipmap.LodLevel parentLod;
        MyClipmap.LodLevel childLod;
        this.GetNearbyLodLevels(out parentLod, out childLod);
        MyCellCoord thisLodCell = new MyCellCoord();
        foreach (KeyValuePair<uint, MyClipmap.CellData> keyValuePair in this.m_clippedCells)
        {
          MyClipmap.CellData data = keyValuePair.Value;
          bool flag = false;
          if (data.FarResult == ContainmentType.Disjoint)
          {
            thisLodCell.SetUnpack(keyValuePair.Key);
            flag = !MyClipmap.LodLevel.WasAncestorCellLoaded(parentLod, ref thisLodCell);
          }
          if (flag)
          {
            if (data.State == MyClipmap.CellState.Invalid)
            {
              collector.AddRequest(keyValuePair.Key, data.WasLoaded);
              data.State = MyClipmap.CellState.Pending;
            }
            this.m_storedCellData.Add(keyValuePair.Key, data);
          }
          else
          {
            if (data.State == MyClipmap.CellState.Pending)
              collector.CancelRequest(keyValuePair.Key);
            if (data.Cell != null)
              this.Delete(keyValuePair.Key, data);
          }
        }
        this.m_clippedCells.Clear();
      }

      internal void UpdateCellsInScene(Vector3D localPosition)
      {
        MyClipmap.LodLevel parentLod;
        MyClipmap.LodLevel childLod;
        this.GetNearbyLodLevels(out parentLod, out childLod);
        BoundingSphereD nearClipSphere = new BoundingSphereD(localPosition, (double) this.m_nearDistance);
        BoundingSphereD farClipSphere = new BoundingSphereD(localPosition, (double) this.m_farDistance);
        MyCellCoord myCellCoord = new MyCellCoord();
        foreach (KeyValuePair<uint, MyClipmap.CellData> keyValuePair in this.m_nonEmptyCells)
        {
          MyClipmap.CellData data = keyValuePair.Value;
          myCellCoord.SetUnpack(keyValuePair.Key);
          MyClipmap.LodLevel.TestClipSpheres(ref myCellCoord, ref nearClipSphere, ref farClipSphere, out data.NearResult, out data.FarResult);
          if (data.NearResult == ContainmentType.Contains)
          {
            if (MyClipmap.LodLevel.ChildrenWereLoaded(childLod, ref myCellCoord))
            {
              this.RemoveFromScene(keyValuePair.Key, data);
            }
            else
            {
              this.AddToScene(keyValuePair.Key, data);
              data.Cell.PixelDiscardEnabled = false;
            }
          }
          else if (data.NearResult == ContainmentType.Intersects)
          {
            this.AddToScene(keyValuePair.Key, data);
            data.Cell.PixelDiscardEnabled = MyClipmap.LodLevel.ChildrenWereLoaded(childLod, ref myCellCoord);
          }
          else if (data.FarResult == ContainmentType.Intersects)
          {
            this.AddToScene(keyValuePair.Key, data);
            data.Cell.PixelDiscardEnabled = MyClipmap.LodLevel.WasAncestorCellLoaded(parentLod, ref myCellCoord);
          }
          else if (data.FarResult == ContainmentType.Disjoint)
          {
            if (MyClipmap.LodLevel.WasAncestorCellLoaded(parentLod, ref myCellCoord))
            {
              this.RemoveFromScene(keyValuePair.Key, data);
            }
            else
            {
              this.AddToScene(keyValuePair.Key, data);
              data.Cell.PixelDiscardEnabled = false;
            }
          }
          else
          {
            this.AddToScene(keyValuePair.Key, data);
            data.Cell.PixelDiscardEnabled = false;
          }
        }
      }

      private void GetNearbyLodLevels(out MyClipmap.LodLevel parentLod, out MyClipmap.LodLevel childLod)
      {
        MyClipmap.LodLevel[] self = this.m_parent.m_lodLevels;
        int index1 = this.m_lodIndex + 1;
        parentLod = !ArrayExtensions.IsValidIndex<MyClipmap.LodLevel>(self, index1) ? (MyClipmap.LodLevel) null : self[index1];
        int index2 = this.m_lodIndex - 1;
        if (ArrayExtensions.IsValidIndex<MyClipmap.LodLevel>(self, index2))
          childLod = self[index2];
        else
          childLod = (MyClipmap.LodLevel) null;
      }

      internal void UpdateWorldMatrices(bool sortCellsIntoCullObjects)
      {
        foreach (MyClipmap.CellData cellData in this.m_storedCellData.Values)
        {
          if (cellData.Cell != null)
            cellData.Cell.UpdateWorldMatrix(ref this.m_parent.m_worldMatrix, sortCellsIntoCullObjects);
        }
      }

      private static bool WasAncestorCellLoaded(MyClipmap.LodLevel parentLod, ref MyCellCoord thisLodCell)
      {
        if (parentLod == null || !parentLod.m_fitsInFrustum)
          return true;
        MyCellCoord thisLodCell1 = new MyCellCoord(thisLodCell.Lod + 1, thisLodCell.CoordInLod >> 1);
        MyClipmap.CellData cellData;
        if (parentLod.m_storedCellData.TryGetValue(thisLodCell1.PackId32(), out cellData))
          return cellData.WasLoaded;
        MyClipmap.LodLevel parentLod1;
        if (ArrayExtensions.TryGetValue<MyClipmap.LodLevel>(parentLod.m_parent.m_lodLevels, parentLod.m_lodIndex + 1, out parentLod1))
          return MyClipmap.LodLevel.WasAncestorCellLoaded(parentLod1, ref thisLodCell1);
        else
          return false;
      }

      private static bool ChildrenWereLoaded(MyClipmap.LodLevel childLod, ref MyCellCoord thisLodCell)
      {
        if (childLod == null)
          return false;
        MyCellCoord myCellCoord = new MyCellCoord();
        myCellCoord.Lod = childLod.m_lodIndex;
        Vector3I vector3I = thisLodCell.CoordInLod << 1;
        Vector3I result = vector3I + 1;
        Vector3I.Min(ref result, ref childLod.m_lodSizeMinusOne, out result);
        for (myCellCoord.CoordInLod.Z = vector3I.Z; myCellCoord.CoordInLod.Z <= result.Z; ++myCellCoord.CoordInLod.Z)
        {
          for (myCellCoord.CoordInLod.Y = vector3I.Y; myCellCoord.CoordInLod.Y <= result.Y; ++myCellCoord.CoordInLod.Y)
          {
            for (myCellCoord.CoordInLod.X = vector3I.X; myCellCoord.CoordInLod.X <= result.X; ++myCellCoord.CoordInLod.X)
            {
              uint key = myCellCoord.PackId32();
              MyClipmap.CellData cellData;
              if (!childLod.m_storedCellData.TryGetValue(key, out cellData) || !cellData.WasLoaded)
                return false;
            }
          }
        }
        return true;
      }

      private void Delete(uint key, MyClipmap.CellData data = null)
      {
        data = data ?? this.m_storedCellData[key];
        if (data.Cell != null)
        {
          this.m_nonEmptyCells.Remove(key);
          this.RemoveFromScene(key, data);
          this.m_parent.m_cellHandler.DeleteCell(data.Cell);
        }
        this.m_storedCellData.Remove(key);
      }

      private void AddToScene(uint key, MyClipmap.CellData data = null)
      {
        data = data ?? this.m_storedCellData[key];
        if (data.InScene)
          return;
        this.m_parent.m_cellHandler.AddToScene(data.Cell);
        data.InScene = true;
      }

      private void RemoveFromScene(uint key, MyClipmap.CellData data = null)
      {
        data = data ?? this.m_storedCellData[key];
        if (!data.InScene)
          return;
        this.m_parent.m_cellHandler.RemoveFromScene(data.Cell);
        data.InScene = false;
      }
    }

    private class RequestCollector
    {
      private readonly HashSet<uint> m_sentRequests = new HashSet<uint>();
      private readonly SortedSet<uint> m_unsentRequestsLow = new SortedSet<uint>();
      private readonly SortedSet<uint> m_unsentRequestsHigh = new SortedSet<uint>();
      private readonly HashSet<uint> m_cancelRequests = new HashSet<uint>();
      private int m_maxRequests = int.MaxValue;
      private uint m_clipmapId;

      public bool SentRequestsEmpty
      {
        get
        {
          return this.m_sentRequests.Count == 0;
        }
      }

      public RequestCollector(uint clipmapId)
      {
        this.m_clipmapId = clipmapId;
      }

      public void AddRequest(uint cellId, bool isHighPriority)
      {
        this.m_cancelRequests.Remove(cellId);
        if (this.m_sentRequests.Contains(cellId))
          return;
        if (isHighPriority)
          this.m_unsentRequestsHigh.Add(cellId);
        else
          this.m_unsentRequestsLow.Add(cellId);
      }

      public void CancelRequest(uint cellId)
      {
        this.m_unsentRequestsLow.Remove(cellId);
        if (!this.m_sentRequests.Contains(cellId))
          return;
        this.m_cancelRequests.Add(cellId);
      }

      public void Submit()
      {
        MyCellCoord cell = new MyCellCoord();
        foreach (uint id in this.m_cancelRequests)
        {
          cell.SetUnpack(id);
          MyRenderProxy.CancelClipmapCell(this.m_clipmapId, cell);
          this.m_sentRequests.Remove(id);
        }
        foreach (uint id in this.m_unsentRequestsHigh)
        {
          cell.SetUnpack(id);
          MyRenderProxy.RequireClipmapCell(this.m_clipmapId, cell, true);
        }
        this.m_unsentRequestsHigh.Clear();
        while (0 < this.m_unsentRequestsLow.Count && this.m_sentRequests.Count < this.m_maxRequests)
        {
          uint max = this.m_unsentRequestsLow.Max;
          cell.SetUnpack(max);
          Vector3I vector3I = cell.CoordInLod >> 1 << 1;
          Vector3I next = Vector3I.Zero;
          Vector3I.RangeIterator rangeIterator = new Vector3I.RangeIterator(ref Vector3I.Zero, ref Vector3I.One);
          while (rangeIterator.IsValid())
          {
            cell.CoordInLod = vector3I + next;
            uint num = cell.PackId32();
            if (this.m_unsentRequestsLow.Contains(num))
            {
              this.m_unsentRequestsLow.Remove(num);
              MyRenderProxy.RequireClipmapCell(this.m_clipmapId, cell, false);
              this.m_sentRequests.Add(num);
            }
            rangeIterator.GetNext(out next);
          }
        }
        this.m_cancelRequests.Clear();
      }

      internal void RequestFulfilled(uint cellId)
      {
        this.m_sentRequests.Remove(cellId);
      }
    }

    private class UpdateQueueItem : HeapItem<short>
    {
      public readonly MyClipmap Clipmap;

      public UpdateQueueItem(MyClipmap clipmap)
      {
        this.Clipmap = clipmap;
      }
    }

    private class UpdateFrameComparer : IComparer<short>
    {
      public int Compare(short x, short y)
      {
        x -= MyClipmap.m_currentFrameIdx;
        y -= MyClipmap.m_currentFrameIdx;
        return (int) x - (int) y;
      }
    }
  }
}
