﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Voxels.MyVoxelCoordSystems
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Voxels
{
  public static class MyVoxelCoordSystems
  {
    public static void WorldPositionToLocalPosition(Vector3D referenceVoxelMapPosition, ref Vector3D worldPosition, out Vector3D localPosition)
    {
      localPosition = worldPosition - referenceVoxelMapPosition;
    }

    public static void LocalPositionToWorldPosition(Vector3D referenceVoxelMapPosition, ref Vector3D localPosition, out Vector3D worldPosition)
    {
      worldPosition = localPosition + referenceVoxelMapPosition;
    }

    public static void LocalPositionToVoxelCoord(ref Vector3D localPosition, out Vector3I voxelCoord)
    {
      Vector3D v = localPosition / 1.0;
      Vector3I.Floor(ref v, out voxelCoord);
    }

    public static void LocalPositionToGeometryCellCoord(ref Vector3D localPosition, out Vector3I geometryCellCoord)
    {
      Vector3D v = (localPosition - 0.5) / 8.0;
      Vector3I.Floor(ref v, out geometryCellCoord);
    }

    public static void LocalPositionToRenderCellCoord(ref Vector3D localPosition, out Vector3I renderCellCoord)
    {
      Vector3D v = (localPosition - 0.5) / 32.0;
      Vector3I.Floor(ref v, out renderCellCoord);
    }

    public static void WorldPositionToVoxelCoord(Vector3D referenceVoxelMapPosition, ref Vector3D worldPosition, out Vector3I voxelCoord)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.WorldPositionToLocalPosition(referenceVoxelMapPosition, ref worldPosition, out localPosition);
      MyVoxelCoordSystems.LocalPositionToVoxelCoord(ref localPosition, out voxelCoord);
    }

    public static void WorldPositionToGeometryCellCoord(Vector3D referenceVoxelMapPosition, ref Vector3D worldPosition, out Vector3I geometryCellCoord)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.WorldPositionToLocalPosition(referenceVoxelMapPosition, ref worldPosition, out localPosition);
      MyVoxelCoordSystems.LocalPositionToGeometryCellCoord(ref localPosition, out geometryCellCoord);
    }

    public static void WorldPositionToRenderCellCoord(Vector3D referenceVoxelMapPosition, ref Vector3D worldPosition, out Vector3I renderCellCoord)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.WorldPositionToLocalPosition(referenceVoxelMapPosition, ref worldPosition, out localPosition);
      Vector3D v = localPosition / 32.0;
      Vector3I.Floor(ref v, out renderCellCoord);
    }

    public static void VoxelCoordToLocalPosition(ref Vector3I voxelCoord, out Vector3D localPosition)
    {
      localPosition = (Vector3D) (voxelCoord * 1f + 0.5f);
    }

    public static void GeometryCellCoordToLocalPosition(ref Vector3I geometryCellCoord, out Vector3D localPosition)
    {
      localPosition = (Vector3D) (geometryCellCoord * 8f + 4f + 0.5f);
    }

    public static void RenderCellCoordToLocalPosition(ref MyCellCoord renderCell, out Vector3D localPosition)
    {
      int num = 1 << renderCell.Lod;
      localPosition = (Vector3D) (renderCell.CoordInLod * num * 32f + (float) num * 16f + (float) num * 0.5f);
    }

    public static void VoxelCoordToWorldPosition(Vector3D referenceVoxelMapPosition, ref Vector3I voxelCoord, out Vector3D worldPosition)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.VoxelCoordToLocalPosition(ref voxelCoord, out localPosition);
      MyVoxelCoordSystems.LocalPositionToWorldPosition(referenceVoxelMapPosition, ref localPosition, out worldPosition);
    }

    public static void RenderCellCoordToWorldPosition(Vector3D referenceVoxelMapPosition, ref MyCellCoord renderCell, out Vector3D worldPosition)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.RenderCellCoordToLocalPosition(ref renderCell, out localPosition);
      MyVoxelCoordSystems.LocalPositionToWorldPosition(referenceVoxelMapPosition, ref localPosition, out worldPosition);
    }

    public static void GeometryCellCoordToLocalAABB(ref Vector3I geometryCellCoord, out BoundingBox localAABB)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.GeometryCellCoordToLocalPosition(ref geometryCellCoord, out localPosition);
      localAABB = new BoundingBox((Vector3) (localPosition - 4.0), (Vector3) (localPosition + 4.0));
    }

    public static void RenderCellCoordToLocalAABB(ref MyCellCoord renderCell, out BoundingBoxD localAABB)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.RenderCellCoordToLocalPosition(ref renderCell, out localPosition);
      float num = (float) (1 << renderCell.Lod) * 16f;
      localAABB = new BoundingBoxD(localPosition - (double) num, localPosition + (double) num);
    }

    public static void VoxelCoordToWorldAABB(Vector3D referenceVoxelMapPosition, ref Vector3I voxelCoord, out BoundingBoxD worldAABB)
    {
      Vector3D worldPosition;
      MyVoxelCoordSystems.VoxelCoordToWorldPosition(referenceVoxelMapPosition, ref voxelCoord, out worldPosition);
      worldAABB = new BoundingBoxD(worldPosition - 0.5, worldPosition + 0.5);
    }

    public static void GeometryCellCoordToWorldAABB(Vector3D referenceVoxelMapPosition, ref Vector3I geometryCellCoord, out BoundingBoxD worldAABB)
    {
      Vector3D localPosition;
      MyVoxelCoordSystems.GeometryCellCoordToLocalPosition(ref geometryCellCoord, out localPosition);
      MyVoxelCoordSystems.LocalPositionToWorldPosition(referenceVoxelMapPosition, ref localPosition, out localPosition);
      worldAABB = new BoundingBoxD(localPosition - 4.0, localPosition + 4.0);
    }

    public static void RenderCellCoordToWorldAABB(Vector3D referenceVoxelMapPosition, ref MyCellCoord renderCell, out BoundingBoxD worldAABB)
    {
      MyVoxelCoordSystems.RenderCellCoordToLocalAABB(ref renderCell, out worldAABB);
      worldAABB = worldAABB.Translate(referenceVoxelMapPosition);
    }

    public static void VoxelCoordToGeometryCellCoord(ref Vector3I voxelCoord, out Vector3I geometryCellCoord)
    {
      geometryCellCoord = voxelCoord >> 3;
    }

    public static void VoxelCoordToRenderCellCoord(ref Vector3I voxelCoord, out Vector3I renderCellCoord)
    {
      renderCellCoord.X = voxelCoord.X / 32;
      renderCellCoord.Y = voxelCoord.Y / 32;
      renderCellCoord.Z = voxelCoord.Z / 32;
    }
  }
}
