﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Voxels.MyCellCoord
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Voxels
{
  public struct MyCellCoord
  {
    public const int MAX_LOD_COUNT = 16;
    private const int BITS_LOD = 4;
    private const int BITS_X_32 = 10;
    private const int BITS_Y_32 = 8;
    private const int BITS_Z_32 = 10;
    private const int BITS_X_64 = 20;
    private const int BITS_Y_64 = 20;
    private const int BITS_Z_64 = 20;
    private const int SHIFT_LOD_32 = 28;
    private const int SHIFT_X_32 = 18;
    private const int SHIFT_Y_32 = 10;
    private const int SHIFT_Z_32 = 0;
    private const int SHIFT_LOD_64 = 60;
    private const int SHIFT_X_64 = 40;
    private const int SHIFT_Y_64 = 20;
    private const int SHIFT_Z_64 = 0;
    private const int MASK_LOD = 15;
    private const int MASK_X_32 = 1023;
    private const int MASK_Y_32 = 255;
    private const int MASK_Z_32 = 1023;
    private const int MASK_X_64 = 1048575;
    private const int MASK_Y_64 = 1048575;
    private const int MASK_Z_64 = 1048575;
    public int Lod;
    public Vector3I CoordInLod;

    public MyCellCoord(int lod, Vector3I coordInLod)
    {
      this = new MyCellCoord(lod, ref coordInLod);
    }

    public MyCellCoord(int lod, ref Vector3I coordInLod)
    {
      this.Lod = lod;
      this.CoordInLod = coordInLod;
    }

    public void SetUnpack(uint id)
    {
      this.CoordInLod.Z = (int) id & 1023;
      id >>= 10;
      this.CoordInLod.Y = (int) id & (int) byte.MaxValue;
      id >>= 8;
      this.CoordInLod.X = (int) id & 1023;
      id >>= 10;
      this.Lod = (int) id;
    }

    public void SetUnpack(ulong id)
    {
      this.CoordInLod.Z = (int) ((long) id & 1048575L);
      id >>= 20;
      this.CoordInLod.Y = (int) ((long) id & 1048575L);
      id >>= 20;
      this.CoordInLod.X = (int) ((long) id & 1048575L);
      id >>= 20;
      this.Lod = (int) id;
    }

    public uint PackId32()
    {
      return (uint) (this.Lod << 28 | this.CoordInLod.X << 18 | this.CoordInLod.Y << 10 | this.CoordInLod.Z);
    }

    public ulong PackId64()
    {
      return (ulong) ((long) this.Lod << 60 | (long) this.CoordInLod.X << 40 | (long) this.CoordInLod.Y << 20) | (ulong) this.CoordInLod.Z;
    }

    public override string ToString()
    {
      return string.Format("{0}, {1}", (object) this.Lod, (object) this.CoordInLod);
    }
  }
}
