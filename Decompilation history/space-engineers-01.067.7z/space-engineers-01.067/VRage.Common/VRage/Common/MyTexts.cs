﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyTexts
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Resources;
using System.Text;
using VRage.Common.Utils;

namespace VRage.Common
{
  public static class MyTexts
  {
    private static Dictionary<MyStringId, string> m_strings = new Dictionary<MyStringId, string>((IEqualityComparer<MyStringId>) MyStringId.Comparer);
    private static Dictionary<MyStringId, StringBuilder> m_stringBuilders = new Dictionary<MyStringId, StringBuilder>((IEqualityComparer<MyStringId>) MyStringId.Comparer);

    public static StringBuilder Get(MyStringId id)
    {
      StringBuilder stringBuilder;
      if (!MyTexts.m_stringBuilders.TryGetValue(id, out stringBuilder))
        stringBuilder = new StringBuilder(id.ToString());
      return stringBuilder;
    }

    public static string GetString(MyStringId id)
    {
      string str;
      if (!MyTexts.m_strings.TryGetValue(id, out str))
        str = id.ToString();
      return str;
    }

    public static bool Exists(MyStringId id)
    {
      return MyTexts.m_strings.ContainsKey(id);
    }

    public static bool TryGet(MyStringId id, out string value)
    {
      return MyTexts.m_strings.TryGetValue(id, out value);
    }

    public static void Clear()
    {
      MyTexts.m_strings.Clear();
      MyTexts.m_stringBuilders.Clear();
      MyTexts.m_strings[new MyStringId()] = "";
      MyTexts.m_stringBuilders[new MyStringId()] = new StringBuilder();
    }

    public static void LoadTexts(string rootDirectory, string baseLanguageFilename, string cultureName = null, string subcultureName = null)
    {
      MyTexts.PatchTexts(Path.Combine(rootDirectory, string.Format("{0}.resx", (object) baseLanguageFilename)));
      if (cultureName == null)
        return;
      MyTexts.PatchTexts(Path.Combine(rootDirectory, string.Format("{0}.{1}.resx", (object) baseLanguageFilename, (object) cultureName)));
      if (subcultureName == null)
        return;
      MyTexts.PatchTexts(Path.Combine(rootDirectory, string.Format("{0}.{1}-{2}.resx", (object) baseLanguageFilename, (object) cultureName, (object) subcultureName)));
    }

    private static void PatchTexts(string resourceFile)
    {
      if (!File.Exists(resourceFile))
        return;
      using (Stream stream = MyFileSystem.OpenRead(resourceFile))
      {
        using (ResXResourceReader resXresourceReader = new ResXResourceReader(stream))
        {
          foreach (DictionaryEntry dictionaryEntry in resXresourceReader)
          {
            string str1 = dictionaryEntry.Key as string;
            string str2 = dictionaryEntry.Value as string;
            if (str1 != null && str2 != null)
            {
              MyStringId orCompute = MyStringId.GetOrCompute(str1);
              MyTexts.m_strings[orCompute] = str2;
              MyTexts.m_stringBuilders[orCompute] = new StringBuilder(str2);
            }
          }
        }
      }
    }

    public static StringBuilder AppendFormat(this StringBuilder stringBuilder, MyStringId textEnum, object arg0)
    {
      return stringBuilder.AppendFormat(MyTexts.GetString(textEnum), arg0);
    }
  }
}
