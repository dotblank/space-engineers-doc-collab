﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyEnumDuplicitiesTester
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace VRage.Common.Utils
{
  public static class MyEnumDuplicitiesTester
  {
    private const string m_keenSWHCompanyName = "Keen Software House";

    [Conditional("DEBUG")]
    public static void CheckEnumNotDuplicitiesInRunningApplication()
    {
      MyEnumDuplicitiesTester.CheckEnumNotDuplicities("Keen Software House");
    }

    private static void CheckEnumNotDuplicities(string companyName)
    {
      Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
      string[] files = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.dll");
      List<Assembly> list = new List<Assembly>(assemblies.Length + files.Length);
      foreach (Assembly assembly in assemblies)
      {
        if (companyName == null || MyEnumDuplicitiesTester.GetCompanyNameOfAssembly(assembly) == companyName)
          list.Add(assembly);
      }
      foreach (string str in files)
      {
        if (!MyEnumDuplicitiesTester.IsLoaded(assemblies, str) && (companyName == null || FileVersionInfo.GetVersionInfo(str).CompanyName == companyName))
          list.Add(Assembly.LoadFrom(str));
      }
      HashSet<object> hashSet = new HashSet<object>();
      foreach (Assembly assembly in list)
        MyEnumDuplicitiesTester.TestEnumNotDuplicitiesInAssembly(assembly, hashSet);
    }

    private static bool IsLoaded(Assembly[] assemblies, string assemblyPath)
    {
      foreach (Assembly assembly in assemblies)
      {
        if (assembly.IsDynamic || !string.IsNullOrEmpty(assembly.Location) && Path.GetFullPath(assembly.Location) == assemblyPath)
          return true;
      }
      return false;
    }

    private static string GetCompanyNameOfAssembly(Assembly assembly)
    {
      AssemblyCompanyAttribute companyAttribute = Attribute.GetCustomAttribute(assembly, typeof (AssemblyCompanyAttribute), false) as AssemblyCompanyAttribute;
      if (companyAttribute == null)
        return string.Empty;
      else
        return companyAttribute.Company;
    }

    private static void TestEnumNotDuplicitiesInAssembly(Assembly assembly, HashSet<object> hashSet)
    {
      foreach (Type enumType in assembly.GetTypes())
      {
        if (enumType.IsEnum && !enumType.IsGenericType && !enumType.IsDefined(typeof (DontCheckAttribute), false))
          MyEnumDuplicitiesTester.AssertEnumNotDuplicities(enumType, hashSet);
      }
    }

    private static void AssertEnumNotDuplicities(Type enumType, HashSet<object> hashSet)
    {
      hashSet.Clear();
      foreach (object obj in Enum.GetValues(enumType))
      {
        if (!hashSet.Add(obj))
          throw new Exception(string.Concat(new object[4]
          {
            (object) "Duplicate enum found: ",
            obj,
            (object) " in ",
            (object) enumType.AssemblyQualifiedName
          }));
      }
    }
  }
}
