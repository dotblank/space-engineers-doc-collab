﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyPolyLine
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Utils
{
  public struct MyPolyLine
  {
    public Vector3 LineDirectionNormalized;
    public Vector3 Point0;
    public Vector3 Point1;
    public float Thickness;
  }
}
