﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyEventArgs
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Linq;

namespace VRage.Common.Utils
{
  public class MyEventArgs : EventArgs
  {
    private Dictionary<MyStringId, object> m_args = new Dictionary<MyStringId, object>();

    public Dictionary<MyStringId, object>.KeyCollection ArgNames
    {
      get
      {
        return this.m_args.Keys;
      }
    }

    public MyEventArgs()
    {
    }

    public MyEventArgs(KeyValuePair<MyStringId, object> arg)
    {
      this.SetArg(arg.Key, arg.Value);
    }

    public MyEventArgs(KeyValuePair<MyStringId, object>[] args)
    {
      foreach (KeyValuePair<MyStringId, object> keyValuePair in args)
        this.SetArg(keyValuePair.Key, keyValuePair.Value);
    }

    public object GetArg(MyStringId argName)
    {
      if (!Enumerable.Contains<MyStringId>((IEnumerable<MyStringId>) this.ArgNames, argName))
        return (object) null;
      else
        return this.m_args[argName];
    }

    public void SetArg(MyStringId argName, object value)
    {
      this.m_args.Remove(argName);
      this.m_args.Add(argName, value);
    }
  }
}
