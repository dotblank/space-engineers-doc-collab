﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyStringId
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using ProtoBuf;
using System.Collections.Generic;
using VRage;

namespace VRage.Common.Utils
{
  [ProtoContract]
  public struct MyStringId
  {
    public static readonly MyStringId.IdComparerType Comparer = new MyStringId.IdComparerType();
    private static Dictionary<string, MyStringId> m_idByString = new Dictionary<string, MyStringId>(50);
    private static Dictionary<MyStringId, string> m_stringById = new Dictionary<MyStringId, string>(50, (IEqualityComparer<MyStringId>) MyStringId.Comparer);
    public static readonly MyStringId NullOrEmpty = MyStringId.GetOrCompute("");
    [ProtoMember(1)]
    private readonly int m_id;

    private MyStringId(int hash)
    {
      this.m_id = hash;
    }

    public static explicit operator int(MyStringId id)
    {
      return id.m_id;
    }

    public static bool operator ==(MyStringId lhs, MyStringId rhs)
    {
      return lhs.m_id == rhs.m_id;
    }

    public static bool operator !=(MyStringId lhs, MyStringId rhs)
    {
      return lhs.m_id != rhs.m_id;
    }

    public override string ToString()
    {
      return MyStringId.m_stringById[this];
    }

    public override int GetHashCode()
    {
      return this.m_id;
    }

    public override bool Equals(object obj)
    {
      if (obj is MyStringId)
        return this.Equals((MyStringId) obj);
      else
        return false;
    }

    public bool Equals(MyStringId id)
    {
      return this.m_id == id.m_id;
    }

    public static MyStringId GetOrCompute(string str)
    {
      MyStringId key;
      if (str == null)
        key = MyStringId.NullOrEmpty;
      else if (!MyStringId.m_idByString.TryGetValue(str, out key))
      {
        key = new MyStringId(MyStringUtils.GetHash(str, 0));
        MyStringId.m_stringById.Add(key, str);
        MyStringId.m_idByString.Add(str, key);
      }
      return key;
    }

    public static MyStringId Get(string str)
    {
      return MyStringId.m_idByString[str];
    }

    public static MyStringId Get(int id)
    {
      return MyStringId.m_idByString[MyStringId.m_stringById[new MyStringId(id)]];
    }

    public static bool TryGet(string str, out MyStringId id)
    {
      return MyStringId.m_idByString.TryGetValue(str, out id);
    }

    public static MyStringId TryGet(string str)
    {
      MyStringId myStringId;
      MyStringId.m_idByString.TryGetValue(str, out myStringId);
      return myStringId;
    }

    public static MyStringId TryGet(int id)
    {
      MyStringId key = new MyStringId(id);
      if (MyStringId.m_stringById.ContainsKey(key))
        return key;
      else
        return MyStringId.NullOrEmpty;
    }

    public static bool IsKnown(MyStringId id)
    {
      return MyStringId.m_stringById.ContainsKey(id);
    }

    public class IdComparerType : IComparer<MyStringId>, IEqualityComparer<MyStringId>
    {
      public int Compare(MyStringId x, MyStringId y)
      {
        return x.m_id - y.m_id;
      }

      public bool Equals(MyStringId x, MyStringId y)
      {
        return x.m_id == y.m_id;
      }

      public int GetHashCode(MyStringId obj)
      {
        return obj.m_id;
      }
    }
  }
}
