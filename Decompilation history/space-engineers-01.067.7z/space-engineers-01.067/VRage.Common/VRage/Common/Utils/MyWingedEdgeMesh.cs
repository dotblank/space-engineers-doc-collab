﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyWingedEdgeMesh
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using VRage;
using VRageMath;
using VRageRender;

namespace VRage.Common.Utils
{
  public class MyWingedEdgeMesh
  {
    private HashSet<int> m_tmpFreeEdges = new HashSet<int>();
    private HashSet<int> m_tmpFreeFaces = new HashSet<int>();
    private HashSet<int> m_tmpFreeVertices = new HashSet<int>();
    private HashSet<int> m_tmpVisitedIndices = new HashSet<int>();
    public static bool BASIC_CONSISTENCY_CHECKS;
    public static bool ADVANCED_CONSISTENCY_CHECKS;
    private List<MyWingedEdgeMesh.EdgeTableEntry> m_edgeTable;
    private List<MyWingedEdgeMesh.VertexTableEntry> m_vertexTable;
    private List<MyWingedEdgeMesh.FaceTableEntry> m_faceTable;
    private int m_freeEdges;
    private int m_freeVertices;
    private int m_freeFaces;
    private static HashSet<int> m_debugDrawEdges;

    public MyWingedEdgeMesh()
    {
      this.m_edgeTable = new List<MyWingedEdgeMesh.EdgeTableEntry>();
      this.m_vertexTable = new List<MyWingedEdgeMesh.VertexTableEntry>();
      this.m_faceTable = new List<MyWingedEdgeMesh.FaceTableEntry>();
      this.m_freeEdges = -1;
      this.m_freeVertices = -1;
      this.m_freeFaces = -1;
    }

    public static void DebugDrawEdgesReset()
    {
      if (MyWingedEdgeMesh.m_debugDrawEdges == null)
        MyWingedEdgeMesh.m_debugDrawEdges = new HashSet<int>();
      else if (MyWingedEdgeMesh.m_debugDrawEdges.Count == 0)
        MyWingedEdgeMesh.m_debugDrawEdges = (HashSet<int>) null;
      else
        MyWingedEdgeMesh.m_debugDrawEdges.Clear();
    }

    public static void DebugDrawEdgesAdd(int edgeIndex)
    {
      if (MyWingedEdgeMesh.m_debugDrawEdges == null)
        return;
      MyWingedEdgeMesh.m_debugDrawEdges.Add(edgeIndex);
    }

    private MyWingedEdgeMesh.EdgeTableEntry GetEdgeEntry(int index)
    {
      return this.m_edgeTable[index];
    }

    private void SetEdgeEntry(int index, ref MyWingedEdgeMesh.EdgeTableEntry entry)
    {
      this.m_edgeTable[index] = entry;
    }

    private MyWingedEdgeMesh.FaceTableEntry GetFaceEntry(int index)
    {
      return this.m_faceTable[index];
    }

    private void SetFaceEntry(int index, MyWingedEdgeMesh.FaceTableEntry entry)
    {
      this.m_faceTable[index] = entry;
    }

    public MyWingedEdgeMesh.Edge GetEdge(int edgeIndex)
    {
      return new MyWingedEdgeMesh.Edge(this, edgeIndex);
    }

    public MyWingedEdgeMesh.Face GetFace(int faceIndex)
    {
      return new MyWingedEdgeMesh.Face(this, faceIndex);
    }

    public Vector3 GetVertex(int vertexIndex)
    {
      return this.m_vertexTable[vertexIndex].VertexPosition;
    }

    public int MakeEdgeFace(int vert1, int vert2, int edge1, int edge2, object faceUserData, out int newEdge)
    {
      newEdge = this.AllocateEdge();
      int face = this.AllocateAndInsertFace(faceUserData, newEdge);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(edge1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(edge2);
      MyWingedEdgeMesh.EdgeTableEntry entry = new MyWingedEdgeMesh.EdgeTableEntry();
      entry.Init();
      entry.Vertex1 = vert1;
      entry.Vertex2 = vert2;
      entry.RightFace = face;
      edgeEntry1.AddFace(face);
      edgeEntry2.AddFace(face);
      int num1 = edgeEntry2.OtherVertex(vert2);
      for (int index = edgeEntry2.VertexSucc(num1); index != edge1; {
        MyWingedEdgeMesh.EdgeTableEntry edgeEntry3;
        index = edgeEntry3.VertexSucc(num1);
      }
      )
      {
        edgeEntry3 = this.GetEdgeEntry(index);
        edgeEntry3.AddFace(face);
        this.SetEdgeEntry(index, ref edgeEntry3);
        num1 = edgeEntry3.OtherVertex(num1);
      }
      entry.SetVertexSucc(vert2, edge2);
      int num2 = edgeEntry2.SetVertexPred(vert2, newEdge);
      entry.SetVertexPred(vert1, edge1);
      int num3 = edgeEntry1.SetVertexSucc(vert1, newEdge);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry4 = this.GetEdgeEntry(num2);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry5 = this.GetEdgeEntry(num3);
      edgeEntry5.SetVertexPred(vert1, newEdge);
      entry.SetVertexSucc(vert1, num3);
      edgeEntry4.SetVertexSucc(vert2, newEdge);
      entry.SetVertexPred(vert2, num2);
      this.SetEdgeEntry(num2, ref edgeEntry4);
      this.SetEdgeEntry(num3, ref edgeEntry5);
      this.SetEdgeEntry(newEdge, ref entry);
      this.SetEdgeEntry(edge1, ref edgeEntry1);
      this.SetEdgeEntry(edge2, ref edgeEntry2);
      return face;
    }

    public void MergeEdges(int edge1, int edge2)
    {
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(edge1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(edge2);
      int predVertex1;
      int succVertex1;
      edgeEntry1.GetFaceVertices(-1, out predVertex1, out succVertex1);
      int predVertex2;
      int succVertex2;
      edgeEntry2.GetFaceVertices(-1, out predVertex2, out succVertex2);
      int num1 = edgeEntry1.OtherFace(-1);
      int num2 = edgeEntry1.FaceSucc(-1);
      int num3 = edgeEntry1.FacePred(-1);
      int num4 = edgeEntry2.FaceSucc(-1);
      int num5 = edgeEntry2.FacePred(-1);
      int num6 = edgeEntry1.FaceSucc(num1);
      int num7 = edgeEntry1.FacePred(num1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry3 = this.GetEdgeEntry(num2);
      MyWingedEdgeMesh.EdgeTableEntry entry1 = new MyWingedEdgeMesh.EdgeTableEntry();
      if (num2 != num3)
        entry1 = this.GetEdgeEntry(num3);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry4 = this.GetEdgeEntry(num4);
      MyWingedEdgeMesh.EdgeTableEntry entry2 = new MyWingedEdgeMesh.EdgeTableEntry();
      if (num4 != num5)
        entry2 = this.GetEdgeEntry(num5);
      edgeEntry3.SetFacePred(-1, num5);
      edgeEntry4.SetFacePred(-1, num3);
      if (num2 != num3)
        entry1.SetFaceSucc(-1, num4);
      else
        edgeEntry3.SetFaceSucc(-1, num4);
      if (num4 != num5)
        entry2.SetFaceSucc(-1, num2);
      else
        edgeEntry4.SetFaceSucc(-1, num2);
      edgeEntry2.AddFace(num1);
      edgeEntry2.SetFacePred(num1, num7);
      edgeEntry2.SetFaceSucc(num1, num6);
      edgeEntry3.SetFacePredVertex(-1, predVertex2);
      if (num2 != num3)
        entry1.SetFaceSuccVertex(-1, succVertex2);
      else
        edgeEntry3.SetFaceSuccVertex(-1, succVertex2);
      if (num7 == num2)
      {
        edgeEntry3.SetFaceSucc(num1, edge2);
      }
      else
      {
        MyWingedEdgeMesh.EdgeTableEntry edgeEntry5 = this.GetEdgeEntry(num7);
        edgeEntry5.SetFaceSucc(num1, edge2);
        edgeEntry5.SetFaceSuccVertex(num1, predVertex2);
        this.SetEdgeEntry(num7, ref edgeEntry5);
        for (int index = edgeEntry5.VertexPred(predVertex2); index != num2; {
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry6;
          index = edgeEntry6.VertexPred(predVertex2);
        }
        )
        {
          edgeEntry6 = this.GetEdgeEntry(index);
          edgeEntry6.ChangeVertex(succVertex1, predVertex2);
          this.SetEdgeEntry(index, ref edgeEntry6);
        }
      }
      if (num6 == num3)
      {
        if (num2 != num3)
          entry1.SetFacePred(num1, edge2);
        else
          edgeEntry3.SetFacePred(num1, edge2);
      }
      else
      {
        MyWingedEdgeMesh.EdgeTableEntry edgeEntry5 = this.GetEdgeEntry(num6);
        edgeEntry5.SetFacePred(num1, edge2);
        edgeEntry5.SetFacePredVertex(num1, succVertex2);
        this.SetEdgeEntry(num6, ref edgeEntry5);
        for (int index = edgeEntry5.VertexSucc(succVertex2); index != num3; {
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry6;
          index = edgeEntry6.VertexSucc(succVertex2);
        }
        )
        {
          edgeEntry6 = this.GetEdgeEntry(index);
          edgeEntry6.ChangeVertex(predVertex1, succVertex2);
          this.SetEdgeEntry(index, ref edgeEntry6);
        }
      }
      MyWingedEdgeMesh.FaceTableEntry faceEntry = this.GetFaceEntry(num1);
      faceEntry.IncidentEdge = edge2;
      this.SetFaceEntry(num1, faceEntry);
      this.DeallocateVertex(predVertex1);
      this.DeallocateVertex(succVertex1);
      this.DeallocateEdge(edge1);
      this.SetEdgeEntry(edge2, ref edgeEntry2);
      this.SetEdgeEntry(num2, ref edgeEntry3);
      if (num2 != num3)
        this.SetEdgeEntry(num3, ref entry1);
      this.SetEdgeEntry(num4, ref edgeEntry4);
      if (num4 == num5)
        return;
      this.SetEdgeEntry(num5, ref entry2);
    }

    public int ExtrudeTriangleFromEdge(ref Vector3 newVertex, int edge, object faceUserData, out int newEdgeS, out int newEdgeP)
    {
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(edge);
      newEdgeP = this.AllocateEdge();
      newEdgeS = this.AllocateEdge();
      int num1 = edgeEntry1.FacePred(-1);
      int num2 = edgeEntry1.FaceSucc(-1);
      int predVertex;
      int succVertex;
      edgeEntry1.GetFaceVertices(-1, out predVertex, out succVertex);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(num1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry3 = this.GetEdgeEntry(num2);
      MyWingedEdgeMesh.EdgeTableEntry entry1 = new MyWingedEdgeMesh.EdgeTableEntry();
      entry1.Init();
      MyWingedEdgeMesh.EdgeTableEntry entry2 = new MyWingedEdgeMesh.EdgeTableEntry();
      entry2.Init();
      int num3 = this.AllocateAndInsertFace(faceUserData, newEdgeP);
      int vertex = this.AllocateAndInsertVertex(ref newVertex, newEdgeP);
      entry1.AddFace(num3);
      entry1.SetFacePredVertex(num3, vertex);
      entry1.SetFacePred(num3, newEdgeS);
      entry1.SetFaceSuccVertex(num3, predVertex);
      entry1.SetFaceSucc(num3, edge);
      entry1.SetFacePred(-1, num1);
      entry1.SetFaceSucc(-1, newEdgeS);
      entry2.AddFace(num3);
      entry2.SetFacePredVertex(num3, succVertex);
      entry2.SetFacePred(num3, edge);
      entry2.SetFaceSuccVertex(num3, vertex);
      entry2.SetFaceSucc(num3, newEdgeP);
      entry2.SetFacePred(-1, newEdgeP);
      entry2.SetFaceSucc(-1, num2);
      edgeEntry1.AddFace(num3);
      edgeEntry1.SetFacePred(num3, newEdgeP);
      edgeEntry1.SetFaceSucc(num3, newEdgeS);
      edgeEntry2.SetFaceSucc(-1, newEdgeP);
      edgeEntry3.SetFacePred(-1, newEdgeS);
      this.SetEdgeEntry(newEdgeP, ref entry1);
      this.SetEdgeEntry(newEdgeS, ref entry2);
      this.SetEdgeEntry(num1, ref edgeEntry2);
      this.SetEdgeEntry(num2, ref edgeEntry3);
      this.SetEdgeEntry(edge, ref edgeEntry1);
      return num3;
    }

    public void MergeAngle(int leftEdge, int rightEdge, int commonVert)
    {
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(leftEdge);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(rightEdge);
      int num1 = edgeEntry1.FaceSucc(-1);
      int num2 = edgeEntry2.FacePred(-1);
      int num3 = edgeEntry1.OtherVertex(commonVert);
      int num4 = edgeEntry2.OtherVertex(commonVert);
      int num5 = edgeEntry1.OtherFace(-1);
      int num6 = edgeEntry1.FaceSucc(num5);
      int num7 = edgeEntry1.FacePred(num5);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry3 = this.GetEdgeEntry(num6);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry4 = this.GetEdgeEntry(num1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry5 = this.GetEdgeEntry(num2);
      edgeEntry4.SetFacePredVertex(-1, num4);
      edgeEntry4.SetFacePred(-1, num2);
      edgeEntry5.SetFaceSucc(-1, num1);
      if (num7 == num1)
      {
        edgeEntry4.SetFaceSucc(num5, rightEdge);
      }
      else
      {
        MyWingedEdgeMesh.EdgeTableEntry edgeEntry6 = this.GetEdgeEntry(num7);
        edgeEntry6.SetFaceSucc(num5, rightEdge);
        edgeEntry6.ChangeVertex(num3, num4);
        this.SetEdgeEntry(num7, ref edgeEntry6);
        for (int index = edgeEntry6.VertexPred(num4); index != num1; {
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry7;
          index = edgeEntry7.VertexPred(num4);
        }
        )
        {
          edgeEntry7 = this.GetEdgeEntry(index);
          edgeEntry7.ChangeVertex(num3, num4);
          this.SetEdgeEntry(index, ref edgeEntry7);
        }
      }
      edgeEntry2.AddFace(num5);
      edgeEntry2.SetFacePred(num5, num7);
      edgeEntry2.SetFaceSucc(num5, num6);
      edgeEntry3.SetFacePred(num5, rightEdge);
      MyWingedEdgeMesh.VertexTableEntry vertexTableEntry = this.m_vertexTable[commonVert];
      vertexTableEntry.IncidentEdge = rightEdge;
      this.m_vertexTable[commonVert] = vertexTableEntry;
      MyWingedEdgeMesh.FaceTableEntry faceEntry = this.GetFaceEntry(num5);
      faceEntry.IncidentEdge = rightEdge;
      this.SetFaceEntry(num5, faceEntry);
      this.DeallocateEdge(leftEdge);
      this.DeallocateVertex(num3);
      this.SetEdgeEntry(rightEdge, ref edgeEntry2);
      this.SetEdgeEntry(num1, ref edgeEntry4);
      this.SetEdgeEntry(num6, ref edgeEntry3);
      this.SetEdgeEntry(num2, ref edgeEntry5);
    }

    public int MakeFace(object userData, int incidentEdge)
    {
      int num = this.AllocateAndInsertFace(userData, incidentEdge);
      int index = incidentEdge;
      do
      {
        MyWingedEdgeMesh.EdgeTableEntry edgeEntry = this.GetEdgeEntry(index);
        edgeEntry.AddFace(num);
        this.SetEdgeEntry(index, ref edgeEntry);
        index = edgeEntry.FaceSucc(num);
      }
      while (index != incidentEdge);
      return num;
    }

    public int MakeNewTriangle(object userData, ref Vector3 A, ref Vector3 B, ref Vector3 C, out int edgeAB, out int edgeBC, out int edgeCA)
    {
      edgeAB = this.AllocateEdge();
      edgeBC = this.AllocateEdge();
      edgeCA = this.AllocateEdge();
      int vertex1 = this.AllocateAndInsertVertex(ref A, edgeAB);
      int vertex2 = this.AllocateAndInsertVertex(ref B, edgeBC);
      int vertex3 = this.AllocateAndInsertVertex(ref C, edgeCA);
      int num = this.AllocateAndInsertFace(userData, edgeAB);
      MyWingedEdgeMesh.EdgeTableEntry entry1 = new MyWingedEdgeMesh.EdgeTableEntry();
      entry1.Init();
      MyWingedEdgeMesh.EdgeTableEntry entry2 = new MyWingedEdgeMesh.EdgeTableEntry();
      entry2.Init();
      MyWingedEdgeMesh.EdgeTableEntry entry3 = new MyWingedEdgeMesh.EdgeTableEntry();
      entry3.Init();
      entry1.AddFace(num);
      entry2.AddFace(num);
      entry3.AddFace(num);
      entry1.SetFaceSuccVertex(num, vertex2);
      entry2.SetFaceSuccVertex(num, vertex3);
      entry3.SetFaceSuccVertex(num, vertex1);
      entry1.SetFacePredVertex(num, vertex1);
      entry2.SetFacePredVertex(num, vertex2);
      entry3.SetFacePredVertex(num, vertex3);
      entry1.SetFaceSucc(num, edgeBC);
      entry2.SetFaceSucc(num, edgeCA);
      entry3.SetFaceSucc(num, edgeAB);
      entry1.SetFacePred(num, edgeCA);
      entry2.SetFacePred(num, edgeAB);
      entry3.SetFacePred(num, edgeBC);
      entry1.SetFaceSucc(-1, edgeCA);
      entry2.SetFaceSucc(-1, edgeAB);
      entry3.SetFaceSucc(-1, edgeBC);
      entry1.SetFacePred(-1, edgeBC);
      entry2.SetFacePred(-1, edgeCA);
      entry3.SetFacePred(-1, edgeAB);
      this.SetEdgeEntry(edgeAB, ref entry1);
      this.SetEdgeEntry(edgeBC, ref entry2);
      this.SetEdgeEntry(edgeCA, ref entry3);
      return num;
    }

    public void RemoveFace(int faceIndex)
    {
      int num1 = this.GetFaceEntry(faceIndex).IncidentEdge;
      int index1 = num1;
      bool flag = false;
      MyWingedEdgeMesh.EdgeTableEntry entry1 = this.GetEdgeEntry(num1);
      MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(index1);
      int predVertex;
      int succVertex;
      entry1.GetFaceVertices(faceIndex, out predVertex, out succVertex);
      do
      {
        int num2 = entry1.FaceSucc(faceIndex);
        int index2 = succVertex;
        MyWingedEdgeMesh.EdgeTableEntry entry2 = num2 != index1 || !flag ? this.GetEdgeEntry(num2) : edgeEntry1;
        succVertex = entry2.OtherVertex(succVertex);
        if (entry1.VertexLeftFace(index2) == -1)
        {
          if (num1 == index1)
            flag = true;
          this.DeallocateEdge(num1);
          if (entry2.VertexLeftFace(succVertex) == -1)
          {
            if (entry2.VertexSucc(index2) == num1)
            {
              this.DeallocateVertex(index2);
            }
            else
            {
              int num3 = entry2.VertexSucc(index2);
              int num4 = entry1.VertexPred(index2);
              MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(num3);
              MyWingedEdgeMesh.EdgeTableEntry edgeEntry3 = this.GetEdgeEntry(num4);
              edgeEntry2.SetVertexPred(index2, num4);
              edgeEntry3.SetVertexSucc(index2, num3);
              this.SetEdgeEntry(num4, ref edgeEntry3);
              this.SetEdgeEntry(num3, ref edgeEntry2);
              MyWingedEdgeMesh.VertexTableEntry vertexTableEntry = this.m_vertexTable[index2];
              vertexTableEntry.IncidentEdge = num4;
              this.m_vertexTable[index2] = vertexTableEntry;
            }
          }
          else
          {
            int num3 = entry1.FacePred(-1);
            MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(num3);
            edgeEntry2.SetFaceSucc(-1, num2);
            if (num2 != index1)
              entry2.SetFacePred(faceIndex, num3);
            else
              entry2.SetFacePred(-1, num3);
            this.SetEdgeEntry(num3, ref edgeEntry2);
            this.SetEdgeEntry(num2, ref entry2);
            MyWingedEdgeMesh.VertexTableEntry vertexTableEntry = this.m_vertexTable[index2];
            vertexTableEntry.IncidentEdge = num2;
            this.m_vertexTable[index2] = vertexTableEntry;
          }
        }
        else if (entry2.VertexLeftFace(succVertex) == -1)
        {
          int num3 = entry2.FaceSucc(-1);
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(num3);
          edgeEntry2.SetFacePred(-1, num1);
          entry1.SetFaceSucc(faceIndex, num3);
          entry1.ChangeFace(faceIndex, -1);
          this.SetEdgeEntry(num3, ref edgeEntry2);
          this.SetEdgeEntry(num1, ref entry1);
          MyWingedEdgeMesh.VertexTableEntry vertexTableEntry = this.m_vertexTable[index2];
          vertexTableEntry.IncidentEdge = num1;
          this.m_vertexTable[index2] = vertexTableEntry;
        }
        else
        {
          for (int index3 = entry2.VertexSucc(index2); index3 != num1; {
            MyWingedEdgeMesh.EdgeTableEntry edgeEntry2;
            index3 = edgeEntry2.VertexSucc(index2);
          }
          )
          {
            edgeEntry2 = this.GetEdgeEntry(index3);
            if (edgeEntry2.VertexRightFace(index2) == -1)
            {
              int num3 = edgeEntry2.VertexSucc(index2);
              Vector3 position = this.m_vertexTable[index2].VertexPosition;
              int num4 = this.AllocateAndInsertVertex(ref position, num3);
              MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(num3);
              edgeEntry2.SetVertexPred(index2, num1);
              entry1.SetVertexSucc(index2, num3);
              entry1.ChangeVertex(index2, num4);
              while (true)
              {
                edgeEntry2.ChangeVertex(index2, num4);
                this.SetEdgeEntry(num3, ref edgeEntry2);
                num3 = edgeEntry2.VertexSucc(num4);
                if (num3 != num1)
                  edgeEntry2 = this.GetEdgeEntry(num3);
                else
                  break;
              }
              edgeEntry2.SetVertexSucc(index2, num2);
              entry2.SetVertexPred(index2, index3);
              this.SetEdgeEntry(index3, ref edgeEntry2);
              this.SetEdgeEntry(num2, ref entry2);
              break;
            }
          }
          entry1.ChangeFace(faceIndex, -1);
          this.SetEdgeEntry(num1, ref entry1);
        }
        num1 = num2;
        entry1 = entry2;
      }
      while (num1 != index1);
      this.DeallocateFace(faceIndex);
    }

    private int AllocateAndInsertFace(object userData, int incidentEdge)
    {
      MyWingedEdgeMesh.FaceTableEntry faceTableEntry = new MyWingedEdgeMesh.FaceTableEntry()
      {
        IncidentEdge = incidentEdge,
        UserData = userData
      };
      if (this.m_freeFaces == -1)
      {
        int count = this.m_faceTable.Count;
        this.m_faceTable.Add(faceTableEntry);
        return count;
      }
      else
      {
        int index = this.m_freeFaces;
        this.m_freeFaces = this.m_faceTable[this.m_freeFaces].NextFreeEntry;
        this.m_faceTable[index] = faceTableEntry;
        return index;
      }
    }

    private int AllocateAndInsertVertex(ref Vector3 position, int incidentEdge)
    {
      MyWingedEdgeMesh.VertexTableEntry vertexTableEntry = new MyWingedEdgeMesh.VertexTableEntry()
      {
        IncidentEdge = incidentEdge,
        VertexPosition = position
      };
      if (this.m_freeVertices == -1)
      {
        int count = this.m_vertexTable.Count;
        this.m_vertexTable.Add(vertexTableEntry);
        return count;
      }
      else
      {
        int index = this.m_freeVertices;
        this.m_freeVertices = this.m_vertexTable[this.m_freeVertices].NextFreeEntry;
        this.m_vertexTable[index] = vertexTableEntry;
        return index;
      }
    }

    private int AllocateEdge()
    {
      MyWingedEdgeMesh.EdgeTableEntry edgeTableEntry = new MyWingedEdgeMesh.EdgeTableEntry();
      edgeTableEntry.Init();
      if (this.m_freeEdges == -1)
      {
        int count = this.m_edgeTable.Count;
        this.m_edgeTable.Add(edgeTableEntry);
        return count;
      }
      else
      {
        int index = this.m_freeEdges;
        this.m_freeEdges = this.m_edgeTable[this.m_freeEdges].NextFreeEntry;
        this.m_edgeTable[index] = edgeTableEntry;
        return index;
      }
    }

    private void DeallocateFace(int faceIndex)
    {
      this.m_faceTable[faceIndex] = new MyWingedEdgeMesh.FaceTableEntry()
      {
        NextFreeEntry = this.m_freeFaces
      };
      this.m_freeFaces = faceIndex;
    }

    private void DeallocateVertex(int vertexIndex)
    {
      this.m_vertexTable[vertexIndex] = new MyWingedEdgeMesh.VertexTableEntry()
      {
        NextFreeEntry = this.m_freeVertices
      };
      this.m_freeVertices = vertexIndex;
    }

    private void DeallocateEdge(int edgeIndex)
    {
      this.m_edgeTable[edgeIndex] = new MyWingedEdgeMesh.EdgeTableEntry()
      {
        NextFreeEntry = this.m_freeEdges
      };
      this.m_freeEdges = edgeIndex;
    }

    public void DebugDraw(ref Matrix drawMatrix, MyWEMDebugDrawMode draw)
    {
      HashSet<int> hashSet = new HashSet<int>();
      for (int index = this.m_freeEdges; index != -1; index = this.m_edgeTable[index].NextFreeEntry)
        hashSet.Add(index);
      for (int index = 0; index < this.m_edgeTable.Count; ++index)
      {
        if (!hashSet.Contains(index) && (MyWingedEdgeMesh.m_debugDrawEdges == null || MyWingedEdgeMesh.m_debugDrawEdges.Contains(index)))
        {
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry1 = this.GetEdgeEntry(index);
          Vector3 vector3_1 = Vector3.Transform(this.m_vertexTable[edgeEntry1.Vertex1].VertexPosition, drawMatrix);
          Vector3 vector3_2 = Vector3.Transform(this.m_vertexTable[edgeEntry1.Vertex2].VertexPosition, drawMatrix);
          Vector3 vector3_3 = (vector3_1 + vector3_2) * 0.5f;
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry2 = this.GetEdgeEntry(edgeEntry1.LeftSucc);
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry3 = this.GetEdgeEntry(edgeEntry1.RightPred);
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry4 = this.GetEdgeEntry(edgeEntry1.LeftPred);
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry5 = this.GetEdgeEntry(edgeEntry1.RightSucc);
          Vector3 vector3_4 = Vector3.Transform(this.m_vertexTable[edgeEntry2.OtherVertex(edgeEntry1.Vertex1)].VertexPosition, drawMatrix);
          Vector3 vector3_5 = Vector3.Transform(this.m_vertexTable[edgeEntry3.OtherVertex(edgeEntry1.Vertex1)].VertexPosition, drawMatrix);
          Vector3 vector3_6 = Vector3.Transform(this.m_vertexTable[edgeEntry4.OtherVertex(edgeEntry1.Vertex2)].VertexPosition, drawMatrix);
          Vector3 vector3_7 = Vector3.Transform(this.m_vertexTable[edgeEntry5.OtherVertex(edgeEntry1.Vertex2)].VertexPosition, drawMatrix);
          if (draw.HasFlag((Enum) MyWEMDebugDrawMode.LINES) || draw.HasFlag((Enum) MyWEMDebugDrawMode.EDGES))
          {
            bool flag = edgeEntry1.LeftFace == -1 || edgeEntry1.RightFace == -1;
            Color colorFrom = draw.HasFlag((Enum) MyWEMDebugDrawMode.LINES) ? (flag ? Color.Red : Color.DarkSlateBlue) : Color.Black;
            Color colorTo = draw.HasFlag((Enum) MyWEMDebugDrawMode.LINES) ? (flag ? Color.Red : Color.DarkSlateBlue) : Color.White;
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_1, (Vector3D) vector3_2, colorFrom, colorTo, true);
          }
          if (draw.HasFlag((Enum) MyWEMDebugDrawMode.EDGES))
          {
            if (edgeEntry1.RightFace == -1)
            {
              Vector3 vector2 = vector3_2 - vector3_1;
              double num = (double) vector2.Normalize();
              Vector3 vector3_8 = vector3_6 - vector2 * Vector3.Dot(vector3_6 - vector3_2, vector2);
              vector3_7 = vector3_2 + vector3_2 - vector3_8;
              Vector3 vector3_9 = vector3_4 - vector2 * Vector3.Dot(vector3_4 - vector3_1, vector2);
              vector3_5 = vector3_1 + vector3_1 - vector3_9;
            }
            if (edgeEntry1.LeftFace == -1)
            {
              Vector3 vector2 = vector3_1 - vector3_2;
              double num = (double) vector2.Normalize();
              Vector3 vector3_8 = vector3_7 - vector2 * Vector3.Dot(vector3_7 - vector3_2, vector2);
              vector3_6 = vector3_2 + vector3_2 - vector3_8;
              Vector3 vector3_9 = vector3_5 - vector2 * Vector3.Dot(vector3_5 - vector3_1, vector2);
              vector3_4 = vector3_1 + vector3_1 - vector3_9;
            }
            Vector3 vector3_10 = (vector3_1 * 0.8f + vector3_4 * 0.2f) * 0.5f + vector3_3 * 0.5f;
            Vector3 vector3_11 = (vector3_1 * 0.8f + vector3_5 * 0.2f) * 0.5f + vector3_3 * 0.5f;
            Vector3 vector3_12 = (vector3_2 * 0.8f + vector3_6 * 0.2f) * 0.5f + vector3_3 * 0.5f;
            Vector3 vector3_13 = (vector3_2 * 0.8f + vector3_7 * 0.2f) * 0.5f + vector3_3 * 0.5f;
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) vector3_10, Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) vector3_11, Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) vector3_12, Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) vector3_13, Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) ((vector3_13 + vector3_11) * 0.5f), Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawLine3D((Vector3D) vector3_3, (Vector3D) ((vector3_12 + vector3_10) * 0.5f), Color.Black, Color.Gray, false);
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3_3, index.ToString(), Color.Yellow, 0.5f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3_10, edgeEntry1.LeftSucc.ToString(), Color.LightYellow, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3_11, edgeEntry1.RightPred.ToString(), Color.LightYellow, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3_12, edgeEntry1.LeftPred.ToString(), Color.LightYellow, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3_13, edgeEntry1.RightSucc.ToString(), Color.LightYellow, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            if (edgeEntry1.RightFace != -1)
              MyRenderProxy.DebugDrawText3D((Vector3D) ((vector3_13 + vector3_11) * 0.5f), edgeEntry1.RightFace.ToString(), Color.LightBlue, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            else
              MyRenderProxy.DebugDrawText3D((Vector3D) ((vector3_13 + vector3_11) * 0.5f), edgeEntry1.RightFace.ToString(), Color.Red, 0.8f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            if (edgeEntry1.LeftFace != -1)
              MyRenderProxy.DebugDrawText3D((Vector3D) ((vector3_12 + vector3_10) * 0.5f), edgeEntry1.LeftFace.ToString(), Color.LightBlue, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            else
              MyRenderProxy.DebugDrawText3D((Vector3D) ((vector3_12 + vector3_10) * 0.5f), edgeEntry1.LeftFace.ToString(), Color.Red, 0.8f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) (vector3_1 * 0.05f + vector3_2 * 0.95f), edgeEntry1.Vertex2.ToString(), Color.LightGreen, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
            MyRenderProxy.DebugDrawText3D((Vector3D) (vector3_1 * 0.95f + vector3_2 * 0.05f), edgeEntry1.Vertex1.ToString(), Color.LightGreen, 0.4f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
          }
        }
      }
      if (draw.HasFlag((Enum) MyWEMDebugDrawMode.FACES))
      {
        hashSet.Clear();
        for (int index = this.m_freeFaces; index != -1; index = this.GetFaceEntry(index).NextFreeEntry)
          hashSet.Add(index);
        for (int faceIndex = 0; faceIndex < this.m_faceTable.Count; ++faceIndex)
        {
          if (!hashSet.Contains(faceIndex))
          {
            Vector3 vector3 = Vector3.Zero;
            int num = 0;
            MyWingedEdgeMesh.VertexEnumerator vertexEnumerator = this.GetFace(faceIndex).GetVertexEnumerator();
            while (vertexEnumerator.MoveNext())
            {
              vector3 += vertexEnumerator.Current;
              ++num;
            }
            MyRenderProxy.DebugDrawText3D((Vector3D) Vector3.Transform(vector3 / (float) num, drawMatrix), faceIndex.ToString(), Color.CadetBlue, 0.6f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
          }
        }
      }
      if (!draw.HasFlag((Enum) MyWEMDebugDrawMode.VERTICES) && !draw.HasFlag((Enum) MyWEMDebugDrawMode.VERTICES_DETAILED))
        return;
      hashSet.Clear();
      for (int index = this.m_freeVertices; index != -1; index = this.m_vertexTable[index].NextFreeEntry)
        hashSet.Add(index);
      for (int index = 0; index < this.m_vertexTable.Count; ++index)
      {
        if (!hashSet.Contains(index))
        {
          Vector3 vector3 = Vector3.Transform(this.m_vertexTable[index].VertexPosition, drawMatrix);
          if (draw.HasFlag((Enum) MyWEMDebugDrawMode.VERTICES_DETAILED))
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3, this.m_vertexTable[index].ToString(), Color.LightGreen, 0.5f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
          else
            MyRenderProxy.DebugDrawText3D((Vector3D) vector3, index.ToString(), Color.LightGreen, 0.5f, false, MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER, -1);
        }
      }
    }

    [Conditional("DEBUG")]
    private void CheckVertexLoopConsistency(int vertexIndex)
    {
    }

    [Conditional("DEBUG")]
    private void CheckFreeEntryConsistency()
    {
      if (!MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS)
        return;
      this.m_tmpVisitedIndices.Clear();
      int index1 = this.m_freeVertices;
      while (index1 != -1)
      {
        index1 = this.m_vertexTable[index1].NextFreeEntry;
        this.m_tmpVisitedIndices.Add(index1);
      }
      this.m_tmpVisitedIndices.Clear();
      int index2 = this.m_freeEdges;
      while (index2 != -1)
      {
        index2 = this.m_edgeTable[index2].NextFreeEntry;
        this.m_tmpVisitedIndices.Add(index2);
      }
      this.m_tmpVisitedIndices.Clear();
      int index3 = this.m_freeFaces;
      while (index3 != -1)
      {
        index3 = this.m_faceTable[index3].NextFreeEntry;
        this.m_tmpVisitedIndices.Add(index3);
      }
      this.m_tmpVisitedIndices.Clear();
    }

    [Conditional("DEBUG")]
    private void CheckEdgeIndexValid(int index)
    {
      if (!MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS)
        return;
      int index1 = this.m_freeEdges;
      while (index1 != -1)
        index1 = this.m_edgeTable[index1].NextFreeEntry;
    }

    [Conditional("DEBUG")]
    private void CheckFaceIndexValid(int index)
    {
      if (!MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS)
        return;
      int index1 = this.m_freeFaces;
      while (index1 != -1)
        index1 = this.m_faceTable[index1].NextFreeEntry;
    }

    [Conditional("DEBUG")]
    private void CheckFaceIndexValidQuick(int index, HashSet<int> freeFaces)
    {
      int num = MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS ? 1 : 0;
    }

    [Conditional("DEBUG")]
    private void CheckEdgeIndexValidQuick(int index, HashSet<int> freeEdges)
    {
      int num = MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS ? 1 : 0;
    }

    [Conditional("DEBUG")]
    private void CheckVertexIndexValidQuick(int index, HashSet<int> freeVertices)
    {
      int num = MyWingedEdgeMesh.BASIC_CONSISTENCY_CHECKS ? 1 : 0;
    }

    [Conditional("DEBUG")]
    public void CheckMeshConsistency()
    {
      if (!MyWingedEdgeMesh.ADVANCED_CONSISTENCY_CHECKS)
        return;
      this.m_tmpFreeEdges.Clear();
      this.m_tmpFreeFaces.Clear();
      this.m_tmpFreeVertices.Clear();
      for (int index = this.m_freeEdges; index != -1; index = this.m_edgeTable[index].NextFreeEntry)
        this.m_tmpFreeEdges.Add(index);
      for (int index = this.m_freeFaces; index != -1; index = this.m_faceTable[index].NextFreeEntry)
        this.m_tmpFreeFaces.Add(index);
      for (int index = this.m_freeVertices; index != -1; index = this.m_vertexTable[index].NextFreeEntry)
        this.m_tmpFreeVertices.Add(index);
      for (int index = 0; index < this.m_edgeTable.Count; ++index)
      {
        if (!this.m_tmpFreeEdges.Contains(index))
        {
          MyWingedEdgeMesh.EdgeTableEntry edgeTableEntry = this.m_edgeTable[index];
          int num1 = edgeTableEntry.LeftFace;
          int num2 = edgeTableEntry.RightFace;
        }
      }
    }

    public int ApproximateMemoryFootprint()
    {
      int num1 = Environment.Is64BitProcess ? 32 : 20;
      int num2 = Environment.Is64BitProcess ? 88 : 56;
      int num3 = Environment.Is64BitProcess ? 52 : 32;
      int num4 = 16;
      int num5 = 32;
      int num6 = (Environment.Is64BitProcess ? 8 : 12) + num2;
      return num3 + 3 * num1 + this.m_edgeTable.Capacity * num5 + this.m_faceTable.Capacity * num6 + this.m_vertexTable.Capacity * num4;
    }

    private struct EdgeTableEntry
    {
      public int Vertex1;
      public int Vertex2;
      public int LeftFace;
      public int RightFace;
      public int LeftPred;
      public int LeftSucc;
      public int RightPred;
      public int RightSucc;

      public int NextFreeEntry
      {
        get
        {
          return this.Vertex1;
        }
        set
        {
          this.Vertex1 = value;
        }
      }

      public void Init()
      {
        this.Vertex1 = -1;
        this.Vertex2 = -1;
        this.LeftFace = -1;
        this.RightFace = -1;
        this.LeftPred = -1;
        this.LeftSucc = -1;
        this.RightPred = -1;
        this.RightSucc = -1;
      }

      public int OtherVertex(int vert)
      {
        if (vert != this.Vertex1)
          return this.Vertex1;
        else
          return this.Vertex2;
      }

      public void GetFaceVertices(int face, out int predVertex, out int succVertex)
      {
        if (face == this.LeftFace)
        {
          predVertex = this.Vertex2;
          succVertex = this.Vertex1;
        }
        else
        {
          predVertex = this.Vertex1;
          succVertex = this.Vertex2;
        }
      }

      public int GetFaceSuccVertex(int face)
      {
        if (face == this.LeftFace)
          return this.Vertex1;
        else
          return this.Vertex2;
      }

      public int GetFacePredVertex(int face)
      {
        if (face == this.LeftFace)
          return this.Vertex2;
        else
          return this.Vertex1;
      }

      public void SetFaceSuccVertex(int face, int vertex)
      {
        if (face == this.LeftFace)
          this.Vertex1 = vertex;
        else
          this.Vertex2 = vertex;
      }

      public void SetFacePredVertex(int face, int vertex)
      {
        if (face == this.LeftFace)
          this.Vertex2 = vertex;
        else
          this.Vertex1 = vertex;
      }

      public int TryGetSharedVertex(ref MyWingedEdgeMesh.EdgeTableEntry otherEdge)
      {
        if (this.Vertex1 == otherEdge.Vertex1 || this.Vertex1 == otherEdge.Vertex2)
          return this.Vertex1;
        if (this.Vertex2 == otherEdge.Vertex1 || this.Vertex2 == otherEdge.Vertex2)
          return this.Vertex2;
        else
          return -1;
      }

      public void ChangeVertex(int oldVertex, int newVertex)
      {
        if (oldVertex == this.Vertex1)
          this.Vertex1 = newVertex;
        else
          this.Vertex2 = newVertex;
      }

      public int OtherFace(int face)
      {
        if (face == this.LeftFace)
          return this.RightFace;
        else
          return this.LeftFace;
      }

      public int VertexLeftFace(int vertex)
      {
        if (vertex != this.Vertex1)
          return this.LeftFace;
        else
          return this.RightFace;
      }

      public int VertexRightFace(int vertex)
      {
        if (vertex != this.Vertex1)
          return this.RightFace;
        else
          return this.LeftFace;
      }

      public void AddFace(int face)
      {
        if (this.LeftFace == -1)
          this.LeftFace = face;
        else
          this.RightFace = face;
      }

      public void ChangeFace(int previousFace, int newFace)
      {
        if (previousFace == this.LeftFace)
          this.LeftFace = newFace;
        else
          this.RightFace = newFace;
      }

      public int FaceSucc(int faceIndex)
      {
        if (faceIndex == this.LeftFace)
          return this.LeftSucc;
        else
          return this.RightSucc;
      }

      public void SetFaceSucc(int faceIndex, int newSucc)
      {
        if (faceIndex == this.LeftFace)
          this.LeftSucc = newSucc;
        else
          this.RightSucc = newSucc;
      }

      public int FacePred(int faceIndex)
      {
        if (faceIndex == this.LeftFace)
          return this.LeftPred;
        else
          return this.RightPred;
      }

      public void SetFacePred(int faceIndex, int newPred)
      {
        if (faceIndex == this.LeftFace)
          this.LeftPred = newPred;
        else
          this.RightPred = newPred;
      }

      public int VertexSucc(int vertexIndex)
      {
        if (vertexIndex != this.Vertex1)
          return this.RightSucc;
        else
          return this.LeftSucc;
      }

      public int SetVertexSucc(int vertexIndex, int newSucc)
      {
        int num;
        if (vertexIndex == this.Vertex1)
        {
          num = this.LeftSucc;
          this.LeftSucc = newSucc;
        }
        else
        {
          num = this.RightSucc;
          this.RightSucc = newSucc;
        }
        return num;
      }

      public int VertexPred(int vertexIndex)
      {
        if (vertexIndex != this.Vertex1)
          return this.LeftPred;
        else
          return this.RightPred;
      }

      public int SetVertexPred(int vertexIndex, int newPred)
      {
        int num;
        if (vertexIndex == this.Vertex1)
        {
          num = this.RightPred;
          this.RightPred = newPred;
        }
        else
        {
          num = this.LeftPred;
          this.LeftPred = newPred;
        }
        return num;
      }

      public override string ToString()
      {
        return "V: " + (object) this.Vertex1 + ", " + (string) (object) this.Vertex2 + "; Left (Pred, Face, Succ): " + (string) (object) this.LeftPred + ", " + (string) (object) this.LeftFace + ", " + (string) (object) this.LeftSucc + "; Right (Pred, Face, Succ): " + (string) (object) this.RightPred + ", " + (string) (object) this.RightFace + ", " + (string) (object) this.RightSucc;
      }
    }

    private struct VertexTableEntry
    {
      public int IncidentEdge;
      public Vector3 VertexPosition;

      public int NextFreeEntry
      {
        get
        {
          return this.IncidentEdge;
        }
        set
        {
          this.IncidentEdge = value;
        }
      }

      public override string ToString()
      {
        return this.VertexPosition.ToString() + (object) " -> " + (string) (object) this.IncidentEdge;
      }
    }

    private struct FaceTableEntry
    {
      public int IncidentEdge;
      public object UserData;

      public int NextFreeEntry
      {
        get
        {
          return this.IncidentEdge;
        }
        set
        {
          this.IncidentEdge = value;
        }
      }

      public override string ToString()
      {
        return "-> " + this.IncidentEdge.ToString();
      }
    }

    public struct Edge
    {
      private MyWingedEdgeMesh.EdgeTableEntry m_entry;

      public int LeftFace
      {
        get
        {
          return this.m_entry.LeftFace;
        }
      }

      public int RightFace
      {
        get
        {
          return this.m_entry.RightFace;
        }
      }

      public Edge(MyWingedEdgeMesh mesh, int index)
      {
        this.m_entry = mesh.GetEdgeEntry(index);
      }

      public int TryGetSharedVertex(ref MyWingedEdgeMesh.Edge other)
      {
        return this.m_entry.TryGetSharedVertex(ref other.m_entry);
      }

      public int GetFacePredVertex(int face)
      {
        return this.m_entry.GetFacePredVertex(face);
      }

      public int GetFaceSuccVertex(int face)
      {
        return this.m_entry.GetFaceSuccVertex(face);
      }

      public int OtherVertex(int vertex)
      {
        return this.m_entry.OtherVertex(vertex);
      }

      public int OtherFace(int face)
      {
        return this.m_entry.OtherFace(face);
      }

      public int GetPreviousEdge(int faceIndex)
      {
        return this.m_entry.FacePred(faceIndex);
      }

      public int GetNextEdge(int faceIndex)
      {
        return this.m_entry.FaceSucc(faceIndex);
      }

      public int GetNextVertexEdge(int vertexIndex)
      {
        return this.m_entry.VertexPred(vertexIndex);
      }

      public int VertexLeftFace(int vertexIndex)
      {
        return this.m_entry.VertexLeftFace(vertexIndex);
      }
    }

    public struct Face
    {
      private int m_faceIndex;
      private MyWingedEdgeMesh m_mesh;

      public Face(MyWingedEdgeMesh mesh, int index)
      {
        this.m_mesh = mesh;
        this.m_faceIndex = index;
      }

      public MyWingedEdgeMesh.EdgeEnumerator GetEnumerator()
      {
        return new MyWingedEdgeMesh.EdgeEnumerator(this.m_mesh, this.m_faceIndex);
      }

      public MyWingedEdgeMesh.VertexEnumerator GetVertexEnumerator()
      {
        return new MyWingedEdgeMesh.VertexEnumerator(this.m_mesh, this.m_faceIndex);
      }

      public T GetUserData<T>() where T : class
      {
        return this.m_mesh.GetFaceEntry(this.m_faceIndex).UserData as T;
      }
    }

    public struct EdgeEnumerator
    {
      private MyWingedEdgeMesh m_mesh;
      private int m_faceIndex;
      private int m_currentEdge;
      private int m_startingEdge;

      public int Current
      {
        get
        {
          return this.m_currentEdge;
        }
      }

      public EdgeEnumerator(MyWingedEdgeMesh mesh, int faceIndex)
      {
        this.m_mesh = mesh;
        this.m_faceIndex = faceIndex;
        this.m_currentEdge = -1;
        this.m_startingEdge = this.m_mesh.GetFaceEntry(faceIndex).IncidentEdge;
      }

      public bool MoveNext()
      {
        if (this.m_currentEdge == -1)
        {
          this.m_currentEdge = this.m_startingEdge;
          return true;
        }
        else
        {
          this.m_currentEdge = this.m_mesh.GetEdgeEntry(this.m_currentEdge).FaceSucc(this.m_faceIndex);
          return this.m_currentEdge != this.m_startingEdge;
        }
      }
    }

    public struct VertexEnumerator
    {
      private MyWingedEdgeMesh m_mesh;
      private int m_faceIndex;
      private int m_currentEdge;
      private int m_startingEdge;

      public Vector3 Current
      {
        get
        {
          MyWingedEdgeMesh.EdgeTableEntry edgeEntry = this.m_mesh.GetEdgeEntry(this.m_currentEdge);
          if (this.m_faceIndex == edgeEntry.LeftFace)
            return this.m_mesh.m_vertexTable[edgeEntry.Vertex2].VertexPosition;
          else
            return this.m_mesh.m_vertexTable[edgeEntry.Vertex1].VertexPosition;
        }
      }

      public VertexEnumerator(MyWingedEdgeMesh mesh, int faceIndex)
      {
        this.m_mesh = mesh;
        this.m_faceIndex = faceIndex;
        this.m_currentEdge = -1;
        this.m_startingEdge = this.m_mesh.GetFaceEntry(faceIndex).IncidentEdge;
      }

      public bool MoveNext()
      {
        if (this.m_currentEdge == -1)
        {
          this.m_currentEdge = this.m_startingEdge;
          return true;
        }
        else
        {
          this.m_currentEdge = this.m_mesh.GetEdgeEntry(this.m_currentEdge).FaceSucc(this.m_faceIndex);
          return this.m_currentEdge != this.m_startingEdge;
        }
      }
    }
  }
}
