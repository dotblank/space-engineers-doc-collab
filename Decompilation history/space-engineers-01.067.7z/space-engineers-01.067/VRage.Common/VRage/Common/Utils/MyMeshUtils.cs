﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyMeshUtils
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRageMath;

namespace VRage.Common.Utils
{
  public static class MyMeshUtils
  {
    public static void GetOpenBoundaries(Vector3[] vertices, int[] indices, List<Vector3> openBoundaries)
    {
      Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>();
      for (int index = 0; index < vertices.Length; ++index)
      {
        for (int key = 0; key < index; ++key)
        {
          if (MyVRageUtils.IsEqual(vertices[key], vertices[index]))
          {
            if (!dictionary.ContainsKey(key))
              dictionary[key] = new List<int>();
            dictionary[key].Add(index);
            break;
          }
        }
      }
      foreach (KeyValuePair<int, List<int>> keyValuePair in dictionary)
      {
        foreach (int num in keyValuePair.Value)
        {
          for (int index = 0; index < indices.Length; ++index)
          {
            if (indices[index] == num)
              indices[index] = keyValuePair.Key;
          }
        }
      }
      Dictionary<MyMeshUtils.Edge, int> edgeCounts = new Dictionary<MyMeshUtils.Edge, int>();
      int index1 = 0;
      while (index1 < indices.Length)
      {
        MyMeshUtils.AddEdge(indices[index1], indices[index1 + 1], edgeCounts);
        MyMeshUtils.AddEdge(indices[index1 + 1], indices[index1 + 2], edgeCounts);
        MyMeshUtils.AddEdge(indices[index1 + 2], indices[index1], edgeCounts);
        index1 += 3;
      }
      openBoundaries.Clear();
      foreach (KeyValuePair<MyMeshUtils.Edge, int> keyValuePair in edgeCounts)
      {
        if (keyValuePair.Value == 1)
        {
          openBoundaries.Add(vertices[keyValuePair.Key.I0]);
          openBoundaries.Add(vertices[keyValuePair.Key.I1]);
        }
      }
    }

    private static void AddEdge(int i0, int i1, Dictionary<MyMeshUtils.Edge, int> edgeCounts)
    {
      MyMeshUtils.Edge key = new MyMeshUtils.Edge()
      {
        I0 = i0,
        I1 = i1
      };
      key.GetHashCode();
      if (edgeCounts.ContainsKey(key))
        edgeCounts[key] = edgeCounts[key] + 1;
      else
        edgeCounts[key] = 1;
    }

    private struct Edge : IEquatable<MyMeshUtils.Edge>
    {
      public int I0;
      public int I1;

      public bool Equals(MyMeshUtils.Edge other)
      {
        return object.Equals((object) other.GetHashCode(), (object) this.GetHashCode());
      }

      public override int GetHashCode()
      {
        if (this.I0 >= this.I1)
          return this.I1.GetHashCode() * 397 ^ this.I0.GetHashCode();
        else
          return this.I0.GetHashCode() * 397 ^ this.I1.GetHashCode();
      }
    }
  }
}
