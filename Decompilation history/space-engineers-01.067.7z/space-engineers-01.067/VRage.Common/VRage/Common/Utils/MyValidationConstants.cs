﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyValidationConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common.Utils
{
  public static class MyValidationConstants
  {
    public const int USERNAME_LENGTH_MIN = 3;
    public const int USERNAME_LENGTH_MAX = 15;
    public const int EMAIL_LENGTH_MAX = 50;
    public const int PASSWORD_LENGTH_MIN = 6;
    public const int PASSWORD_LENGTH_MAX = 10;
    public const int POSITION_X_MAX = 5;
    public const int POSITION_Y_MAX = 5;
    public const int POSITION_Z_MAX = 5;
  }
}
