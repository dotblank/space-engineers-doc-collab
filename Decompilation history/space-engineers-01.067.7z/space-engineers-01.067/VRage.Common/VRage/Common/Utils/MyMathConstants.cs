﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyMathConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common.Utils
{
  public static class MyMathConstants
  {
    public const float EPSILON = 1E-05f;
    public const float EPSILON10 = 1E-06f;
    public const float EPSILON_SQUARED = 9.999999E-11f;
  }
}
