﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MySectorConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Utils
{
  public static class MySectorConstants
  {
    public static readonly Vector3 SECTOR_SIZE_VECTOR3 = new Vector3(50000f, 50000f, 50000f);
    public static readonly float SECTOR_DIAMETER = MySectorConstants.SECTOR_SIZE_VECTOR3.Length();
    public static readonly BoundingBox SAFE_SECTOR_SIZE_BOUNDING_BOX = new BoundingBox(new Vector3(-25100f, -25100f, -25100f), new Vector3(25100f, 25100f, 25100f));
    public static readonly Vector3[] SAFE_SECTOR_SIZE_BOUNDING_BOX_CORNERS = MySectorConstants.SAFE_SECTOR_SIZE_BOUNDING_BOX.GetCorners();
    public static readonly BoundingBox SECTOR_SIZE_FOR_PHYS_OBJECTS_BOUNDING_BOX = new BoundingBox(new Vector3(-22500f, -22500f, -22500f), new Vector3(22500f, 22500f, 22500f));
    public static readonly BoundingBox SECTOR_SIZE_BOUNDING_BOX = new BoundingBox(new Vector3(-25000f, -25000f, -25000f), new Vector3(25000f, 25000f, 25000f));
    public const float SECTOR_SIZE = 50000f;
    public const float SECTOR_SIZE_HALF = 25000f;
    public const float SAFE_SECTOR_SIZE = 50200f;
    public const float SECTOR_SIZE_FOR_PHYS_OBJECTS_SIZE_HALF = 22500f;
    public const float SAFE_SECTOR_SIZE_HALF = 25100f;
  }
}
