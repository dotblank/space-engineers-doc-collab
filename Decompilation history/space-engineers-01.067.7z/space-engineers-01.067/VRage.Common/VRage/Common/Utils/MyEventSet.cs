﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyEventSet
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;

namespace VRage.Common.Utils
{
  public sealed class MyEventSet
  {
    private readonly Dictionary<MyStringId, Delegate> m_events = new Dictionary<MyStringId, Delegate>();

    public void Add(MyStringId eventKey, Delegate handler)
    {
      Delegate a;
      this.m_events.TryGetValue(eventKey, out a);
      this.m_events[eventKey] = Delegate.Combine(a, handler);
    }

    public void Remove(MyStringId eventKey, Delegate handler)
    {
      Delegate source;
      if (!this.m_events.TryGetValue(eventKey, out source))
        return;
      Delegate @delegate = Delegate.Remove(source, handler);
      if (@delegate != null)
        this.m_events[eventKey] = @delegate;
      else
        this.m_events.Remove(eventKey);
    }

    public void Raise(MyStringId eventKey, object sender, EventArgs e)
    {
      Delegate @delegate;
      this.m_events.TryGetValue(eventKey, out @delegate);
      if (@delegate == null)
        return;
      @delegate.DynamicInvoke(sender, (object) e);
    }
  }
}
