﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MySerialKey
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace VRage.Common.Utils
{
  public static class MySerialKey
  {
    private static int m_dataSize = 14;
    private static int m_hashSize = 4;

    public static string[] Generate(short productTypeId, short distributorId, int keyCount)
    {
      byte[] bytes1 = BitConverter.GetBytes(productTypeId);
      byte[] bytes2 = BitConverter.GetBytes(distributorId);
      using (RNGCryptoServiceProvider cryptoServiceProvider = new RNGCryptoServiceProvider())
      {
        using (SHA1Managed shA1Managed = new SHA1Managed())
        {
          List<string> list = new List<string>(keyCount);
          byte[] numArray = new byte[MySerialKey.m_dataSize + MySerialKey.m_hashSize];
          for (int index1 = 0; index1 < keyCount; ++index1)
          {
            cryptoServiceProvider.GetBytes(numArray);
            numArray[0] = bytes1[0];
            numArray[1] = bytes1[1];
            numArray[2] = bytes2[0];
            numArray[3] = bytes2[1];
            for (int index2 = 0; index2 < 4; ++index2)
              numArray[index2] = (byte) ((uint) numArray[index2] ^ (uint) numArray[index2 + 4]);
            byte[] hash = shA1Managed.ComputeHash(numArray, 0, MySerialKey.m_dataSize);
            for (int index2 = 0; index2 < MySerialKey.m_hashSize; ++index2)
              numArray[MySerialKey.m_dataSize + index2] = hash[index2];
            list.Add(new string(My5BitEncoding.Default.Encode(Enumerable.ToArray<byte>((IEnumerable<byte>) numArray))) + "X");
          }
          return list.ToArray();
        }
      }
    }

    public static string AddDashes(string key)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < key.Length; ++index)
      {
        if (index % 5 == 0 && index > 0)
          stringBuilder.Append('-');
        stringBuilder.Append(key[index]);
      }
      return ((object) stringBuilder).ToString();
    }

    public static string RemoveDashes(string key)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < key.Length; ++index)
      {
        if ((index + 1) % 6 != 0)
          stringBuilder.Append(key[index]);
      }
      return ((object) stringBuilder).ToString();
    }

    public static bool ValidateSerial(string serialKey, out int productTypeId, out int distributorId)
    {
      using (new RNGCryptoServiceProvider())
      {
        using (SHA1 shA1 = SHA1.Create())
        {
          if (serialKey.EndsWith("X"))
          {
            byte[] numArray = My5BitEncoding.Default.Decode(Enumerable.ToArray<char>(Enumerable.Take<char>((IEnumerable<char>) serialKey, serialKey.Length - 1)));
            byte[] buffer = Enumerable.ToArray<byte>(Enumerable.Take<byte>((IEnumerable<byte>) numArray, numArray.Length - MySerialKey.m_hashSize));
            byte[] hash = shA1.ComputeHash(buffer);
            if (Enumerable.SequenceEqual<byte>(Enumerable.Take<byte>(Enumerable.Skip<byte>((IEnumerable<byte>) numArray, buffer.Length), MySerialKey.m_hashSize), Enumerable.Take<byte>((IEnumerable<byte>) hash, MySerialKey.m_hashSize)))
            {
              for (int index = 0; index < 4; ++index)
                buffer[index] = (byte) ((uint) buffer[index] ^ (uint) buffer[index + 4]);
              productTypeId = (int) BitConverter.ToInt16(buffer, 0);
              distributorId = (int) BitConverter.ToInt16(buffer, 2);
              return true;
            }
          }
          productTypeId = 0;
          distributorId = 0;
          return false;
        }
      }
    }
  }
}
