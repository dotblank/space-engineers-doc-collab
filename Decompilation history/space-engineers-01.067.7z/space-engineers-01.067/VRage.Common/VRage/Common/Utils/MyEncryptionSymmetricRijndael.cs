﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyEncryptionSymmetricRijndael
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace VRage.Common.Utils
{
  public static class MyEncryptionSymmetricRijndael
  {
    public static string EncryptString(string inputText, string password)
    {
      if (inputText.Length <= 0)
        return "";
      RijndaelManaged rijndaelManaged = new RijndaelManaged();
      byte[] bytes1 = Encoding.Unicode.GetBytes(inputText);
      byte[] bytes2 = Encoding.ASCII.GetBytes(password.Length.ToString());
      PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(password, bytes2);
      ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(passwordDeriveBytes.GetBytes(32), passwordDeriveBytes.GetBytes(16));
      MemoryStream memoryStream = new MemoryStream();
      CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, encryptor, CryptoStreamMode.Write);
      cryptoStream.Write(bytes1, 0, bytes1.Length);
      cryptoStream.FlushFinalBlock();
      byte[] inArray = memoryStream.ToArray();
      memoryStream.Close();
      cryptoStream.Close();
      return Convert.ToBase64String(inArray);
    }

    public static string DecryptString(string inputText, string password)
    {
      if (inputText.Length <= 0)
        return "";
      RijndaelManaged rijndaelManaged = new RijndaelManaged();
      byte[] buffer = Convert.FromBase64String(inputText);
      byte[] bytes = Encoding.ASCII.GetBytes(password.Length.ToString());
      PasswordDeriveBytes passwordDeriveBytes = new PasswordDeriveBytes(password, bytes);
      ICryptoTransform decryptor = rijndaelManaged.CreateDecryptor(passwordDeriveBytes.GetBytes(32), passwordDeriveBytes.GetBytes(16));
      MemoryStream memoryStream = new MemoryStream(buffer);
      CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, decryptor, CryptoStreamMode.Read);
      byte[] numArray = new byte[buffer.Length];
      int count = cryptoStream.Read(numArray, 0, numArray.Length);
      memoryStream.Close();
      cryptoStream.Close();
      return Encoding.Unicode.GetString(numArray, 0, count);
    }
  }
}
