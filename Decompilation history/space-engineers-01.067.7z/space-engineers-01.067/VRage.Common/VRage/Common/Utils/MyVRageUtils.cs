﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyVRageUtils
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using SysUtils.Utils;
using VRageMath;

namespace VRage.Common.Utils
{
  public static class MyVRageUtils
  {
    private static readonly string[] BYTE_SIZE_PREFIX = new string[5]
    {
      "",
      "K",
      "M",
      "G",
      "T"
    };
    public static readonly StringBuilder EmptyStringBuilder = new StringBuilder();
    private static byte[] m_randomBuffer = new byte[8];
    private static List<char> m_splitBuffer = new List<char>(16);
    public static readonly Matrix ZeroMatrix = new Matrix(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    [ThreadStatic]
    private static Random m_secretRandom;

    private static Random m_random
    {
      get
      {
        if (MyVRageUtils.m_secretRandom == null)
          MyVRageUtils.m_secretRandom = new Random();
        return MyVRageUtils.m_secretRandom;
      }
    }

    public static string FormatByteSizePrefix(ref float byteSize)
    {
      long num = 1L;
      for (int index = 0; index < MyVRageUtils.BYTE_SIZE_PREFIX.Length; ++index)
      {
        num *= 1024L;
        if ((double) byteSize < (double) num)
        {
          byteSize = byteSize / (float) (num / 1024L);
          return MyVRageUtils.BYTE_SIZE_PREFIX[index];
        }
      }
      return string.Empty;
    }

    public static void CheckFloatValues(object graph, string name, ref double? min, ref double? max)
    {
      int frameCount = new StackTrace().FrameCount;
      if (graph == null)
        return;
      if (graph is float)
      {
        float f = (float) graph;
        if (float.IsInfinity(f) || float.IsNaN(f))
          throw new InvalidOperationException("Invalid value: " + name);
        if (min.HasValue)
        {
          double num = (double) f;
          double? nullable = min;
          if ((num >= nullable.GetValueOrDefault() ? 0 : (nullable.HasValue ? 1 : 0)) == 0)
            goto label_8;
        }
        min = new double?((double) f);
label_8:
        if (max.HasValue)
        {
          double num = (double) f;
          double? nullable = max;
          if ((num <= nullable.GetValueOrDefault() ? 0 : (nullable.HasValue ? 1 : 0)) == 0)
            goto label_11;
        }
        max = new double?((double) f);
      }
label_11:
      if (graph is double)
      {
        double d = (double) graph;
        if (double.IsInfinity(d) || double.IsNaN(d))
          throw new InvalidOperationException("Invalid value: " + name);
        if (min.HasValue)
        {
          double num = d;
          double? nullable = min;
          if ((num >= nullable.GetValueOrDefault() ? 0 : (nullable.HasValue ? 1 : 0)) == 0)
            goto label_17;
        }
        min = new double?(d);
label_17:
        if (max.HasValue)
        {
          double num = d;
          double? nullable = max;
          if ((num <= nullable.GetValueOrDefault() ? 0 : (nullable.HasValue ? 1 : 0)) == 0)
            goto label_20;
        }
        max = new double?(d);
      }
label_20:
      if (graph.GetType().IsPrimitive || graph is string || graph is DateTime)
        return;
      if (graph is IEnumerable)
      {
        foreach (object graph1 in graph as IEnumerable)
          MyVRageUtils.CheckFloatValues(graph1, name + "[]", ref min, ref max);
      }
      else
      {
        foreach (FieldInfo fieldInfo in graph.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public))
          MyVRageUtils.CheckFloatValues(fieldInfo.GetValue(graph), name + "." + fieldInfo.Name, ref min, ref max);
        foreach (PropertyInfo propertyInfo in graph.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
          MyVRageUtils.CheckFloatValues(propertyInfo.GetValue(graph, (object[]) null), name + "." + propertyInfo.Name, ref min, ref max);
      }
    }

    public static int GetRandomInt(int maxValue)
    {
      return MyVRageUtils.m_random.Next(maxValue);
    }

    public static int GetRandomInt(int minValue, int maxValue)
    {
      return MyVRageUtils.m_random.Next(minValue, maxValue);
    }

    public static Vector3 GetRandomVector3()
    {
      return new Vector3(MyVRageUtils.GetRandomFloat(-1f, 1f), MyVRageUtils.GetRandomFloat(-1f, 1f), MyVRageUtils.GetRandomFloat(-1f, 1f));
    }

    public static Vector3D GetRandomVector3D()
    {
      return new Vector3D((double) MyVRageUtils.GetRandomFloat(-1f, 1f), (double) MyVRageUtils.GetRandomFloat(-1f, 1f), (double) MyVRageUtils.GetRandomFloat(-1f, 1f));
    }

    public static Vector3 GetRandomPosition(ref BoundingSphere sphere)
    {
      return sphere.Center + MyVRageUtils.GetRandomVector3Normalized() * sphere.Radius;
    }

    public static Vector3D GetRandomPosition(ref BoundingSphereD sphere)
    {
      return sphere.Center + MyVRageUtils.GetRandomVector3Normalized() * (float) sphere.Radius;
    }

    public static Vector3 GetRandomPosition(ref BoundingBox box)
    {
      return box.Center + MyVRageUtils.GetRandomVector3() * box.HalfExtents;
    }

    public static Vector3D GetRandomPosition(ref BoundingBoxD box)
    {
      return box.Center + MyVRageUtils.GetRandomVector3() * (Vector3) box.HalfExtents;
    }

    public static Vector3 GetRandomBorderPosition(ref BoundingBox box)
    {
      BoundingBoxD box1 = (BoundingBoxD) box;
      return (Vector3) MyVRageUtils.GetRandomBorderPosition(ref box1);
    }

    public static Vector3D GetRandomBorderPosition(ref BoundingBoxD box)
    {
      Vector3D vector3D = box.Size();
      double num1 = 2.0 / box.SurfaceArea();
      double num2 = vector3D.X * vector3D.Y * num1;
      double num3 = vector3D.X * vector3D.Z * num1;
      double num4 = 1.0 - num2 - num3;
      double num5 = MyVRageUtils.m_random.NextDouble();
      if (num5 < num2)
      {
        vector3D.Z = num5 >= num2 * 0.5 ? box.Max.Z : box.Min.Z;
        vector3D.X = MyVRageUtils.GetRandomDouble(box.Min.X, box.Max.X);
        vector3D.Y = MyVRageUtils.GetRandomDouble(box.Min.Y, box.Max.Y);
        return vector3D;
      }
      else
      {
        double num6 = num5 - num2;
        if (num6 < num3)
        {
          vector3D.Y = num6 >= num3 * 0.5 ? box.Max.Y : box.Min.Y;
          vector3D.X = MyVRageUtils.GetRandomDouble(box.Min.X, box.Max.X);
          vector3D.Z = MyVRageUtils.GetRandomDouble(box.Min.Z, box.Max.Z);
          return vector3D;
        }
        else
        {
          vector3D.X = num6 - num4 >= num4 * 0.5 ? box.Max.X : box.Min.X;
          vector3D.Y = MyVRageUtils.GetRandomDouble(box.Min.Y, box.Max.Y);
          vector3D.Z = MyVRageUtils.GetRandomDouble(box.Min.Z, box.Max.Z);
          return vector3D;
        }
      }
    }

    public static Vector3 GetRandomVector3Normalized()
    {
      float randomRadian = MyVRageUtils.GetRandomRadian();
      float randomFloat = MyVRageUtils.GetRandomFloat(-1f, 1f);
      float num = (float) Math.Sqrt(1.0 - (double) randomFloat * (double) randomFloat);
      return (Vector3) new Vector3D((double) num * Math.Cos((double) randomRadian), (double) num * Math.Sin((double) randomRadian), (double) randomFloat);
    }

    public static Vector3 GetRandomVector3HemisphereNormalized(Vector3 normal)
    {
      Vector3 vector3Normalized = MyVRageUtils.GetRandomVector3Normalized();
      if ((double) Vector3.Dot(vector3Normalized, normal) < 0.0)
        return -vector3Normalized;
      else
        return vector3Normalized;
    }

    public static Vector3 GetRandomVector3CircleNormalized()
    {
      float randomRadian = MyVRageUtils.GetRandomRadian();
      return new Vector3((float) Math.Sin((double) randomRadian), 0.0f, (float) Math.Cos((double) randomRadian));
    }

    public static float GetRandomSign()
    {
      return (float) Math.Sign((float) MyVRageUtils.m_random.NextDouble() - 0.5f);
    }

    public static float GetRandomFloat(float minValue, float maxValue)
    {
      return (float) MyVRageUtils.m_random.NextDouble() * (maxValue - minValue) + minValue;
    }

    public static double GetRandomDouble(double minValue, double maxValue)
    {
      return MyVRageUtils.m_random.NextDouble() * (maxValue - minValue) + minValue;
    }

    public static float GetRandomRadian()
    {
      return MyVRageUtils.GetRandomFloat(0.0f, 6.283186f);
    }

    public static long GetRandomLong()
    {
      MyVRageUtils.m_random.NextBytes(MyVRageUtils.m_randomBuffer);
      return BitConverter.ToInt64(MyVRageUtils.m_randomBuffer, 0);
    }

    public static TimeSpan GetRandomTimeSpan(TimeSpan begin, TimeSpan end)
    {
      long randomLong = MyVRageUtils.GetRandomLong();
      return new TimeSpan(begin.Ticks + randomLong % (end.Ticks - begin.Ticks));
    }

    public static int? GetInt32FromString(string s)
    {
      int result;
      if (int.TryParse(s, out result))
        return new int?(result);
      else
        return new int?();
    }

    public static void SplitStringBuilder(StringBuilder destination, StringBuilder source, string splitSeparator)
    {
      int length1 = source.Length;
      int length2 = splitSeparator.Length;
      int index1 = 0;
      for (int index2 = 0; index2 < length1; ++index2)
      {
        char ch1 = source[index2];
        if ((int) ch1 == (int) splitSeparator[index1])
        {
          ++index1;
          if (index1 == length2)
          {
            destination.AppendLine();
            MyVRageUtils.m_splitBuffer.Clear();
            index1 = 0;
          }
          else
            MyVRageUtils.m_splitBuffer.Add(ch1);
        }
        else
        {
          if (index1 > 0)
          {
            foreach (char ch2 in MyVRageUtils.m_splitBuffer)
              destination.Append(ch2);
            MyVRageUtils.m_splitBuffer.Clear();
            index1 = 0;
          }
          destination.Append(ch1);
        }
      }
      foreach (char ch in MyVRageUtils.m_splitBuffer)
        destination.Append(ch);
      MyVRageUtils.m_splitBuffer.Clear();
    }

    public static int GetClampInt(int value, int min, int max)
    {
      if (value < min)
        return min;
      if (value > max)
        return max;
      else
        return value;
    }

    public static int GetMaxValueFromEnum<T>()
    {
      Array values = Enum.GetValues(typeof (T));
      int num1 = int.MinValue;
      Type underlyingType = Enum.GetUnderlyingType(typeof (T));
      if (underlyingType == typeof (byte))
      {
        foreach (byte num2 in values)
        {
          if ((int) num2 > num1)
            num1 = (int) num2;
        }
      }
      else if (underlyingType == typeof (short))
      {
        foreach (short num2 in values)
        {
          if ((int) num2 > num1)
            num1 = (int) num2;
        }
      }
      else if (underlyingType == typeof (ushort))
      {
        foreach (ushort num2 in values)
        {
          if ((int) num2 > num1)
            num1 = (int) num2;
        }
      }
      else
      {
        if (!(underlyingType == typeof (int)))
          throw new InvalidBranchException();
        foreach (int num2 in values)
        {
          if (num2 > num1)
            num1 = num2;
        }
      }
      return num1;
    }

    public static int? GetIntFromString(string s)
    {
      int result;
      if (!int.TryParse(s, out result))
        return new int?();
      else
        return new int?(result);
    }

    public static byte? GetByteFromString(string s)
    {
      byte result;
      if (!byte.TryParse(s, out result))
        return new byte?();
      else
        return new byte?(result);
    }

    public static int GetIntFromString(string s, int defaultValue)
    {
      int? intFromString = MyVRageUtils.GetIntFromString(s);
      if (intFromString.HasValue)
        return intFromString.Value;
      else
        return defaultValue;
    }

    public static float? GetFloatFromString(string s)
    {
      float result;
      if (!float.TryParse(s, NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture.NumberFormat, out result))
        return new float?();
      else
        return new float?(result);
    }

    public static float GetFloatFromString(string s, float defaultValue)
    {
      float? floatFromString = MyVRageUtils.GetFloatFromString(s);
      if (floatFromString.HasValue)
        return floatFromString.Value;
      else
        return defaultValue;
    }

    public static bool? GetBoolFromString(string s)
    {
      bool result;
      if (!bool.TryParse(s, out result))
        return new bool?();
      else
        return new bool?(result);
    }

    public static bool GetBoolFromString(string s, bool defaultValue)
    {
      bool? boolFromString = MyVRageUtils.GetBoolFromString(s);
      if (boolFromString.HasValue)
        return boolFromString.Value;
      else
        return defaultValue;
    }

    private static string GetRandomSerialKeyChunk(Random rnd, int length)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < length; ++index)
        stringBuilder.Append("ABCDEFGHJKLMNOPQRSTUVWXYZ0123456789"[rnd.Next("ABCDEFGHJKLMNOPQRSTUVWXYZ0123456789".Length)]);
      return ((object) stringBuilder).ToString();
    }

    public static bool HasValidLength(Vector3 vec)
    {
      return (double) vec.Length() > 9.99999997475243E-07;
    }

    public static bool HasValidLength(Vector3D vec)
    {
      return vec.Length() > 9.99999997475243E-07;
    }

    [Conditional("DEBUG")]
    public static void AssertLengthValid(ref Vector3 vec)
    {
    }

    [Conditional("DEBUG")]
    public static void AssertLengthValid(ref Vector3D vec)
    {
    }

    public static Vector3 Normalize(Vector3 vec)
    {
      return Vector3.Normalize(vec);
    }

    public static Vector3D Normalize(Vector3D vec)
    {
      return Vector3D.Normalize(vec);
    }

    public static void Normalize(ref Vector3 vec, out Vector3 normalized)
    {
      Vector3.Normalize(ref vec, out normalized);
    }

    public static void Normalize(ref Vector3D vec, out Vector3D normalized)
    {
      Vector3D.Normalize(ref vec, out normalized);
    }

    public static void Normalize(ref Matrix m, out Matrix normalized)
    {
      normalized = Matrix.CreateWorld(m.Translation, MyVRageUtils.Normalize(m.Forward), MyVRageUtils.Normalize(m.Up));
    }

    public static void Normalize(ref MatrixD m, out MatrixD normalized)
    {
      normalized = MatrixD.CreateWorld(m.Translation, MyVRageUtils.Normalize(m.Forward), MyVRageUtils.Normalize(m.Up));
    }

    public static bool IsZero(float value, float epsilon = 1E-05f)
    {
      if ((double) value > -(double) epsilon)
        return (double) value < (double) epsilon;
      else
        return false;
    }

    public static bool IsZero(double value, float epsilon = 1E-05f)
    {
      if (value > -(double) epsilon)
        return value < (double) epsilon;
      else
        return false;
    }

    public static bool IsZero(Vector3 value, float epsilon = 1E-05f)
    {
      if (MyVRageUtils.IsZero(value.X, epsilon) && MyVRageUtils.IsZero(value.Y, epsilon))
        return MyVRageUtils.IsZero(value.Z, epsilon);
      else
        return false;
    }

    public static bool IsZero(Vector3D value, float epsilon = 1E-05f)
    {
      if (MyVRageUtils.IsZero(value.X, epsilon) && MyVRageUtils.IsZero(value.Y, epsilon))
        return MyVRageUtils.IsZero(value.Z, epsilon);
      else
        return false;
    }

    public static bool IsZero(Quaternion value, float epsilon = 1E-05f)
    {
      if (MyVRageUtils.IsZero(value.X, epsilon) && MyVRageUtils.IsZero(value.Y, epsilon) && MyVRageUtils.IsZero(value.Z, epsilon))
        return MyVRageUtils.IsZero(value.W, epsilon);
      else
        return false;
    }

    public static bool IsZero(Vector4 value)
    {
      if (MyVRageUtils.IsZero(value.X, 1E-05f) && MyVRageUtils.IsZero(value.Y, 1E-05f) && MyVRageUtils.IsZero(value.Z, 1E-05f))
        return MyVRageUtils.IsZero(value.W, 1E-05f);
      else
        return false;
    }

    public static T GetRandomItem<T>(this T[] list)
    {
      return list[MyVRageUtils.GetRandomInt(list.Length)];
    }

    public static T GetRandomItem<T>(this List<T> list)
    {
      return list[MyVRageUtils.GetRandomInt(list.Count)];
    }

    public static void ShuffleList<T>(this IList<T> list)
    {
      int count = list.Count;
      while (count > 1)
      {
        --count;
        int randomInt = MyVRageUtils.GetRandomInt(count + 1);
        T obj = list[randomInt];
        list[randomInt] = list[count];
        list[count] = obj;
      }
    }

    public static string GetDescriptionAttributeText<T>(T val) where T : struct, IConvertible
    {
      return MyVRageUtils.GetAttributeOfEnumValue<DescriptionAttribute, T>(val).Description;
    }

    public static A GetAttributeOfEnumValue<A, T>(T val) where A : Attribute where T : struct, IConvertible
    {
      return (A) typeof (T).GetMember(val.ToString())[0].GetCustomAttributes(typeof (A), false)[0];
    }

    public static void SerializeValue(XmlWriter writer, Vector3 v)
    {
      writer.WriteValue(v.X.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + v.Y.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + v.Z.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public static void SerializeValue(XmlWriter writer, Vector4 v)
    {
      writer.WriteValue(v.X.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + v.Y.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + v.Z.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + v.W.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public static void DeserializeValue(XmlReader reader, out Vector3 value)
    {
      object obj = (object) reader.Value;
      reader.Read();
      string[] strArray = ((string) obj).Split(' ');
      Vector3 vector3 = new Vector3(Convert.ToSingle(strArray[0], (IFormatProvider) CultureInfo.InvariantCulture), Convert.ToSingle(strArray[1], (IFormatProvider) CultureInfo.InvariantCulture), Convert.ToSingle(strArray[2], (IFormatProvider) CultureInfo.InvariantCulture));
      value = vector3;
    }

    public static void DeserializeValue(XmlReader reader, out Vector4 value)
    {
      object obj = (object) reader.Value;
      reader.Read();
      string[] strArray = ((string) obj).Split(' ');
      Vector4 vector4 = new Vector4(Convert.ToSingle(strArray[0], (IFormatProvider) CultureInfo.InvariantCulture), Convert.ToSingle(strArray[1], (IFormatProvider) CultureInfo.InvariantCulture), Convert.ToSingle(strArray[2], (IFormatProvider) CultureInfo.InvariantCulture), Convert.ToSingle(strArray[3], (IFormatProvider) CultureInfo.InvariantCulture));
      value = vector4;
    }

    public static double NextDouble(double value)
    {
      long num = BitConverter.DoubleToInt64Bits(value);
      if (value > 0.0)
        return BitConverter.Int64BitsToDouble(num + 1L);
      if (value < 0.0)
        return BitConverter.Int64BitsToDouble(num - 1L);
      else
        return -4.94065645841247E-324;
    }

    public static void GenerateQuad(out MyQuadD quad, ref Vector3D position, float width, float height, ref MatrixD matrix)
    {
      Vector3 vector3_1 = (Vector3) (matrix.Left * (double) width);
      Vector3 vector3_2 = (Vector3) (matrix.Up * (double) height);
      quad.Point0 = position + vector3_1 + vector3_2;
      quad.Point1 = position + vector3_1 - vector3_2;
      quad.Point2 = position - vector3_1 - vector3_2;
      quad.Point3 = position - vector3_1 + vector3_2;
    }

    public static void GetBillboardQuadOriented(out MyQuadD quad, ref Vector3D position, float radius, ref Vector3 leftVector, ref Vector3 upVector)
    {
      Vector3D vector3D1 = (Vector3D) (leftVector * radius);
      Vector3D vector3D2 = (Vector3D) (upVector * radius);
      quad.Point0 = position + vector3D1 + vector3D2;
      quad.Point1 = position + vector3D1 - vector3D2;
      quad.Point2 = position - vector3D1 - vector3D2;
      quad.Point3 = position - vector3D1 + vector3D2;
    }

    public static void GetBillboardQuadOriented(out MyQuadD quad, ref Vector3D position, float width, float height, ref Vector3 leftVector, ref Vector3 upVector)
    {
      Vector3D vector3D1 = (Vector3D) (leftVector * width);
      Vector3D vector3D2 = (Vector3D) (upVector * height);
      quad.Point0 = position + vector3D1 + vector3D2;
      quad.Point1 = position + vector3D1 - vector3D2;
      quad.Point2 = position - vector3D1 - vector3D2;
      quad.Point3 = position - vector3D1 + vector3D2;
    }

    [DllImport("kernel32")]
    public static extern bool SetProcessWorkingSetSize(IntPtr handle, int minSize, int maxSize);

    public static void GetClampVelocity(ref Vector3 velocity, float maxSpeed)
    {
      if ((double) velocity.Length() <= (double) maxSpeed)
        return;
      velocity = MyVRageUtils.Normalize(velocity);
      velocity.X *= maxSpeed;
      velocity.Y *= maxSpeed;
      velocity.Z *= maxSpeed;
    }

    public static float GetClampVolume(float volume)
    {
      return MathHelper.Clamp(volume, 0.0f, 2f);
    }

    public static float GetClampPitch(float pitch)
    {
      return MathHelper.Clamp(pitch, -1f, 1f);
    }

    public static string GetFormatedVector2(Vector2 vec, int decimalDigits)
    {
      return "{X: " + MyValueFormatter.GetFormatedDouble((double) vec.X, decimalDigits) + " Y: " + MyValueFormatter.GetFormatedDouble((double) vec.Y, decimalDigits) + "}";
    }

    public static string GetFormatedVector3(Vector3 vec, int decimalDigits)
    {
      return "{X: " + MyValueFormatter.GetFormatedDouble((double) vec.X, decimalDigits) + " Y: " + MyValueFormatter.GetFormatedDouble((double) vec.Y, decimalDigits) + " Z: " + MyValueFormatter.GetFormatedDouble((double) vec.Z, decimalDigits) + "}";
    }

    public static string GetFormatedVector4(Vector4 vec, int decimalDigits)
    {
      return "{X: " + MyValueFormatter.GetFormatedDouble((double) vec.X, decimalDigits) + " Y: " + MyValueFormatter.GetFormatedDouble((double) vec.Y, decimalDigits) + " Z: " + MyValueFormatter.GetFormatedDouble((double) vec.Z, decimalDigits) + " W: " + MyValueFormatter.GetFormatedDouble((double) vec.W, decimalDigits) + "}";
    }

    public static string GetFormatedVector2Int(Vector2I vec)
    {
      return "{X: " + MyValueFormatter.GetFormatedInt(vec.X) + " Y: " + MyValueFormatter.GetFormatedInt(vec.Y) + "}";
    }

    public static string GetFormatedVector3Int(Vector3I vec)
    {
      return "{X: " + MyValueFormatter.GetFormatedInt(vec.X) + " Y: " + MyValueFormatter.GetFormatedInt(vec.Y) + " Z: " + MyValueFormatter.GetFormatedInt(vec.Z) + "}";
    }

    public static string GetFormatedBoundingBox(BoundingBox boundingBox, int decimalDigits)
    {
      return "Min: " + MyVRageUtils.GetFormatedVector3(boundingBox.Min, decimalDigits) + ", Max: " + MyVRageUtils.GetFormatedVector3(boundingBox.Max, decimalDigits);
    }

    public static BoundingBox GetNewBoundingBox(Vector3 position, Vector3 sizeInMetres)
    {
      return new BoundingBox(position, position + sizeInMetres);
    }

    public static string GetFormatedMatrix(Matrix matrix, int decimalDigits)
    {
      return "{Translation.X: " + MyValueFormatter.GetFormatedDouble((double) matrix.Translation.X, decimalDigits) + " Translation.Y: " + MyValueFormatter.GetFormatedDouble((double) matrix.Translation.Y, decimalDigits) + " Translation.Z: " + MyValueFormatter.GetFormatedDouble((double) matrix.Translation.Z, decimalDigits) + " Forward.X: " + MyValueFormatter.GetFormatedDouble((double) matrix.Forward.X, decimalDigits) + " Forward.Y: " + MyValueFormatter.GetFormatedDouble((double) matrix.Forward.Y, decimalDigits) + " Forward.Z: " + MyValueFormatter.GetFormatedDouble((double) matrix.Forward.Z, decimalDigits) + "}";
    }

    public static void RotationMatrixToYawPitchRoll(ref Matrix mx, out float yaw, out float pitch, out float roll)
    {
      float num1 = mx.M32;
      if ((double) num1 > 1.0)
        num1 = 1f;
      else if ((double) num1 < -1.0)
        num1 = -1f;
      pitch = (float) Math.Asin(-(double) num1);
      float num2 = 1.0 / 1000.0;
      if (Math.Cos((double) pitch) > (double) num2)
      {
        roll = (float) Math.Atan2((double) mx.M12, (double) mx.M22);
        yaw = (float) Math.Atan2((double) mx.M31, (double) mx.M33);
      }
      else
      {
        roll = (float) Math.Atan2(-(double) mx.M21, (double) mx.M11);
        yaw = 0.0f;
      }
    }

    public static void BinaryWrite(BinaryWriter bw, ref Vector3 vector)
    {
      bw.Write(vector.X);
      bw.Write(vector.Y);
      bw.Write(vector.Z);
    }

    public static void BinaryWrite(BinaryWriter bw, ref Matrix matrix)
    {
      bw.Write(matrix.M11);
      bw.Write(matrix.M12);
      bw.Write(matrix.M13);
      bw.Write(matrix.M14);
      bw.Write(matrix.M21);
      bw.Write(matrix.M22);
      bw.Write(matrix.M23);
      bw.Write(matrix.M24);
      bw.Write(matrix.M31);
      bw.Write(matrix.M32);
      bw.Write(matrix.M33);
      bw.Write(matrix.M34);
      bw.Write(matrix.M41);
      bw.Write(matrix.M42);
      bw.Write(matrix.M43);
      bw.Write(matrix.M44);
    }

    public static void BinaryRead(BinaryReader br, ref Vector3 vector)
    {
      vector.X = br.ReadSingle();
      vector.Y = br.ReadSingle();
      vector.Z = br.ReadSingle();
    }

    public static void BinaryRead(BinaryReader br, ref Matrix matrix)
    {
      matrix.M11 = br.ReadSingle();
      matrix.M12 = br.ReadSingle();
      matrix.M13 = br.ReadSingle();
      matrix.M14 = br.ReadSingle();
      matrix.M21 = br.ReadSingle();
      matrix.M22 = br.ReadSingle();
      matrix.M23 = br.ReadSingle();
      matrix.M24 = br.ReadSingle();
      matrix.M31 = br.ReadSingle();
      matrix.M32 = br.ReadSingle();
      matrix.M33 = br.ReadSingle();
      matrix.M34 = br.ReadSingle();
      matrix.M41 = br.ReadSingle();
      matrix.M42 = br.ReadSingle();
      matrix.M43 = br.ReadSingle();
      matrix.M44 = br.ReadSingle();
    }

    public static int GetBresenhamSgn(int a)
    {
      return a >= 0 ? 1 : -1;
    }

    public static Vector3 GetVector3Scaled(Vector3 originalVector, float newLength)
    {
      if ((double) newLength == 0.0)
        return Vector3.Zero;
      float num1 = originalVector.Length();
      if ((double) num1 == 0.0)
        return Vector3.Zero;
      float num2 = newLength / num1;
      return new Vector3(originalVector.X * num2, originalVector.Y * num2, originalVector.Z * num2);
    }

    public static Vector3 GetCartesianCoordinatesFromSpherical_Weird(float angleHorizontal, float angleVertical, float radius)
    {
      angleVertical = 1.570796f - angleVertical;
      return new Vector3((float) ((double) radius * Math.Sin((double) angleVertical) * Math.Sin((double) angleHorizontal)), radius * (float) Math.Cos((double) angleVertical), (float) ((double) radius * Math.Sin((double) angleVertical) * Math.Cos((double) angleHorizontal)));
    }

    public static Vector3 GetCartesianCoordinatesFromSpherical(float angleHorizontal, float angleVertical, float radius)
    {
      angleVertical = 1.570796f - angleVertical;
      angleHorizontal = 3.141593f - angleHorizontal;
      return new Vector3((float) ((double) radius * Math.Sin((double) angleVertical) * Math.Sin((double) angleHorizontal)), radius * (float) Math.Cos((double) angleVertical), (float) ((double) radius * Math.Sin((double) angleVertical) * Math.Cos((double) angleHorizontal)));
    }

    public static Vector2 GetSphericalCoordinatesFromCartesian(ref Vector3 vector)
    {
      return new Vector2(-(float) Math.Atan2(-(double) vector.X, -(double) vector.Z), (float) Math.Atan2((double) vector.Y, Math.Sqrt((double) vector.Z * (double) vector.Z + (double) vector.X * (double) vector.X)));
    }

    public static float GetAngleBetweenVectors(Vector3 vectorA, Vector3 vectorB)
    {
      float num = Vector3.Dot(vectorA, vectorB);
      if ((double) num > 1.0 && (double) num <= 1.00010001659393)
        num = 1f;
      if ((double) num < -1.0 && (double) num >= -1.00010001659393)
        num = -1f;
      return (float) Math.Acos((double) num);
    }

    public static float GetAngleBetweenVectorsAndNormalise(Vector3 vectorA, Vector3 vectorB)
    {
      return MyVRageUtils.GetAngleBetweenVectors(Vector3.Normalize(vectorA), Vector3.Normalize(vectorB));
    }

    public static void VectorPlaneRotation(Vector3 xVector, Vector3 yVector, out Vector3 xOut, out Vector3 yOut, float angle)
    {
      Vector3 vector3_1 = xVector * (float) Math.Cos((double) angle) + yVector * (float) Math.Sin((double) angle);
      Vector3 vector3_2 = xVector * (float) Math.Cos((double) angle + Math.PI / 2.0) + yVector * (float) Math.Sin((double) angle + Math.PI / 2.0);
      xOut = vector3_1;
      yOut = vector3_2;
    }

    public static Vector3 GetTransform(Vector3 vec, ref Matrix matrix)
    {
      Vector3 result;
      Vector3.Transform(ref vec, ref matrix, out result);
      return result;
    }

    public static Vector3 GetTransform(ref Vector3 vec, ref Matrix matrix)
    {
      Vector3 result;
      Vector3.Transform(ref vec, ref matrix, out result);
      return result;
    }

    public static Vector3 GetTransformNormal(Vector3 vec, ref Matrix matrix)
    {
      Vector3 result;
      Vector3.TransformNormal(ref vec, ref matrix, out result);
      return result;
    }

    public static Vector3 GetTransformNormalNormalized(Vector3 vec, ref Matrix matrix)
    {
      Vector3 result;
      Vector3.TransformNormal(ref vec, ref matrix, out result);
      return MyVRageUtils.Normalize(result);
    }

    public static Vector3D GetTransformNormalNormalized(Vector3D vec, ref MatrixD matrix)
    {
      Vector3D result;
      Vector3D.TransformNormal(ref vec, ref matrix, out result);
      return MyVRageUtils.Normalize(result);
    }

    public static float GetSmallestDistanceToSphere(ref Vector3 from, ref BoundingSphere sphere)
    {
      return Vector3.Distance(from, sphere.Center) - sphere.Radius;
    }

    public static float GetSmallestDistanceToSphereAlwaysPositive(ref Vector3 from, ref BoundingSphere sphere)
    {
      float num = MyVRageUtils.GetSmallestDistanceToSphere(ref from, ref sphere);
      if ((double) num < 0.0)
        num = 0.0f;
      return num;
    }

    public static float GetLargestDistanceToSphere(ref Vector3 from, ref BoundingSphere sphere)
    {
      return Vector3.Distance(from, sphere.Center) + sphere.Radius;
    }

    public static float GetDistanceBetweenSpheres(ref BoundingSphere sphere1, ref BoundingSphere sphere2)
    {
      return Vector3.Distance(sphere1.Center, sphere2.Center) - (sphere1.Radius + sphere2.Radius);
    }

    public static float GetDistanceBetweenSpheresAbsolute(ref BoundingSphere sphere1, ref BoundingSphere sphere2)
    {
      float num = MyVRageUtils.GetDistanceBetweenSpheres(ref sphere1, ref sphere2);
      if ((double) num < 0.0)
        num = 0.0f;
      return num;
    }

    public static float GetAngleBetweenVectorsForSphereCollision(Vector3 vector1, Vector3 vector2)
    {
      float f = (float) Math.Acos((double) Vector3.Dot(vector1, vector2) / (double) (vector1.Length() * vector2.Length()));
      if (float.IsNaN(f))
        return 0.0f;
      else
        return f;
    }

    public static float GetPointLineDistance(ref Vector3 linePointA, ref Vector3 linePointB, ref Vector3 point)
    {
      Vector3 vector1 = linePointB - linePointA;
      return Vector3.Cross(vector1, point - linePointA).Length() / vector1.Length();
    }

    public static Vector3 GetClosestPointOnLine(ref Vector3 linePointA, ref Vector3 linePointB, ref Vector3 point)
    {
      float dist = 0.0f;
      return MyVRageUtils.GetClosestPointOnLine(ref linePointA, ref linePointB, ref point, out dist);
    }

    public static Vector3 GetClosestPointOnLine(ref Vector3 linePointA, ref Vector3 linePointB, ref Vector3 point, out float dist)
    {
      Vector3 vector2 = point - linePointA;
      Vector3 vector1 = MyVRageUtils.Normalize(linePointB - linePointA);
      float num1 = Vector3.Distance(linePointA, linePointB);
      float num2 = Vector3.Dot(vector1, vector2);
      dist = num2;
      if ((double) num2 <= 0.0)
        return linePointA;
      if ((double) num2 >= (double) num1)
        return linePointB;
      Vector3 vector3 = vector1 * num2;
      return linePointA + vector3;
    }

    public static bool IsBoxIntersectingSphere(ref BoundingBox box, ref BoundingSphere sphere)
    {
      bool result;
      box.Intersects(ref sphere, out result);
      return result;
    }

    public static bool IsBoxIntersectingSphere(BoundingBox box, ref BoundingSphere sphere)
    {
      bool result;
      box.Intersects(ref sphere, out result);
      return result;
    }

    public static bool IsBoxIntersectingBox(ref BoundingBox box0, ref BoundingBox box1)
    {
      bool result;
      box0.Intersects(ref box1, out result);
      return result;
    }

    public static bool IsBoxIntersectingBox(BoundingBox box0, ref BoundingBox box1)
    {
      bool result;
      box0.Intersects(ref box1, out result);
      return result;
    }

    public static float GetClosestDistanceFromPointToAxisAlignedBoundingBox(Vector3 point, BoundingBox axisAlignedBoundingBox)
    {
      float num1 = Math.Abs(axisAlignedBoundingBox.Min.X - point.X);
      float num2 = Math.Abs(axisAlignedBoundingBox.Max.X - point.X);
      float num3 = Math.Abs(axisAlignedBoundingBox.Min.Y - point.Y);
      float num4 = Math.Abs(axisAlignedBoundingBox.Max.Y - point.Y);
      float num5 = Math.Abs(axisAlignedBoundingBox.Min.Z - point.Z);
      float num6 = Math.Abs(axisAlignedBoundingBox.Max.Z - point.Z);
      float num7 = float.MaxValue;
      if ((double) num1 < (double) num7)
        num7 = num1;
      if ((double) num2 < (double) num7)
        num7 = num2;
      if ((double) num3 < (double) num7)
        num7 = num3;
      if ((double) num4 < (double) num7)
        num7 = num4;
      if ((double) num5 < (double) num7)
        num7 = num5;
      if ((double) num6 < (double) num7)
        num7 = num6;
      return num7;
    }

    public static Vector2 GetHalfPixel(int screenSizeX, int screenSizeY)
    {
      return new Vector2(0.5f / (float) screenSizeX, 0.5f / (float) screenSizeY);
    }

    public static T GetNextOrPreviousEnumValue<T>(T currentEnumValue, bool nextElement) where T : struct
    {
      int enumMemberIndex = MyVRageUtils.GetEnumMemberIndex<T>(currentEnumValue);
      Array values = Enum.GetValues(typeof (T));
      int length = values.Length;
      int num = !nextElement ? (enumMemberIndex == 0 ? length - 1 : enumMemberIndex - 1) : (enumMemberIndex == length - 1 ? 0 : enumMemberIndex + 1);
      foreach (T obj in values)
      {
        if (Array.IndexOf(values, (object) obj) == num)
          return obj;
      }
      return currentEnumValue;
    }

    public static int GetEnumMemberIndex<T>(T element) where T : struct
    {
      return Array.IndexOf<T>((T[]) Enum.GetValues(typeof (T)), element);
    }

    public static Vector3 GetRoundedVector3(Vector3 vec, int precisionDigits)
    {
      return new Vector3((float) Math.Round((double) vec.X, precisionDigits), (float) Math.Round((double) vec.Y, precisionDigits), (float) Math.Round((double) vec.Z, precisionDigits));
    }

    public static float GetYFromRGB(Color color)
    {
      return (float) ((double) color.R * 0.29899999499321 + (double) color.G * 0.587000012397766 + (double) color.B * (57.0 / 500.0));
    }

    public static float GetUFromRGB(Color color)
    {
      return (float) (0.435999989509583 * (((double) color.B - (double) MyVRageUtils.GetYFromRGB(color)) / 0.885999977588654));
    }

    public static float GetVFromRGB(Color color)
    {
      return (float) (0.615000009536743 * (((double) color.R - (double) MyVRageUtils.GetYFromRGB(color)) / 0.700999975204468));
    }

    public static Color GetRGBFromYUV(float Y, float U, float V)
    {
      return new Color(Y + V * 1.139837f, (float) ((double) Y - (double) U * 0.032930001616478 - (double) V * 0.580599009990692), Y + U * 2.03211f);
    }

    public static Color SetYtoRGB(Color color, float Y)
    {
      float ufromRgb = MyVRageUtils.GetUFromRGB(color);
      float vfromRgb = MyVRageUtils.GetVFromRGB(color);
      byte a = color.A;
      color = MyVRageUtils.GetRGBFromYUV(Y, ufromRgb, vfromRgb);
      color.A = a;
      return color;
    }

    public static bool IsValid(Vector3 vec)
    {
      if (MyVRageUtils.IsValid(vec.X) && MyVRageUtils.IsValid(vec.Y))
        return MyVRageUtils.IsValid(vec.Z);
      else
        return false;
    }

    public static bool IsValidNormal(Vector3 vec)
    {
      float num = vec.LengthSquared();
      if (MyVRageUtils.IsValid(vec) && (double) num > 0.999000012874603)
        return (double) num < 1.00100004673004;
      else
        return false;
    }

    public static bool IsValid(Vector2 vec)
    {
      if (MyVRageUtils.IsValid(vec.X))
        return MyVRageUtils.IsValid(vec.Y);
      else
        return false;
    }

    public static bool IsValid(float f)
    {
      if (!float.IsNaN(f))
        return !float.IsInfinity(f);
      else
        return false;
    }

    public static bool IsValid(Vector3? vec)
    {
      if (!vec.HasValue)
        return true;
      if (MyVRageUtils.IsValid(vec.Value.X) && MyVRageUtils.IsValid(vec.Value.Y))
        return MyVRageUtils.IsValid(vec.Value.Z);
      else
        return false;
    }

    public static bool IsValid(Matrix matrix)
    {
      if (MyVRageUtils.IsValid(matrix.Up) && MyVRageUtils.IsValid(matrix.Left) && (MyVRageUtils.IsValid(matrix.Forward) && MyVRageUtils.IsValid(matrix.Translation)))
        return matrix != MyVRageUtils.ZeroMatrix;
      else
        return false;
    }

    public static void AssertIsValid(Vector3 vec)
    {
    }

    public static void AssertIsValid(Vector3? vec)
    {
    }

    public static void AssertIsValid(Vector2 vec)
    {
    }

    public static void AssertIsValid(float f)
    {
    }

    public static void AssertIsValid(Matrix matrix)
    {
    }

    public static bool IsEqual(float value1, float value2)
    {
      return MyVRageUtils.IsZero(value1 - value2, 1E-05f);
    }

    public static bool IsEqual(Vector2 value1, Vector2 value2)
    {
      if (MyVRageUtils.IsZero(value1.X - value2.X, 1E-05f))
        return MyVRageUtils.IsZero(value1.Y - value2.Y, 1E-05f);
      else
        return false;
    }

    public static bool IsEqual(Vector3 value1, Vector3 value2)
    {
      if (MyVRageUtils.IsZero(value1.X - value2.X, 1E-05f) && MyVRageUtils.IsZero(value1.Y - value2.Y, 1E-05f))
        return MyVRageUtils.IsZero(value1.Z - value2.Z, 1E-05f);
      else
        return false;
    }

    public static bool IsEqual(Matrix value1, Matrix value2)
    {
      if (MyVRageUtils.IsZero(value1.Left - value2.Left, 1E-05f) && MyVRageUtils.IsZero(value1.Up - value2.Up, 1E-05f) && MyVRageUtils.IsZero(value1.Forward - value2.Forward, 1E-05f))
        return MyVRageUtils.IsZero(value1.Translation - value2.Translation, 1E-05f);
      else
        return false;
    }

    public static float ReadSingleSafe(string text)
    {
      text = text.Replace(',', '.');
      return Convert.ToSingle(text, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    public static T FirstElement<T>(this HashSet<T> set)
    {
      HashSet<T>.Enumerator enumerator = set.GetEnumerator();
      enumerator.MoveNext();
      return enumerator.Current;
    }

    public static bool IsWrongTriangle(Vector3 vertex0, Vector3 vertex1, Vector3 vertex2)
    {
      return (double) (vertex2 - vertex0).LengthSquared() <= 0.0 / 1.0 || (double) (vertex1 - vertex0).LengthSquared() <= 0.0 / 1.0 || (double) (vertex1 - vertex2).LengthSquared() <= 0.0 / 1.0;
    }

    public static Color[] GenerateBoxColors()
    {
      List<Color> list = new List<Color>();
      float amount1 = 0.0f;
      while ((double) amount1 < 1.0)
      {
        float amount2 = 0.0f;
        while ((double) amount2 < 1.0)
        {
          float amount3 = 0.0f;
          while ((double) amount3 < 1.0)
          {
            float x = MathHelper.Lerp(0.5f, 0.5833333f, amount1);
            float y = MathHelper.Lerp(0.4f, 0.9f, amount2);
            float z = MathHelper.Lerp(0.4f, 1f, amount3);
            list.Add(ColorExtensions.HSVtoColor(new Vector3(x, y, z)));
            amount3 += 0.33f;
          }
          amount2 += 0.33f;
        }
        amount1 += 0.2f;
      }
      MyVRageUtils.ShuffleList<Color>((IList<Color>) list);
      return list.ToArray();
    }
  }
}
