﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyBinaryReader
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.IO;
using System.Security;
using System.Text;

namespace VRage.Common.Utils
{
  public class MyBinaryReader : BinaryReader
  {
    private Decoder m_decoder;
    private int m_maxCharsSize;
    private byte[] m_charBytes;
    private char[] m_charBuffer;

    public MyBinaryReader(Stream stream)
      : this(stream, (Encoding) new UTF8Encoding())
    {
    }

    public MyBinaryReader(Stream stream, Encoding encoding)
      : base(stream, encoding)
    {
      this.m_decoder = encoding.GetDecoder();
      this.m_maxCharsSize = encoding.GetMaxCharCount(128);
      if (encoding.GetMaxByteCount(1) >= 16)
        ;
    }

    public new int Read7BitEncodedInt()
    {
      int num1 = 0;
      int num2 = 0;
      while (num2 != 35)
      {
        byte num3 = this.ReadByte();
        num1 |= ((int) num3 & (int) sbyte.MaxValue) << num2;
        num2 += 7;
        if (((int) num3 & 128) == 0)
          return num1;
      }
      return -1;
    }

    [SecuritySafeCritical]
    public string ReadStringIncomplete(out bool isComplete)
    {
      if (this.BaseStream == null)
      {
        isComplete = false;
        return string.Empty;
      }
      else
      {
        int num = 0;
        int capacity = this.Read7BitEncodedInt();
        if (capacity < 0)
        {
          isComplete = false;
          return string.Empty;
        }
        else if (capacity == 0)
        {
          isComplete = true;
          return string.Empty;
        }
        else
        {
          if (this.m_charBytes == null)
            this.m_charBytes = new byte[128];
          if (this.m_charBuffer == null)
            this.m_charBuffer = new char[this.m_maxCharsSize];
          StringBuilder stringBuilder = (StringBuilder) null;
          do
          {
            int byteCount = this.BaseStream.Read(this.m_charBytes, 0, capacity - num > 128 ? 128 : capacity - num);
            if (byteCount == 0)
            {
              isComplete = false;
              if (stringBuilder == null)
                return string.Empty;
              else
                return ((object) stringBuilder).ToString();
            }
            else
            {
              int chars = this.m_decoder.GetChars(this.m_charBytes, 0, byteCount, this.m_charBuffer, 0);
              if (num == 0 && byteCount == capacity)
              {
                isComplete = true;
                return new string(this.m_charBuffer, 0, chars);
              }
              else
              {
                if (stringBuilder == null)
                  stringBuilder = new StringBuilder(capacity);
                stringBuilder.Append(this.m_charBuffer, 0, chars);
                num += byteCount;
              }
            }
          }
          while (num < capacity);
          isComplete = true;
          return ((object) stringBuilder).ToString();
        }
      }
    }
  }
}
