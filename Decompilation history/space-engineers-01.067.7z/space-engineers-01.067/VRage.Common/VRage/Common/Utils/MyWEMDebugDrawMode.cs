﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Utils.MyWEMDebugDrawMode
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;

namespace VRage.Common.Utils
{
  [Flags]
  public enum MyWEMDebugDrawMode
  {
    NONE = 0,
    LINES = 1,
    EDGES = 2,
    FACES = 4,
    VERTICES = 8,
    VERTICES_DETAILED = 16,
    NORMALS = 32,
  }
}
