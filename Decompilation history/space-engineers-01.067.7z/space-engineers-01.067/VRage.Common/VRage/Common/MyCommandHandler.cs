﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyCommandHandler
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VRage.Common
{
  internal class MyCommandHandler
  {
    private Dictionary<string, MyCommand> m_commands;

    public MyCommandHandler()
    {
      this.m_commands = new Dictionary<string, MyCommand>();
    }

    public StringBuilder Handle(string input)
    {
      List<string> args = this.SplitArgs(input);
      if (args.Count <= 0)
        return new StringBuilder("Error: Empty string");
      string input1 = args[0];
      string commandKey = this.GetCommandKey(input1);
      if (commandKey == null)
        return new StringBuilder().AppendFormat("Error: Invalid method syntax '{0}'", (object) input);
      args.RemoveAt(0);
      MyCommand myCommand;
      if (!this.m_commands.TryGetValue(commandKey, out myCommand))
        return new StringBuilder().AppendFormat("Error: Unknown command {0}\n", (object) commandKey);
      string commandMethod = this.GetCommandMethod(input1);
      if (commandMethod == null)
        return new StringBuilder().AppendFormat("Error: Invalid method syntax '{0}'", (object) input);
      if (commandMethod == "")
        return new StringBuilder("Error: Empty Method");
      try
      {
        return new StringBuilder().Append(commandKey).Append(".").Append(commandMethod).Append(": ").Append((object) myCommand.Execute(commandMethod, args));
      }
      catch (MyConsoleInvalidArgumentsException ex)
      {
        return new StringBuilder().AppendFormat("Error: Invalid Argument for method {0}.{1}", (object) commandKey, (object) commandMethod);
      }
      catch (MyConsoleMethodNotFoundException ex)
      {
        return new StringBuilder().AppendFormat("Error: Command {0} does not contain method {1}", (object) commandKey, (object) commandMethod);
      }
    }

    public List<string> SplitArgs(string input)
    {
      return Enumerable.ToList<string>(Enumerable.SelectMany<string[], string>(Enumerable.Select<string, string[]>((IEnumerable<string>) input.Split('"'), (Func<string, int, string[]>) ((element, index) =>
      {
        if (index % 2 != 0)
          return new string[1]
          {
            element
          };
        else
          return element.Split(new char[1]
          {
            ' '
          }, StringSplitOptions.RemoveEmptyEntries);
      })), (Func<string[], IEnumerable<string>>) (element => (IEnumerable<string>) element)));
    }

    public string GetCommandKey(string input)
    {
      if (!input.Contains("."))
        return (string) null;
      else
        return input.Substring(0, input.IndexOf("."));
    }

    public string GetCommandMethod(string input)
    {
      try
      {
        return input.Substring(input.IndexOf(".") + 1);
      }
      catch
      {
        return (string) null;
      }
    }

    public void AddCommand(MyCommand command)
    {
      if (this.m_commands.ContainsKey(command.Prefix()))
        this.m_commands.Remove(command.Prefix());
      this.m_commands.Add(command.Prefix(), command);
    }

    public void RemoveAllCommands()
    {
      this.m_commands.Clear();
    }

    public bool ContainsCommand(string command)
    {
      return this.m_commands.ContainsKey(command);
    }

    public bool TryGetCommand(string commandName, out MyCommand command)
    {
      if (!this.m_commands.ContainsKey(commandName))
      {
        command = (MyCommand) null;
        return false;
      }
      else
      {
        command = this.m_commands[commandName];
        return true;
      }
    }
  }
}
