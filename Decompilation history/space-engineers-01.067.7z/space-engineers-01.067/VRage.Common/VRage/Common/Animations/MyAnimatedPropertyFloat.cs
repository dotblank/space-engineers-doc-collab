﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedPropertyFloat
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Globalization;
using System.Xml;
using VRage.Common.Utils;

namespace VRage.Common.Animations
{
  public class MyAnimatedPropertyFloat : MyAnimatedProperty<float>
  {
    public MyAnimatedPropertyFloat()
    {
    }

    public MyAnimatedPropertyFloat(string name)
      : this(name, (MyAnimatedProperty<float>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedPropertyFloat(string name, MyAnimatedProperty<float>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    protected override void Init()
    {
      this.Interpolator = new MyAnimatedProperty<float>.InterpolatorDelegate(MyFloatInterpolator.Lerp);
      base.Init();
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedPropertyFloat animatedPropertyFloat = new MyAnimatedPropertyFloat(this.Name);
      this.Duplicate((IMyConstProperty) animatedPropertyFloat);
      return (IMyConstProperty) animatedPropertyFloat;
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      writer.WriteValue(((float) value).ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      base.DeserializeValue(reader, out value);
      value = (object) Convert.ToSingle(value, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    protected override bool EqualsValues(object value1, object value2)
    {
      return MyVRageUtils.IsZero((float) value1 - (float) value2, 1E-05f);
    }
  }
}
