﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyVector3Interpolator
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Animations
{
  internal static class MyVector3Interpolator
  {
    public static void Lerp(ref Vector3 val1, ref Vector3 val2, float time, out Vector3 value)
    {
      value.X = val1.X + (val2.X - val1.X) * time;
      value.Y = val1.Y + (val2.Y - val1.Y) * time;
      value.Z = val1.Z + (val2.Z - val1.Z) * time;
    }
  }
}
