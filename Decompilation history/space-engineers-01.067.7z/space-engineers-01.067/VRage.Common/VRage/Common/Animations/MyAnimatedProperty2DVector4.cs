﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedProperty2DVector4
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyAnimatedProperty2DVector4 : MyAnimatedProperty2D<MyAnimatedPropertyVector4, Vector4, float>
  {
    public MyAnimatedProperty2DVector4(string name)
      : this(name, (MyAnimatedProperty<Vector4>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedProperty2DVector4(string name, MyAnimatedProperty<Vector4>.InterpolatorDelegate interpolator)
      : base(name, (MyAnimatedProperty<Vector4>.InterpolatorDelegate) null)
    {
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      MyAnimatedPropertyVector4 animatedPropertyVector4 = new MyAnimatedPropertyVector4(this.Name, this.m_interpolator2);
      animatedPropertyVector4.Deserialize(reader);
      value = (object) animatedPropertyVector4;
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedProperty2DVector4 property2Dvector4 = new MyAnimatedProperty2DVector4(this.Name);
      this.Duplicate((IMyConstProperty) property2Dvector4);
      return (IMyConstProperty) property2Dvector4;
    }

    public override void ApplyVariance(ref Vector4 interpolatedValue, ref float variance, float multiplier, out Vector4 value)
    {
      float randomFloat = MyVRageUtils.GetRandomFloat(1f - variance, 1f + variance);
      value.X = interpolatedValue.X * randomFloat;
      value.Y = interpolatedValue.Y * randomFloat;
      value.Z = interpolatedValue.Z * randomFloat;
      value.W = interpolatedValue.W;
      double num1 = (double) MathHelper.Clamp(value.X, 0.0f, 1f);
      double num2 = (double) MathHelper.Clamp(value.Y, 0.0f, 1f);
      double num3 = (double) MathHelper.Clamp(value.Z, 0.0f, 1f);
    }
  }
}
