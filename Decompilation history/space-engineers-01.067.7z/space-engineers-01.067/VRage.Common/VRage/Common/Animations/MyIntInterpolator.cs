﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyIntInterpolator
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common.Animations
{
  internal static class MyIntInterpolator
  {
    public static void Lerp(ref int val1, ref int val2, float time, out int value)
    {
      value = val1 + (int) ((double) (val2 - val1) * (double) time);
    }

    public static void Switch(ref int val1, ref int val2, float time, out int value)
    {
      value = (double) time < 0.5 ? val1 : val2;
    }
  }
}
