﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyConstPropertyInt
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Globalization;
using System.Xml;

namespace VRage.Common.Animations
{
  public class MyConstPropertyInt : MyConstProperty<int>
  {
    public MyConstPropertyInt()
    {
    }

    public MyConstPropertyInt(string name)
      : base(name)
    {
    }

    public static implicit operator int(MyConstPropertyInt f)
    {
      return f.GetValue<int>();
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      writer.WriteValue(((int) value).ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      base.DeserializeValue(reader, out value);
      value = (object) Convert.ToInt32(value, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    public override IMyConstProperty Duplicate()
    {
      MyConstPropertyInt constPropertyInt = new MyConstPropertyInt(this.Name);
      this.Duplicate((IMyConstProperty) constPropertyInt);
      return (IMyConstProperty) constPropertyInt;
    }
  }
}
