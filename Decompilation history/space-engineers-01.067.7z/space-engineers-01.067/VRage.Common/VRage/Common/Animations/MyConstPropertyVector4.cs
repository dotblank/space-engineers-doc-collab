﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyConstPropertyVector4
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyConstPropertyVector4 : MyConstProperty<Vector4>
  {
    public MyConstPropertyVector4()
    {
    }

    public MyConstPropertyVector4(string name)
      : base(name)
    {
    }

    public static implicit operator Vector4(MyConstPropertyVector4 f)
    {
      return f.GetValue<Vector4>();
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      MyVRageUtils.SerializeValue(writer, (Vector4) value);
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      Vector4 vector4;
      MyVRageUtils.DeserializeValue(reader, out vector4);
      value = (object) vector4;
    }

    public override IMyConstProperty Duplicate()
    {
      MyConstPropertyVector4 constPropertyVector4 = new MyConstPropertyVector4(this.Name);
      this.Duplicate((IMyConstProperty) constPropertyVector4);
      return (IMyConstProperty) constPropertyVector4;
    }
  }
}
