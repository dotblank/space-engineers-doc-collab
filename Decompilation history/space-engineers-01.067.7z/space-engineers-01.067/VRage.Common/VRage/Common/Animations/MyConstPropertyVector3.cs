﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyConstPropertyVector3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyConstPropertyVector3 : MyConstProperty<Vector3>
  {
    public MyConstPropertyVector3()
    {
    }

    public MyConstPropertyVector3(string name)
      : base(name)
    {
    }

    public static implicit operator Vector3(MyConstPropertyVector3 f)
    {
      return f.GetValue<Vector3>();
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      MyVRageUtils.SerializeValue(writer, (Vector3) value);
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      Vector3 vector3;
      MyVRageUtils.DeserializeValue(reader, out vector3);
      value = (object) vector3;
    }

    public override IMyConstProperty Duplicate()
    {
      MyConstPropertyVector3 constPropertyVector3 = new MyConstPropertyVector3(this.Name);
      this.Duplicate((IMyConstProperty) constPropertyVector3);
      return (IMyConstProperty) constPropertyVector3;
    }
  }
}
