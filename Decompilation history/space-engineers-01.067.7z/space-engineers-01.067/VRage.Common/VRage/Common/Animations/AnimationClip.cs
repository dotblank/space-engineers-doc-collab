﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.AnimationClip
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace VRage.Common.Animations
{
  public class AnimationClip
  {
    private List<AnimationClip.Bone> bones = new List<AnimationClip.Bone>();
    public string Name;
    public double Duration;

    public List<AnimationClip.Bone> Bones
    {
      get
      {
        return this.bones;
      }
    }

    public class Keyframe
    {
      public Quaternion Rotation = Quaternion.Identity;
      public double Time;
      public Vector3 Translation;

      public Matrix Transform
      {
        get
        {
          return Matrix.CreateFromQuaternion(this.Rotation) * Matrix.CreateTranslation(this.Translation);
        }
        set
        {
          Matrix matrix = value;
          matrix.Right = Vector3.Normalize(matrix.Right);
          matrix.Up = Vector3.Normalize(matrix.Up);
          matrix.Backward = Vector3.Normalize(matrix.Backward);
          this.Rotation = Quaternion.CreateFromRotationMatrix(matrix);
          this.Translation = matrix.Translation;
        }
      }
    }

    public class Bone
    {
      private string m_name = "";
      private List<AnimationClip.Keyframe> m_keyframes = new List<AnimationClip.Keyframe>();

      public string Name
      {
        get
        {
          return this.m_name;
        }
        set
        {
          this.m_name = value;
        }
      }

      public List<AnimationClip.Keyframe> Keyframes
      {
        get
        {
          return this.m_keyframes;
        }
      }

      public override string ToString()
      {
        return string.Concat(new object[4]
        {
          (object) this.m_name,
          (object) " (",
          (object) this.Keyframes.Count,
          (object) " keys)"
        });
      }
    }
  }
}
