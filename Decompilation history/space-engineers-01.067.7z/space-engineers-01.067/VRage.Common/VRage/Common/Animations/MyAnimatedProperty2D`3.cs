﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedProperty2D`3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Xml;

namespace VRage.Common.Animations
{
  public class MyAnimatedProperty2D<T, V, W> : MyAnimatedProperty<T>, IMyAnimatedProperty2D<T, V, W>, IMyAnimatedProperty2D, IMyAnimatedProperty, IMyConstProperty where T : MyAnimatedProperty<V>, new()
  {
    protected MyAnimatedProperty<V>.InterpolatorDelegate m_interpolator2;

    public MyAnimatedProperty2D()
    {
    }

    public MyAnimatedProperty2D(string name, MyAnimatedProperty<V>.InterpolatorDelegate interpolator)
      : base(name, (MyAnimatedProperty<T>.InterpolatorDelegate) null)
    {
      this.m_interpolator2 = interpolator;
    }

    public X GetInterpolatedValue<X>(float overallTime, float time) where X : V
    {
      T previousValue1;
      float previousTime;
      this.GetPreviousValue(overallTime, out previousValue1, out previousTime);
      T nextValue1;
      float nextTime;
      float difference;
      this.GetNextValue(overallTime, out nextValue1, out nextTime, out difference);
      V previousValue2;
      previousValue1.GetInterpolatedValue<V>(time, out previousValue2);
      V nextValue2;
      nextValue1.GetInterpolatedValue<V>(time, out nextValue2);
      V v;
      previousValue1.Interpolator(ref previousValue2, ref nextValue2, (overallTime - previousTime) * difference, out v);
      return (X) (object) v;
    }

    public void GetInterpolatedKeys(float overallTime, float multiplier, IMyAnimatedProperty interpolatedKeys)
    {
      this.GetInterpolatedKeys(overallTime, default (W), multiplier, interpolatedKeys);
    }

    public void GetInterpolatedKeys(float overallTime, W variance, float multiplier, IMyAnimatedProperty interpolatedKeysOb)
    {
      T previousValue1;
      float previousTime;
      this.GetPreviousValue(overallTime, out previousValue1, out previousTime);
      T nextValue1;
      float nextTime;
      float difference;
      this.GetNextValue(overallTime, out nextValue1, out nextTime, out difference);
      T obj = interpolatedKeysOb as T;
      obj.ClearKeys();
      if (this.m_interpolator2 != null)
        obj.Interpolator = this.m_interpolator2;
      for (int index = 0; index < previousValue1.GetKeysCount(); ++index)
      {
        float time;
        V v;
        previousValue1.GetKey(index, out time, out v);
        V previousValue2;
        previousValue1.GetInterpolatedValue<V>(time, out previousValue2);
        V nextValue2;
        nextValue1.GetInterpolatedValue<V>(time, out nextValue2);
        V interpolatedValue = previousValue2;
        if ((double) nextTime != (double) previousTime)
          obj.Interpolator(ref previousValue2, ref nextValue2, (overallTime - previousTime) * difference, out interpolatedValue);
        this.ApplyVariance(ref interpolatedValue, ref variance, multiplier, out interpolatedValue);
        obj.AddKey<V>(time, interpolatedValue);
      }
    }

    public virtual void ApplyVariance(ref V interpolatedValue, ref W variance, float multiplier, out V value)
    {
      value = default (V);
    }

    public IMyAnimatedProperty CreateEmptyKeys()
    {
      return (IMyAnimatedProperty) Activator.CreateInstance<T>();
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      (value as IMyAnimatedProperty).Serialize(writer);
    }

    public override IMyConstProperty Duplicate()
    {
      return (IMyConstProperty) null;
    }

    protected override void Duplicate(IMyConstProperty targetProp)
    {
      MyAnimatedProperty2D<T, V, W> animatedProperty2D = targetProp as MyAnimatedProperty2D<T, V, W>;
      animatedProperty2D.Interpolator = this.Interpolator;
      animatedProperty2D.m_interpolator2 = this.m_interpolator2;
      animatedProperty2D.ClearKeys();
      foreach (MyAnimatedProperty<T>.ValueHolder val in this.m_keys)
        animatedProperty2D.AddKey(val);
    }
  }
}
