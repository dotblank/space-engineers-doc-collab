﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.IMyAnimatedProperty`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Reflection;

namespace VRage.Common.Animations
{
  [Obfuscation(ApplyToMembers = true, Exclude = true, Feature = "cw symbol renaming")]
  public interface IMyAnimatedProperty<T> : IMyAnimatedProperty, IMyConstProperty
  {
    [Obfuscation(Exclude = true, Feature = "cw symbol renaming")]
    void GetInterpolatedValue<U>(float time, out U value) where U : T;

    [Obfuscation(Exclude = true, Feature = "cw symbol renaming")]
    void AddKey<U>(float time, U val) where U : T;
  }
}
