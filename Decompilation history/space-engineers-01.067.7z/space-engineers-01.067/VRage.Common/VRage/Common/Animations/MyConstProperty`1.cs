﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyConstProperty`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;

namespace VRage.Common.Animations
{
  public class MyConstProperty<T> : IMyConstProperty
  {
    private string m_name;
    private T m_value;

    public string Name
    {
      get
      {
        return this.m_name;
      }
    }

    public MyConstProperty()
    {
      this.Init();
    }

    public MyConstProperty(string name)
      : this()
    {
      this.m_name = name;
    }

    protected virtual void Init()
    {
    }

    public U GetValue<U>() where U : T
    {
      return (U) (object) this.m_value;
    }

    public void SetValue(object val)
    {
      this.SetValue((T) val);
    }

    public void SetValue(T val)
    {
      this.m_value = val;
    }

    public virtual IMyConstProperty Duplicate()
    {
      return (IMyConstProperty) null;
    }

    protected virtual void Duplicate(IMyConstProperty targetProp)
    {
      targetProp.SetValue((object) this.GetValue<T>());
    }

    public virtual void Serialize(XmlWriter writer)
    {
      writer.WriteStartElement(this.GetType().Name);
      writer.WriteAttributeString("name", this.Name);
      this.SerializeValue(writer, (object) this.m_value);
      writer.WriteEndElement();
    }

    public virtual void Deserialize(XmlReader reader)
    {
      this.m_name = reader.GetAttribute("name");
      reader.ReadStartElement();
      object obj;
      this.DeserializeValue(reader, out obj);
      this.m_value = (T) obj;
      reader.ReadEndElement();
    }

    public virtual void SerializeValue(XmlWriter writer, object value)
    {
    }

    public virtual void DeserializeValue(XmlReader reader, out object value)
    {
      value = (object) reader.Value;
      reader.Read();
    }
  }
}
