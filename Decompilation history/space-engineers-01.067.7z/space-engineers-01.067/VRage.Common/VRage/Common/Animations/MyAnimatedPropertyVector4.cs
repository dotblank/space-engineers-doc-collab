﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedPropertyVector4
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Globalization;
using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyAnimatedPropertyVector4 : MyAnimatedProperty<Vector4>
  {
    public MyAnimatedPropertyVector4()
    {
    }

    public MyAnimatedPropertyVector4(string name)
      : this(name, (MyAnimatedProperty<Vector4>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedPropertyVector4(string name, MyAnimatedProperty<Vector4>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    protected override void Init()
    {
      this.Interpolator = new MyAnimatedProperty<Vector4>.InterpolatorDelegate(MyVector4Interpolator.Lerp);
      base.Init();
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedPropertyVector4 animatedPropertyVector4 = new MyAnimatedPropertyVector4(this.Name);
      this.Duplicate((IMyConstProperty) animatedPropertyVector4);
      return (IMyConstProperty) animatedPropertyVector4;
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      Vector4 vector4 = (Vector4) value;
      writer.WriteValue(vector4.X.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + vector4.Y.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + vector4.Z.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + vector4.W.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      Vector4 vector4;
      MyVRageUtils.DeserializeValue(reader, out vector4);
      value = (object) vector4;
    }

    protected override bool EqualsValues(object value1, object value2)
    {
      return MyVRageUtils.IsZero((Vector4) value1 - (Vector4) value2);
    }
  }
}
