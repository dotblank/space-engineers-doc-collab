﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.ModelAnimations
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;

namespace VRage.Common.Animations
{
  public class ModelAnimations
  {
    private List<int> skeleton = new List<int>();
    private List<AnimationClip> clips = new List<AnimationClip>();

    public List<int> Skeleton
    {
      get
      {
        return this.skeleton;
      }
      set
      {
        this.skeleton = value;
      }
    }

    public List<AnimationClip> Clips
    {
      get
      {
        return this.clips;
      }
      set
      {
        this.clips = value;
      }
    }
  }
}
