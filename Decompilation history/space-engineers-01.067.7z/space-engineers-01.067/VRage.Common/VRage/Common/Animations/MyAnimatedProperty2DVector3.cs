﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedProperty2DVector3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyAnimatedProperty2DVector3 : MyAnimatedProperty2D<MyAnimatedPropertyVector3, Vector3, Vector3>
  {
    public MyAnimatedProperty2DVector3(string name)
      : this(name, (MyAnimatedProperty<Vector3>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedProperty2DVector3(string name, MyAnimatedProperty<Vector3>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      MyAnimatedPropertyVector3 animatedPropertyVector3 = new MyAnimatedPropertyVector3(this.Name, this.m_interpolator2);
      animatedPropertyVector3.Deserialize(reader);
      value = (object) animatedPropertyVector3;
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedProperty2DVector3 property2Dvector3 = new MyAnimatedProperty2DVector3(this.Name);
      this.Duplicate((IMyConstProperty) property2Dvector3);
      return (IMyConstProperty) property2Dvector3;
    }

    public override void ApplyVariance(ref Vector3 interpolatedValue, ref Vector3 variance, float multiplier, out Vector3 value)
    {
      if (variance != Vector3.Zero || (double) multiplier != 1.0)
      {
        value.X = MyVRageUtils.GetRandomFloat(interpolatedValue.X - variance.X, interpolatedValue.X + variance.X) * multiplier;
        value.Y = MyVRageUtils.GetRandomFloat(interpolatedValue.Y - variance.Y, interpolatedValue.Y + variance.Y) * multiplier;
        value.Z = MyVRageUtils.GetRandomFloat(interpolatedValue.Z - variance.Z, interpolatedValue.Z + variance.Z) * multiplier;
      }
      value = interpolatedValue;
    }
  }
}
