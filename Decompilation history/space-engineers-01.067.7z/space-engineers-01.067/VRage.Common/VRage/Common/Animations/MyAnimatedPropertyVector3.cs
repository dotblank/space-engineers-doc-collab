﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedPropertyVector3
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Globalization;
using System.Xml;
using VRage.Common.Utils;
using VRageMath;

namespace VRage.Common.Animations
{
  public class MyAnimatedPropertyVector3 : MyAnimatedProperty<Vector3>
  {
    public MyAnimatedPropertyVector3()
    {
    }

    public MyAnimatedPropertyVector3(string name)
      : this(name, (MyAnimatedProperty<Vector3>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedPropertyVector3(string name, MyAnimatedProperty<Vector3>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    protected override void Init()
    {
      this.Interpolator = new MyAnimatedProperty<Vector3>.InterpolatorDelegate(MyVector3Interpolator.Lerp);
      base.Init();
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedPropertyVector3 animatedPropertyVector3 = new MyAnimatedPropertyVector3(this.Name);
      this.Duplicate((IMyConstProperty) animatedPropertyVector3);
      return (IMyConstProperty) animatedPropertyVector3;
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      Vector3 vector3 = (Vector3) value;
      writer.WriteValue(vector3.X.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + vector3.Y.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + vector3.Z.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      Vector3 vector3;
      MyVRageUtils.DeserializeValue(reader, out vector3);
      value = (object) vector3;
    }

    protected override bool EqualsValues(object value1, object value2)
    {
      return MyVRageUtils.IsZero((Vector3) value1 - (Vector3) value2, 1E-05f);
    }
  }
}
