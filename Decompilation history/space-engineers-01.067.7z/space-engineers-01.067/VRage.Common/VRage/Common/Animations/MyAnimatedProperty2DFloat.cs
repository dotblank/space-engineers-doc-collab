﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedProperty2DFloat
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Utils;

namespace VRage.Common.Animations
{
  public class MyAnimatedProperty2DFloat : MyAnimatedProperty2D<MyAnimatedPropertyFloat, float, float>
  {
    public MyAnimatedProperty2DFloat(string name)
      : this(name, (MyAnimatedProperty<float>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedProperty2DFloat(string name, MyAnimatedProperty<float>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      MyAnimatedPropertyFloat animatedPropertyFloat = new MyAnimatedPropertyFloat(this.Name, this.m_interpolator2);
      animatedPropertyFloat.Deserialize(reader);
      value = (object) animatedPropertyFloat;
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedProperty2DFloat animatedProperty2Dfloat = new MyAnimatedProperty2DFloat(this.Name);
      this.Duplicate((IMyConstProperty) animatedProperty2Dfloat);
      return (IMyConstProperty) animatedProperty2Dfloat;
    }

    public override void ApplyVariance(ref float interpolatedValue, ref float variance, float multiplier, out float value)
    {
      if ((double) variance != 0.0 || (double) multiplier != 1.0)
        interpolatedValue = MyVRageUtils.GetRandomFloat(interpolatedValue - variance, interpolatedValue + variance) * multiplier;
      value = interpolatedValue;
    }
  }
}
