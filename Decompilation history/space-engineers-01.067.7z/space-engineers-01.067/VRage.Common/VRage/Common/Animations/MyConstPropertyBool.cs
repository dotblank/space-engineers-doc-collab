﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyConstPropertyBool
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Xml;

namespace VRage.Common.Animations
{
  public class MyConstPropertyBool : MyConstProperty<bool>
  {
    public MyConstPropertyBool()
    {
    }

    public MyConstPropertyBool(string name)
      : base(name)
    {
    }

    public static implicit operator bool(MyConstPropertyBool f)
    {
      return f.GetValue<bool>();
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      writer.WriteValue((bool) value);
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      base.DeserializeValue(reader, out value);
      value = (object) (bool) (Convert.ToBoolean(value) ? 1 : 0);
    }

    public override IMyConstProperty Duplicate()
    {
      MyConstPropertyBool constPropertyBool = new MyConstPropertyBool(this.Name);
      this.Duplicate((IMyConstProperty) constPropertyBool);
      return (IMyConstProperty) constPropertyBool;
    }
  }
}
