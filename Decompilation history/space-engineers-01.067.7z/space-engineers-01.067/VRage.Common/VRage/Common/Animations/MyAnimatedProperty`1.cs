﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Animations.MyAnimatedProperty`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;

namespace VRage.Common.Animations
{
  public class MyAnimatedProperty<T> : IMyAnimatedProperty<T>, IMyAnimatedProperty, IMyConstProperty
  {
    private static MyAnimatedProperty<T>.MyKeysComparer m_keysComparer = new MyAnimatedProperty<T>.MyKeysComparer();
    protected List<MyAnimatedProperty<T>.ValueHolder> m_keys = new List<MyAnimatedProperty<T>.ValueHolder>();
    public MyAnimatedProperty<T>.InterpolatorDelegate Interpolator;
    private string m_name;

    public string Name
    {
      get
      {
        return this.m_name;
      }
    }

    public MyAnimatedProperty()
    {
      this.Init();
    }

    public MyAnimatedProperty(string name, MyAnimatedProperty<T>.InterpolatorDelegate interpolator)
      : this()
    {
      this.m_name = name;
      if (interpolator == null)
        return;
      this.Interpolator = interpolator;
    }

    protected virtual void Init()
    {
    }

    public void SetValue(object val)
    {
    }

    public void SetValue(T val)
    {
    }

    public object GetValue()
    {
      return (object) null;
    }

    public U GetValue<U>()
    {
      return default (U);
    }

    void IMyAnimatedProperty.GetInterpolatedValue(float time, out object value)
    {
      T obj;
      this.GetInterpolatedValue<T>(time, out obj);
      value = (object) obj;
    }

    public void GetInterpolatedValue<U>(float time, out U value) where U : T
    {
      if (this.m_keys.Count == 0)
        value = default (U);
      else if (this.m_keys.Count == 1)
        value = (U) (object) this.m_keys[0].Value;
      else if ((double) time > (double) this.m_keys[this.m_keys.Count - 1].Time)
      {
        value = (U) (object) this.m_keys[this.m_keys.Count - 1].Value;
      }
      else
      {
        T previousValue;
        float previousTime;
        this.GetPreviousValue(time, out previousValue, out previousTime);
        T nextValue;
        float nextTime;
        float difference;
        this.GetNextValue(time, out nextValue, out nextTime, out difference);
        if ((double) nextTime == (double) previousTime)
        {
          value = (U) (object) previousValue;
        }
        else
        {
          T obj;
          this.Interpolator(ref previousValue, ref nextValue, (time - previousTime) * difference, out obj);
          value = (U) (object) obj;
        }
      }
    }

    public void GetPreviousValue(float time, out T previousValue, out float previousTime)
    {
      previousValue = default (T);
      previousTime = 0.0f;
      if (this.m_keys.Count > 0)
      {
        previousTime = this.m_keys[0].Time;
        previousValue = this.m_keys[0].Value;
      }
      for (int index = 1; index < this.m_keys.Count && (double) this.m_keys[index].Time < (double) time; ++index)
      {
        previousTime = this.m_keys[index].Time;
        previousValue = this.m_keys[index].Value;
      }
    }

    public void GetNextValue(float time, out T nextValue, out float nextTime, out float difference)
    {
      nextValue = default (T);
      nextTime = -1f;
      difference = 0.0f;
      for (int index = 0; index < this.m_keys.Count; ++index)
      {
        nextTime = this.m_keys[index].Time;
        nextValue = this.m_keys[index].Value;
        difference = this.m_keys[index].PrecomputedDiff;
        if ((double) nextTime >= (double) time)
          break;
      }
    }

    public void AddKey(MyAnimatedProperty<T>.ValueHolder val)
    {
      this.m_keys.Add(val);
    }

    public void AddKey<U>(float time, U val) where U : T
    {
      this.RemoveKey(time);
      this.m_keys.Add(new MyAnimatedProperty<T>.ValueHolder(time, (T) val, 0.0f));
      this.m_keys.Sort((IComparer<MyAnimatedProperty<T>.ValueHolder>) MyAnimatedProperty<T>.m_keysComparer);
      int index = 0;
      while (index < this.m_keys.Count && (double) this.m_keys[index].Time != (double) time)
        ++index;
      if (index <= 0)
        return;
      this.UpdateDiff(index);
    }

    private void UpdateDiff(int index)
    {
      if (index == 0 || index >= this.m_keys.Count)
        return;
      float time = this.m_keys[index].Time;
      float num = this.m_keys[index - 1].Time;
      this.m_keys[index] = new MyAnimatedProperty<T>.ValueHolder(time, this.m_keys[index].Value, (float) (1.0 / ((double) time - (double) num)));
    }

    void IMyAnimatedProperty.AddKey(float time, object val)
    {
      this.AddKey<T>(time, (T) val);
    }

    public void RemoveKey(float time)
    {
      for (int index = 0; index < this.m_keys.Count; ++index)
      {
        if ((double) this.m_keys[index].Time == (double) time)
        {
          this.RemoveKey(index);
          break;
        }
      }
    }

    private void RemoveKey(int index)
    {
      this.m_keys.RemoveAt(index);
      this.UpdateDiff(index);
    }

    public void ClearKeys()
    {
      this.m_keys.Clear();
    }

    public void GetKey(int index, out float time, out T value)
    {
      time = this.m_keys[index].Time;
      value = this.m_keys[index].Value;
    }

    public int GetKeysCount()
    {
      return this.m_keys.Count;
    }

    public virtual IMyConstProperty Duplicate()
    {
      return (IMyConstProperty) null;
    }

    protected virtual void Duplicate(IMyConstProperty targetProp)
    {
      MyAnimatedProperty<T> animatedProperty = targetProp as MyAnimatedProperty<T>;
      animatedProperty.Interpolator = this.Interpolator;
      animatedProperty.ClearKeys();
      foreach (MyAnimatedProperty<T>.ValueHolder val in this.m_keys)
        animatedProperty.AddKey(val);
    }

    public virtual void Serialize(XmlWriter writer)
    {
      writer.WriteStartElement(this.GetType().Name);
      writer.WriteAttributeString("name", this.Name);
      writer.WriteStartElement("Keys");
      foreach (MyAnimatedProperty<T>.ValueHolder valueHolder in this.m_keys)
      {
        writer.WriteStartElement("Key");
        writer.WriteElementString("Time", valueHolder.Time.ToString((IFormatProvider) CultureInfo.InvariantCulture));
        writer.WriteStartElement("Value");
        this.SerializeValue(writer, (object) valueHolder.Value);
        writer.WriteEndElement();
        writer.WriteEndElement();
      }
      writer.WriteEndElement();
      writer.WriteEndElement();
    }

    public virtual void Deserialize(XmlReader reader)
    {
      this.m_name = reader.GetAttribute("name");
      reader.ReadStartElement();
      this.m_keys.Clear();
      bool isEmptyElement = reader.IsEmptyElement;
      reader.ReadStartElement();
      while (reader.NodeType != XmlNodeType.EndElement)
      {
        reader.ReadStartElement();
        float time = reader.ReadElementContentAsFloat();
        reader.ReadStartElement();
        object obj;
        this.DeserializeValue(reader, out obj);
        reader.ReadEndElement();
        this.AddKey<T>(time, (T) obj);
        reader.ReadEndElement();
      }
      if (!isEmptyElement)
        reader.ReadEndElement();
      reader.ReadEndElement();
    }

    private void RemoveRedundantKeys()
    {
      int index = 0;
      bool flag1 = true;
      while (index < this.m_keys.Count - 1)
      {
        bool flag2 = this.EqualsValues((object) this.m_keys[index].Value, (object) this.m_keys[index + 1].Value);
        if (flag2 && !flag1)
        {
          this.RemoveKey(index);
        }
        else
        {
          flag1 = !flag2;
          ++index;
        }
      }
      if (this.m_keys.Count != 2 || !this.EqualsValues((object) this.m_keys[0].Value, (object) this.m_keys[1].Value))
        return;
      this.RemoveKey(index);
    }

    public virtual void SerializeValue(XmlWriter writer, object value)
    {
    }

    public virtual void DeserializeValue(XmlReader reader, out object value)
    {
      value = (object) reader.Value;
      reader.Read();
    }

    protected virtual bool EqualsValues(object value1, object value2)
    {
      return false;
    }

    public struct ValueHolder
    {
      public T Value;
      public float PrecomputedDiff;
      public float Time;

      public ValueHolder(float time, T value, float diff)
      {
        this.Time = time;
        this.Value = value;
        this.PrecomputedDiff = diff;
      }
    }

    private class MyKeysComparer : IComparer<MyAnimatedProperty<T>.ValueHolder>
    {
      public int Compare(MyAnimatedProperty<T>.ValueHolder x, MyAnimatedProperty<T>.ValueHolder y)
      {
        return x.Time.CompareTo(y.Time);
      }
    }

    public delegate void InterpolatorDelegate(ref T previousValue, ref T nextValue, float time, out T value);
  }
}
