﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MySingleCrypto
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common
{
  public class MySingleCrypto
  {
    private readonly byte[] m_password;

    private MySingleCrypto()
    {
    }

    public MySingleCrypto(byte[] password)
    {
      this.m_password = (byte[]) password.Clone();
    }

    public void Encrypt(byte[] data, int length)
    {
      int index1 = 0;
      for (int index2 = 0; index2 < length; ++index2)
      {
        data[index2] = (byte) ((uint) data[index2] + (uint) this.m_password[index1]);
        index1 = (index1 + 1) % this.m_password.Length;
      }
    }

    public void Decrypt(byte[] data, int length)
    {
      int index1 = 0;
      for (int index2 = 0; index2 < length; ++index2)
      {
        data[index2] = (byte) ((uint) data[index2] - (uint) this.m_password[index1]);
        index1 = (index1 + 1) % this.m_password.Length;
      }
    }
  }
}
