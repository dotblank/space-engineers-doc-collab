﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.IPhysicsMesh
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common
{
  public interface IPhysicsMesh
  {
    void SetAABB(Vector3 min, Vector3 max);

    void AddSectionData(int indexStart, int triCount, string materialName);

    void AddIndex(int index);

    void AddVertex(Vector3 position, Vector3 normal, Vector3 tangent, Vector2 texCoord);

    int GetSectionsCount();

    bool GetSectionData(int idx, ref int indexStart, ref int triCount, ref string matIdx);

    int GetIndicesCount();

    int GetIndex(int idx);

    int GetVerticesCount();

    bool GetVertex(int vertexId, ref Vector3 position, ref Vector3 normal, ref Vector3 tangent, ref Vector2 texCoord);

    void Transform(Matrix m);
  }
}
