﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyConsole
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using System.Text;

namespace VRage.Common
{
  public static class MyConsole
  {
    private static StringBuilder m_displayScreen = new StringBuilder();
    private static MyCommandHandler m_handler = new MyCommandHandler();
    private static LinkedList<string> m_commandHistory = new LinkedList<string>();
    private static LinkedListNode<string> m_position = (LinkedListNode<string>) null;

    public static StringBuilder DisplayScreen
    {
      get
      {
        return MyConsole.m_displayScreen;
      }
    }

    public static void ParseCommand(string command)
    {
      if (MyConsole.m_position == null)
      {
        MyConsole.m_commandHistory.AddLast(command);
      }
      else
      {
        MyConsole.m_commandHistory.AddAfter(MyConsole.m_position, command);
        MyConsole.m_position = MyConsole.m_position.Next;
      }
      MyConsole.m_displayScreen.Append((object) MyConsole.m_handler.Handle(command)).AppendLine();
    }

    public static void PreviousLine()
    {
      if (MyConsole.m_position == null)
      {
        MyConsole.m_position = MyConsole.m_commandHistory.Last;
      }
      else
      {
        if (MyConsole.m_position == MyConsole.m_commandHistory.First)
          return;
        MyConsole.m_position = MyConsole.m_position.Previous;
      }
    }

    public static void NextLine()
    {
      if (MyConsole.m_position == null)
        return;
      MyConsole.m_position = MyConsole.m_position.Next;
    }

    public static string GetLine()
    {
      if (MyConsole.m_position == null)
        return "";
      else
        return MyConsole.m_position.Value;
    }

    public static void Clear()
    {
      MyConsole.m_displayScreen.Clear();
    }

    public static void AddCommand(MyCommand command)
    {
      MyConsole.m_handler.AddCommand(command);
    }

    public static bool TryGetCommand(string commandName, out MyCommand command)
    {
      return MyConsole.m_handler.TryGetCommand(commandName, out command);
    }
  }
}
