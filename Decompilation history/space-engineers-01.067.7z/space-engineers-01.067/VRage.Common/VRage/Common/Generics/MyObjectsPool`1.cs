﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Generics.MyObjectsPool`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRage.Collections;

namespace VRage.Common.Generics
{
  public class MyObjectsPool<T> where T : class, new()
  {
    private Stack<T> m_unused;
    private HashSet<T> m_active;
    private HashSet<T> m_marked;
    private int m_baseCapacity;

    public StackReader<T> Unused
    {
      get
      {
        return new StackReader<T>(this.m_unused);
      }
    }

    public HashSetReader<T> Active
    {
      get
      {
        return new HashSetReader<T>(this.m_active);
      }
    }

    public int ActiveCount
    {
      get
      {
        return this.m_active.Count;
      }
    }

    public int BaseCapacity
    {
      get
      {
        return this.m_baseCapacity;
      }
    }

    public int Capacity
    {
      get
      {
        return this.m_unused.Count + this.m_active.Count;
      }
    }

    private MyObjectsPool()
    {
    }

    public MyObjectsPool(int baseCapacity)
    {
      this.m_baseCapacity = baseCapacity;
      this.m_unused = new Stack<T>(this.m_baseCapacity);
      this.m_active = new HashSet<T>();
      this.m_marked = new HashSet<T>();
      for (int index = 0; index < this.m_baseCapacity; ++index)
        this.m_unused.Push(Activator.CreateInstance<T>());
    }

    public bool AllocateOrCreate(out T item)
    {
      bool flag = this.m_unused.Count == 0;
      item = !flag ? this.m_unused.Pop() : Activator.CreateInstance<T>();
      this.m_active.Add(item);
      return flag;
    }

    public T Allocate(bool nullAllowed = false)
    {
      T obj = default (T);
      if (this.m_unused.Count > 0)
      {
        obj = this.m_unused.Pop();
        this.m_active.Add(obj);
      }
      return obj;
    }

    public void Deallocate(T item)
    {
      this.m_active.Remove(item);
      this.m_unused.Push(item);
    }

    public void MarkForDeallocate(T item)
    {
      this.m_marked.Add(item);
    }

    public void DeallocateAllMarked()
    {
      foreach (T obj in this.m_marked)
        this.Deallocate(obj);
      this.m_marked.Clear();
    }

    public void DeallocateAll()
    {
      foreach (T obj in this.m_active)
        this.m_unused.Push(obj);
      this.m_active.Clear();
      this.m_marked.Clear();
    }

    public void TrimToBaseCapacity()
    {
      while (this.Capacity > this.BaseCapacity && this.m_unused.Count > 0)
        this.m_unused.Pop();
      this.m_unused.TrimExcess();
      this.m_active.TrimExcess();
      this.m_marked.TrimExcess();
    }
  }
}
