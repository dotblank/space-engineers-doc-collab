﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Generics.MyDynamicObjectPool`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;

namespace VRage.Common.Generics
{
  public class MyDynamicObjectPool<T> where T : class
  {
    private Stack<T> m_poolStack;

    public int Count
    {
      get
      {
        return this.m_poolStack.Count;
      }
    }

    public MyDynamicObjectPool(int capacity)
    {
      this.m_poolStack = new Stack<T>(capacity);
      this.Preallocate(capacity);
    }

    private void Preallocate(int count)
    {
      for (int index = 0; index < count; ++index)
        this.m_poolStack.Push(Activator.CreateInstance<T>());
    }

    public T Allocate()
    {
      if (this.m_poolStack.Count == 0)
        this.Preallocate(1);
      return this.m_poolStack.Pop();
    }

    public void Deallocate(T item)
    {
      this.m_poolStack.Push(item);
    }
  }
}
