﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Generics.MyWeightDictionary`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;

namespace VRage.Common.Generics
{
  public class MyWeightDictionary<T>
  {
    private Dictionary<T, float> m_data;
    private float m_sum;

    public int Count
    {
      get
      {
        return this.m_data.Count;
      }
    }

    public MyWeightDictionary(Dictionary<T, float> data)
    {
      this.m_data = data;
      this.m_sum = 0.0f;
      foreach (KeyValuePair<T, float> keyValuePair in data)
        this.m_sum += keyValuePair.Value;
    }

    public float GetSum()
    {
      return this.m_sum;
    }

    public T GetItemByWeightNormalized(float weightNormalized)
    {
      return this.GetItemByWeight(weightNormalized * this.m_sum);
    }

    public T GetItemByWeight(float weight)
    {
      float num = 0.0f;
      T obj = default (T);
      foreach (KeyValuePair<T, float> keyValuePair in this.m_data)
      {
        obj = keyValuePair.Key;
        num += keyValuePair.Value;
        if ((double) num > (double) weight)
          return obj;
      }
      return obj;
    }

    public T GetRandomItem(Random rnd)
    {
      return this.GetItemByWeight((float) rnd.NextDouble() * this.m_sum);
    }
  }
}
