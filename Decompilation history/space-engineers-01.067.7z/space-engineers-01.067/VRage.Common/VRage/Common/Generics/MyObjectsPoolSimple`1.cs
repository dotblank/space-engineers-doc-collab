﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Generics.MyObjectsPoolSimple`1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using SysUtils.Utils;

namespace VRage.Common.Generics
{
  public class MyObjectsPoolSimple<T> where T : class, new()
  {
    private T[] m_items;
    private int m_nextAllocateIndex;

    private MyObjectsPoolSimple()
    {
    }

    public MyObjectsPoolSimple(int capacity)
    {
      MyDebug.AssertRelease(capacity > 0);
      this.ClearAllAllocated();
      this.m_items = new T[capacity];
      for (int index = 0; index < this.m_items.Length; ++index)
        this.m_items[index] = Activator.CreateInstance<T>();
    }

    public T Allocate()
    {
      if (this.m_nextAllocateIndex >= this.m_items.Length)
        return default (T);
      T obj = this.m_items[this.m_nextAllocateIndex];
      ++this.m_nextAllocateIndex;
      return obj;
    }

    public int GetAllocatedCount()
    {
      return this.m_nextAllocateIndex;
    }

    public int GetCapacity()
    {
      return this.m_items.Length;
    }

    public void ClearAllAllocated()
    {
      this.m_nextAllocateIndex = 0;
    }

    public T GetAllocatedItem(int index)
    {
      return this.m_items[index];
    }

    public void Sort(IComparer<T> comparer)
    {
      if (this.m_nextAllocateIndex <= 1)
        return;
      Array.Sort<T>(this.m_items, 0, this.m_nextAllocateIndex, comparer);
    }
  }
}
