﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyRectangle2D
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common
{
  public struct MyRectangle2D
  {
    public Vector2 LeftTop;
    public Vector2 Size;

    public MyRectangle2D(Vector2 leftTop, Vector2 size)
    {
      this.LeftTop = leftTop;
      this.Size = size;
    }
  }
}
