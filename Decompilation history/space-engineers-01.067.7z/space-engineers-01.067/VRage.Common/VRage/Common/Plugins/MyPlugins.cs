﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Plugins.MyPlugins
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using SysUtils.Utils;
using VRage.Collections;
using VRage.Common.Utils;

namespace VRage.Common.Plugins
{
  public class MyPlugins : IDisposable
  {
    private static List<IPlugin> m_plugins = new List<IPlugin>();
    private static Assembly m_gamePluginAssembly;
    private static Assembly m_userPluginAssembly;
    private static MyPlugins m_instance;

    public static bool Loaded
    {
      get
      {
        return MyPlugins.m_instance != null;
      }
    }

    public static ListReader<IPlugin> Plugins
    {
      get
      {
        return (ListReader<IPlugin>) MyPlugins.m_plugins;
      }
    }

    public static Assembly GameAssembly
    {
      get
      {
        return MyPlugins.m_gamePluginAssembly;
      }
    }

    public static Assembly UserAssembly
    {
      get
      {
        return MyPlugins.m_userPluginAssembly;
      }
    }

    private MyPlugins()
    {
    }

    ~MyPlugins()
    {
    }

    public static void RegisterFromArgs(string[] args)
    {
      MyPlugins.m_userPluginAssembly = (Assembly) null;
      if (args == null)
        return;
      string assemblyFile = (string) null;
      if (Enumerable.Contains<string>((IEnumerable<string>) args, "-plugin"))
      {
        int num = Enumerable.ToList<string>((IEnumerable<string>) args).IndexOf("-plugin");
        if (num + 1 < args.Length)
          assemblyFile = args[num + 1];
      }
      if (assemblyFile == null)
        return;
      MyPlugins.m_userPluginAssembly = Assembly.LoadFrom(assemblyFile);
    }

    public static void RegisterGameAssemblyFile(string gameAssemblyFile)
    {
      if (gameAssemblyFile == null)
        return;
      MyPlugins.m_gamePluginAssembly = Assembly.LoadFrom(Path.Combine(MyFileSystem.ExePath, gameAssemblyFile));
    }

    public static void Load()
    {
      if (MyPlugins.m_gamePluginAssembly != (Assembly) null)
        MyPlugins.LoadPlugins(MyPlugins.m_gamePluginAssembly);
      if (MyPlugins.m_userPluginAssembly != (Assembly) null)
        MyPlugins.LoadPlugins(MyPlugins.m_userPluginAssembly);
      MyPlugins.m_instance = new MyPlugins();
    }

    private static void LoadPlugins(Assembly assembly)
    {
      foreach (Type type in Enumerable.Where<Type>((IEnumerable<Type>) assembly.GetTypes(), (Func<Type, bool>) (s => Enumerable.Contains<Type>((IEnumerable<Type>) s.GetInterfaces(), typeof (IPlugin)))))
      {
        try
        {
          MyLog.Default.WriteLine("Creating instance of: " + type.FullName);
          MyPlugins.m_plugins.Add((IPlugin) Activator.CreateInstance(type));
        }
        catch (Exception ex)
        {
          MyLog.Default.WriteLine("Error instantiating plugin class: " + (object) type);
          MyLog.Default.WriteLine(ex);
        }
      }
    }

    public static void Unload()
    {
      foreach (IDisposable disposable in MyPlugins.m_plugins)
        disposable.Dispose();
      MyPlugins.m_plugins.Clear();
      MyPlugins.m_instance.Dispose();
      MyPlugins.m_instance = (MyPlugins) null;
    }

    public void Dispose()
    {
      GC.SuppressFinalize((object) this);
    }
  }
}
