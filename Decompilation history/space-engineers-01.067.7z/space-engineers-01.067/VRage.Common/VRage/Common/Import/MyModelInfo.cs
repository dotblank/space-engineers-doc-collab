﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyModelInfo
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Import
{
  public class MyModelInfo
  {
    public int TrianglesCount;
    public int VerticesCount;
    public Vector3 BoundingBoxSize;

    public MyModelInfo(int triCnt, int VertCnt, Vector3 BBsize)
    {
      this.TrianglesCount = triCnt;
      this.VerticesCount = VertCnt;
      this.BoundingBoxSize = BBsize;
    }
  }
}
