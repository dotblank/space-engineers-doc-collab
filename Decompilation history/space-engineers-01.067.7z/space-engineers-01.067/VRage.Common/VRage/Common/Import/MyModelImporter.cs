﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyModelImporter
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using BulletXNA.BulletCollision;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using VRage.Common.Animations;
using VRage.Common.Utils;
using VRageMath;
using VRageMath.PackedVector;

namespace VRage.Common.Import
{
  public class MyModelImporter
  {
    private static Dictionary<string, MyModelImporter.ITagReader> TagReaders = new Dictionary<string, MyModelImporter.ITagReader>()
    {
      {
        "Vertices",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<HalfVector4[]>(new Func<BinaryReader, HalfVector4[]>(MyModelImporter.ReadArrayOfHalfVector4))
      },
      {
        "Normals",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Byte4[]>(new Func<BinaryReader, Byte4[]>(MyModelImporter.ReadArrayOfByte4))
      },
      {
        "TexCoords0",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<HalfVector2[]>(new Func<BinaryReader, HalfVector2[]>(MyModelImporter.ReadArrayOfHalfVector2))
      },
      {
        "Binormals",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Byte4[]>(new Func<BinaryReader, Byte4[]>(MyModelImporter.ReadArrayOfByte4))
      },
      {
        "Tangents",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Byte4[]>(new Func<BinaryReader, Byte4[]>(MyModelImporter.ReadArrayOfByte4))
      },
      {
        "TexCoords1",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<HalfVector2[]>(new Func<BinaryReader, HalfVector2[]>(MyModelImporter.ReadArrayOfHalfVector2))
      },
      {
        "RescaleToLengthInMeters",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<bool>((Func<BinaryReader, bool>) (x => x.ReadBoolean()))
      },
      {
        "LengthInMeters",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<float>((Func<BinaryReader, float>) (x => x.ReadSingle()))
      },
      {
        "Centered",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<bool>((Func<BinaryReader, bool>) (x => x.ReadBoolean()))
      },
      {
        "UseChannelTextures",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<bool>((Func<BinaryReader, bool>) (x => x.ReadBoolean()))
      },
      {
        "SpecularShininess",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<float>((Func<BinaryReader, float>) (x => x.ReadSingle()))
      },
      {
        "SpecularPower",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<float>((Func<BinaryReader, float>) (x => x.ReadSingle()))
      },
      {
        "BoundingBox",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<BoundingBox>(new Func<BinaryReader, BoundingBox>(MyModelImporter.ReadBoundingBox))
      },
      {
        "BoundingSphere",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<BoundingSphere>(new Func<BinaryReader, BoundingSphere>(MyModelImporter.ReadBoundingSphere))
      },
      {
        "RescaleFactor",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<float>((Func<BinaryReader, float>) (x => x.ReadSingle()))
      },
      {
        "SwapWindingOrder",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<bool>((Func<BinaryReader, bool>) (x => x.ReadBoolean()))
      },
      {
        "Dummies",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Dictionary<string, MyModelDummy>>(new Func<BinaryReader, Dictionary<string, MyModelDummy>>(MyModelImporter.ReadDummies))
      },
      {
        "MeshParts",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<List<MyMeshPartInfo>>(new Func<BinaryReader, int, List<MyMeshPartInfo>>(MyModelImporter.ReadMeshParts))
      },
      {
        "ModelBvh",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<GImpactQuantizedBvh>((Func<BinaryReader, GImpactQuantizedBvh>) (reader =>
        {
          GImpactQuantizedBvh gimpactQuantizedBvh = new GImpactQuantizedBvh();
          gimpactQuantizedBvh.Load(MyModelImporter.ReadArrayOfBytes(reader));
          return gimpactQuantizedBvh;
        }))
      },
      {
        "ModelInfo",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<MyModelInfo>((Func<BinaryReader, MyModelInfo>) (reader => new MyModelInfo(reader.ReadInt32(), reader.ReadInt32(), MyModelImporter.ImportVector3(reader))))
      },
      {
        "BlendIndices",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Vector4I[]>(new Func<BinaryReader, Vector4I[]>(MyModelImporter.ReadArrayOfVector4Int))
      },
      {
        "BlendWeights",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Vector4[]>(new Func<BinaryReader, Vector4[]>(MyModelImporter.ReadArrayOfVector4))
      },
      {
        "Animations",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<ModelAnimations>(new Func<BinaryReader, ModelAnimations>(MyModelImporter.ReadAnimations))
      },
      {
        "Bones",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<MyModelBone[]>(new Func<BinaryReader, MyModelBone[]>(MyModelImporter.ReadBones))
      },
      {
        "BoneMapping",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<Vector3I[]>(new Func<BinaryReader, Vector3I[]>(MyModelImporter.ReadArrayOfVector3Int))
      },
      {
        "HavokCollisionGeometry",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<byte[]>(new Func<BinaryReader, byte[]>(MyModelImporter.ReadArrayOfBytes))
      },
      {
        "PatternScale",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<float>((Func<BinaryReader, float>) (x => x.ReadSingle()))
      },
      {
        "LODs",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<MyLODDescriptor[]>(new Func<BinaryReader, MyLODDescriptor[]>(MyModelImporter.ReadLODs))
      },
      {
        "HavokDestructionGeometry",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<byte[]>(new Func<BinaryReader, byte[]>(MyModelImporter.ReadArrayOfBytes))
      },
      {
        "HavokDestruction",
        (MyModelImporter.ITagReader) new MyModelImporter.TagReader<byte[]>(new Func<BinaryReader, byte[]>(MyModelImporter.ReadArrayOfBytes))
      }
    };
    private Dictionary<string, object> m_retTagData = new Dictionary<string, object>();
    private int m_version;

    public int DataVersion
    {
      get
      {
        return this.m_version;
      }
    }

    public Dictionary<string, object> GetTagData()
    {
      return this.m_retTagData;
    }

    private static HalfVector4 ReadHalfVector4(BinaryReader reader)
    {
      return new HalfVector4()
      {
        PackedValue = reader.ReadUInt64()
      };
    }

    private static HalfVector2 ReadHalfVector2(BinaryReader reader)
    {
      return new HalfVector2()
      {
        PackedValue = reader.ReadUInt32()
      };
    }

    private static Byte4 ReadByte4(BinaryReader reader)
    {
      return new Byte4()
      {
        PackedValue = reader.ReadUInt32()
      };
    }

    private static Vector3 ImportVector3(BinaryReader reader)
    {
      Vector3 vector3;
      vector3.X = reader.ReadSingle();
      vector3.Y = reader.ReadSingle();
      vector3.Z = reader.ReadSingle();
      return vector3;
    }

    private static Vector4 ImportVector4(BinaryReader reader)
    {
      Vector4 vector4;
      vector4.X = reader.ReadSingle();
      vector4.Y = reader.ReadSingle();
      vector4.Z = reader.ReadSingle();
      vector4.W = reader.ReadSingle();
      return vector4;
    }

    private static Quaternion ImportQuaternion(BinaryReader reader)
    {
      Quaternion quaternion;
      quaternion.X = reader.ReadSingle();
      quaternion.Y = reader.ReadSingle();
      quaternion.Z = reader.ReadSingle();
      quaternion.W = reader.ReadSingle();
      return quaternion;
    }

    private static Vector4I ImportVector4Int(BinaryReader reader)
    {
      Vector4I vector4I;
      vector4I.X = reader.ReadInt32();
      vector4I.Y = reader.ReadInt32();
      vector4I.Z = reader.ReadInt32();
      vector4I.W = reader.ReadInt32();
      return vector4I;
    }

    private static Vector3I ImportVector3Int(BinaryReader reader)
    {
      Vector3I vector3I;
      vector3I.X = reader.ReadInt32();
      vector3I.Y = reader.ReadInt32();
      vector3I.Z = reader.ReadInt32();
      return vector3I;
    }

    private static Vector2 ImportVector2(BinaryReader reader)
    {
      Vector2 vector2;
      vector2.X = reader.ReadSingle();
      vector2.Y = reader.ReadSingle();
      return vector2;
    }

    private static HalfVector4[] ReadArrayOfHalfVector4(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      HalfVector4[] halfVector4Array = new HalfVector4[length];
      for (int index = 0; index < length; ++index)
        halfVector4Array[index] = MyModelImporter.ReadHalfVector4(reader);
      return halfVector4Array;
    }

    private static Byte4[] ReadArrayOfByte4(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Byte4[] byte4Array = new Byte4[length];
      for (int index = 0; index < length; ++index)
        byte4Array[index] = MyModelImporter.ReadByte4(reader);
      return byte4Array;
    }

    private static HalfVector2[] ReadArrayOfHalfVector2(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      HalfVector2[] halfVector2Array = new HalfVector2[length];
      for (int index = 0; index < length; ++index)
        halfVector2Array[index] = MyModelImporter.ReadHalfVector2(reader);
      return halfVector2Array;
    }

    private static Vector3[] ReadArrayOfVector3(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Vector3[] vector3Array = new Vector3[length];
      for (int index = 0; index < length; ++index)
        vector3Array[index] = MyModelImporter.ImportVector3(reader);
      return vector3Array;
    }

    private static Vector4[] ReadArrayOfVector4(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Vector4[] vector4Array = new Vector4[length];
      for (int index = 0; index < length; ++index)
        vector4Array[index] = MyModelImporter.ImportVector4(reader);
      return vector4Array;
    }

    private static Vector4I[] ReadArrayOfVector4Int(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Vector4I[] vector4IArray = new Vector4I[length];
      for (int index = 0; index < length; ++index)
        vector4IArray[index] = MyModelImporter.ImportVector4Int(reader);
      return vector4IArray;
    }

    private static Vector3I[] ReadArrayOfVector3Int(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Vector3I[] vector3IArray = new Vector3I[length];
      for (int index = 0; index < length; ++index)
        vector3IArray[index] = MyModelImporter.ImportVector3Int(reader);
      return vector3IArray;
    }

    private static Vector2[] ReadArrayOfVector2(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      Vector2[] vector2Array = new Vector2[length];
      for (int index = 0; index < length; ++index)
        vector2Array[index] = MyModelImporter.ImportVector2(reader);
      return vector2Array;
    }

    private static string[] ReadArrayOfString(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      string[] strArray = new string[length];
      for (int index = 0; index < length; ++index)
        strArray[index] = reader.ReadString();
      return strArray;
    }

    private static BoundingBox ReadBoundingBox(BinaryReader reader)
    {
      BoundingBox boundingBox;
      boundingBox.Min = MyModelImporter.ImportVector3(reader);
      boundingBox.Max = MyModelImporter.ImportVector3(reader);
      return boundingBox;
    }

    private static BoundingSphere ReadBoundingSphere(BinaryReader reader)
    {
      BoundingSphere boundingSphere;
      boundingSphere.Center = MyModelImporter.ImportVector3(reader);
      boundingSphere.Radius = reader.ReadSingle();
      return boundingSphere;
    }

    private static Matrix ReadMatrix(BinaryReader reader)
    {
      Matrix matrix;
      matrix.M11 = reader.ReadSingle();
      matrix.M12 = reader.ReadSingle();
      matrix.M13 = reader.ReadSingle();
      matrix.M14 = reader.ReadSingle();
      matrix.M21 = reader.ReadSingle();
      matrix.M22 = reader.ReadSingle();
      matrix.M23 = reader.ReadSingle();
      matrix.M24 = reader.ReadSingle();
      matrix.M31 = reader.ReadSingle();
      matrix.M32 = reader.ReadSingle();
      matrix.M33 = reader.ReadSingle();
      matrix.M34 = reader.ReadSingle();
      matrix.M41 = reader.ReadSingle();
      matrix.M42 = reader.ReadSingle();
      matrix.M43 = reader.ReadSingle();
      matrix.M44 = reader.ReadSingle();
      return matrix;
    }

    private static List<MyMeshPartInfo> ReadMeshParts(BinaryReader reader, int version)
    {
      List<MyMeshPartInfo> list = new List<MyMeshPartInfo>();
      int num = reader.ReadInt32();
      for (int index = 0; index < num; ++index)
      {
        MyMeshPartInfo myMeshPartInfo = new MyMeshPartInfo();
        myMeshPartInfo.Import(reader, version);
        list.Add(myMeshPartInfo);
      }
      return list;
    }

    private static Dictionary<string, MyModelDummy> ReadDummies(BinaryReader reader)
    {
      Dictionary<string, MyModelDummy> dictionary = new Dictionary<string, MyModelDummy>();
      int num1 = reader.ReadInt32();
      for (int index1 = 0; index1 < num1; ++index1)
      {
        string key1 = reader.ReadString();
        Matrix matrix = MyModelImporter.ReadMatrix(reader);
        MyModelDummy myModelDummy = new MyModelDummy();
        myModelDummy.Matrix = matrix;
        myModelDummy.CustomData = new Dictionary<string, object>();
        int num2 = reader.ReadInt32();
        for (int index2 = 0; index2 < num2; ++index2)
        {
          string key2 = reader.ReadString();
          string str = reader.ReadString();
          myModelDummy.CustomData.Add(key2, (object) str);
        }
        dictionary.Add(key1, myModelDummy);
      }
      return dictionary;
    }

    private static int[] ReadArrayOfInt(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      int[] numArray = new int[length];
      for (int index = 0; index < length; ++index)
        numArray[index] = reader.ReadInt32();
      return numArray;
    }

    private static byte[] ReadArrayOfBytes(BinaryReader reader)
    {
      int count = reader.ReadInt32();
      return reader.ReadBytes(count);
    }

    private static AnimationClip ReadClip(BinaryReader reader)
    {
      AnimationClip animationClip = new AnimationClip();
      animationClip.Name = reader.ReadString();
      animationClip.Duration = reader.ReadDouble();
      int num1 = reader.ReadInt32();
      while (num1-- > 0)
      {
        AnimationClip.Bone bone = new AnimationClip.Bone();
        bone.Name = reader.ReadString();
        int num2 = reader.ReadInt32();
        while (num2-- > 0)
          bone.Keyframes.Add(new AnimationClip.Keyframe()
          {
            Time = reader.ReadDouble(),
            Rotation = MyModelImporter.ImportQuaternion(reader),
            Translation = MyModelImporter.ImportVector3(reader)
          });
        animationClip.Bones.Add(bone);
      }
      return animationClip;
    }

    private static ModelAnimations ReadAnimations(BinaryReader reader)
    {
      int num1 = reader.ReadInt32();
      ModelAnimations modelAnimations = new ModelAnimations();
      while (num1-- > 0)
      {
        AnimationClip animationClip = MyModelImporter.ReadClip(reader);
        modelAnimations.Clips.Add(animationClip);
      }
      int num2 = reader.ReadInt32();
      while (num2-- > 0)
      {
        int num3 = reader.ReadInt32();
        modelAnimations.Skeleton.Add(num3);
      }
      return modelAnimations;
    }

    private static MyModelBone[] ReadBones(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      MyModelBone[] myModelBoneArray = new MyModelBone[length];
      int index = 0;
      while (length-- > 0)
      {
        MyModelBone myModelBone = new MyModelBone();
        myModelBoneArray[index] = myModelBone;
        myModelBone.Name = reader.ReadString();
        myModelBone.Index = index++;
        myModelBone.Parent = reader.ReadInt32();
        myModelBone.Transform = MyModelImporter.ReadMatrix(reader);
      }
      return myModelBoneArray;
    }

    private static MyLODDescriptor[] ReadLODs(BinaryReader reader)
    {
      int length = reader.ReadInt32();
      MyLODDescriptor[] myLodDescriptorArray = new MyLODDescriptor[length];
      int num = 0;
      while (length-- > 0)
      {
        MyLODDescriptor myLodDescriptor = new MyLODDescriptor();
        myLodDescriptorArray[num++] = myLodDescriptor;
        myLodDescriptor.Read(reader);
      }
      return myLodDescriptorArray;
    }

    public void ImportData(string assetFileName, string[] tags = null)
    {
      this.Clear();
      using (Stream input = MyFileSystem.OpenRead(Path.IsPathRooted(assetFileName) ? assetFileName : Path.Combine(MyFileSystem.ContentPath, assetFileName)))
      {
        using (BinaryReader reader = new BinaryReader(input))
          this.LoadTagData(reader, tags);
      }
    }

    public void Clear()
    {
      this.m_retTagData.Clear();
      this.m_version = 0;
    }

    private bool LoadTagData(BinaryReader reader, string[] tags)
    {
      string key1 = reader.ReadString();
      string[] strArray = MyModelImporter.ReadArrayOfString(reader);
      this.m_retTagData.Add(key1, (object) strArray);
      string oldValue = "Version:";
      if (strArray.Length > 0 && strArray[0].Contains(oldValue))
        this.m_version = Convert.ToInt32(strArray[0].Replace(oldValue, ""));
      if (this.m_version >= 1066002)
      {
        Dictionary<string, int> dictionary = this.ReadIndexDictionary(reader);
        if (tags == null)
          tags = Enumerable.ToArray<string>((IEnumerable<string>) dictionary.Keys);
        foreach (string key2 in tags)
        {
          if (dictionary.ContainsKey(key2))
          {
            int num = dictionary[key2];
            reader.BaseStream.Seek((long) num, SeekOrigin.Begin);
            reader.ReadString();
            this.m_retTagData.Add(key2, MyModelImporter.TagReaders[key2].Read(reader, this.m_version));
          }
        }
      }
      else
        this.LoadOldVersion(reader);
      return true;
    }

    private Dictionary<string, int> ReadIndexDictionary(BinaryReader reader)
    {
      Dictionary<string, int> dictionary = new Dictionary<string, int>();
      int num1 = reader.ReadInt32();
      for (int index = 0; index < num1; ++index)
      {
        string key = reader.ReadString();
        int num2 = reader.ReadInt32();
        dictionary.Add(key, num2);
      }
      return dictionary;
    }

    private void LoadOldVersion(BinaryReader reader)
    {
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadDummies(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfHalfVector4(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfByte4(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfHalfVector2(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfByte4(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfByte4(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfHalfVector2(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) (bool) (reader.ReadBoolean() ? 1 : 0));
      this.m_retTagData.Add(reader.ReadString(), (object) reader.ReadSingle());
      this.m_retTagData.Add(reader.ReadString(), (object) reader.ReadSingle());
      this.m_retTagData.Add(reader.ReadString(), (object) (bool) (reader.ReadBoolean() ? 1 : 0));
      this.m_retTagData.Add(reader.ReadString(), (object) (bool) (reader.ReadBoolean() ? 1 : 0));
      this.m_retTagData.Add(reader.ReadString(), (object) reader.ReadSingle());
      this.m_retTagData.Add(reader.ReadString(), (object) reader.ReadSingle());
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadBoundingBox(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadBoundingSphere(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) (bool) (reader.ReadBoolean() ? 1 : 0));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadMeshParts(reader, this.m_version));
      string key = reader.ReadString();
      GImpactQuantizedBvh gimpactQuantizedBvh = new GImpactQuantizedBvh();
      gimpactQuantizedBvh.Load(MyModelImporter.ReadArrayOfBytes(reader));
      this.m_retTagData.Add(key, (object) gimpactQuantizedBvh);
      this.m_retTagData.Add(reader.ReadString(), (object) new MyModelInfo(reader.ReadInt32(), reader.ReadInt32(), MyModelImporter.ImportVector3(reader)));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfVector4Int(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfVector4(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadAnimations(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadBones(reader));
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfVector3Int(reader));
      if (reader.BaseStream.Position < reader.BaseStream.Length)
        this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfBytes(reader));
      if (reader.BaseStream.Position < reader.BaseStream.Length)
        this.m_retTagData.Add(reader.ReadString(), (object) reader.ReadSingle());
      if (reader.BaseStream.Position < reader.BaseStream.Length)
        this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadLODs(reader));
      if (reader.BaseStream.Position < reader.BaseStream.Length)
        this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfBytes(reader));
      if (reader.BaseStream.Position >= reader.BaseStream.Length)
        return;
      this.m_retTagData.Add(reader.ReadString(), (object) MyModelImporter.ReadArrayOfBytes(reader));
    }

    private interface ITagReader
    {
      object Read(BinaryReader reader, int version);
    }

    private struct TagReader<T> : MyModelImporter.ITagReader
    {
      private Func<BinaryReader, int, T> m_tagReader;

      public TagReader(Func<BinaryReader, T> tagReader)
      {
        this.m_tagReader = (Func<BinaryReader, int, T>) ((x, y) => tagReader(x));
      }

      public TagReader(Func<BinaryReader, int, T> tagReader)
      {
        this.m_tagReader = tagReader;
      }

      private T ReadTag(BinaryReader reader, int version)
      {
        return this.m_tagReader(reader, version);
      }

      public object Read(BinaryReader reader, int version)
      {
        return (object) this.ReadTag(reader, version);
      }
    }
  }
}
