﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.PositionPacker
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;
using VRageMath.PackedVector;

namespace VRage.Common.Import
{
  public static class PositionPacker
  {
    public static HalfVector4 PackPosition(ref Vector3 position)
    {
      float w = Math.Min((float) Math.Floor((double) Math.Max(Math.Max(Math.Abs(position.X), Math.Abs(position.Y)), Math.Abs(position.Z))), 2048f);
      float num;
      if ((double) w > 0.0)
        num = 1f / w;
      else
        w = num = 1f;
      return new HalfVector4(num * position.X, num * position.Y, num * position.Z, w);
    }

    public static Vector3 UnpackPosition(ref HalfVector4 position)
    {
      Vector4 vector4 = position.ToVector4();
      return vector4.W * new Vector3(vector4.X, vector4.Y, vector4.Z);
    }
  }
}
