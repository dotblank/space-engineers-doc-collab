﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyLODDescriptor
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using System.IO;

namespace VRage.Common.Import
{
  public class MyLODDescriptor
  {
    public float Distance;
    public string Model;
    public string RenderQuality;
    public List<int> RenderQualityList;

    public bool Write(BinaryWriter writer)
    {
      writer.Write(this.Distance);
      writer.Write(this.Model != null ? this.Model : "");
      writer.Write(this.RenderQuality != null ? this.RenderQuality : "");
      return true;
    }

    public bool Read(BinaryReader reader)
    {
      this.Distance = reader.ReadSingle();
      this.Model = reader.ReadString();
      if (string.IsNullOrEmpty(this.Model))
        this.Model = (string) null;
      this.RenderQuality = reader.ReadString();
      if (string.IsNullOrEmpty(this.RenderQuality))
        this.RenderQuality = (string) null;
      return true;
    }
  }
}
