﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyMaterialDescriptor
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using System.IO;
using VRageMath;

namespace VRage.Common.Import
{
  public class MyMaterialDescriptor
  {
    public Vector3 DiffuseColor = Vector3.One;
    public Vector3 ExtraData = Vector3.Zero;
    public Dictionary<string, string> Textures = new Dictionary<string, string>();
    public string Technique = "MESH";
    public string GlassCW = "";
    public string GlassCCW = "";
    public bool GlassSmoothNormals = true;
    public float SpecularPower;

    public string MaterialName { get; private set; }

    public float SpecularIntensity
    {
      get
      {
        return this.ExtraData.X;
      }
      set
      {
        this.ExtraData.X = value;
      }
    }

    public MyMaterialDescriptor(string materialName)
    {
      this.MaterialName = materialName;
    }

    public MyMaterialDescriptor()
    {
    }

    public bool Write(BinaryWriter writer)
    {
      writer.Write(this.MaterialName != null ? this.MaterialName : "");
      writer.Write(this.Textures.Count);
      foreach (KeyValuePair<string, string> keyValuePair in this.Textures)
      {
        writer.Write(keyValuePair.Key);
        writer.Write(keyValuePair.Value == null ? "" : keyValuePair.Value);
      }
      writer.Write(this.SpecularPower);
      writer.Write(this.DiffuseColor.X);
      writer.Write(this.DiffuseColor.Y);
      writer.Write(this.DiffuseColor.Z);
      writer.Write(this.ExtraData.X);
      writer.Write(this.ExtraData.Y);
      writer.Write(this.ExtraData.Z);
      writer.Write(this.Technique);
      if (this.Technique == "GLASS")
      {
        writer.Write(this.GlassCW);
        writer.Write(this.GlassCCW);
        writer.Write(this.GlassSmoothNormals);
      }
      return true;
    }

    public bool Read(BinaryReader reader, int version)
    {
      this.Textures.Clear();
      this.MaterialName = reader.ReadString();
      if (string.IsNullOrEmpty(this.MaterialName))
        this.MaterialName = (string) null;
      if (version < 1052002)
      {
        string str1 = reader.ReadString();
        if (!string.IsNullOrEmpty(str1))
          this.Textures.Add("DiffuseTexture", str1);
        string str2 = reader.ReadString();
        if (!string.IsNullOrEmpty(str2))
          this.Textures.Add("NormalTexture", str2);
      }
      else
      {
        int num = reader.ReadInt32();
        for (int index = 0; index < num; ++index)
          this.Textures.Add(reader.ReadString(), reader.ReadString());
      }
      this.SpecularPower = reader.ReadSingle();
      this.DiffuseColor.X = reader.ReadSingle();
      this.DiffuseColor.Y = reader.ReadSingle();
      this.DiffuseColor.Z = reader.ReadSingle();
      this.ExtraData.X = reader.ReadSingle();
      this.ExtraData.Y = reader.ReadSingle();
      this.ExtraData.Z = reader.ReadSingle();
      this.Technique = version >= 1052001 ? reader.ReadString() : ((object) (MyMeshDrawTechnique) reader.ReadInt32()).ToString();
      if (this.Technique == "GLASS")
      {
        if (version >= 1043001)
        {
          this.GlassCW = reader.ReadString();
          this.GlassCCW = reader.ReadString();
          this.GlassSmoothNormals = reader.ReadBoolean();
        }
        else
        {
          double num1 = (double) reader.ReadSingle();
          double num2 = (double) reader.ReadSingle();
          double num3 = (double) reader.ReadSingle();
          double num4 = (double) reader.ReadSingle();
          this.GlassCW = "GlassCW";
          this.GlassCCW = "GlassCCW";
          this.GlassSmoothNormals = false;
        }
      }
      return true;
    }
  }
}
