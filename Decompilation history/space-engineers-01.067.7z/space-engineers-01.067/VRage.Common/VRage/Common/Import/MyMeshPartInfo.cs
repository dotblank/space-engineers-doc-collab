﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyMeshPartInfo
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.IO;

namespace VRage.Common.Import
{
  public class MyMeshPartInfo
  {
    public List<int> m_indices = new List<int>();
    public int m_MaterialHash;
    public MyMaterialDescriptor m_MaterialDesc;
    public MyMeshDrawTechnique Technique;

    public bool Export(BinaryWriter writer)
    {
      writer.Write(this.m_MaterialHash);
      writer.Write(this.m_indices.Count);
      foreach (int num in this.m_indices)
        writer.Write(num);
      bool flag = true;
      if (this.m_MaterialDesc != null)
      {
        writer.Write(true);
        flag = this.m_MaterialDesc.Write(writer);
      }
      else
        writer.Write(false);
      return flag;
    }

    public bool Import(BinaryReader reader, int version)
    {
      this.m_MaterialHash = reader.ReadInt32();
      if (version < 1052001)
        reader.ReadInt32();
      int num = reader.ReadInt32();
      for (int index = 0; index < num; ++index)
        this.m_indices.Add(reader.ReadInt32());
      bool flag1 = reader.ReadBoolean();
      bool flag2 = true;
      if (flag1)
      {
        this.m_MaterialDesc = new MyMaterialDescriptor();
        flag2 = this.m_MaterialDesc.Read(reader, version) & Enum.TryParse<MyMeshDrawTechnique>(this.m_MaterialDesc.Technique, out this.Technique);
      }
      else
        this.m_MaterialDesc = (MyMaterialDescriptor) null;
      return flag2;
    }
  }
}
