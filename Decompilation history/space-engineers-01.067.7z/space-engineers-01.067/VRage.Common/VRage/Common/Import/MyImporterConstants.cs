﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyImporterConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRage.Common.Import
{
  public static class MyImporterConstants
  {
    public const string TAG_DEBUG = "Debug";
    public const string TAG_VERTICES = "Vertices";
    public const string TAG_NORMALS = "Normals";
    public const string TAG_INDICES = "Indices";
    public const string TAG_TEXCOORDS0 = "TexCoords0";
    public const string TAG_BINORMALS = "Binormals";
    public const string TAG_TANGENTS = "Tangents";
    public const string TAG_TEXCOORDS1 = "TexCoords1";
    public const string TAG_RESCALE_TO_LENGTH_IN_METERS = "RescaleToLengthInMeters";
    public const string TAG_LENGTH_IN_METERS = "LengthInMeters";
    public const string TAG_CENTERED = "Centered";
    public const string TAG_USE_CHANNEL_TEXTURES = "UseChannelTextures";
    public const string TAG_SPECULAR_SHININESS = "SpecularShininess";
    public const string TAG_SPECULAR_POWER = "SpecularPower";
    public const string TAG_BOUNDING_BOX = "BoundingBox";
    public const string TAG_BOUNDING_SPHERE = "BoundingSphere";
    public const string TAG_RESCALE_FACTOR = "RescaleFactor";
    public const string TAG_SWAP_WINDING_ORDER = "SwapWindingOrder";
    public const string TAG_DUMMIES = "Dummies";
    public const string TAG_MESH_PARTS = "MeshParts";
    public const string TAG_MODEL_BVH = "ModelBvh";
    public const string TAG_MODEL_INFO = "ModelInfo";
    public const string TAG_BLENDINDICES = "BlendIndices";
    public const string TAG_BLENDWEIGHTS = "BlendWeights";
    public const string TAG_ANIMATIONS = "Animations";
    public const string TAG_BONES = "Bones";
    public const string TAG_BONE_MAPPING = "BoneMapping";
    public const string TAG_HAVOK_COLLISION_GEOMETRY = "HavokCollisionGeometry";
    public const string TAG_PATTERN_SCALE = "PatternScale";
    public const string TAG_LODS = "LODs";
    public const string TAG_HAVOK_DESTRUCTION_GEOMETRY = "HavokDestructionGeometry";
    public const string TAG_HAVOK_DESTRUCTION = "HavokDestruction";
  }
}
