﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.MyModelBone
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRage.Common.Import
{
  public sealed class MyModelBone
  {
    public int Index;
    public string Name;
    public int Parent;
    public Matrix Transform;

    public override string ToString()
    {
      return string.Concat(new object[4]
      {
        (object) this.Name,
        (object) " (",
        (object) this.Index,
        (object) ")"
      });
    }
  }
}
