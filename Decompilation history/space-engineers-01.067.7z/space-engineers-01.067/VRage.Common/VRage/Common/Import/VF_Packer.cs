﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.Import.VF_Packer
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;
using VRageMath.PackedVector;

namespace VRage.Common.Import
{
  public class VF_Packer
  {
    public static short PackAmbientAndAlpha(float ambient, byte alpha)
    {
      short num1 = (short) ((double) ambient * 8191.0);
      int num2 = (int) num1 < 0 ? -1 : 1;
      return (short) ((int) num1 + (int) (short) (num2 * ((int) alpha * 8192)));
    }

    public static float UnpackAmbient(float packed)
    {
      return (float) ((double) packed % 8192.0 / 8191.0);
    }

    public static float UnpackAmbient(short packed)
    {
      return (float) ((double) packed % 8192.0 / 8191.0);
    }

    public static byte UnpackAlpha(short packed)
    {
      return (byte) Math.Abs((int) packed / 8192);
    }

    public static byte UnpackAlpha(float packed)
    {
      return (byte) Math.Abs(packed / 8192f);
    }

    public static uint PackNormal(ref Vector3 normal)
    {
      Vector3 vector3 = normal;
      vector3.X = (float) (0.5 * ((double) vector3.X + 1.0));
      vector3.Y = (float) (0.5 * ((double) vector3.Y + 1.0));
      uint num1 = (uint) (ushort) ((double) vector3.X * (double) short.MaxValue);
      uint num2 = (uint) (ushort) ((double) vector3.Y * (double) short.MaxValue);
      ushort num3 = (double) vector3.Z > 0.0 ? (ushort) 1 : (ushort) 0;
      return num1 | (uint) (ushort) ((uint) num3 << 15) | num2 << 16;
    }

    public static uint PackTangentSign(ref Vector4 tangent)
    {
      Vector4 vector4 = tangent;
      vector4.X = (float) (0.5 * ((double) vector4.X + 1.0));
      vector4.Y = (float) (0.5 * ((double) vector4.Y + 1.0));
      uint num1 = (uint) (ushort) ((double) vector4.X * (double) short.MaxValue);
      uint num2 = (uint) (ushort) ((double) vector4.Y * (double) short.MaxValue);
      ushort num3 = (double) vector4.Z > 0.0 ? (ushort) 1 : (ushort) 0;
      return num1 | (uint) (ushort) ((uint) num3 << 15) | (num2 | (uint) (ushort) (((double) vector4.W > 0.0 ? 1 : 0) << 15)) << 16;
    }

    public static Vector4 UnpackTangentSign(ref Byte4 packedTangent)
    {
      Vector4 vector4 = packedTangent.ToVector4();
      float num1 = (double) vector4.Y > 127.5 ? 1f : -1f;
      float w = (double) vector4.W > 127.5 ? 1f : -1f;
      if ((double) num1 > 0.0)
        vector4.Y -= 128f;
      if ((double) w > 0.0)
        vector4.W -= 128f;
      float num2 = vector4.X + 256f * vector4.Y;
      float num3 = vector4.Z + 256f * vector4.W;
      float num4 = num2 / (float) short.MaxValue;
      float num5 = num3 / (float) short.MaxValue;
      float x = (float) (2.0 * (double) num4 - 1.0);
      float y = (float) (2.0 * (double) num5 - 1.0);
      float num6 = Math.Max(0.0f, (float) (1.0 - (double) x * (double) x - (double) y * (double) y));
      float z = num1 * (float) Math.Sqrt((double) num6);
      return new Vector4(x, y, z, w);
    }

    public static Byte4 PackNormalB4(ref Vector3 normal)
    {
      uint num = VF_Packer.PackNormal(ref normal);
      return new Byte4()
      {
        PackedValue = num
      };
    }

    public static Byte4 PackTangentSignB4(ref Vector4 tangentW)
    {
      uint num = VF_Packer.PackTangentSign(ref tangentW);
      return new Byte4()
      {
        PackedValue = num
      };
    }

    public static Vector3 UnpackNormal(ref uint packedNormal)
    {
      return VF_Packer.UnpackNormal(ref new Byte4()
      {
        PackedValue = packedNormal
      });
    }

    public static Vector3 UnpackNormal(uint packedNormal)
    {
      return VF_Packer.UnpackNormal(ref new Byte4()
      {
        PackedValue = packedNormal
      });
    }

    public static Vector3 UnpackNormal(ref Byte4 packedNormal)
    {
      Vector4 vector4 = packedNormal.ToVector4();
      float num1 = (double) vector4.Y > 127.5 ? 1f : -1f;
      if ((double) num1 > 0.0)
        vector4.Y -= 128f;
      float num2 = vector4.X + 256f * vector4.Y;
      float num3 = vector4.Z + 256f * vector4.W;
      float num4 = num2 / (float) short.MaxValue;
      float num5 = num3 / (float) short.MaxValue;
      float x = (float) (2.0 * (double) num4 - 1.0);
      float y = (float) (2.0 * (double) num5 - 1.0);
      float num6 = Math.Max(0.0f, (float) (1.0 - (double) x * (double) x - (double) y * (double) y));
      float z = num1 * (float) Math.Sqrt((double) num6);
      return new Vector3(x, y, z);
    }

    public static HalfVector4 PackPosition(Vector3 position)
    {
      Vector3 position1 = position;
      return PositionPacker.PackPosition(ref position1);
    }

    public static HalfVector4 PackPosition(ref Vector3 position)
    {
      return PositionPacker.PackPosition(ref position);
    }

    public static Vector3 UnpackPosition(ref HalfVector4 position)
    {
      return PositionPacker.UnpackPosition(ref position);
    }

    public static Vector3 UnpackPosition(HalfVector4 position)
    {
      return PositionPacker.UnpackPosition(ref position);
    }

    public static Vector3 RepackModelPosition(ref Vector3 position)
    {
      HalfVector4 position1 = VF_Packer.PackPosition(ref position);
      return VF_Packer.UnpackPosition(ref position1);
    }
  }
}
