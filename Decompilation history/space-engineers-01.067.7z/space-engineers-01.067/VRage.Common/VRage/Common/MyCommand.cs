﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyCommand
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VRage.Common
{
  public abstract class MyCommand
  {
    protected Dictionary<string, MyCommand.MyCommandAction> m_methods;

    public List<string> Methods
    {
      get
      {
        return Enumerable.ToList<string>((IEnumerable<string>) this.m_methods.Keys);
      }
    }

    public MyCommand()
    {
      this.m_methods = new Dictionary<string, MyCommand.MyCommandAction>();
    }

    public abstract string Prefix();

    public StringBuilder Execute(string method, List<string> args)
    {
      MyCommand.MyCommandAction myCommandAction;
      if (!this.m_methods.TryGetValue(method, out myCommandAction))
        throw new MyConsoleMethodNotFoundException();
      try
      {
        MyCommand.MyCommandArgs commandArgs = myCommandAction.Parser(args);
        return myCommandAction.CallAction(commandArgs);
      }
      catch
      {
        throw new MyConsoleInvalidArgumentsException();
      }
    }

    public StringBuilder GetHint(string method)
    {
      MyCommand.MyCommandAction myCommandAction;
      if (this.m_methods.TryGetValue(method, out myCommandAction))
        return myCommandAction.AutocompleteHint;
      else
        return (StringBuilder) null;
    }

    protected delegate MyCommand.MyCommandArgs ParserDelegate(List<string> args);

    protected delegate StringBuilder ActionDelegate(MyCommand.MyCommandArgs commandArgs);

    protected class MyCommandAction
    {
      public StringBuilder AutocompleteHint = new StringBuilder("");
      public MyCommand.ParserDelegate Parser;
      public MyCommand.ActionDelegate CallAction;
    }

    protected abstract class MyCommandArgs
    {
    }
  }
}
