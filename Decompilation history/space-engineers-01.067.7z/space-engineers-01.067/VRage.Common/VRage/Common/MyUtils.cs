﻿// Decompiled with JetBrains decompiler
// Type: VRage.Common.MyUtils
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using VRage.Common.Utils;
using VRageMath;
using VRageRender;

namespace VRage.Common
{
  public static class MyUtils
  {
    public static readonly Matrix ZeroMatrix = new Matrix(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);

    [DllImport("kernel32")]
    public static extern bool SetProcessWorkingSetSize(IntPtr handle, int minSize, int maxSize);

    public static StringBuilder GetFormatedVector3(this StringBuilder sb, string before, Vector3 value, string after = "")
    {
      sb.Clear();
      sb.Append(before);
      sb.Append("{");
      StringBuilderExtensions.ConcatFormat<float>(sb, "{0: #,000} ", value.X, (NumberFormatInfo) null);
      StringBuilderExtensions.ConcatFormat<float>(sb, "{0: #,000} ", value.Y, (NumberFormatInfo) null);
      StringBuilderExtensions.ConcatFormat<float>(sb, "{0: #,000} ", value.Z, (NumberFormatInfo) null);
      sb.Append("}");
      sb.Append(after);
      return sb;
    }

    public static StringBuilder GetFormatedVector3(this StringBuilder sb, string before, Vector3D value, string after = "")
    {
      sb.Clear();
      sb.Append(before);
      sb.Append("{");
      StringBuilderExtensions.ConcatFormat<double>(sb, "{0: #,000} ", value.X, (NumberFormatInfo) null);
      StringBuilderExtensions.ConcatFormat<double>(sb, "{0: #,000} ", value.Y, (NumberFormatInfo) null);
      StringBuilderExtensions.ConcatFormat<double>(sb, "{0: #,000} ", value.Z, (NumberFormatInfo) null);
      sb.Append("}");
      sb.Append(after);
      return sb;
    }

    public static float GetAngleBetweenVectors(Vector3 vectorA, Vector3 vectorB)
    {
      float num = Vector3.Dot(vectorA, vectorB);
      if ((double) num > 1.0 && (double) num <= 1.00010001659393)
        num = 1f;
      if ((double) num < -1.0 && (double) num >= -1.00010001659393)
        num = -1f;
      return (float) Math.Acos((double) num);
    }

    public static void VectorPlaneRotation(Vector3 xVector, Vector3 yVector, out Vector3 xOut, out Vector3 yOut, float angle)
    {
      Vector3 vector3_1 = xVector * (float) Math.Cos((double) angle) + yVector * (float) Math.Sin((double) angle);
      Vector3 vector3_2 = xVector * (float) Math.Cos((double) angle + Math.PI / 2.0) + yVector * (float) Math.Sin((double) angle + Math.PI / 2.0);
      xOut = vector3_1;
      yOut = vector3_2;
    }

    public static void VectorPlaneRotation(Vector3D xVector, Vector3D yVector, out Vector3D xOut, out Vector3D yOut, float angle)
    {
      Vector3D vector3D1 = xVector * Math.Cos((double) angle) + yVector * Math.Sin((double) angle);
      Vector3D vector3D2 = xVector * Math.Cos((double) angle + Math.PI / 2.0) + yVector * Math.Sin((double) angle + Math.PI / 2.0);
      xOut = vector3D1;
      yOut = vector3D2;
    }

    public static Vector3 LinePlaneIntersection(Vector3 planePoint, Vector3 planeNormal, Vector3 lineStart, Vector3 lineDir)
    {
      float num1 = Vector3.Dot(planePoint - lineStart, planeNormal);
      float num2 = Vector3.Dot(lineDir, planeNormal);
      return lineStart + lineDir * (num1 / num2);
    }

    public static Vector3D LinePlaneIntersection(Vector3D planePoint, Vector3 planeNormal, Vector3D lineStart, Vector3 lineDir)
    {
      double num1 = Vector3D.Dot(planePoint - lineStart, planeNormal);
      float num2 = Vector3.Dot(lineDir, planeNormal);
      return lineStart + (Vector3D) lineDir * (num1 / (double) num2);
    }

    public static Vector3 GetTransformNormalNormalized(Vector3 vec, ref Matrix matrix)
    {
      Vector3 result;
      Vector3.TransformNormal(ref vec, ref matrix, out result);
      return MyVRageUtils.Normalize(result);
    }

    public static float GetSmallestDistanceToSphere(ref Vector3 from, ref BoundingSphere sphere)
    {
      return Vector3.Distance(from, sphere.Center) - sphere.Radius;
    }

    public static double GetSmallestDistanceToSphere(ref Vector3D from, ref BoundingSphereD sphere)
    {
      return Vector3D.Distance(from, sphere.Center) - sphere.Radius;
    }

    public static float GetSmallestDistanceToSphereAlwaysPositive(ref Vector3 from, ref BoundingSphere sphere)
    {
      float num = MyUtils.GetSmallestDistanceToSphere(ref from, ref sphere);
      if ((double) num < 0.0)
        num = 0.0f;
      return num;
    }

    public static double GetSmallestDistanceToSphereAlwaysPositive(ref Vector3D from, ref BoundingSphereD sphere)
    {
      double num = MyUtils.GetSmallestDistanceToSphere(ref from, ref sphere);
      if (num < 0.0)
        num = 0.0;
      return num;
    }

    public static float GetLargestDistanceToSphere(ref Vector3 from, ref BoundingSphere sphere)
    {
      return Vector3.Distance(from, sphere.Center) + sphere.Radius;
    }

    public static double GetLargestDistanceToSphere(ref Vector3D from, ref BoundingSphereD sphere)
    {
      return Vector3D.Distance(from, sphere.Center) + sphere.Radius;
    }

    public static bool GetInsidePolygonForSphereCollision(ref Vector3D point, ref MyTriangle_Vertexes triangle)
    {
      return (double) (0.0f + MyUtils.GetAngleBetweenVectorsForSphereCollision((Vector3) (triangle.Vertex0 - point), (Vector3) (triangle.Vertex1 - point)) + MyUtils.GetAngleBetweenVectorsForSphereCollision((Vector3) (triangle.Vertex1 - point), (Vector3) (triangle.Vertex2 - point)) + MyUtils.GetAngleBetweenVectorsForSphereCollision((Vector3) (triangle.Vertex2 - point), (Vector3) (triangle.Vertex0 - point))) >= 6.22035415919481;
    }

    public static float GetAngleBetweenVectorsForSphereCollision(Vector3 vector1, Vector3 vector2)
    {
      float f = (float) Math.Acos((double) Vector3.Dot(vector1, vector2) / (double) (vector1.Length() * vector2.Length()));
      if (float.IsNaN(f))
        return 0.0f;
      else
        return f;
    }

    public static Vector3? GetEdgeSphereCollision(ref Vector3D sphereCenter, float sphereRadius, ref MyTriangle_Vertexes triangle)
    {
      Vector3 closestPointOnLine1 = MyUtils.GetClosestPointOnLine(ref triangle.Vertex0, ref triangle.Vertex1, ref sphereCenter);
      if ((double) Vector3.Distance(closestPointOnLine1, (Vector3) sphereCenter) < (double) sphereRadius)
        return new Vector3?(closestPointOnLine1);
      Vector3 closestPointOnLine2 = MyUtils.GetClosestPointOnLine(ref triangle.Vertex1, ref triangle.Vertex2, ref sphereCenter);
      if ((double) Vector3.Distance(closestPointOnLine2, (Vector3) sphereCenter) < (double) sphereRadius)
        return new Vector3?(closestPointOnLine2);
      Vector3 closestPointOnLine3 = MyUtils.GetClosestPointOnLine(ref triangle.Vertex2, ref triangle.Vertex0, ref sphereCenter);
      if ((double) Vector3.Distance(closestPointOnLine3, (Vector3) sphereCenter) < (double) sphereRadius)
        return new Vector3?(closestPointOnLine3);
      else
        return new Vector3?();
    }

    public static Vector3 GetClosestPointOnLine(ref Vector3 linePointA, ref Vector3 linePointB, ref Vector3D point)
    {
      float dist = 0.0f;
      return MyUtils.GetClosestPointOnLine(ref linePointA, ref linePointB, ref point, out dist);
    }

    public static Vector3D GetClosestPointOnLine(ref Vector3D linePointA, ref Vector3D linePointB, ref Vector3D point)
    {
      double dist = 0.0;
      return MyUtils.GetClosestPointOnLine(ref linePointA, ref linePointB, ref point, out dist);
    }

    public static Vector3 GetClosestPointOnLine(ref Vector3 linePointA, ref Vector3 linePointB, ref Vector3D point, out float dist)
    {
      Vector3 vector2 = (Vector3) (point - linePointA);
      Vector3 vector1 = MyVRageUtils.Normalize(linePointB - linePointA);
      float num1 = Vector3.Distance(linePointA, linePointB);
      float num2 = Vector3.Dot(vector1, vector2);
      dist = num2;
      if ((double) num2 <= 0.0)
        return linePointA;
      if ((double) num2 >= (double) num1)
        return linePointB;
      Vector3 vector3 = vector1 * num2;
      return linePointA + vector3;
    }

    public static Vector3D GetClosestPointOnLine(ref Vector3D linePointA, ref Vector3D linePointB, ref Vector3D point, out double dist)
    {
      Vector3D vector2 = point - linePointA;
      Vector3D vector1 = MyVRageUtils.Normalize(linePointB - linePointA);
      double num1 = Vector3D.Distance(linePointA, linePointB);
      double num2 = Vector3D.Dot(vector1, vector2);
      dist = num2;
      if (num2 <= 0.0)
        return linePointA;
      if (num2 >= num1)
        return linePointB;
      Vector3D vector3D = vector1 * num2;
      return linePointA + vector3D;
    }

    public static Vector3 GetNormalVectorFromTriangle(ref MyTriangle_Vertexes inputTriangle)
    {
      return Vector3.Normalize(Vector3.Cross(inputTriangle.Vertex2 - inputTriangle.Vertex0, inputTriangle.Vertex1 - inputTriangle.Vertex0));
    }

    public static BoundingSphere GetBoundingSphereFromBoundingBox(ref BoundingBox box)
    {
      BoundingSphere boundingSphere;
      boundingSphere.Center = (box.Max + box.Min) / 2f;
      boundingSphere.Radius = Vector3.Distance(boundingSphere.Center, box.Max);
      return boundingSphere;
    }

    public static BoundingSphereD GetBoundingSphereFromBoundingBox(ref BoundingBoxD box)
    {
      BoundingSphereD boundingSphereD;
      boundingSphereD.Center = (box.Max + box.Min) / 2.0;
      boundingSphereD.Radius = Vector3D.Distance(boundingSphereD.Center, box.Max);
      return boundingSphereD;
    }

    public static bool IsLineIntersectingBoundingBox(ref Line line, ref BoundingBox boundingBox)
    {
      Ray ray = new Ray(line.From, line.Direction);
      float? nullable = boundingBox.Intersects(ray);
      return nullable.HasValue && (double) nullable.Value <= (double) line.Length;
    }

    public static float? GetLineBoundingBoxIntersection(ref Line line, ref BoundingBox boundingBox)
    {
      Ray ray = new Ray(line.From, line.Direction);
      float? nullable = boundingBox.Intersects(ray);
      if (!nullable.HasValue)
        return new float?();
      if ((double) nullable.Value <= (double) line.Length)
        return new float?(nullable.Value);
      else
        return new float?();
    }

    public static bool IsLineIntersectingBoundingSphere(ref Line line, ref BoundingSphereD boundingSphere)
    {
      LineD line1 = new LineD((Vector3D) line.From, (Vector3D) line.To);
      return MyUtils.IsLineIntersectingBoundingSphere(ref line1, ref boundingSphere);
    }

    public static bool IsLineIntersectingBoundingSphere(ref LineD line, ref BoundingSphereD boundingSphere)
    {
      RayD ray = new RayD(line.From, line.Direction);
      double? nullable = boundingSphere.Intersects(ray);
      return nullable.HasValue && nullable.Value <= line.Length;
    }

    public static float? GetLineTriangleIntersection(ref Line line, ref MyTriangle_Vertexes triangle)
    {
      Vector3 result1;
      Vector3.Subtract(ref triangle.Vertex1, ref triangle.Vertex0, out result1);
      Vector3 result2;
      Vector3.Subtract(ref triangle.Vertex2, ref triangle.Vertex0, out result2);
      Vector3 result3;
      Vector3.Cross(ref line.Direction, ref result2, out result3);
      float result4;
      Vector3.Dot(ref result1, ref result3, out result4);
      if ((double) result4 > -1.40129846432482E-45 && (double) result4 < 1.40129846432482E-45)
        return new float?();
      float num1 = 1f / result4;
      Vector3 result5;
      Vector3.Subtract(ref line.From, ref triangle.Vertex0, out result5);
      float result6;
      Vector3.Dot(ref result5, ref result3, out result6);
      float num2 = result6 * num1;
      if ((double) num2 < 0.0 || (double) num2 > 1.0)
        return new float?();
      Vector3 result7;
      Vector3.Cross(ref result5, ref result1, out result7);
      float result8;
      Vector3.Dot(ref line.Direction, ref result7, out result8);
      float num3 = result8 * num1;
      if ((double) num3 < 0.0 || (double) num2 + (double) num3 > 1.0)
        return new float?();
      float result9;
      Vector3.Dot(ref result2, ref result7, out result9);
      float num4 = result9 * num1;
      if ((double) num4 < 0.0)
        return new float?();
      if ((double) num4 > (double) line.Length)
        return new float?();
      else
        return new float?(num4);
    }

    public static void Swap<T>(ref T lhs, ref T rhs)
    {
      T obj = lhs;
      lhs = rhs;
      rhs = obj;
    }

    public static bool IsValid(float f)
    {
      if (!float.IsNaN(f))
        return !float.IsInfinity(f);
      else
        return false;
    }

    public static bool IsValid(double f)
    {
      if (!double.IsNaN(f))
        return !double.IsInfinity(f);
      else
        return false;
    }

    public static bool IsValid(Vector3 vec)
    {
      if (MyUtils.IsValid(vec.X) && MyUtils.IsValid(vec.Y))
        return MyUtils.IsValid(vec.Z);
      else
        return false;
    }

    public static bool IsValid(Vector3D vec)
    {
      if (MyUtils.IsValid(vec.X) && MyUtils.IsValid(vec.Y))
        return MyUtils.IsValid(vec.Z);
      else
        return false;
    }

    public static bool IsValid(Vector3? vec)
    {
      if (!vec.HasValue)
        return true;
      if (MyUtils.IsValid(vec.Value.X) && MyUtils.IsValid(vec.Value.Y))
        return MyUtils.IsValid(vec.Value.Z);
      else
        return false;
    }

    public static bool IsValid(Matrix matrix)
    {
      if (MyUtils.IsValid(matrix.Up) && MyUtils.IsValid(matrix.Left) && (MyUtils.IsValid(matrix.Forward) && MyUtils.IsValid(matrix.Translation)))
        return matrix != Matrix.Zero;
      else
        return false;
    }

    public static bool IsValid(MatrixD matrix)
    {
      if (MyUtils.IsValid(matrix.Up) && MyUtils.IsValid(matrix.Left) && (MyUtils.IsValid(matrix.Forward) && MyUtils.IsValid(matrix.Translation)))
        return matrix != MatrixD.Zero;
      else
        return false;
    }

    public static void AssertIsValid(Vector3 vec)
    {
    }

    public static void AssertIsValid(Vector3? vec)
    {
    }

    public static void AssertIsValid(float f)
    {
    }

    public static void AssertIsValid(double d)
    {
    }

    public static void AssertIsValid(Matrix matrix)
    {
    }

    public static void AssertIsValid(Vector3D v)
    {
    }

    public static void AssertIsValid(MatrixD matrix)
    {
    }

    public static T FirstElement<T>(this HashSet<T> set)
    {
      HashSet<T>.Enumerator enumerator = set.GetEnumerator();
      enumerator.MoveNext();
      return enumerator.Current;
    }

    public static MySpherePlaneIntersectionEnum GetSpherePlaneIntersection(ref BoundingSphereD sphere, ref PlaneD plane, out double distanceFromPlaneToSphere)
    {
      double num = plane.D;
      distanceFromPlaneToSphere = plane.Normal.X * sphere.Center.X + plane.Normal.Y * sphere.Center.Y + plane.Normal.Z * sphere.Center.Z + num;
      if (Math.Abs(distanceFromPlaneToSphere) < sphere.Radius)
        return MySpherePlaneIntersectionEnum.INTERSECTS;
      return distanceFromPlaneToSphere >= sphere.Radius ? MySpherePlaneIntersectionEnum.FRONT : MySpherePlaneIntersectionEnum.BEHIND;
    }

    public static Vector3? GetSphereTriangleIntersection(ref BoundingSphereD sphere, ref PlaneD trianglePlane, ref MyTriangle_Vertexes triangle)
    {
      double distanceFromPlaneToSphere;
      if (MyUtils.GetSpherePlaneIntersection(ref sphere, ref trianglePlane, out distanceFromPlaneToSphere) == MySpherePlaneIntersectionEnum.INTERSECTS)
      {
        Vector3D vector3D = trianglePlane.Normal * distanceFromPlaneToSphere;
        Vector3D point;
        point.X = sphere.Center.X - vector3D.X;
        point.Y = sphere.Center.Y - vector3D.Y;
        point.Z = sphere.Center.Z - vector3D.Z;
        if (MyUtils.GetInsidePolygonForSphereCollision(ref point, ref triangle))
          return new Vector3?((Vector3) point);
        Vector3? edgeSphereCollision = MyUtils.GetEdgeSphereCollision(ref sphere.Center, (float) sphere.Radius / 1f, ref triangle);
        if (edgeSphereCollision.HasValue)
          return new Vector3?(edgeSphereCollision.Value);
      }
      return new Vector3?();
    }
  }
}
