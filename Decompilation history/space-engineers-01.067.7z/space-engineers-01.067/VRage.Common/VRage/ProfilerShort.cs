﻿// Decompiled with JetBrains decompiler
// Type: VRage.ProfilerShort
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VRage
{
  public static class ProfilerShort
  {
    public static bool Autocommit
    {
      get
      {
        return false;
      }
      set
      {
      }
    }

    [Conditional("RENDER_PROFILING")]
    public static void Begin(string blockName = null, float customValue = 0.0f, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void BeginNextBlock(string blockName = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void End(float customValue = 0.0f, MyTimeSpan? customTime = null, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void CustomValue(string name, float value, MyTimeSpan? customTime, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void End(float customValue, float customTimeMs, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void CustomValue(string name, float value, float customTimeMs, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public static void Commit()
    {
    }
  }
}
