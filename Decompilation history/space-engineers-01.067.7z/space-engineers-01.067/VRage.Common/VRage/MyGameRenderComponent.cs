﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyGameRenderComponent
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageRender;

namespace VRage
{
  public class MyGameRenderComponent : IDisposable
  {
    public MyRenderThread RenderThread { get; private set; }

    public void Start(MyGameTimer timer, InitHandler windowInitializer, MyRenderDeviceSettings? settingsToTry, MyRenderQualityEnum renderQuality)
    {
      this.RenderThread = MyRenderThread.Start(timer, windowInitializer, settingsToTry, renderQuality);
    }

    public void Stop()
    {
      this.RenderThread.Exit();
      this.RenderThread = (MyRenderThread) null;
    }

    public void StartSync(MyGameTimer timer, IMyRenderWindow window, MyRenderDeviceSettings? settings, MyRenderQualityEnum renderQuality)
    {
      this.RenderThread = MyRenderThread.StartSync(timer, window, settings, renderQuality);
    }

    public void Dispose()
    {
      if (this.RenderThread != null)
        this.Stop();
      MyRenderProxy.DisposeDevice();
    }
  }
}
