﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyRenderWindow
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using VRageMath;
using VRageRender;

namespace VRage
{
  public class MyRenderWindow : IMyRenderWindow, IMyBufferedInputSource
  {
    private FastResourceLock m_bufferedCharsLock = new FastResourceLock();
    private List<char> m_bufferedChars = new List<char>();
    public Control Control;
    public Form TopLevelForm;
    private Vector2 m_mousePosition;

    public bool DrawEnabled
    {
      get
      {
        return true;
      }
    }

    public IntPtr Handle
    {
      get
      {
        return this.Control.Handle;
      }
    }

    Vector2 IMyBufferedInputSource.MousePosition
    {
      get
      {
        return this.m_mousePosition;
      }
    }

    Vector2 IMyBufferedInputSource.MouseAreaSize
    {
      get
      {
        return new Vector2((float) this.Control.ClientSize.Width, (float) this.Control.ClientSize.Height);
      }
    }

    public void BeforeDraw()
    {
    }

    public void OnModeChanged(MyWindowModeEnum mode, int width, int height)
    {
    }

    void IMyBufferedInputSource.SwapBufferedTextInput(ref List<char> swappedBuffer)
    {
      swappedBuffer.Clear();
      using (FastResourceLockExtensions.AcquireExclusiveUsing(this.m_bufferedCharsLock))
      {
        List<char> list = swappedBuffer;
        swappedBuffer = this.m_bufferedChars;
        this.m_bufferedChars = list;
      }
    }
  }
}
