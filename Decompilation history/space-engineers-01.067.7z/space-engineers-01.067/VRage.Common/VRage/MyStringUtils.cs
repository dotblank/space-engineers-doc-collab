﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyStringUtils
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using SysUtils.Utils;
using VRageMath;

namespace VRage
{
  public class MyStringUtils
  {
    public const string C_CRLF = "\r\n";

    public static bool SearchStringInArray(string[] strings, string lookFor)
    {
      foreach (string str in strings)
      {
        if (str.Equals(lookFor))
          return true;
      }
      return false;
    }

    public static string AlignIntToRight(int value, int charsCount, char ch)
    {
      string str = value.ToString();
      int length = str.Length;
      if (length > charsCount)
        return str;
      else
        return new string(ch, charsCount - length) + str;
    }

    public static string DownloadStringSynchronously(string url, int timeoutInMilliseconds, string userAgent, Encoding fileEncoding)
    {
      MyLog.Default.WriteLine("DownloadStringSynchronously - START");
      MyLog.Default.IncreaseIndent();
      MyLog.Default.WriteLine("Url: " + url);
      MyLog.Default.WriteLine("TimeoutInMilliseconds: " + (object) timeoutInMilliseconds);
      string str = (string) null;
      int num = 3;
      while (num-- > 0)
      {
        try
        {
          HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
          httpWebRequest.UserAgent = userAgent;
          httpWebRequest.Timeout = timeoutInMilliseconds;
          httpWebRequest.Proxy = (IWebProxy) null;
          WebResponse webResponse = (WebResponse) null;
          try
          {
            webResponse = httpWebRequest.GetResponse();
            Stream stream = (Stream) null;
            try
            {
              stream = webResponse.GetResponseStream();
              StreamReader streamReader = (StreamReader) null;
              try
              {
                streamReader = new StreamReader(stream, fileEncoding);
                str = streamReader.ReadToEnd();
              }
              catch (Exception ex)
              {
                str = (string) null;
                MyLog.Default.WriteLine(ex);
              }
              finally
              {
                if (streamReader != null)
                  streamReader.Close();
              }
            }
            catch (Exception ex)
            {
              str = (string) null;
              MyLog.Default.WriteLine(ex);
            }
            finally
            {
              if (stream != null)
                stream.Close();
            }
          }
          catch (Exception ex)
          {
            str = (string) null;
            MyLog.Default.WriteLine(ex);
          }
          finally
          {
            if (webResponse != null)
              webResponse.Close();
          }
        }
        catch (Exception ex)
        {
          str = (string) null;
          MyLog.Default.WriteLine(ex);
        }
        if (str == null)
        {
          Thread.Sleep(3000);
          MyLog.Default.WriteLine("Retrying...");
        }
        else
          break;
      }
      MyLog.Default.WriteLine("Characters count: " + (str == null ? "null" : str.Length.ToString()));
      MyLog.Default.DecreaseIndent();
      MyLog.Default.WriteLine("DownloadStringSynchronously - END");
      return str;
    }

    public static string GetStringRight(string s, int charactersCountFromRight)
    {
      if (s.Length <= charactersCountFromRight)
        return s;
      else
        return s.Substring(s.Length - charactersCountFromRight, charactersCountFromRight);
    }

    public static string EscapeSemicolons(string s)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < s.Length; ++index)
      {
        switch (s[index])
        {
          case '\'':
            stringBuilder.Append("\\A");
            break;
          case ';':
            stringBuilder.Append("\\B");
            break;
          case '\\':
            stringBuilder.Append("\\\\");
            break;
          case '\t':
            stringBuilder.Append("\\t");
            break;
          case '\n':
            stringBuilder.Append("\\n");
            break;
          case '\r':
            stringBuilder.Append("\\r");
            break;
          case '"':
            stringBuilder.Append("\\Q");
            break;
          default:
            stringBuilder.Append(s[index]);
            break;
        }
      }
      return ((object) stringBuilder).ToString();
    }

    public static string UnescapeSemicolons(string s)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < s.Length; ++index)
      {
        if ((int) s[index] == 92)
        {
          if (++index == s.Length)
          {
            stringBuilder.Append("\\");
          }
          else
          {
            switch (s[index])
            {
              case '\\':
                stringBuilder.Append("\\");
                continue;
              case 'n':
                stringBuilder.Append("\n");
                continue;
              case 'r':
                stringBuilder.Append("\r");
                continue;
              case 't':
                stringBuilder.Append("\t");
                continue;
              case 'A':
                stringBuilder.Append("'");
                continue;
              case 'B':
                stringBuilder.Append(";");
                continue;
              case 'Q':
                stringBuilder.Append("\"");
                continue;
              default:
                stringBuilder.Append("\\").Append(s[index]);
                continue;
            }
          }
        }
        else
          stringBuilder.Append(s[index]);
      }
      return ((object) stringBuilder).ToString();
    }

    public static int GetHash(string text, int seed = 0)
    {
      int num = seed;
      if (text != null)
      {
        foreach (char ch in text)
          num = num * 31 + (int) ch;
      }
      return num;
    }

    public static Vector2 GetCoordAligned(Vector2 coordScreen, Vector2 size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return coordScreen;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return coordScreen - size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return coordScreen - size * new Vector2(0.0f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return coordScreen - size * 0.5f;
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return coordScreen - size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return coordScreen - size * new Vector2(0.5f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return coordScreen - size;
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return coordScreen - size * new Vector2(1f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return coordScreen - size * new Vector2(1f, 0.0f);
        default:
          throw new InvalidBranchException();
      }
    }

    public static Vector2 GetCoordAlignedFromCenter(Vector2 coordCenter, Vector2 size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return coordCenter + size * new Vector2(-0.5f, -0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return coordCenter + size * new Vector2(-0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return coordCenter + size * new Vector2(-0.5f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return coordCenter;
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return coordCenter + size * new Vector2(0.0f, -0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return coordCenter + size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return coordCenter + size * new Vector2(0.5f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return coordCenter + size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return coordCenter + size * new Vector2(0.5f, -0.5f);
        default:
          throw new InvalidBranchException();
      }
    }

    public static Vector2 GetCoordAlignedFromTopLeft(Vector2 topLeft, Vector2 size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return topLeft;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return topLeft + size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return topLeft + size * new Vector2(0.0f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return topLeft + size * new Vector2(0.5f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return topLeft + size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return topLeft + size * new Vector2(0.5f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return topLeft + size * new Vector2(1f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return topLeft + size * new Vector2(1f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return topLeft + size * new Vector2(1f, 0.0f);
        default:
          return topLeft;
      }
    }

    public static Vector2 GetCoordTopLeftFromAligned(Vector2 alignedCoord, Vector2 size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return alignedCoord;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return alignedCoord - size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return alignedCoord - size * new Vector2(0.0f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return alignedCoord - size * 0.5f;
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return alignedCoord - size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return alignedCoord - size * new Vector2(0.5f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return alignedCoord - size;
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return alignedCoord - size * new Vector2(1f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return alignedCoord - size * new Vector2(1f, 0.0f);
        default:
          throw new InvalidBranchException();
      }
    }

    public static Vector2I GetCoordTopLeftFromAligned(Vector2I alignedCoord, Vector2I size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return alignedCoord;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return new Vector2I(alignedCoord.X, alignedCoord.Y - size.Y / 2);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return new Vector2I(alignedCoord.X, alignedCoord.Y - size.Y);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return new Vector2I(alignedCoord.X - size.X / 2, alignedCoord.Y - size.Y / 2);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return new Vector2I(alignedCoord.X - size.X / 2, alignedCoord.Y);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return new Vector2I(alignedCoord.X - size.X / 2, alignedCoord.Y - size.Y);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return new Vector2I(alignedCoord.X - size.X, alignedCoord.Y - size.Y);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return new Vector2I(alignedCoord.X - size.X, alignedCoord.Y - size.Y / 2);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return new Vector2I(alignedCoord.X - size.X, alignedCoord.Y);
        default:
          throw new InvalidBranchException();
      }
    }

    public static Vector2 GetCoordCenterFromAligned(Vector2 alignedCoord, Vector2 size, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return alignedCoord + size * 0.5f;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return alignedCoord + size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return alignedCoord + size * new Vector2(0.5f, -0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return alignedCoord;
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return alignedCoord + size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return alignedCoord - size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return alignedCoord - size * 0.5f;
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return alignedCoord - size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return alignedCoord + size * new Vector2(-0.5f, 0.5f);
        default:
          throw new InvalidBranchException();
      }
    }

    public static Vector2 GetCoordAlignedFromRectangle(ref RectangleF rect, MyGuiDrawAlignEnum drawAlign)
    {
      switch (drawAlign)
      {
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP:
          return rect.Position;
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_CENTER:
          return rect.Position + rect.Size * new Vector2(0.0f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_BOTTOM:
          return rect.Position + rect.Size * new Vector2(0.0f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_CENTER:
          return rect.Position + rect.Size * 0.5f;
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_TOP:
          return rect.Position + rect.Size * new Vector2(0.5f, 0.0f);
        case MyGuiDrawAlignEnum.HORISONTAL_CENTER_AND_VERTICAL_BOTTOM:
          return rect.Position + rect.Size * new Vector2(0.5f, 1f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_BOTTOM:
          return rect.Position + rect.Size * 1f;
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_CENTER:
          return rect.Position + rect.Size * new Vector2(1f, 0.5f);
        case MyGuiDrawAlignEnum.HORISONTAL_RIGHT_AND_VERTICAL_TOP:
          return rect.Position + rect.Size * new Vector2(1f, 0.0f);
        default:
          throw new InvalidBranchException();
      }
    }
  }
}
