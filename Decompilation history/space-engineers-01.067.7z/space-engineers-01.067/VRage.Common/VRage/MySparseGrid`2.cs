﻿// Decompiled with JetBrains decompiler
// Type: VRage.MySparseGrid`2
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections;
using System.Collections.Generic;
using VRage.Collections;
using VRageMath;

namespace VRage
{
  public class MySparseGrid<TItemData, TCellData> : IDictionary<Vector3I, TItemData>, ICollection<KeyValuePair<Vector3I, TItemData>>, IEnumerable<KeyValuePair<Vector3I, TItemData>>, IEnumerable
  {
    private Dictionary<Vector3I, MySparseGrid<TItemData, TCellData>.Cell> m_cells = new Dictionary<Vector3I, MySparseGrid<TItemData, TCellData>.Cell>();
    private HashSet<Vector3I> m_dirtyCells = new HashSet<Vector3I>();
    private int m_itemCount;
    public readonly int CellSize;

    public DictionaryReader<Vector3I, MySparseGrid<TItemData, TCellData>.Cell> Cells
    {
      get
      {
        return new DictionaryReader<Vector3I, MySparseGrid<TItemData, TCellData>.Cell>(this.m_cells);
      }
    }

    public HashSetReader<Vector3I> DirtyCells
    {
      get
      {
        return (HashSetReader<Vector3I>) this.m_dirtyCells;
      }
    }

    public int ItemCount
    {
      get
      {
        return this.m_itemCount;
      }
    }

    public int CellCount
    {
      get
      {
        return this.m_cells.Count;
      }
    }

    ICollection<Vector3I> IDictionary<Vector3I, TItemData>.Keys
    {
      get
      {
        throw new InvalidOperationException("Operation not supported");
      }
    }

    ICollection<TItemData> IDictionary<Vector3I, TItemData>.Values
    {
      get
      {
        throw new InvalidOperationException("Operation not supported");
      }
    }

    TItemData IDictionary<Vector3I, TItemData>.this[Vector3I key]
    {
      get
      {
        return this.Get(key);
      }
      set
      {
        this.Remove(key, true);
        this.Add(key, value);
      }
    }

    int ICollection<KeyValuePair<Vector3I, TItemData>>.Count
    {
      get
      {
        return this.m_itemCount;
      }
    }

    bool ICollection<KeyValuePair<Vector3I, TItemData>>.IsReadOnly
    {
      get
      {
        return false;
      }
    }

    public MySparseGrid(int cellSize)
    {
      this.CellSize = cellSize;
    }

    public Vector3I Add(Vector3I pos, TItemData data)
    {
      Vector3I cell = pos / this.CellSize;
      this.GetCell(cell, true).m_items.Add(pos, data);
      this.MarkDirty(cell);
      ++this.m_itemCount;
      return cell;
    }

    public bool Contains(Vector3I pos)
    {
      MySparseGrid<TItemData, TCellData>.Cell cell = this.GetCell(pos / this.CellSize, false);
      if (cell != null)
        return cell.m_items.ContainsKey(pos);
      else
        return false;
    }

    public bool Remove(Vector3I pos, bool removeEmptyCell = true)
    {
      Vector3I vector3I = pos / this.CellSize;
      MySparseGrid<TItemData, TCellData>.Cell cell = this.GetCell(vector3I, false);
      if (cell == null || !cell.m_items.Remove(pos))
        return false;
      this.MarkDirty(vector3I);
      --this.m_itemCount;
      if (removeEmptyCell && cell.m_items.Count == 0)
        this.m_cells.Remove(vector3I);
      return true;
    }

    public void Clear()
    {
      this.m_cells.Clear();
      this.m_itemCount = 0;
    }

    public void ClearCells()
    {
      foreach (KeyValuePair<Vector3I, MySparseGrid<TItemData, TCellData>.Cell> keyValuePair in this.m_cells)
        keyValuePair.Value.m_items.Clear();
      this.m_itemCount = 0;
    }

    public TItemData Get(Vector3I pos)
    {
      return this.GetCell(pos / this.CellSize, false).m_items[pos];
    }

    public bool TryGet(Vector3I pos, out TItemData data)
    {
      MySparseGrid<TItemData, TCellData>.Cell cell = this.GetCell(pos / this.CellSize, false);
      if (cell != null)
        return cell.m_items.TryGetValue(pos, out data);
      data = default (TItemData);
      return false;
    }

    public MySparseGrid<TItemData, TCellData>.Cell GetCell(Vector3I cell)
    {
      return this.m_cells[cell];
    }

    public bool TryGetCell(Vector3I cell, out MySparseGrid<TItemData, TCellData>.Cell result)
    {
      return this.m_cells.TryGetValue(cell, out result);
    }

    private MySparseGrid<TItemData, TCellData>.Cell GetCell(Vector3I cell, bool createIfNotExists)
    {
      MySparseGrid<TItemData, TCellData>.Cell cell1;
      if (!this.m_cells.TryGetValue(cell, out cell1) && createIfNotExists)
      {
        cell1 = new MySparseGrid<TItemData, TCellData>.Cell();
        this.m_cells[cell] = cell1;
      }
      return cell1;
    }

    public bool IsDirty(Vector3I cell)
    {
      return this.m_dirtyCells.Contains(cell);
    }

    public void MarkDirty(Vector3I cell)
    {
      this.m_dirtyCells.Add(cell);
    }

    public void UnmarkDirty(Vector3I cell)
    {
      this.m_dirtyCells.Remove(cell);
    }

    public void UnmarkDirtyAll()
    {
      this.m_dirtyCells.Clear();
    }

    public Dictionary<Vector3I, MySparseGrid<TItemData, TCellData>.Cell>.Enumerator GetEnumerator()
    {
      return this.m_cells.GetEnumerator();
    }

    void IDictionary<Vector3I, TItemData>.Add(Vector3I key, TItemData value)
    {
      this.Add(key, value);
    }

    bool IDictionary<Vector3I, TItemData>.ContainsKey(Vector3I key)
    {
      return this.Contains(key);
    }

    bool IDictionary<Vector3I, TItemData>.Remove(Vector3I key)
    {
      return this.Remove(key, true);
    }

    bool IDictionary<Vector3I, TItemData>.TryGetValue(Vector3I key, out TItemData value)
    {
      return this.TryGet(key, out value);
    }

    void ICollection<KeyValuePair<Vector3I, TItemData>>.Add(KeyValuePair<Vector3I, TItemData> item)
    {
      this.Add(item.Key, item.Value);
    }

    void ICollection<KeyValuePair<Vector3I, TItemData>>.Clear()
    {
      this.Clear();
    }

    bool ICollection<KeyValuePair<Vector3I, TItemData>>.Contains(KeyValuePair<Vector3I, TItemData> item)
    {
      throw new InvalidOperationException("Operation not supported");
    }

    void ICollection<KeyValuePair<Vector3I, TItemData>>.CopyTo(KeyValuePair<Vector3I, TItemData>[] array, int arrayIndex)
    {
      throw new InvalidOperationException("Operation not supported");
    }

    bool ICollection<KeyValuePair<Vector3I, TItemData>>.Remove(KeyValuePair<Vector3I, TItemData> item)
    {
      throw new InvalidOperationException("Operation not supported");
    }

    IEnumerator<KeyValuePair<Vector3I, TItemData>> IEnumerable<KeyValuePair<Vector3I, TItemData>>.GetEnumerator()
    {
      throw new InvalidOperationException("Operation not supported");
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      throw new InvalidOperationException("Operation not supported");
    }

    public class Cell
    {
      internal Dictionary<Vector3I, TItemData> m_items = new Dictionary<Vector3I, TItemData>();
      public TCellData CellData;

      public DictionaryReader<Vector3I, TItemData> Items
      {
        get
        {
          return new DictionaryReader<Vector3I, TItemData>(this.m_items);
        }
      }
    }
  }
}
