﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.LoggingOptions
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;

namespace SysUtils.Utils
{
  [Flags]
  public enum LoggingOptions
  {
    NONE = 1,
    ENUM_CHECKING = 2,
    LOADING_MODELS = 4,
    LOADING_TEXTURES = 8,
    LOADING_CUSTOM_ASSETS = 16,
    LOADING_SPRITE_VIDEO = 32,
    VALIDATING_CUE_PARAMS = 64,
    CONFIG_ACCESS = 128,
    SIMPLE_NETWORKING = 256,
    VOXEL_MAPS = 512,
    MISC_RENDER_ASSETS = 1024,
    AUDIO = 2048,
    TRAILERS = 4096,
    SESSION_SETTINGS = 8192,
    ALL = SESSION_SETTINGS | TRAILERS | AUDIO | MISC_RENDER_ASSETS | VOXEL_MAPS | SIMPLE_NETWORKING | CONFIG_ACCESS | VALIDATING_CUE_PARAMS | LOADING_SPRITE_VIDEO | LOADING_CUSTOM_ASSETS | LOADING_TEXTURES | LOADING_MODELS | ENUM_CHECKING | NONE,
  }
}
