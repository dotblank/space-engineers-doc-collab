﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.MySingleProgramInstance
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Reflection;
using System.Threading;

namespace SysUtils.Utils
{
  public class MySingleProgramInstance
  {
    private Mutex m_mutex;
    private bool m_weOwn;

    public bool IsSingleInstance
    {
      get
      {
        return this.m_weOwn;
      }
    }

    public MySingleProgramInstance()
    {
      this.m_mutex = new Mutex(true, Assembly.GetExecutingAssembly().GetName().Name, out this.m_weOwn);
    }

    public MySingleProgramInstance(string identifier)
    {
      this.m_mutex = new Mutex(true, identifier, out this.m_weOwn);
    }

    public void Close()
    {
      if (!this.m_weOwn)
        return;
      this.m_mutex.ReleaseMutex();
      this.m_mutex.Close();
      this.m_weOwn = false;
    }
  }
}
