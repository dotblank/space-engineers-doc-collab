﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.MyUserFileAccess
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;

namespace SysUtils.Utils
{
  public class MyUserFileAccess
  {
    private string m_path;
    private int m_accessCode;
    private WindowsIdentity m_principal;

    public string Path
    {
      get
      {
        return this.m_path;
      }
      set
      {
        this.m_path = value;
        this.GetAccessRights(this.m_path, this.m_principal);
      }
    }

    public WindowsIdentity WindowsIdentity
    {
      get
      {
        return this.m_principal;
      }
      set
      {
        this.m_principal = value;
        this.GetAccessRights(this.m_path, this.m_principal);
      }
    }

    public bool CanAppendData
    {
      get
      {
        return this.HasRight(FileSystemRights.AppendData);
      }
    }

    public bool CanChangePermissions
    {
      get
      {
        return this.HasRight(FileSystemRights.ChangePermissions);
      }
    }

    public bool CanCreateDirectories
    {
      get
      {
        return this.HasRight(FileSystemRights.AppendData);
      }
    }

    public bool CanCreateFiles
    {
      get
      {
        return this.HasRight(FileSystemRights.WriteData);
      }
    }

    public bool CanDelete
    {
      get
      {
        return this.HasRight(FileSystemRights.Delete);
      }
    }

    public bool CanDeleteSubdirectoriesAndFiles
    {
      get
      {
        return this.HasRight(FileSystemRights.DeleteSubdirectoriesAndFiles);
      }
    }

    public bool CanExecuteFile
    {
      get
      {
        return this.HasRight(FileSystemRights.ExecuteFile);
      }
    }

    public bool CanFullControl
    {
      get
      {
        return this.HasRight(FileSystemRights.FullControl);
      }
    }

    public bool CanListDirectory
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadData);
      }
    }

    public bool CanModify
    {
      get
      {
        return this.HasRight(FileSystemRights.Modify);
      }
    }

    public bool CanRead
    {
      get
      {
        return this.HasRight(FileSystemRights.Read);
      }
    }

    public bool CanReadAndExecute
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadAndExecute);
      }
    }

    public bool CanReadAttributes
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadAttributes);
      }
    }

    public bool CanReadData
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadData);
      }
    }

    public bool CanReadExtendedAttributes
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadExtendedAttributes);
      }
    }

    public bool CanReadPermissions
    {
      get
      {
        return this.HasRight(FileSystemRights.ReadPermissions);
      }
    }

    public bool CanSynchronize
    {
      get
      {
        return this.HasRight(FileSystemRights.Synchronize);
      }
    }

    public bool CanTakeOwnership
    {
      get
      {
        return this.HasRight(FileSystemRights.TakeOwnership);
      }
    }

    public bool CanTraverse
    {
      get
      {
        return this.HasRight(FileSystemRights.ExecuteFile);
      }
    }

    public bool CanWrite
    {
      get
      {
        return this.HasRight(FileSystemRights.Write);
      }
    }

    public bool CanWriteAttributes
    {
      get
      {
        return this.HasRight(FileSystemRights.WriteAttributes);
      }
    }

    public bool CanWriteData
    {
      get
      {
        return this.HasRight(FileSystemRights.WriteData);
      }
    }

    public bool CanWriteExtendedAttributes
    {
      get
      {
        return this.HasRight(FileSystemRights.WriteExtendedAttributes);
      }
    }

    public MyUserFileAccess(string path)
      : this(path, WindowsIdentity.GetCurrent())
    {
    }

    public MyUserFileAccess(string path, WindowsIdentity principal)
    {
      this.m_path = path;
      this.m_principal = principal;
      this.GetAccessRights(this.m_path, this.m_principal);
    }

    public bool HasRight(FileSystemRights right)
    {
      return ((FileSystemRights) this.m_accessCode & right) != (FileSystemRights) 0;
    }

    private void AssignAccessRight(FileSystemAccessRule rule)
    {
      if (AccessControlType.Deny.Equals((object) rule.AccessControlType))
      {
        this.m_accessCode &= (int) ~rule.FileSystemRights;
      }
      else
      {
        if (!AccessControlType.Allow.Equals((object) rule.AccessControlType))
          return;
        this.m_accessCode |= (int) rule.FileSystemRights;
      }
    }

    private void GetAccessRights(string path, WindowsIdentity principal)
    {
      this.m_accessCode = 0;
      try
      {
        AuthorizationRuleCollection accessRules = new FileInfo(path).GetAccessControl().GetAccessRules(true, true, typeof (SecurityIdentifier));
        foreach (FileSystemAccessRule rule in (ReadOnlyCollectionBase) accessRules)
        {
          if (((object) principal.User).Equals((object) rule.IdentityReference))
            this.AssignAccessRight(rule);
        }
        IdentityReferenceCollection groups = this.m_principal.Groups;
        for (int index = 0; index < groups.Count; ++index)
        {
          foreach (FileSystemAccessRule rule in (ReadOnlyCollectionBase) accessRules)
          {
            if (groups[index].Equals((object) rule.IdentityReference))
              this.AssignAccessRight(rule);
          }
        }
      }
      catch
      {
      }
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (string str in Enum.GetNames(typeof (FileSystemRights)))
      {
        if (this.HasRight((FileSystemRights) Enum.Parse(typeof (FileSystemRights), str)))
          stringBuilder.AppendFormat("{0}{1}", stringBuilder.Length == 0 ? (object) string.Empty : (object) ", ", (object) str);
      }
      if (stringBuilder.Length == 0)
        return "None";
      else
        return ((object) stringBuilder).ToString();
    }
  }
}
