﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.MyDebug
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Diagnostics;
using VRage.Common.Utils;
using VRageMath;

namespace SysUtils.Utils
{
  public class MyDebug
  {
    public static void AssertRelease(bool condition)
    {
      MyDebug.AssertRelease(condition, "Assertion failed");
    }

    public static void AssertRelease(bool condition, string assertMessage)
    {
      if (!condition)
        MyLog.Default.WriteLine("Assert: " + assertMessage);
      Trace.Assert(condition, assertMessage);
    }

    [DebuggerStepThrough]
    [Conditional("DEBUG")]
    public static void AssertDebug(bool condition)
    {
    }

    [Conditional("DEBUG")]
    [DebuggerStepThrough]
    public static void AssertDebug(bool condition, string assertMessage)
    {
    }

    public static bool IsValid(float f)
    {
      if (!float.IsNaN(f))
        return !float.IsInfinity(f);
      else
        return false;
    }

    public static bool IsValid(Vector3 vec)
    {
      if (MyDebug.IsValid(vec.X) && MyDebug.IsValid(vec.Y))
        return MyDebug.IsValid(vec.Z);
      else
        return false;
    }

    public static bool IsValidNormal(Vector3 vec)
    {
      float num = vec.LengthSquared();
      if (MyDebug.IsValid(vec) && (double) num > 0.999000012874603)
        return (double) num < 1.00100004673004;
      else
        return false;
    }

    public static bool IsValid(Vector2 vec)
    {
      if (MyDebug.IsValid(vec.X))
        return MyDebug.IsValid(vec.Y);
      else
        return false;
    }

    public static bool IsValid(Vector3? vec)
    {
      if (!vec.HasValue)
        return true;
      if (MyDebug.IsValid(vec.Value.X) && MyDebug.IsValid(vec.Value.Y))
        return MyDebug.IsValid(vec.Value.Z);
      else
        return false;
    }

    public static bool IsValid(Matrix matrix)
    {
      if (MyDebug.IsValid(matrix.Up) && MyDebug.IsValid(matrix.Left) && (MyDebug.IsValid(matrix.Forward) && MyDebug.IsValid(matrix.Translation)))
        return matrix != Matrix.Zero;
      else
        return false;
    }

    public static bool IsValid(Quaternion q)
    {
      if (MyDebug.IsValid(q.X) && MyDebug.IsValid(q.Y) && (MyDebug.IsValid(q.Z) && MyDebug.IsValid(q.W)))
        return !MyVRageUtils.IsZero(q, 1E-05f);
      else
        return false;
    }

    public static void AssertIsValid(Vector3 vec)
    {
    }

    public static void AssertIsValid(Vector3? vec)
    {
    }

    public static void AssertIsValid(Vector2 vec)
    {
    }

    public static void AssertIsValid(float f)
    {
    }

    public static void AssertIsValid(Matrix matrix)
    {
    }

    public static void AssertIsValid(Quaternion q)
    {
    }
  }
}
