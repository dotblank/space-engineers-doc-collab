﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.MyFileSystemUtils
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;

namespace SysUtils.Utils
{
  public class MyFileSystemUtils
  {
    public static void CreateFolder(string folderPath)
    {
      Directory.CreateDirectory(folderPath);
    }

    public static void CopyDirectory(string source, string destination)
    {
      if (!Directory.Exists(source))
        return;
      if (!Directory.Exists(destination))
        Directory.CreateDirectory(destination);
      foreach (string str in Directory.GetFiles(source))
      {
        string fileName = Path.GetFileName(str);
        string destFileName = Path.Combine(destination, fileName);
        System.IO.File.Copy(str, destFileName, true);
      }
    }

    public static bool DownloadFileSynchronously(string url, string filepath)
    {
      WebClient webClient = (WebClient) null;
      try
      {
        webClient = new WebClient();
        webClient.Proxy = (IWebProxy) null;
        webClient.DownloadFile(url, filepath);
      }
      catch (Exception ex)
      {
        MyLog.Default.WriteLine(ex);
        return false;
      }
      finally
      {
        if (webClient != null)
          webClient.Dispose();
      }
      return true;
    }

    public static string StripInvalidChars(string filename)
    {
      return Enumerable.Aggregate<char, string>((IEnumerable<char>) Path.GetInvalidFileNameChars(), filename, (Func<string, char, string>) ((current, c) => current.Replace(c.ToString(), string.Empty)));
    }
  }
}
