﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.Utils.MyLog
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using VRage.Common.Utils;

namespace SysUtils.Utils
{
  public class MyLog
  {
    private readonly object m_lock = new object();
    private StringBuilder m_stringBuilder = new StringBuilder(2048);
    private char[] m_tmpWrite = new char[2048];
    private LoggingOptions m_loggingOptions = LoggingOptions.NONE | LoggingOptions.ENUM_CHECKING | LoggingOptions.LOADING_TEXTURES | LoggingOptions.LOADING_CUSTOM_ASSETS | LoggingOptions.LOADING_SPRITE_VIDEO | LoggingOptions.VALIDATING_CUE_PARAMS | LoggingOptions.CONFIG_ACCESS | LoggingOptions.SIMPLE_NETWORKING | LoggingOptions.VOXEL_MAPS | LoggingOptions.MISC_RENDER_ASSETS | LoggingOptions.AUDIO | LoggingOptions.TRAILERS | LoggingOptions.SESSION_SETTINGS;
    private StringBuilder m_consoleStringBuilder = new StringBuilder();
    private bool LogForMemoryProfiler;
    private bool m_enabled;
    private Stream m_stream;
    private StreamWriter m_streamWriter;
    private Dictionary<int, int> m_indentsByThread;
    private Dictionary<MyLog.MyLogIndentKey, MyLog.MyLogIndentValue> m_indents;
    private string m_filepath;
    private Action<string> m_normalWriter;
    private Action<string> m_closedLogWriter;
    private static MyLog m_default;

    public static MyLog Default
    {
      get
      {
        return MyLog.m_default;
      }
      set
      {
        MyLog.m_default = value;
      }
    }

    public LoggingOptions Options
    {
      get
      {
        return this.m_loggingOptions;
      }
      set
      {
        value = this.m_loggingOptions;
      }
    }

    public bool LogEnabled
    {
      get
      {
        return this.m_enabled;
      }
    }

    public void Init(string logFileName, StringBuilder appVersionString)
    {
      lock (this.m_lock)
      {
        try
        {
          this.m_filepath = Path.IsPathRooted(logFileName) ? logFileName : Path.Combine(MyFileSystem.UserDataPath, logFileName);
          this.m_stream = MyFileSystem.OpenWrite(this.m_filepath, FileMode.Create);
          this.m_streamWriter = new StreamWriter(this.m_stream);
          this.m_normalWriter = new Action<string>(this.WriteLine);
          this.m_closedLogWriter = (Action<string>) (s => File.AppendAllText(this.m_filepath, s + Environment.NewLine));
          this.m_enabled = true;
        }
        catch (Exception exception_0)
        {
          Trace.Fail("Cannot create log file: " + ((object) exception_0).ToString());
        }
        this.m_indentsByThread = new Dictionary<int, int>();
        this.m_indents = new Dictionary<MyLog.MyLogIndentKey, MyLog.MyLogIndentValue>();
        int local_1 = (int) Math.Round((DateTime.Now - DateTime.UtcNow).TotalHours);
        this.WriteLine("Log Started");
        this.WriteLine(string.Format("Timezone (local - UTC): {0}h", (object) local_1));
        this.WriteLine("App Version: " + (object) appVersionString);
      }
    }

    public string GetFilePath()
    {
      lock (this.m_lock)
        return this.m_filepath;
    }

    public MyLog.IndentToken IndentUsing(LoggingOptions options = LoggingOptions.NONE)
    {
      return new MyLog.IndentToken(this, options);
    }

    public void IncreaseIndent(LoggingOptions option)
    {
      if (!this.LogFlag(option))
        return;
      this.IncreaseIndent();
    }

    public void IncreaseIndent()
    {
      if (!this.m_enabled)
        return;
      lock (this.m_lock)
      {
        int local_0 = this.GetThreadId();
        this.m_indentsByThread[local_0] = this.GetIdentByThread(local_0) + 1;
        this.m_indents[new MyLog.MyLogIndentKey(local_0, this.m_indentsByThread[local_0])] = new MyLog.MyLogIndentValue(this.GetManagedMemory(), this.GetSystemMemory(), DateTimeOffset.Now);
        if (!this.LogForMemoryProfiler)
          return;
        MyMemoryLogs.StartEvent();
      }
    }

    public bool IsIndentKeyIncreased()
    {
      if (!this.m_enabled)
        return false;
      lock (this.m_lock)
      {
        int local_0 = this.GetThreadId();
        return this.m_indents.ContainsKey(new MyLog.MyLogIndentKey(local_0, this.GetIdentByThread(local_0)));
      }
    }

    public void DecreaseIndent(LoggingOptions option)
    {
      if (!this.LogFlag(option))
        return;
      this.DecreaseIndent();
    }

    public void DecreaseIndent()
    {
      if (!this.m_enabled)
        return;
      lock (this.m_lock)
      {
        int local_1 = this.GetThreadId();
        MyLog.MyLogIndentValue local_0 = this.m_indents[new MyLog.MyLogIndentKey(local_1, this.GetIdentByThread(local_1))];
        if (this.LogForMemoryProfiler)
          MyMemoryLogs.EndEvent(new MyMemoryLogs.MyMemoryEvent()
          {
            DeltaTime = (float) ((DateTimeOffset.Now - local_0.LastDateTimeOffset).TotalMilliseconds / 1000.0),
            ManagedEndSize = (float) this.GetManagedMemory(),
            ProcessEndSize = (float) this.GetSystemMemory(),
            ManagedStartSize = (float) local_0.LastGcTotalMemory,
            ProcessStartSize = (float) local_0.LastWorkingSet
          });
      }
      lock (this.m_lock)
      {
        int local_4 = this.GetThreadId();
        this.m_indentsByThread[local_4] = this.GetIdentByThread(local_4) - 1;
      }
    }

    private string GetFormatedMemorySize(long bytesCount)
    {
      return MyValueFormatter.GetFormatedFloat((float) ((double) bytesCount / 1024.0 / 1024.0), 3) + " Mb (" + MyValueFormatter.GetFormatedLong(bytesCount) + " bytes)";
    }

    private long GetManagedMemory()
    {
      return GC.GetTotalMemory(false);
    }

    private long GetSystemMemory()
    {
      return Environment.WorkingSet;
    }

    public void Close()
    {
      if (!this.m_enabled)
        return;
      lock (this.m_lock)
      {
        this.WriteLine("Log Closed");
        this.m_streamWriter.Close();
        this.m_stream.Close();
        this.m_stream = (Stream) null;
        this.m_streamWriter = (StreamWriter) null;
        this.m_enabled = false;
      }
    }

    public void AppendToClosedLog(string text)
    {
      if (this.m_enabled)
      {
        this.WriteLine(text);
      }
      else
      {
        if (this.m_filepath == null)
          return;
        File.AppendAllText(this.m_filepath, text + Environment.NewLine);
      }
    }

    public void AppendToClosedLog(Exception e)
    {
      if (this.m_enabled)
      {
        this.WriteLine(e);
      }
      else
      {
        if (this.m_filepath == null)
          return;
        MyLog.WriteLine(this.m_closedLogWriter, e);
      }
    }

    public bool LogFlag(LoggingOptions option)
    {
      return (this.m_loggingOptions & option) != (LoggingOptions) 0;
    }

    public void WriteLine(string message, LoggingOptions option)
    {
      if (!this.LogFlag(option))
        return;
      this.WriteLine(message);
    }

    private static void WriteLine(Action<string> writer, Exception ex)
    {
      writer("Exception occured: " + (ex == null ? "null" : ((object) ex).ToString()));
      if (ex != null && ex is ReflectionTypeLoadException)
      {
        writer("LoaderExceptions: ");
        foreach (Exception ex1 in ((ReflectionTypeLoadException) ex).LoaderExceptions)
          MyLog.WriteLine(writer, ex1);
      }
      if (ex == null || ex.InnerException == null)
        return;
      writer("InnerException: ");
      MyLog.WriteLine(writer, ex.InnerException);
    }

    public void WriteLine(Exception ex)
    {
      if (!this.m_enabled)
        return;
      MyLog.WriteLine(this.m_normalWriter, ex);
    }

    public void WriteLineAndConsole(string msg)
    {
      this.WriteLine(msg);
      this.m_consoleStringBuilder.Clear();
      this.AppendDateAndTime(this.m_consoleStringBuilder);
      this.m_consoleStringBuilder.Append(": ");
      this.m_consoleStringBuilder.Append(msg);
      Console.WriteLine(((object) this.m_consoleStringBuilder).ToString());
    }

    public void WriteLine(string msg)
    {
      if (this.m_enabled)
      {
        lock (this.m_lock)
        {
          this.WriteDateTimeAndThreadId();
          this.WriteString(msg);
          this.m_streamWriter.WriteLine();
          ((TextWriter) this.m_streamWriter).Flush();
        }
      }
      if (!this.LogForMemoryProfiler)
        return;
      MyMemoryLogs.AddConsoleLine(msg);
    }

    private string GetGCMemoryString(string prependText = "")
    {
      return string.Format("{0}: GC Memory: {1} B", (object) prependText, (object) this.GetManagedMemory().ToString("##,#"));
    }

    public void WriteMemoryUsage(string prefixText)
    {
      this.WriteLine(this.GetGCMemoryString(prefixText));
    }

    public void LogThreadPoolInfo()
    {
      if (!this.m_enabled)
        return;
      this.WriteLine("LogThreadPoolInfo - START");
      this.IncreaseIndent();
      int workerThreads;
      int completionPortThreads;
      ThreadPool.GetMaxThreads(out workerThreads, out completionPortThreads);
      this.WriteLine("GetMaxThreads.WorkerThreads: " + (object) workerThreads);
      this.WriteLine("GetMaxThreads.CompletionPortThreads: " + (object) completionPortThreads);
      ThreadPool.GetMinThreads(out workerThreads, out completionPortThreads);
      this.WriteLine("GetMinThreads.WorkerThreads: " + (object) workerThreads);
      this.WriteLine("GetMinThreads.CompletionPortThreads: " + (object) completionPortThreads);
      ThreadPool.GetAvailableThreads(out workerThreads, out completionPortThreads);
      this.WriteLine("GetAvailableThreads.WorkerThreads: " + (object) workerThreads);
      this.WriteLine("GetAvailableThreads.WompletionPortThreads: " + (object) completionPortThreads);
      this.DecreaseIndent();
      this.WriteLine("LogThreadPoolInfo - END");
    }

    private void WriteDateTimeAndThreadId()
    {
      this.m_stringBuilder.Clear();
      this.AppendDateAndTime(this.m_stringBuilder);
      this.m_stringBuilder.Append(" - ");
      this.m_stringBuilder.Append("Thread: ");
      StringBuilderExtensions.Concat(this.m_stringBuilder, this.GetThreadId(), 3U, ' ');
      this.m_stringBuilder.Append(" ->  ");
      this.m_stringBuilder.Append(' ', this.GetIdentByThread(this.GetThreadId()) * 3);
      this.WriteStringBuilder(this.m_stringBuilder);
    }

    private void AppendDateAndTime(StringBuilder sb)
    {
      DateTimeOffset now = DateTimeOffset.Now;
      StringBuilderExtensions.Concat(sb, now.Year, 4U, '0', 10U, false).Append('-');
      StringBuilderExtensions.Concat(sb, now.Month, 2U).Append('-');
      StringBuilderExtensions.Concat(sb, now.Day, 2U).Append(' ');
      StringBuilderExtensions.Concat(sb, now.Hour, 2U).Append(':');
      StringBuilderExtensions.Concat(sb, now.Minute, 2U).Append(':');
      StringBuilderExtensions.Concat(sb, now.Second, 2U).Append('.');
      StringBuilderExtensions.Concat(sb, now.Millisecond, 3U);
    }

    private void WriteString(string text)
    {
      if (this.m_tmpWrite.Length < text.Length)
        Array.Resize<char>(ref this.m_tmpWrite, Math.Max(this.m_tmpWrite.Length * 2, text.Length));
      text.CopyTo(0, this.m_tmpWrite, 0, text.Length);
      this.m_streamWriter.Write(this.m_tmpWrite, 0, text.Length);
    }

    private void WriteStringBuilder(StringBuilder sb)
    {
      if (this.m_tmpWrite.Length < sb.Length)
        Array.Resize<char>(ref this.m_tmpWrite, Math.Max(this.m_tmpWrite.Length * 2, sb.Length));
      sb.CopyTo(0, this.m_tmpWrite, 0, sb.Length);
      this.m_streamWriter.Write(this.m_tmpWrite, 0, sb.Length);
    }

    private int GetThreadId()
    {
      return Thread.CurrentThread.ManagedThreadId;
    }

    private int GetIdentByThread(int threadId)
    {
      int num;
      if (!this.m_indentsByThread.TryGetValue(threadId, out num))
        num = 0;
      return num;
    }

    public struct IndentToken : IDisposable
    {
      private MyLog m_log;
      private LoggingOptions m_options;

      internal IndentToken(MyLog log, LoggingOptions options)
      {
        this.m_log = log;
        this.m_options = options;
        this.m_log.IncreaseIndent(options);
      }

      public void Dispose()
      {
        if (this.m_log == null)
          return;
        this.m_log.DecreaseIndent(this.m_options);
        this.m_log = (MyLog) null;
      }
    }

    private struct MyLogIndentKey
    {
      public int ThreadId;
      public int Indent;

      public MyLogIndentKey(int threadId, int indent)
      {
        this.ThreadId = threadId;
        this.Indent = indent;
      }
    }

    private struct MyLogIndentValue
    {
      public long LastGcTotalMemory;
      public long LastWorkingSet;
      public DateTimeOffset LastDateTimeOffset;

      public MyLogIndentValue(long lastGcTotalMemory, long lastWorkingSet, DateTimeOffset lastDateTimeOffset)
      {
        this.LastGcTotalMemory = lastGcTotalMemory;
        this.LastWorkingSet = lastWorkingSet;
        this.LastDateTimeOffset = lastDateTimeOffset;
      }
    }
  }
}
