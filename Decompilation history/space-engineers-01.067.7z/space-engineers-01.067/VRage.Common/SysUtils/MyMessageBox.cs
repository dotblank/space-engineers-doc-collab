﻿// Decompiled with JetBrains decompiler
// Type: SysUtils.MyMessageBox
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Runtime.InteropServices;

namespace SysUtils
{
  public static class MyMessageBox
  {
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern uint MessageBox(IntPtr hWndle, string text, string caption, int buttons);

    public static void Show(string caption, string text)
    {
      int num = (int) MyMessageBox.MessageBox(new IntPtr(), text, caption, 0);
    }
  }
}
