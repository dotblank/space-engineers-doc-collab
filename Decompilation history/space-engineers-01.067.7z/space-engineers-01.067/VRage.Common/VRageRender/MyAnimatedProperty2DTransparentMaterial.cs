﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyAnimatedProperty2DTransparentMaterial
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Animations;

namespace VRageRender
{
  public class MyAnimatedProperty2DTransparentMaterial : MyAnimatedProperty2D<MyAnimatedPropertyTransparentMaterial, MyTransparentMaterial, int>
  {
    public MyAnimatedProperty2DTransparentMaterial(string name)
      : this(name, (MyAnimatedProperty<MyTransparentMaterial>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedProperty2DTransparentMaterial(string name, MyAnimatedProperty<MyTransparentMaterial>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      MyAnimatedPropertyTransparentMaterial transparentMaterial = new MyAnimatedPropertyTransparentMaterial(this.Name, this.m_interpolator2);
      transparentMaterial.Deserialize(reader);
      value = (object) transparentMaterial;
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedProperty2DTransparentMaterial dtransparentMaterial = new MyAnimatedProperty2DTransparentMaterial(this.Name);
      this.Duplicate((IMyConstProperty) dtransparentMaterial);
      return (IMyConstProperty) dtransparentMaterial;
    }

    public override void ApplyVariance(ref MyTransparentMaterial interpolatedValue, ref int variance, float multiplier, out MyTransparentMaterial value)
    {
      value = interpolatedValue;
    }
  }
}
