﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyUpdateData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Collections;

namespace VRageRender
{
  internal class MyUpdateData
  {
    private MyConcurrentPool<MyUpdateFrame> m_frameDataPool;
    private MyConcurrentQueue<MyUpdateFrame> m_updateDataQueue;

    public MyUpdateFrame CurrentUpdateFrame { get; private set; }

    public MyUpdateData()
    {
      this.m_frameDataPool = new MyConcurrentPool<MyUpdateFrame>(5, true);
      this.m_updateDataQueue = new MyConcurrentQueue<MyUpdateFrame>(5);
      this.CurrentUpdateFrame = this.m_frameDataPool.Get();
    }

    public void CommitUpdateFrame()
    {
      this.CurrentUpdateFrame.Processed = false;
      this.m_updateDataQueue.Enqueue(this.CurrentUpdateFrame);
      this.CurrentUpdateFrame = this.m_frameDataPool.Get();
    }

    public MyUpdateFrame GetRenderFrame(out bool isPreFrame)
    {
      if (this.m_updateDataQueue.Count > 1)
      {
        isPreFrame = true;
        return this.m_updateDataQueue.Dequeue();
      }
      else
      {
        isPreFrame = false;
        MyUpdateFrame instance;
        if (!this.m_updateDataQueue.TryPeek(out instance))
          return (MyUpdateFrame) null;
        else
          return instance;
      }
    }

    public void ReturnPreFrame(MyUpdateFrame frame)
    {
      this.m_frameDataPool.Return(frame);
    }
  }
}
