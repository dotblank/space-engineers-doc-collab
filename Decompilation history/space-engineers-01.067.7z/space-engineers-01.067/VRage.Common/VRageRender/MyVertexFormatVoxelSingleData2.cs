﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyVertexFormatVoxelSingleData2
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Import;
using VRageMath;
using VRageMath.PackedVector;

namespace VRageRender
{
  public struct MyVertexFormatVoxelSingleData2
  {
    private const int AMBIENT_MASK = 16383;
    public MyUShort4 m_positionAndAmbient;
    public Byte4 m_normal;

    public Vector3 Position
    {
      get
      {
        return new Vector3((float) this.m_positionAndAmbient.X, (float) this.m_positionAndAmbient.Y, (float) this.m_positionAndAmbient.Z) / (float) ushort.MaxValue;
      }
      set
      {
        this.m_positionAndAmbient.X = (ushort) ((double) value.X * (double) ushort.MaxValue);
        this.m_positionAndAmbient.Y = (ushort) ((double) value.Y * (double) ushort.MaxValue);
        this.m_positionAndAmbient.Z = (ushort) ((double) value.Z * (double) ushort.MaxValue);
      }
    }

    public byte MaterialAlphaIndex
    {
      get
      {
        return (byte) (((int) this.m_positionAndAmbient.W & 16383) >> 14);
      }
      set
      {
        this.m_positionAndAmbient.W = (ushort) ((int) this.m_positionAndAmbient.W & 16383 | ((int) value & 3) << 14);
      }
    }

    public float Ambient
    {
      get
      {
        return (float) (((int) this.m_positionAndAmbient.W & 16383) * 2 - 1);
      }
      set
      {
        this.m_positionAndAmbient.W = (ushort) ((uint) this.m_positionAndAmbient.W & 4294950912U | (uint) (int) (((double) value * 0.5 + 0.5) * 16383.0));
      }
    }

    public Vector3 Normal
    {
      get
      {
        return VF_Packer.UnpackNormal(ref this.m_normal);
      }
      set
      {
        this.m_normal.PackedValue = VF_Packer.PackNormal(ref value);
      }
    }

    public Byte4 PackedNormal
    {
      get
      {
        return this.m_normal;
      }
      set
      {
        this.m_normal = value;
      }
    }
  }
}
