﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyInstanceData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;
using VRageMath.PackedVector;

namespace VRageRender
{
  public struct MyInstanceData
  {
    public HalfVector4 m_row0;
    public HalfVector4 m_row1;
    public HalfVector4 m_row2;
    public HalfVector4 ColorMaskHSV;

    public Matrix LocalMatrix
    {
      get
      {
        Vector4 vector4_1 = this.m_row0.ToVector4();
        Vector4 vector4_2 = this.m_row1.ToVector4();
        Vector4 vector4_3 = this.m_row2.ToVector4();
        return new Matrix(vector4_1.X, vector4_2.X, vector4_3.X, 0.0f, vector4_1.Y, vector4_2.Y, vector4_3.Y, 0.0f, vector4_1.Z, vector4_2.Z, vector4_3.Z, 0.0f, vector4_1.W, vector4_2.W, vector4_3.W, 1f);
      }
      set
      {
        this.m_row0 = new HalfVector4(value.M11, value.M21, value.M31, value.M41);
        this.m_row1 = new HalfVector4(value.M12, value.M22, value.M32, value.M42);
        this.m_row2 = new HalfVector4(value.M13, value.M23, value.M33, value.M43);
      }
    }
  }
}
