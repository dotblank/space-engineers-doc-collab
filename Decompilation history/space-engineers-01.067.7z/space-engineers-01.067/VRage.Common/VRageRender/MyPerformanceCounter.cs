﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyPerformanceCounter
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using VRage.Common.Utils;

namespace VRageRender
{
  public static class MyPerformanceCounter
  {
    private static MyPerformanceCounter.MyPerCameraDraw PerCameraDraw0 = new MyPerformanceCounter.MyPerCameraDraw();
    private static MyPerformanceCounter.MyPerCameraDraw PerCameraDraw1 = new MyPerformanceCounter.MyPerCameraDraw();
    private static MyPerformanceCounter.MyPerCameraDraw11 PerCameraDraw11_0 = new MyPerformanceCounter.MyPerCameraDraw11();
    private static MyPerformanceCounter.MyPerCameraDraw11 PerCameraDraw11_1 = new MyPerformanceCounter.MyPerCameraDraw11();
    public static MyPerformanceCounter.MyPerCameraDraw PerCameraDrawRead = MyPerformanceCounter.PerCameraDraw0;
    public static MyPerformanceCounter.MyPerCameraDraw PerCameraDrawWrite = MyPerformanceCounter.PerCameraDraw0;
    public static MyPerformanceCounter.MyPerCameraDraw11 PerCameraDraw11Read = MyPerformanceCounter.PerCameraDraw11_0;
    public static MyPerformanceCounter.MyPerCameraDraw11 PerCameraDraw11Write = MyPerformanceCounter.PerCameraDraw11_0;
    public static MyPerformanceCounter.MyPerAppLifetime PerAppLifetime = new MyPerformanceCounter.MyPerAppLifetime();
    public static bool LogFiles = false;
    public const int NoSplit = 4;

    public static void Restart(string name)
    {
      MyPerformanceCounter.PerCameraDrawRead.CustomTimers.Remove(name);
      MyPerformanceCounter.PerCameraDrawWrite.CustomTimers.Remove(name);
      MyPerformanceCounter.PerCameraDrawRead.StartTimer(name);
      MyPerformanceCounter.PerCameraDrawWrite.StartTimer(name);
    }

    public static void Stop(string name)
    {
      MyPerformanceCounter.PerCameraDrawRead.StopTimer(name);
      MyPerformanceCounter.PerCameraDrawWrite.StopTimer(name);
    }

    internal static void SwitchCounters()
    {
      if (MyPerformanceCounter.PerCameraDrawRead == MyPerformanceCounter.PerCameraDraw0)
      {
        MyPerformanceCounter.PerCameraDrawRead = MyPerformanceCounter.PerCameraDraw1;
        MyPerformanceCounter.PerCameraDrawWrite = MyPerformanceCounter.PerCameraDraw0;
        MyPerformanceCounter.PerCameraDraw11Read = MyPerformanceCounter.PerCameraDraw11_1;
        MyPerformanceCounter.PerCameraDraw11Write = MyPerformanceCounter.PerCameraDraw11_0;
      }
      else
      {
        MyPerformanceCounter.PerCameraDrawRead = MyPerformanceCounter.PerCameraDraw0;
        MyPerformanceCounter.PerCameraDrawWrite = MyPerformanceCounter.PerCameraDraw1;
        MyPerformanceCounter.PerCameraDraw11Read = MyPerformanceCounter.PerCameraDraw11_0;
        MyPerformanceCounter.PerCameraDraw11Write = MyPerformanceCounter.PerCameraDraw11_1;
      }
    }

    public struct Timer
    {
      public static readonly MyPerformanceCounter.Timer Empty = new MyPerformanceCounter.Timer()
      {
        Runtime = 0L,
        StartTime = long.MaxValue
      };
      private static Stopwatch m_timer = new Stopwatch();
      public long StartTime;
      public long Runtime;

      public float RuntimeMs
      {
        get
        {
          return (float) ((double) this.Runtime / (double) Stopwatch.Frequency * 1000.0);
        }
      }

      private bool IsRunning
      {
        get
        {
          return this.StartTime != long.MaxValue;
        }
      }

      static Timer()
      {
        MyPerformanceCounter.Timer.m_timer.Start();
      }

      public void Start()
      {
        this.StartTime = MyPerformanceCounter.Timer.m_timer.ElapsedTicks;
      }

      public void Stop()
      {
        this.Runtime += MyPerformanceCounter.Timer.m_timer.ElapsedTicks - this.StartTime;
        this.StartTime = long.MaxValue;
      }
    }

    public class MyPerCameraDraw
    {
      public readonly Dictionary<string, MyPerformanceCounter.Timer> CustomTimers = new Dictionary<string, MyPerformanceCounter.Timer>(5);
      public readonly Dictionary<string, float> CustomCounters = new Dictionary<string, float>(5);
      private readonly List<string> m_tmpKeys = new List<string>();
      public int RenderCellsInFrustum_LOD0;
      public int RenderCellsInFrustum_LOD1;
      public int VoxelTrianglesInFrustum_LOD0;
      public int VoxelTrianglesInFrustum_LOD1;
      public int EntitiesRendered;
      public int ModelTrianglesInFrustum_LOD0;
      public int ModelTrianglesInFrustum_LOD1;
      public int DecalsForVoxelsInFrustum;
      public int DecalsForEntitiesInFrustum;
      public int DecalsForCockipGlassInFrustum;
      public int BillboardsInFrustum;
      public int BillboardsDrawCalls;
      public int BillboardsSorted;
      public int OldParticlesInFrustum;
      public int NewParticlesCount;
      public int ParticleEffectsTotal;
      public int ParticleEffectsDrawn;
      public int EntitiesOccluded;
      public int QueriesCount;
      public int LightsCount;
      public int RenderElementsInFrustum;
      public int RenderElementsIBChanges;
      public int RenderElementsInShadows;
      public int[] ShadowDrawCalls;
      public int TotalDrawCalls;
      public int[] MaterialChanges;
      public int[] TechniqueChanges;
      public int[] VertexBufferChanges;
      public int[] EntityChanges;
      private long m_gcMemory;

      public long GcMemory
      {
        get
        {
          return Interlocked.Read(ref this.m_gcMemory);
        }
        set
        {
          Interlocked.Exchange(ref this.m_gcMemory, value);
        }
      }

      public float this[string name]
      {
        get
        {
          float num;
          if (!this.CustomCounters.TryGetValue(name, out num))
            num = 0.0f;
          return num;
        }
        set
        {
          this.CustomCounters[name] = value;
        }
      }

      public List<string> SortedCounterKeys
      {
        get
        {
          this.m_tmpKeys.Clear();
          return this.m_tmpKeys;
        }
      }

      public MyPerCameraDraw()
      {
        this.ShadowDrawCalls = new int[5];
        int length = MyVRageUtils.GetMaxValueFromEnum<MyLodTypeEnum>() + 1;
        this.MaterialChanges = new int[length];
        this.TechniqueChanges = new int[length];
        this.VertexBufferChanges = new int[length];
        this.EntityChanges = new int[length];
      }

      public void SetCounter(string name, float count)
      {
        this.CustomCounters[name] = count;
      }

      public void StartTimer(string name)
      {
        MyPerformanceCounter.Timer timer;
        this.CustomTimers.TryGetValue(name, out timer);
        timer.Start();
        this.CustomTimers[name] = timer;
      }

      public void StopTimer(string name)
      {
        MyPerformanceCounter.Timer timer;
        if (!this.CustomTimers.TryGetValue(name, out timer))
          return;
        timer.Stop();
        this.CustomTimers[name] = timer;
      }

      public void Reset()
      {
        this.RenderCellsInFrustum_LOD1 = 0;
        this.RenderCellsInFrustum_LOD0 = 0;
        this.VoxelTrianglesInFrustum_LOD0 = 0;
        this.VoxelTrianglesInFrustum_LOD1 = 0;
        this.EntitiesRendered = 0;
        this.ModelTrianglesInFrustum_LOD0 = 0;
        this.ModelTrianglesInFrustum_LOD1 = 0;
        this.DecalsForVoxelsInFrustum = 0;
        this.DecalsForEntitiesInFrustum = 0;
        this.DecalsForCockipGlassInFrustum = 0;
        this.BillboardsInFrustum = 0;
        this.BillboardsDrawCalls = 0;
        this.BillboardsSorted = 0;
        this.OldParticlesInFrustum = 0;
        this.NewParticlesCount = 0;
        this.QueriesCount = 0;
        this.LightsCount = 0;
        this.RenderElementsInFrustum = 0;
        this.RenderElementsIBChanges = 0;
        this.RenderElementsInShadows = 0;
        this.ClearCustomCounters();
        this.GcMemory = GC.GetTotalMemory(false);
        for (int index = 0; index < this.ShadowDrawCalls.Length; ++index)
          this.ShadowDrawCalls[index] = 0;
        for (int index = 0; index < this.MaterialChanges.Length; ++index)
        {
          this.MaterialChanges[index] = 0;
          this.TechniqueChanges[index] = 0;
          this.VertexBufferChanges[index] = 0;
          this.EntityChanges[index] = 0;
        }
        this.TotalDrawCalls = 0;
      }

      public void ClearCustomCounters()
      {
        this.m_tmpKeys.Clear();
      }
    }

    public class MyPerCameraDraw11
    {
      public int RenderableObjectsNum;
      public int ViewFrustumObjectsNum;
      public int Cascade0ObjectsNum;
      public int Cascade1ObjectsNum;
      public int Cascade2ObjectsNum;
      public int Cascade3ObjectsNum;
      public int MeshesDrawn;
      public int SubmeshesDrawn;
      public int ObjectConstantsChanges;
      public int MaterialConstantsChanges;
      public int TrianglesDrawn;
      public int InstancesDrawn;
      public int Draw;
      public int DrawInstanced;
      public int DrawIndexed;
      public int DrawIndexedInstanced;
      public int DrawAuto;
      public int SetVB;
      public int SetIB;
      public int SetIL;
      public int SetVS;
      public int SetPS;
      public int SetGS;
      public int SetCB;
      public int SetRasterizerState;
      public int SetBlendState;
      public int BindShaderResources;

      public void Reset()
      {
        this.RenderableObjectsNum = 0;
        this.ViewFrustumObjectsNum = 0;
        this.Cascade0ObjectsNum = 0;
        this.Cascade1ObjectsNum = 0;
        this.Cascade2ObjectsNum = 0;
        this.Cascade3ObjectsNum = 0;
        this.MeshesDrawn = 0;
        this.SubmeshesDrawn = 0;
        this.ObjectConstantsChanges = 0;
        this.MaterialConstantsChanges = 0;
        this.TrianglesDrawn = 0;
        this.InstancesDrawn = 0;
        this.Draw = 0;
        this.DrawInstanced = 0;
        this.DrawIndexed = 0;
        this.DrawIndexedInstanced = 0;
        this.DrawAuto = 0;
        this.SetVB = 0;
        this.SetIB = 0;
        this.SetIL = 0;
        this.SetVS = 0;
        this.SetPS = 0;
        this.SetGS = 0;
        this.SetCB = 0;
        this.SetRasterizerState = 0;
        this.SetBlendState = 0;
        this.BindShaderResources = 0;
      }
    }

    public class MyPerAppLifetime
    {
      public List<string> LoadedTextureFiles = new List<string>();
      public List<string> LoadedModelFiles = new List<string>();
      public int Textures2DCount;
      public int Textures2DSizeInPixels;
      public double Textures2DSizeInMb;
      public int NonMipMappedTexturesCount;
      public int NonDxtCompressedTexturesCount;
      public int DxtCompressedTexturesCount;
      public int TextureCubesCount;
      public int TextureCubesSizeInPixels;
      public double TextureCubesSizeInMb;
      public int ModelsCount;
      public int MyModelsCount;
      public int MyModelsMeshesCount;
      public int MyModelsVertexesCount;
      public int MyModelsTrianglesCount;
      public int ModelVertexBuffersSize;
      public int ModelIndexBuffersSize;
      public int VoxelVertexBuffersSize;
      public int VoxelIndexBuffersSize;
      public int MyModelsFilesSize;
    }
  }
}
