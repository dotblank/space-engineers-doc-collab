﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageAddPointBillboardLocal
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public class MyRenderMessageAddPointBillboardLocal : IMyRenderMessage
  {
    public uint RenderObjectID;
    public string Material;
    public Color Color;
    public Vector3 LocalPos;
    public float Radius;
    public float Angle;
    public int Priority;
    public bool Colorize;
    public bool Near;
    public bool Lowres;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.Draw;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.AddPointBillboardLocal;
      }
    }
  }
}
