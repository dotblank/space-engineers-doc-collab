﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.Profiler.MyRenderProfiler
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using VRage;
using VRage.Profiler;
using VRageMath;
using VRageRender;

namespace VRageRender.Profiler
{
  public abstract class MyRenderProfiler
  {
    protected StringBuilder m_text = new StringBuilder(100);
    protected static MyRenderProfiler.DrawArea m_milisecondsGraphScale = new MyRenderProfiler.DrawArea()
    {
      x_start = 0.5f,
      y_start = 0.0f,
      x_scale = 0.745f,
      y_scale = 0.9f,
      y_inv_range = 0.04f
    };
    protected static MyRenderProfiler.DrawArea m_memoryGraphScale = new MyRenderProfiler.DrawArea()
    {
      x_start = 0.5f,
      y_start = -0.7f,
      x_scale = 0.745f,
      y_scale = 0.6f,
      y_inv_range = 999.9999f
    };
    protected static Color[] m_colors = new Color[19]
    {
      Color.Aqua,
      Color.Orange,
      Color.BlueViolet * 1.5f,
      Color.BurlyWood,
      Color.Chartreuse,
      Color.CornflowerBlue,
      Color.Cyan,
      Color.ForestGreen,
      Color.Fuchsia,
      Color.Gold,
      Color.GreenYellow,
      Color.LightBlue,
      Color.LightGreen,
      Color.LimeGreen,
      Color.Magenta,
      Color.Navy,
      Color.Orchid,
      Color.PeachPuff,
      Color.Purple
    };
    public static bool Paused = false;
    protected static List<MyProfiler> m_threadProfilers = new List<MyProfiler>(16);
    protected static bool m_enabled = false;
    protected static int m_selectedFrame = 0;
    protected static int m_levelLimit = -1;
    protected static bool m_useCustomFrame = false;
    protected static int m_frameLocalArea = MyProfiler.MAX_FRAMES;
    protected static MyProfiler.MyProfilerBlock m_fpsBlock = MyProfiler.CreateExternalBlock("FPS", -2);
    public const bool MemoryProfiling = false;
    protected static float m_fpsPctg;
    [ThreadStatic]
    private static MyProfiler m_threadProfiler;
    private static MyProfiler m_gpuProfiler;
    protected static MyProfiler m_selectedProfiler;

    private static MyProfiler GpuProfiler
    {
      get
      {
        if (MyRenderProfiler.m_gpuProfiler == null)
        {
          lock (MyRenderProfiler.m_threadProfilers)
          {
            MyRenderProfiler.m_gpuProfiler = new MyProfiler(MyRenderProfiler.m_threadProfilers.Count, false);
            MyRenderProfiler.m_gpuProfiler.m_customName = "GPU";
            MyRenderProfiler.m_threadProfilers.Add(MyRenderProfiler.m_gpuProfiler);
          }
        }
        return MyRenderProfiler.m_gpuProfiler;
      }
    }

    private static MyProfiler ThreadProfiler
    {
      get
      {
        if (MyRenderProfiler.m_threadProfiler == null)
        {
          lock (MyRenderProfiler.m_threadProfilers)
          {
            MyRenderProfiler.m_threadProfiler = new MyProfiler(MyRenderProfiler.m_threadProfilers.Count, false);
            MyRenderProfiler.m_threadProfilers.Add(MyRenderProfiler.m_threadProfiler);
          }
        }
        return MyRenderProfiler.m_threadProfiler;
      }
    }

    protected static Color IndexToColor(int index)
    {
      return MyRenderProfiler.m_colors[index % MyRenderProfiler.m_colors.Length];
    }

    public static MyProfiler.MyProfilerBlock FindBlockByIndex(int index)
    {
      List<MyProfiler.MyProfilerBlock> selectedRootChildren = MyRenderProfiler.m_selectedProfiler.SelectedRootChildren;
      if (index >= 0 && index < selectedRootChildren.Count)
        return selectedRootChildren[index];
      else
        return (MyProfiler.MyProfilerBlock) null;
    }

    protected static bool IsValidIndex(int frameIndex, int lastValidFrame)
    {
      return (frameIndex > lastValidFrame ? frameIndex : frameIndex + MyProfiler.MAX_FRAMES) > lastValidFrame + MyProfiler.UPDATE_WINDOW;
    }

    public static MyProfiler.MyProfilerBlock FindBlockByMax(int frameIndex, int lastValidFrame)
    {
      if (!MyRenderProfiler.IsValidIndex(frameIndex, lastValidFrame))
        return (MyProfiler.MyProfilerBlock) null;
      float num1 = float.MinValue;
      MyProfiler.MyProfilerBlock myProfilerBlock1 = (MyProfiler.MyProfilerBlock) null;
      List<MyProfiler.MyProfilerBlock> selectedRootChildren = MyRenderProfiler.m_selectedProfiler.SelectedRootChildren;
      for (int index = 0; index < selectedRootChildren.Count; ++index)
      {
        MyProfiler.MyProfilerBlock myProfilerBlock2 = selectedRootChildren[index];
        float num2 = myProfilerBlock2.Miliseconds[frameIndex];
        if ((double) num2 > (double) num1)
        {
          num1 = num2;
          myProfilerBlock1 = myProfilerBlock2;
        }
      }
      return myProfilerBlock1;
    }

    public static void HandleInput(RenderProfilerCommand command, int index)
    {
      switch (command)
      {
        case RenderProfilerCommand.Enable:
          if (MyRenderProfiler.m_enabled && MyRenderProfiler.m_selectedProfiler.SelectedRoot == null)
          {
            MyRenderProfiler.m_enabled = false;
            MyRenderProfiler.m_useCustomFrame = false;
            break;
          }
          else if (!MyRenderProfiler.m_enabled)
          {
            MyRenderProfiler.m_enabled = true;
            break;
          }
          else
          {
            if (MyRenderProfiler.m_selectedProfiler.SelectedRoot == null)
              break;
            MyRenderProfiler.m_selectedProfiler.SelectedRoot = MyRenderProfiler.m_selectedProfiler.SelectedRoot.Parent;
            break;
          }
        case RenderProfilerCommand.JumpToLevel:
          MyRenderProfiler.m_selectedProfiler.SelectedRoot = MyRenderProfiler.FindBlockByIndex(index - 1);
          break;
        case RenderProfilerCommand.Pause:
          MyRenderProfiler.Paused = !MyRenderProfiler.Paused;
          MyRenderProfiler.m_useCustomFrame = false;
          break;
        case RenderProfilerCommand.NextFrame:
          MyRenderProfiler.NextFrame();
          break;
        case RenderProfilerCommand.PreviousFrame:
          MyRenderProfiler.PreviousFrame();
          break;
        case RenderProfilerCommand.NextThread:
          lock (MyRenderProfiler.m_threadProfilers)
          {
            int local_2 = (MyRenderProfiler.m_threadProfilers.IndexOf(MyRenderProfiler.m_selectedProfiler) + 1) % MyRenderProfiler.m_threadProfilers.Count;
            MyRenderProfiler.m_selectedProfiler = MyRenderProfiler.m_threadProfilers[local_2];
            break;
          }
        case RenderProfilerCommand.PreviousThread:
          lock (MyRenderProfiler.m_threadProfilers)
          {
            int local_4 = (MyRenderProfiler.m_threadProfilers.IndexOf(MyRenderProfiler.m_selectedProfiler) - 1 + MyRenderProfiler.m_threadProfilers.Count) % MyRenderProfiler.m_threadProfilers.Count;
            MyRenderProfiler.m_selectedProfiler = MyRenderProfiler.m_threadProfilers[local_4];
            break;
          }
        case RenderProfilerCommand.IncreaseLevel:
          ++MyRenderProfiler.m_levelLimit;
          MyRenderProfiler.SetLevel();
          break;
        case RenderProfilerCommand.DecreaseLevel:
          --MyRenderProfiler.m_levelLimit;
          if (MyRenderProfiler.m_levelLimit < -1)
            MyRenderProfiler.m_levelLimit = -1;
          MyRenderProfiler.SetLevel();
          break;
        case RenderProfilerCommand.IncreaseLocalArea:
          MyRenderProfiler.m_frameLocalArea = Math.Min(MyProfiler.MAX_FRAMES, MyRenderProfiler.m_frameLocalArea * 2);
          break;
        case RenderProfilerCommand.DecreaseLocalArea:
          MyRenderProfiler.m_frameLocalArea = Math.Max(2, MyRenderProfiler.m_frameLocalArea / 2);
          break;
        case RenderProfilerCommand.FindMaxChild:
          int lastValidFrame;
          MyProfiler.MyProfilerBlock blockByMax;
          using (MyRenderProfiler.m_selectedProfiler.LockHistory(out lastValidFrame))
            blockByMax = MyRenderProfiler.FindBlockByMax(MyRenderProfiler.m_selectedFrame, lastValidFrame);
          if (blockByMax == null)
            break;
          MyRenderProfiler.m_selectedProfiler.SelectedRoot = blockByMax;
          break;
      }
    }

    private static void SetLevel()
    {
      lock (MyRenderProfiler.m_threadProfilers)
      {
        foreach (MyProfiler item_0 in MyRenderProfiler.m_threadProfilers)
          item_0.SetNewLevelLimit(MyRenderProfiler.m_levelLimit);
      }
    }

    private static void PreviousFrame()
    {
      MyRenderProfiler.m_useCustomFrame = true;
      --MyRenderProfiler.m_selectedFrame;
      if (MyRenderProfiler.m_selectedFrame >= 0)
        return;
      MyRenderProfiler.m_selectedFrame = MyProfiler.MAX_FRAMES - 1;
    }

    private static void NextFrame()
    {
      MyRenderProfiler.m_useCustomFrame = true;
      ++MyRenderProfiler.m_selectedFrame;
      if (MyRenderProfiler.m_selectedFrame < MyProfiler.MAX_FRAMES)
        return;
      MyRenderProfiler.m_selectedFrame = 0;
    }

    private static void FindMax(float[] data, int start, int end, ref float max, ref int maxIndex)
    {
      for (int index = start; index <= end; ++index)
      {
        if ((double) data[index] > (double) max)
        {
          max = data[index];
          maxIndex = index;
        }
      }
    }

    private static void FindMax(float[] data, int lower, int upper, int lastValidFrame, ref float max, ref int maxIndex)
    {
      int val2 = (lastValidFrame + 1 + MyProfiler.UPDATE_WINDOW) % MyProfiler.MAX_FRAMES;
      if (lastValidFrame > val2)
      {
        MyRenderProfiler.FindMax(data, Math.Max(lower, val2), Math.Min(lastValidFrame, upper), ref max, ref maxIndex);
      }
      else
      {
        MyRenderProfiler.FindMax(data, lower, Math.Min(lastValidFrame, upper), ref max, ref maxIndex);
        MyRenderProfiler.FindMax(data, Math.Max(lower, val2), upper, ref max, ref maxIndex);
      }
    }

    protected static float FindMaxWrap(float[] data, int lower, int upper, int lastValidFrame, out int maxIndex)
    {
      lower = (lower + MyProfiler.MAX_FRAMES) % MyProfiler.MAX_FRAMES;
      upper = (upper + MyProfiler.MAX_FRAMES) % MyProfiler.MAX_FRAMES;
      float max = 0.0f;
      maxIndex = -1;
      if (upper > lower)
      {
        MyRenderProfiler.FindMax(data, lower, upper, lastValidFrame, ref max, ref maxIndex);
      }
      else
      {
        MyRenderProfiler.FindMax(data, 0, upper, lastValidFrame, ref max, ref maxIndex);
        MyRenderProfiler.FindMax(data, lower, MyProfiler.MAX_FRAMES - 1, lastValidFrame, ref max, ref maxIndex);
      }
      return max;
    }

    [Conditional("RENDER_PROFILING")]
    public void GetAutocommit(ref bool val)
    {
      val = MyRenderProfiler.ThreadProfiler.AutoCommit;
    }

    [Conditional("RENDER_PROFILING")]
    public void SetAutocommit(bool val)
    {
      MyRenderProfiler.ThreadProfiler.AutoCommit = val;
    }

    [Conditional("RENDER_PROFILING")]
    public void Commit([CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      MyProfiler threadProfiler = MyRenderProfiler.ThreadProfiler;
      threadProfiler.Stopwatch.Restart();
      if (!MyRenderProfiler.Paused)
        threadProfiler.CommitFrame();
      else
        threadProfiler.ClearFrame();
      threadProfiler.ProfileCustomValue("Profiler.Commit", member, line, file, 0.0f, new MyTimeSpan?(MyTimeSpan.FromMiliseconds((double) threadProfiler.Stopwatch.ElapsedMilliseconds)), (string) null, (string) null);
    }

    [Conditional("RENDER_PROFILING")]
    public void Draw([CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      if (!MyRenderProfiler.m_enabled)
        return;
      MyProfiler threadProfiler = MyRenderProfiler.ThreadProfiler;
      threadProfiler.Stopwatch.Restart();
      MyProfiler drawProfiler = MyRenderProfiler.m_selectedProfiler;
      int lastValidFrame;
      using (drawProfiler.LockHistory(out lastValidFrame))
      {
        int frameToDraw = MyRenderProfiler.m_useCustomFrame ? MyRenderProfiler.m_selectedFrame : lastValidFrame;
        this.Draw(drawProfiler, lastValidFrame, frameToDraw);
      }
      threadProfiler.ProfileCustomValue("Profiler.Draw", member, line, file, 0.0f, new MyTimeSpan?(MyTimeSpan.FromMiliseconds((double) threadProfiler.Stopwatch.ElapsedMilliseconds)), (string) null, (string) null);
    }

    protected abstract void Draw(MyProfiler drawProfiler, int lastFrameIndex, int frameToDraw);

    [Conditional("RENDER_PROFILING")]
    public void StartProfilingBlock(string blockName = null, float customValue = 0.0f, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      MyRenderProfiler.ThreadProfiler.StartBlock(blockName, member, line, file);
      if (MyRenderProfiler.m_selectedProfiler != null)
        return;
      MyRenderProfiler.m_selectedProfiler = MyRenderProfiler.ThreadProfiler;
    }

    [Conditional("RENDER_PROFILING")]
    public void EndProfilingBlock(float customValue = 0.0f, MyTimeSpan? customTime = null, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      MyRenderProfiler.ThreadProfiler.EndBlock(member, line, file, customTime, customValue, timeFormat, valueFormat);
    }

    [Conditional("RENDER_PROFILING")]
    public void GPU_StartProfilingBlock(string blockName = null, float customValue = 0.0f, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      MyRenderProfiler.GpuProfiler.StartBlock(blockName, member, line, file);
    }

    [Conditional("RENDER_PROFILING")]
    public void GPU_EndProfilingBlock(float customValue = 0.0f, MyTimeSpan? customTime = null, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      MyRenderProfiler.GpuProfiler.EndBlock(member, line, file, customTime, customValue, timeFormat, valueFormat);
    }

    [Conditional("RENDER_PROFILING")]
    public void StartNextBlock(string name, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
    }

    [Conditional("RENDER_PROFILING")]
    public void InitMemoryHack(string name)
    {
      MyRenderProfiler.ThreadProfiler.InitMemoryHack(name);
    }

    [Conditional("RENDER_PROFILING")]
    public void ProfileCustomValue(string name, float value, MyTimeSpan? customTime = null, string timeFormat = null, string valueFormat = null, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0, [CallerFilePath] string file = "")
    {
      if (MyRenderProfiler.m_levelLimit != -1)
        return;
      MyRenderProfiler.ThreadProfiler.ProfileCustomValue(name, member, line, file, value, customTime, timeFormat, valueFormat);
    }

    protected class DrawArea
    {
      public float x_start;
      public float y_start;
      public float x_scale;
      public float y_scale;
      public float y_inv_range;

      public float y_range
      {
        get
        {
          return 1f / this.y_inv_range;
        }
      }
    }
  }
}
