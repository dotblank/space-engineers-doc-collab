﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderProxy
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using SharpDX;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using VRage;
using VRage.Common;
using VRage.Common.Generics;
using VRage.Common.Import;
using VRage.Common.Voxels;
using VRageMath;
using VRageRender.Graphics;
using VRageRender.Lights;
using VRageRender.Messages;
using VRageRender.Profiler;

namespace VRageRender
{
  public static class MyRenderProxy
  {
    public static bool DRAW_RENDER_STATS = false;
    private static IMyRender m_render = (IMyRender) null;
    public static bool IS_OFFICIAL = false;
    public static readonly uint RENDER_ID_UNASSIGNED = uint.MaxValue;
    public static MyRenderSettings Settings = new MyRenderSettings();
    public static MyMessagePool MessagePool = new MyMessagePool();
    public static Action WaitForFlushDelegate = (Action) null;
    public static bool LimitMaxQueueSize = false;

    public static MyRenderThread RenderThread { get; private set; }

    public static List<MyBillboard> BillboardsRead
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Read.Billboards;
      }
    }

    public static List<MyBillboard> BillboardsWrite
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Write.Billboards;
      }
    }

    public static Dictionary<int, MyBillboardViewProjection> BillboardsViewProjectionRead
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Read.Matrices;
      }
    }

    public static Dictionary<int, MyBillboardViewProjection> BillboardsViewProjectionWrite
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Write.Matrices;
      }
    }

    public static MyObjectsPoolSimple<MyBillboard> BillboardsPoolRead
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Read.Pool;
      }
    }

    public static MyObjectsPoolSimple<MyBillboard> BillboardsPoolWrite
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.Billboards.Write.Pool;
      }
    }

    public static MyObjectsPoolSimple<MyTriangleBillboard> TriangleBillboardsPoolRead
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.TriangleBillboards.Read.Pool;
      }
    }

    public static MyObjectsPoolSimple<MyTriangleBillboard> TriangleBillboardsPoolWrite
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.TriangleBillboards.Write.Pool;
      }
    }

    public static HashSet<uint> VisibleObjectsRead
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.VisibleObjects.Read;
      }
    }

    public static HashSet<uint> VisibleObjectsWrite
    {
      get
      {
        return MyRenderProxy.m_render.SharedData.VisibleObjects.Write;
      }
    }

    public static MyTimeSpan CurrentDrawTime
    {
      get
      {
        return MyRenderProxy.m_render.CurrentDrawTime;
      }
      set
      {
        MyRenderProxy.m_render.CurrentDrawTime = value;
      }
    }

    public static MyViewport MainViewport
    {
      get
      {
        return MyRenderProxy.m_render.MainViewport;
      }
    }

    public static Vector2I BackBufferResolution
    {
      get
      {
        return MyRenderProxy.m_render.BackBufferResolution;
      }
    }

    public static MyMessageQueue OutputQueue
    {
      get
      {
        return MyRenderProxy.m_render.OutputQueue;
      }
    }

    public static MyRenderDeviceSettings CreateDevice(MyRenderThread renderThread, IntPtr windowHandle, MyRenderDeviceSettings? settingsToTry)
    {
      MyRenderProxy.RenderThread = renderThread;
      return MyRenderProxy.m_render.CreateDevice(windowHandle, settingsToTry);
    }

    public static void DisposeDevice()
    {
      MyRenderProxy.m_render.DisposeDevice();
      MyRenderProxy.RenderThread = (MyRenderThread) null;
    }

    public static long GetAvailableTextureMemory()
    {
      return MyRenderProxy.m_render.GetAvailableTextureMemory();
    }

    public static MyRenderDeviceCooperativeLevel TestDeviceCooperativeLevel()
    {
      return MyRenderProxy.m_render.TestDeviceCooperativeLevel();
    }

    public static bool ResetDevice()
    {
      return MyRenderProxy.m_render.ResetDevice();
    }

    public static void DrawBegin()
    {
      MyRenderProxy.m_render.DrawBegin();
    }

    public static void DrawEnd()
    {
      MyRenderProxy.m_render.DrawEnd();
    }

    public static bool SettingsChanged(MyRenderDeviceSettings settings)
    {
      return MyRenderProxy.m_render.SettingsChanged(settings);
    }

    public static void ApplySettings(MyRenderDeviceSettings settings)
    {
      MyRenderProxy.m_render.ApplySettings(settings);
    }

    public static void Present()
    {
      MyRenderProxy.m_render.Present();
    }

    public static void ClearBackbuffer(ColorBGRA clearColor)
    {
      MyRenderProxy.m_render.ClearBackbuffer(clearColor);
    }

    public static string RendererInterfaceName()
    {
      return MyRenderProxy.m_render.ToString();
    }

    [Conditional("DEBUG")]
    public static void AssertRenderThread()
    {
    }

    private static void EnqueueMessage(IMyRenderMessage message)
    {
      MyRenderProxy.m_render.EnqueueMessage(message, MyRenderProxy.LimitMaxQueueSize);
    }

    public static void BeforeRender(MyTimeSpan? currentDrawTime)
    {
      MyRenderProxy.m_render.SharedData.BeforeRender(MyRenderProxy.m_render.Settings, currentDrawTime);
    }

    public static void AfterRender()
    {
      if (MyRenderProxy.m_render.SharedData == null)
        return;
      MyRenderProxy.m_render.SharedData.AfterRender();
    }

    public static void BeforeUpdate()
    {
      if (MyRenderProxy.m_render.SharedData == null)
        return;
      MyRenderProxy.m_render.SharedData.BeforeUpdate();
    }

    public static void AfterUpdate(MyTimeSpan? updateTimestamp)
    {
      if (MyRenderProxy.m_render.SharedData == null)
        return;
      MyRenderProxy.m_render.SharedData.AfterUpdate(MyRenderProxy.Settings, updateTimestamp);
    }

    public static void ProcessMessages()
    {
      MyRenderProxy.m_render.Draw(false);
    }

    public static void Draw()
    {
      MyRenderProxy.m_render.Draw(true);
    }

    public static MyRenderProfiler GetRenderProfiler()
    {
      return MyRenderProxy.m_render.GetRenderProfiler();
    }

    public static void Initialize(IMyRender render)
    {
      MyRenderProxy.m_render = render;
    }

    public static void LoadContent(MyRenderQualityEnum quality)
    {
      MyRenderProxy.m_render.LoadContent(quality);
    }

    public static void UnloadContent()
    {
      MyRenderProxy.m_render.UnloadContent();
      MyRenderProxy.ClearLargeMessages();
    }

    public static void ClearLargeMessages()
    {
      MyRenderProxy.MessagePool.Clear(MyRenderMessageEnum.CreateRenderInstanceBuffer);
      MyRenderProxy.MessagePool.Clear(MyRenderMessageEnum.UpdateRenderCubeInstanceBuffer);
      MyRenderProxy.MessagePool.Clear(MyRenderMessageEnum.UpdateRenderInstanceBuffer);
    }

    public static void UnloadData()
    {
      MyRenderProxy.ClearLargeMessages();
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageUnloadData>(MyRenderMessageEnum.UnloadData));
    }

    public static void SetGlobalValues(string rootDirectory, string rootDirectoryEffects, string rootDirectoryDebug)
    {
      MyRenderProxy.m_render.RootDirectory = rootDirectory;
      MyRenderProxy.m_render.RootDirectoryEffects = rootDirectoryEffects;
      MyRenderProxy.m_render.RootDirectoryDebug = rootDirectoryDebug;
    }

    public static void DrawSprite(string texture, ref VRageMath.RectangleF destination, bool scaleDestination, ref VRageMath.Rectangle? sourceRectangle, VRageMath.Color color, float rotation, VRageMath.Vector2 rightVector, ref VRageMath.Vector2 origin, SpriteEffects effects, float depth)
    {
      MyRenderMessageDrawSprite messageDrawSprite = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawSprite>(MyRenderMessageEnum.DrawSprite);
      messageDrawSprite.Texture = texture;
      messageDrawSprite.DestinationRectangle = destination;
      messageDrawSprite.SourceRectangle = sourceRectangle;
      messageDrawSprite.Color = color;
      messageDrawSprite.Rotation = rotation;
      messageDrawSprite.RightVector = rightVector;
      messageDrawSprite.Depth = depth;
      messageDrawSprite.Effects = effects;
      messageDrawSprite.Origin = origin;
      messageDrawSprite.ScaleDestination = scaleDestination;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDrawSprite);
    }

    public static void DrawSprite(string texture, VRageMath.Vector2 normalizedCoord, VRageMath.Vector2 normalizedSize, VRageMath.Color color, MyGuiDrawAlignEnum drawAlign, float rotation, VRageMath.Vector2 rightVector, float scale, VRageMath.Vector2? originNormalized, float rotSpeed = 0.0f)
    {
      MyRenderMessageDrawSpriteNormalized spriteNormalized = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawSpriteNormalized>(MyRenderMessageEnum.DrawSpriteNormalized);
      spriteNormalized.Texture = texture;
      spriteNormalized.NormalizedCoord = normalizedCoord;
      spriteNormalized.NormalizedSize = normalizedSize;
      spriteNormalized.Color = color;
      spriteNormalized.DrawAlign = drawAlign;
      spriteNormalized.Rotation = rotation;
      spriteNormalized.RightVector = rightVector;
      spriteNormalized.Scale = scale;
      spriteNormalized.OriginNormalized = originNormalized;
      spriteNormalized.RotationSpeed = rotSpeed;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) spriteNormalized);
    }

    public static void DrawSpriteAtlas(string texture, VRageMath.Vector2 position, VRageMath.Vector2 textureOffset, VRageMath.Vector2 textureSize, VRageMath.Vector2 rightVector, VRageMath.Vector2 scale, VRageMath.Color color, VRageMath.Vector2 halfSize)
    {
      MyRenderMessageDrawSpriteAtlas messageDrawSpriteAtlas = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawSpriteAtlas>(MyRenderMessageEnum.DrawSpriteAtlas);
      messageDrawSpriteAtlas.Texture = texture;
      messageDrawSpriteAtlas.Position = position;
      messageDrawSpriteAtlas.TextureOffset = textureOffset;
      messageDrawSpriteAtlas.TextureSize = textureSize;
      messageDrawSpriteAtlas.RightVector = rightVector;
      messageDrawSpriteAtlas.Scale = scale;
      messageDrawSpriteAtlas.Color = color;
      messageDrawSpriteAtlas.HalfSize = halfSize;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDrawSpriteAtlas);
    }

    public static void CreateFont(int fontId, string fontPath, bool isDebugFont = false)
    {
      MyRenderMessageCreateFont messageCreateFont = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateFont>(MyRenderMessageEnum.CreateFont);
      messageCreateFont.FontId = fontId;
      messageCreateFont.FontPath = fontPath;
      messageCreateFont.IsDebugFont = isDebugFont;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageCreateFont);
    }

    public static void DrawString(int fontIndex, VRageMath.Vector2 screenCoord, VRageMath.Color colorMask, StringBuilder text, float screenScale, float screenMaxWidth)
    {
      MyRenderMessageDrawString messageDrawString = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawString>(MyRenderMessageEnum.DrawString);
      StringBuilderExtensions.AppendStringBuilder(messageDrawString.Text.Clear(), text);
      messageDrawString.FontIndex = fontIndex;
      messageDrawString.ScreenCoord = screenCoord;
      messageDrawString.ColorMask = colorMask;
      messageDrawString.ScreenScale = screenScale;
      messageDrawString.ScreenMaxWidth = screenMaxWidth;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDrawString);
    }

    public static void PreloadTextures(string inDirectory, bool recursive)
    {
      MyRenderMessagePreloadTextures messagePreloadTextures = MyRenderProxy.MessagePool.Get<MyRenderMessagePreloadTextures>(MyRenderMessageEnum.PreloadTextures);
      messagePreloadTextures.InDirectory = inDirectory;
      messagePreloadTextures.Recursive = recursive;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messagePreloadTextures);
    }

    public static void UnloadTexture(string textureName)
    {
      MyRenderMessageUnloadTexture messageUnloadTexture = MyRenderProxy.MessagePool.Get<MyRenderMessageUnloadTexture>(MyRenderMessageEnum.UnloadTexture);
      messageUnloadTexture.Texture = textureName;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageUnloadTexture);
    }

    public static void RenderProfilerInput(RenderProfilerCommand command, int index)
    {
      MyRenderMessageRenderProfiler messageRenderProfiler = MyRenderProxy.MessagePool.Get<MyRenderMessageRenderProfiler>(MyRenderMessageEnum.RenderProfiler);
      messageRenderProfiler.Command = command;
      messageRenderProfiler.Index = index;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageRenderProfiler);
    }

    public static uint CreateRenderEntity(string debugName, string model, MatrixD worldMatrix, MyMeshDrawTechnique technique, RenderFlags flags, CullingOptions cullingOptions, VRageMath.Color diffuseColor, VRageMath.Vector3 colorMaskHsv, float dithering = 0.0f, float maxViewDistance = 3.402823E+38f)
    {
      MyRenderMessageCreateRenderEntity createRenderEntity = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderEntity>(MyRenderMessageEnum.CreateRenderEntity);
      uint id = MyRenderProxy.m_render.GlobalMessageCounter++;
      createRenderEntity.ID = id;
      createRenderEntity.DebugName = debugName;
      createRenderEntity.Model = model;
      createRenderEntity.WorldMatrix = worldMatrix;
      createRenderEntity.Technique = technique;
      createRenderEntity.Flags = flags;
      createRenderEntity.CullingOptions = cullingOptions;
      createRenderEntity.MaxViewDistance = maxViewDistance;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) createRenderEntity);
      MyRenderProxy.UpdateRenderEntity(id, new VRageMath.Color?(diffuseColor), new VRageMath.Vector3?(colorMaskHsv), dithering);
      return id;
    }

    public static uint CreateLineBasedObject()
    {
      MyRenderMessageCreateLineBasedObject createLineBasedObject = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateLineBasedObject>(MyRenderMessageEnum.CreateLineBasedObject);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      createLineBasedObject.ID = num;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) createLineBasedObject);
      return num;
    }

    public static MyRenderMessageSetRenderEntityData PrepareSetRenderEntityData()
    {
      MyRenderMessageSetRenderEntityData renderEntityData = MyRenderProxy.MessagePool.Get<MyRenderMessageSetRenderEntityData>(MyRenderMessageEnum.SetRenderEntityData);
      renderEntityData.ModelData.Clear();
      return renderEntityData;
    }

    public static void SetRenderEntityData(uint renderObjectId, MyRenderMessageSetRenderEntityData message)
    {
      message.ID = renderObjectId;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) message);
    }

    public static MyRenderMessageAddRuntimeModel PrepareAddRuntimeModel()
    {
      MyRenderMessageAddRuntimeModel messageAddRuntimeModel = MyRenderProxy.MessagePool.Get<MyRenderMessageAddRuntimeModel>(MyRenderMessageEnum.AddRuntimeModel);
      messageAddRuntimeModel.ModelData.Clear();
      return messageAddRuntimeModel;
    }

    public static void PreloadModel(string name)
    {
      MyRenderMessagePreloadModel messagePreloadModel = MyRenderProxy.MessagePool.Get<MyRenderMessagePreloadModel>(MyRenderMessageEnum.PreloadModel);
      messagePreloadModel.Name = name;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messagePreloadModel);
    }

    public static void PreloadMaterials(string name)
    {
      MyRenderMessagePreloadMaterials preloadMaterials = MyRenderProxy.MessagePool.Get<MyRenderMessagePreloadMaterials>(MyRenderMessageEnum.PreloadMaterials);
      preloadMaterials.Name = name;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) preloadMaterials);
    }

    public static void AddRuntimeModel(string name, MyRenderMessageAddRuntimeModel message)
    {
      message.Name = name;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) message);
    }

    public static uint SetRenderEntityLOD(uint id, float distance, string model)
    {
      MyRenderMessageSetRenderEntityLOD setRenderEntityLod = MyRenderProxy.MessagePool.Get<MyRenderMessageSetRenderEntityLOD>(MyRenderMessageEnum.SetRenderEntityLOD);
      setRenderEntityLod.ID = id;
      setRenderEntityLod.Distance = distance;
      setRenderEntityLod.Model = model;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) setRenderEntityLod);
      return id;
    }

    public static uint CreateRenderBatch(string debugName, MatrixD worldMatrix, RenderFlags flags, List<MyRenderBatchPart> batchParts)
    {
      MyRenderMessageCreateRenderBatch createRenderBatch = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderBatch>(MyRenderMessageEnum.CreateRenderBatch);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      createRenderBatch.ID = num;
      createRenderBatch.DebugName = debugName;
      createRenderBatch.WorldMatrix = worldMatrix;
      createRenderBatch.Flags = flags;
      createRenderBatch.RenderBatchParts.Clear();
      ListExtensions.AddList<MyRenderBatchPart>(createRenderBatch.RenderBatchParts, batchParts);
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) createRenderBatch);
      return num;
    }

    public static uint CreateRenderInstanceBuffer(string debugName, MyRenderInstanceBufferType type = MyRenderInstanceBufferType.Cube)
    {
      MyRenderMessageCreateRenderInstanceBuffer renderInstanceBuffer = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderInstanceBuffer>(MyRenderMessageEnum.CreateRenderInstanceBuffer);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      renderInstanceBuffer.ID = num;
      renderInstanceBuffer.DebugName = debugName;
      renderInstanceBuffer.Type = type;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderInstanceBuffer);
      return num;
    }

    public static void UpdateRenderCubeInstanceBuffer(uint id, List<MyCubeInstanceData> instanceData, int capacity)
    {
      MyRenderMessageUpdateRenderCubeInstanceBuffer cubeInstanceBuffer = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderCubeInstanceBuffer>(MyRenderMessageEnum.UpdateRenderCubeInstanceBuffer);
      cubeInstanceBuffer.ID = id;
      cubeInstanceBuffer.InstanceData.Clear();
      ListExtensions.AddList<MyCubeInstanceData>(cubeInstanceBuffer.InstanceData, instanceData);
      if (cubeInstanceBuffer.InstanceData.Count < cubeInstanceBuffer.InstanceData.Capacity && cubeInstanceBuffer.InstanceData.Capacity > 20000)
        cubeInstanceBuffer.InstanceData.TrimExcess();
      cubeInstanceBuffer.Capacity = capacity;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) cubeInstanceBuffer);
    }

    public static void UpdateRenderInstanceBuffer(uint id, List<MyInstanceData> instanceData, int capacity)
    {
      MyRenderMessageUpdateRenderInstanceBuffer renderInstanceBuffer = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderInstanceBuffer>(MyRenderMessageEnum.UpdateRenderInstanceBuffer);
      renderInstanceBuffer.ID = id;
      renderInstanceBuffer.InstanceData.Clear();
      ListExtensions.AddList<MyInstanceData>(renderInstanceBuffer.InstanceData, instanceData);
      if (renderInstanceBuffer.InstanceData.Count < renderInstanceBuffer.InstanceData.Capacity && renderInstanceBuffer.InstanceData.Capacity > 20000)
        renderInstanceBuffer.InstanceData.TrimExcess();
      renderInstanceBuffer.Capacity = capacity;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderInstanceBuffer);
    }

    public static void UpdateLineBasedObject(uint id, Vector3D worldPointA, Vector3D worldPointB)
    {
      MyRenderMessageUpdateLineBasedObject updateLineBasedObject = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateLineBasedObject>(MyRenderMessageEnum.UpdateLineBasedObject);
      updateLineBasedObject.ID = id;
      updateLineBasedObject.WorldPointA = worldPointA;
      updateLineBasedObject.WorldPointB = worldPointB;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateLineBasedObject);
    }

    public static uint CreateManualCullObject(string debugName, MatrixD worldMatrix)
    {
      MyRenderMessageCreateManualCullObject manualCullObject = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateManualCullObject>(MyRenderMessageEnum.CreateManualCullObject);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      manualCullObject.ID = num;
      manualCullObject.DebugName = debugName;
      manualCullObject.WorldMatrix = worldMatrix;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) manualCullObject);
      return num;
    }

    public static void SetParentCullObject(uint renderObject, uint parentCullObject, VRageMath.Matrix? childToParent = null)
    {
      MyRenderMessageSetParentCullObject parentCullObject1 = MyRenderProxy.MessagePool.Get<MyRenderMessageSetParentCullObject>(MyRenderMessageEnum.SetParentCullObject);
      parentCullObject1.ID = renderObject;
      parentCullObject1.CullObjectID = parentCullObject;
      parentCullObject1.ChildToParent = childToParent;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) parentCullObject1);
    }

    public static void SetCameraViewMatrix(MatrixD viewMatrix, VRageMath.Matrix projectionMatrix, VRageMath.Matrix nearProjectionMatrix, float safenear, float nearFov, float fov, float nearPlane, float farPlane, float nearObjectsNearPlane, float nearObjectsFarPlane)
    {
      MyRenderMessageSetCameraViewMatrix cameraViewMatrix = MyRenderProxy.MessagePool.Get<MyRenderMessageSetCameraViewMatrix>(MyRenderMessageEnum.SetCameraViewMatrix);
      cameraViewMatrix.ViewMatrix = viewMatrix;
      cameraViewMatrix.ProjectionMatrix = projectionMatrix;
      cameraViewMatrix.NearProjectionMatrix = nearProjectionMatrix;
      cameraViewMatrix.SafeNear = safenear;
      cameraViewMatrix.NearFOV = nearFov;
      cameraViewMatrix.FOV = fov;
      cameraViewMatrix.NearPlane = nearPlane;
      cameraViewMatrix.FarPlane = farPlane;
      cameraViewMatrix.NearObjectsNearPlane = nearObjectsNearPlane;
      cameraViewMatrix.NearObjectsFarPlane = nearObjectsFarPlane;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) cameraViewMatrix);
    }

    public static void Draw3DScene()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageDrawScene>(MyRenderMessageEnum.DrawScene));
    }

    public static void UpdateRenderObject(uint id, ref MatrixD worldMatrix, bool sortIntoCulling, BoundingBoxD? aabb = null)
    {
      MyRenderMessageUpdateRenderObject updateRenderObject = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderObject>(MyRenderMessageEnum.UpdateRenderObject);
      updateRenderObject.ID = id;
      updateRenderObject.WorldMatrix = worldMatrix;
      updateRenderObject.SortIntoCulling = sortIntoCulling;
      updateRenderObject.AABB = aabb;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateRenderObject);
    }

    public static void UpdateRenderObjectVisibility(uint id, bool visible, bool near)
    {
      MyRenderMessageUpdateRenderObjectVisibility objectVisibility = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderObjectVisibility>(MyRenderMessageEnum.UpdateRenderObjectVisibility);
      objectVisibility.ID = id;
      objectVisibility.Visible = visible;
      objectVisibility.NearFlag = near;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) objectVisibility);
    }

    public static void RemoveRenderObject(uint id)
    {
      MyRenderMessageRemoveRenderObject removeRenderObject = MyRenderProxy.MessagePool.Get<MyRenderMessageRemoveRenderObject>(MyRenderMessageEnum.RemoveRenderObject);
      removeRenderObject.ID = id;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) removeRenderObject);
    }

    public static void UpdateRenderEntity(uint id, VRageMath.Color? diffuseColor, VRageMath.Vector3? colorMaskHsv, float dithering = 0.0f)
    {
      MyRenderMessageUpdateRenderEntity updateRenderEntity = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderEntity>(MyRenderMessageEnum.UpdateRenderEntity);
      updateRenderEntity.ID = id;
      updateRenderEntity.DiffuseColor = diffuseColor;
      updateRenderEntity.ColorMaskHSV = colorMaskHsv;
      updateRenderEntity.Dithering = dithering;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateRenderEntity);
    }

    public static void SetInstanceBuffer(uint entityId, uint instanceBufferId, int instanceStart, int instanceCount, VRageMath.BoundingBox entityLocalAabb)
    {
      MyRenderMessageSetInstanceBuffer setInstanceBuffer = MyRenderProxy.MessagePool.Get<MyRenderMessageSetInstanceBuffer>(MyRenderMessageEnum.SetInstanceBuffer);
      setInstanceBuffer.ID = entityId;
      setInstanceBuffer.InstanceBufferId = instanceBufferId;
      setInstanceBuffer.InstanceStart = instanceStart;
      setInstanceBuffer.InstanceCount = instanceCount;
      setInstanceBuffer.LocalAabb = entityLocalAabb;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) setInstanceBuffer);
    }

    public static void EnableRenderModule(uint id, bool enable)
    {
      MyRenderMessageEnableRenderModule enableRenderModule = MyRenderProxy.MessagePool.Get<MyRenderMessageEnableRenderModule>(MyRenderMessageEnum.EnableRenderModule);
      enableRenderModule.ID = id;
      enableRenderModule.Enable = enable;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) enableRenderModule);
    }

    public static void UseCustomDrawMatrix(uint id, MatrixD drawMatrix, bool enable)
    {
      MyRenderMessageUseCustomDrawMatrix customDrawMatrix = MyRenderProxy.MessagePool.Get<MyRenderMessageUseCustomDrawMatrix>(MyRenderMessageEnum.UseCustomDrawMatrix);
      customDrawMatrix.ID = id;
      customDrawMatrix.DrawMatrix = drawMatrix;
      customDrawMatrix.Enable = enable;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) customDrawMatrix);
    }

    public static uint CreateClipmap(MatrixD worldMatrix, Vector3I sizeLod0)
    {
      MyRenderMessageCreateClipmap messageCreateClipmap = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateClipmap>(MyRenderMessageEnum.CreateClipmap);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      messageCreateClipmap.ClipmapId = num;
      messageCreateClipmap.WorldMatrix = worldMatrix;
      messageCreateClipmap.SizeLod0 = sizeLod0;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageCreateClipmap);
      return num;
    }

    public static void UpdateClipmapCell(uint clipmapId, MyCellCoord cell, List<MyClipmapCellBatch> batches, VRageMath.Vector3 positionOffset, VRageMath.Vector3 positionScale, VRageMath.BoundingBox meshAabb)
    {
      MyRenderMessageUpdateClipmapCell updateClipmapCell = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateClipmapCell>(MyRenderMessageEnum.UpdateClipmapCell);
      updateClipmapCell.ClipmapId = clipmapId;
      updateClipmapCell.Cell = cell;
      ListExtensions.AddList<MyClipmapCellBatch>(updateClipmapCell.Batches, batches);
      updateClipmapCell.PositionOffset = positionOffset;
      updateClipmapCell.PositionScale = positionScale;
      updateClipmapCell.MeshAabb = meshAabb;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateClipmapCell);
    }

    public static void InvalidateClipmapRange(uint clipmapId, Vector3I minCellLod0, Vector3I maxCellLod0)
    {
      MyRenderMessageInvalidateClipmapRange invalidateClipmapRange = MyRenderProxy.MessagePool.Get<MyRenderMessageInvalidateClipmapRange>(MyRenderMessageEnum.InvalidateClipmapRange);
      invalidateClipmapRange.ClipmapId = clipmapId;
      invalidateClipmapRange.MinCellLod0 = minCellLod0;
      invalidateClipmapRange.MaxCellLod0 = maxCellLod0;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) invalidateClipmapRange);
    }

    public static void RebuildCullingStructure()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageRebuildCullingStructure>(MyRenderMessageEnum.RebuildCullingStructure));
    }

    public static void ReloadEffects()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageReloadEffects>(MyRenderMessageEnum.ReloadEffects));
    }

    public static void ReloadModels()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageReloadModels>(MyRenderMessageEnum.ReloadModels));
    }

    public static void ReloadTextures()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageReloadTextures>(MyRenderMessageEnum.ReloadTextures));
    }

    public static void ReloadContent(MyRenderQualityEnum quality)
    {
      MyRenderProxy.m_render.ReloadContent(quality);
    }

    public static void UpdateEnvironmentMap()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateEnvironmentMap>(MyRenderMessageEnum.UpdateEnvironmentMap));
    }

    public static void CreateRenderVoxelMaterials(MyRenderVoxelMaterialData[] materials)
    {
      MyRenderMessageCreateRenderVoxelMaterials renderVoxelMaterials = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderVoxelMaterials>(MyRenderMessageEnum.CreateRenderVoxelMaterials);
      renderVoxelMaterials.Materials = materials;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderVoxelMaterials);
    }

    public static uint CreateRenderVoxelDebris(string debugName, string model, MatrixD worldMatrix, float textureCoordOffset, float textureCoordScale, float textureColorMultiplier, byte voxelMaterialIndex)
    {
      MyRenderMessageCreateRenderVoxelDebris renderVoxelDebris = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderVoxelDebris>(MyRenderMessageEnum.CreateRenderVoxelDebris);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      renderVoxelDebris.ID = num;
      renderVoxelDebris.DebugName = debugName;
      renderVoxelDebris.Model = model;
      renderVoxelDebris.WorldMatrix = worldMatrix;
      renderVoxelDebris.TextureCoordOffset = textureCoordOffset;
      renderVoxelDebris.TextureCoordScale = textureCoordScale;
      renderVoxelDebris.TextureColorMultiplier = textureColorMultiplier;
      renderVoxelDebris.VoxelMaterialIndex = voxelMaterialIndex;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderVoxelDebris);
      return num;
    }

    public static void UpdateModelProperties(uint id, int lod, string model, int meshIndex, string materialName, bool? enabled, VRageMath.Color? diffuseColor, float? specularPower, float? specularIntensity, float? emissivity)
    {
      if ((int) id == (int) MyRenderProxy.RENDER_ID_UNASSIGNED && string.IsNullOrEmpty(model))
        return;
      MyRenderMessageUpdateModelProperties updateModelProperties = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateModelProperties>(MyRenderMessageEnum.UpdateModelProperties);
      updateModelProperties.ID = id;
      updateModelProperties.LOD = lod;
      updateModelProperties.Model = model;
      updateModelProperties.MeshIndex = meshIndex;
      updateModelProperties.MaterialName = materialName;
      updateModelProperties.Enabled = enabled;
      updateModelProperties.DiffuseColor = diffuseColor;
      updateModelProperties.SpecularIntensity = specularIntensity;
      updateModelProperties.SpecularPower = specularPower;
      updateModelProperties.Emissivity = emissivity;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateModelProperties);
    }

    public static void ChangeModel(uint id, int LOD, string model, bool useForShadow)
    {
      MyRenderMessageChangeModel messageChangeModel = MyRenderProxy.MessagePool.Get<MyRenderMessageChangeModel>(MyRenderMessageEnum.ChangeModel);
      messageChangeModel.ID = id;
      messageChangeModel.Model = model;
      messageChangeModel.LOD = LOD;
      messageChangeModel.UseForShadow = useForShadow;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageChangeModel);
    }

    public static void ChangeModelMaterial(string model, string material)
    {
      MyRenderMessageChangeModelMaterial changeModelMaterial = MyRenderProxy.MessagePool.Get<MyRenderMessageChangeModelMaterial>(MyRenderMessageEnum.ChangeModelMaterial);
      changeModelMaterial.Model = model;
      changeModelMaterial.Material = material;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) changeModelMaterial);
    }

    public static void UpdateVoxelMaterialProperties(byte voxelMaterialIndex, float specularPower, float specularIntensity)
    {
      MyRenderMessageUpdateVoxelMaterialsProperties materialsProperties = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateVoxelMaterialsProperties>(MyRenderMessageEnum.UpdateVoxelMaterialsProperties);
      materialsProperties.MaterialIndex = voxelMaterialIndex;
      materialsProperties.SpecularIntensity = specularIntensity;
      materialsProperties.SpecularPower = specularPower;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) materialsProperties);
    }

    private static void EnqueueOutputMessage(IMyRenderMessage message)
    {
      MyRenderProxy.m_render.EnqueueOutputMessage(message);
    }

    public static void RequireClipmapCell(uint clipmapId, MyCellCoord cell, bool highPriority)
    {
      MyRenderMessageRequireClipmapCell requireClipmapCell = MyRenderProxy.MessagePool.Get<MyRenderMessageRequireClipmapCell>(MyRenderMessageEnum.RequireClipmapCell);
      requireClipmapCell.ClipmapId = clipmapId;
      requireClipmapCell.Cell = cell;
      requireClipmapCell.HighPriority = highPriority;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) requireClipmapCell);
    }

    public static void CancelClipmapCell(uint clipmapId, MyCellCoord cell)
    {
      MyRenderMessageCancelClipmapCell cancelClipmapCell = MyRenderProxy.MessagePool.Get<MyRenderMessageCancelClipmapCell>(MyRenderMessageEnum.CancelClipmapCell);
      cancelClipmapCell.ClipmapId = clipmapId;
      cancelClipmapCell.Cell = cell;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) cancelClipmapCell);
    }

    public static uint CreateRenderLight(LightTypeEnum type, Vector3D position, int renderObjectID, float offset, VRageMath.Color color, VRageMath.Color specularColor, float falloff, float range, float intensity, bool lightOn, bool useInForwardRender, float reflectorIntensity, bool reflectorOn, VRageMath.Vector3 reflectorDirection, VRageMath.Vector3 reflectorUp, float reflectorConeMaxAngleCos, VRageMath.Color reflectorColor, float reflectorRange, float reflectorFalloff, string reflectorTexture, float shadowDistance, bool castShadows, bool glareOn, MyGlareTypeEnum glareType, float glareSize, float glareQuerySize, float glareIntensity, string glareMaterial, float glareMaxDistance)
    {
      MyRenderMessageCreateRenderLight createRenderLight = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderLight>(MyRenderMessageEnum.CreateRenderLight);
      uint id = MyRenderProxy.m_render.GlobalMessageCounter++;
      createRenderLight.ID = id;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) createRenderLight);
      MyRenderProxy.UpdateRenderLight(id, type, position, renderObjectID, offset, color, specularColor, falloff, range, intensity, lightOn, useInForwardRender, reflectorIntensity, reflectorOn, reflectorDirection, reflectorUp, reflectorConeMaxAngleCos, reflectorColor, reflectorRange, reflectorFalloff, reflectorTexture, shadowDistance, castShadows, glareOn, glareType, glareSize, glareQuerySize, glareIntensity, glareMaterial, glareMaxDistance);
      return id;
    }

    public static void UpdateRenderLight(uint id, LightTypeEnum type, Vector3D position, int renderObjectID, float offset, VRageMath.Color color, VRageMath.Color specularColor, float falloff, float range, float intensity, bool lightOn, bool useInForwardRender, float reflectorIntensity, bool reflectorOn, VRageMath.Vector3 reflectorDirection, VRageMath.Vector3 reflectorUp, float reflectorConeMaxAngleCos, VRageMath.Color reflectorColor, float reflectorRange, float reflectorFalloff, string reflectorTexture, float shadowDistance, bool castShadows, bool glareOn, MyGlareTypeEnum glareType, float glareSize, float glareQuerySize, float glareIntensity, string glareMaterial, float glareMaxDistance)
    {
      MyRenderMessageUpdateRenderLight updateRenderLight = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderLight>(MyRenderMessageEnum.UpdateRenderLight);
      updateRenderLight.ID = id;
      updateRenderLight.Type = type;
      updateRenderLight.Position = position;
      updateRenderLight.ParentID = renderObjectID;
      updateRenderLight.Offset = offset;
      updateRenderLight.Color = color;
      updateRenderLight.SpecularColor = specularColor;
      updateRenderLight.Falloff = falloff;
      updateRenderLight.Range = range;
      updateRenderLight.Intensity = intensity;
      updateRenderLight.LightOn = lightOn;
      updateRenderLight.UseInForwardRender = useInForwardRender;
      updateRenderLight.ReflectorIntensity = reflectorIntensity;
      updateRenderLight.ReflectorOn = reflectorOn;
      updateRenderLight.ReflectorDirection = reflectorDirection;
      updateRenderLight.ReflectorUp = reflectorUp;
      updateRenderLight.ReflectorConeMaxAngleCos = reflectorConeMaxAngleCos;
      updateRenderLight.ReflectorColor = reflectorColor;
      updateRenderLight.ReflectorRange = reflectorRange;
      updateRenderLight.ReflectorFalloff = reflectorFalloff;
      updateRenderLight.ReflectorTexture = reflectorTexture;
      updateRenderLight.ShadowDistance = shadowDistance;
      updateRenderLight.CastShadows = castShadows;
      updateRenderLight.GlareOn = glareOn;
      updateRenderLight.GlareType = glareType;
      updateRenderLight.GlareSize = glareSize;
      updateRenderLight.GlareQuerySize = glareQuerySize;
      updateRenderLight.GlareIntensity = glareIntensity;
      updateRenderLight.GlareMaterial = glareMaterial;
      updateRenderLight.GlareMaxDistance = glareMaxDistance;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateRenderLight);
    }

    public static void SetLightShadowIgnore(uint id, uint ignoreId)
    {
      MyRenderMessageSetLightShadowIgnore lightShadowIgnore = MyRenderProxy.MessagePool.Get<MyRenderMessageSetLightShadowIgnore>(MyRenderMessageEnum.SetLightShadowIgnore);
      lightShadowIgnore.ID = id;
      lightShadowIgnore.ID2 = ignoreId;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) lightShadowIgnore);
    }

    public static void ClearLightShadowIgnore(uint id)
    {
      MyRenderMessageClearLightShadowIgnore lightShadowIgnore = MyRenderProxy.MessagePool.Get<MyRenderMessageClearLightShadowIgnore>(MyRenderMessageEnum.ClearLightShadowIgnore);
      lightShadowIgnore.ID = id;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) lightShadowIgnore);
    }

    public static void UpdateRenderEnvironment(VRageMath.Vector3 sunDirection, VRageMath.Color sunColor, VRageMath.Color sunBackColor, VRageMath.Color sunSpecularColor, float sunIntensity, float sunBackIntensity, bool sunLightOn, VRageMath.Color ambientColor, float ambientMultiplier, float envAmbientIntensity, VRageMath.Color backgroundColor, string backgroundTexture, VRageMath.Quaternion backgroundOrientation, float sunSizeMultiplier, float distanceToSun, string sunMaterial)
    {
      MyRenderMessageUpdateRenderEnvironment renderEnvironment = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderEnvironment>(MyRenderMessageEnum.UpdateRenderEnvironment);
      renderEnvironment.SunDirection = sunDirection;
      renderEnvironment.SunColor = sunColor;
      renderEnvironment.SunBackColor = sunBackColor;
      renderEnvironment.SunSpecularColor = sunSpecularColor;
      renderEnvironment.SunIntensity = sunIntensity;
      renderEnvironment.SunBackIntensity = sunBackIntensity;
      renderEnvironment.SunLightOn = sunLightOn;
      renderEnvironment.AmbientColor = ambientColor;
      renderEnvironment.AmbientMultiplier = ambientMultiplier;
      renderEnvironment.EnvAmbientIntensity = envAmbientIntensity;
      renderEnvironment.BackgroundColor = backgroundColor;
      renderEnvironment.BackgroundTexture = backgroundTexture;
      renderEnvironment.BackgroundOrientation = backgroundOrientation;
      renderEnvironment.SunSizeMultiplier = sunSizeMultiplier;
      renderEnvironment.DistanceToSun = distanceToSun;
      renderEnvironment.SunMaterial = sunMaterial;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderEnvironment);
    }

    public static void ResetEnvironmentProbes()
    {
      MyRenderProxy.m_render.ResetEnvironmentProbes();
    }

    public static void UpdateHDRSettings(bool enabled, float exposure, float threshold, float bloomIntensity, float bloomIntensityBackground, float verticalBlurAmount, float horizontalBlurAmount, int numberOfBlurPasses)
    {
      MyRenderMessageUpdateHDRSettings updateHdrSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateHDRSettings>(MyRenderMessageEnum.UpdateHDRSettings);
      updateHdrSettings.Enabled = enabled;
      updateHdrSettings.Exposure = exposure;
      updateHdrSettings.Threshold = threshold;
      updateHdrSettings.BloomIntensity = bloomIntensity;
      updateHdrSettings.BloomIntensityBackground = bloomIntensityBackground;
      updateHdrSettings.VerticalBlurAmount = verticalBlurAmount;
      updateHdrSettings.HorizontalBlurAmount = horizontalBlurAmount;
      updateHdrSettings.NumberOfBlurPasses = numberOfBlurPasses;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateHdrSettings);
    }

    public static void UpdateAntiAliasSettings(bool enabled)
    {
      MyRenderMessageUpdateAntiAliasSettings antiAliasSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateAntiAliasSettings>(MyRenderMessageEnum.UpdateAntiAliasSettings);
      antiAliasSettings.Enabled = enabled;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) antiAliasSettings);
    }

    public static void UpdateVignettingSettings(bool enabled, float vignettingPower)
    {
      MyRenderMessageUpdateVignettingSettings vignettingSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateVignettingSettings>(MyRenderMessageEnum.UpdateVignettingSettings);
      vignettingSettings.Enabled = enabled;
      vignettingSettings.VignettingPower = vignettingPower;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) vignettingSettings);
    }

    public static void UpdateColorMappingSettings(bool enabled)
    {
      MyRenderMessageUpdateColorMappingSettings colorMappingSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateColorMappingSettings>(MyRenderMessageEnum.UpdateColorMappingSettings);
      colorMappingSettings.Enabled = enabled;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) colorMappingSettings);
    }

    public static void UpdateChromaticAberrationSettings(bool enabled, float distortionLens, float distortionCubic, VRageMath.Vector3 distortionWeights)
    {
      MyRenderMessageUpdateChromaticAberrationSettings aberrationSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateChromaticAberrationSettings>(MyRenderMessageEnum.UpdateChromaticAberrationSettings);
      aberrationSettings.Enabled = enabled;
      aberrationSettings.DistortionLens = distortionLens;
      aberrationSettings.DistortionCubic = distortionCubic;
      aberrationSettings.DistortionWeights = distortionWeights;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) aberrationSettings);
    }

    public static void UpdateContrastSettings(bool enabled, float contrast, float hue, float saturation)
    {
      MyRenderMessageUpdateContrastSettings contrastSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateContrastSettings>(MyRenderMessageEnum.UpdateContrastSettings);
      contrastSettings.Enabled = enabled;
      contrastSettings.Contrast = contrast;
      contrastSettings.Hue = hue;
      contrastSettings.Saturation = saturation;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) contrastSettings);
    }

    public static void UpdateSSAOSettings(bool enabled, bool showOnlySSAO, bool useBlur, float minRadius, float maxRadius, float radiusGrowZScale, float cameraZFar, float bias, float falloff, float normValue, float contrast)
    {
      MyRenderMessageUpdateSSAOSettings updateSsaoSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateSSAOSettings>(MyRenderMessageEnum.UpdateSSAOSettings);
      updateSsaoSettings.Enabled = enabled;
      updateSsaoSettings.ShowOnlySSAO = showOnlySSAO;
      updateSsaoSettings.UseBlur = useBlur;
      updateSsaoSettings.MinRadius = minRadius;
      updateSsaoSettings.MaxRadius = maxRadius;
      updateSsaoSettings.RadiusGrowZScale = radiusGrowZScale;
      updateSsaoSettings.CameraZFar = cameraZFar;
      updateSsaoSettings.Bias = bias;
      updateSsaoSettings.Falloff = falloff;
      updateSsaoSettings.NormValue = normValue;
      updateSsaoSettings.Contrast = contrast;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateSsaoSettings);
    }

    public static void UpdateFogSettings(bool enable, float fogNear, float fogFar, float fogMultiplier, float fogBacklightMultiplier, VRageMath.Color fogColor)
    {
      MyRenderMessageUpdateFogSettings updateFogSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateFogSettings>(MyRenderMessageEnum.UpdateFogSettings);
      updateFogSettings.Enabled = enable;
      updateFogSettings.FogNear = fogNear;
      updateFogSettings.FogFar = fogFar;
      updateFogSettings.FogMultiplier = fogMultiplier;
      updateFogSettings.FogBacklightMultiplier = fogBacklightMultiplier;
      updateFogSettings.FogColor = fogColor;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateFogSettings);
    }

    public static void UpdateGodRaysSettings(bool enable, float density, float weight, float decay, float exposition, bool applyBlur)
    {
      MyRenderMessageUpdateGodRaysSettings updateGodRaysSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateGodRaysSettings>(MyRenderMessageEnum.UpdateGodRaysSettings);
      updateGodRaysSettings.Enabled = enable;
      updateGodRaysSettings.Density = density;
      updateGodRaysSettings.Weight = weight;
      updateGodRaysSettings.Decay = decay;
      updateGodRaysSettings.Exposition = exposition;
      updateGodRaysSettings.ApplyBlur = applyBlur;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateGodRaysSettings);
    }

    public static uint PlayVideo(string videoFile, float volume)
    {
      MyRenderMessagePlayVideo messagePlayVideo = MyRenderProxy.MessagePool.Get<MyRenderMessagePlayVideo>(MyRenderMessageEnum.PlayVideo);
      uint num = MyRenderProxy.m_render.GlobalMessageCounter++;
      messagePlayVideo.ID = num;
      messagePlayVideo.VideoFile = videoFile;
      messagePlayVideo.Volume = volume;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messagePlayVideo);
      return num;
    }

    public static void CloseVideo(uint id)
    {
      MyRenderMessageCloseVideo messageCloseVideo = MyRenderProxy.MessagePool.Get<MyRenderMessageCloseVideo>(MyRenderMessageEnum.CloseVideo);
      messageCloseVideo.ID = id;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageCloseVideo);
    }

    public static void DrawVideo(uint id, VRageMath.Rectangle rect, VRageMath.Color color, MyVideoRectangleFitMode fitMode = MyVideoRectangleFitMode.None)
    {
      MyRenderMessageDrawVideo messageDrawVideo = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawVideo>(MyRenderMessageEnum.DrawVideo);
      messageDrawVideo.ID = id;
      messageDrawVideo.Rectangle = rect;
      messageDrawVideo.Color = color;
      messageDrawVideo.FitMode = fitMode;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDrawVideo);
    }

    public static void UpdateVideo(uint id)
    {
      MyRenderMessageUpdateVideo messageUpdateVideo = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateVideo>(MyRenderMessageEnum.UpdateVideo);
      messageUpdateVideo.ID = id;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageUpdateVideo);
    }

    public static void SetVideoVolume(uint id, float volume)
    {
      MyRenderMessageSetVideoVolume messageSetVideoVolume = MyRenderProxy.MessagePool.Get<MyRenderMessageSetVideoVolume>(MyRenderMessageEnum.SetVideoVolume);
      messageSetVideoVolume.ID = id;
      messageSetVideoVolume.Volume = volume;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageSetVideoVolume);
    }

    public static bool IsVideoValid(uint id)
    {
      return MyRenderProxy.m_render.IsVideoValid(id);
    }

    public static VideoState GetVideoState(uint id)
    {
      return MyRenderProxy.m_render.GetVideoState(id);
    }

    public static void DrawSecondaryCamera(VRageMath.Matrix viewMatrix)
    {
      MyRenderMessageDrawSecondaryCamera drawSecondaryCamera = MyRenderProxy.MessagePool.Get<MyRenderMessageDrawSecondaryCamera>(MyRenderMessageEnum.DrawSecondaryCamera);
      drawSecondaryCamera.ViewMatrix = viewMatrix;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) drawSecondaryCamera);
    }

    public static void HideDecals(uint id, VRageMath.Vector3 center, float radius)
    {
      MyRenderMessageHideDecals messageHideDecals = MyRenderProxy.MessagePool.Get<MyRenderMessageHideDecals>(MyRenderMessageEnum.HideDecals);
      messageHideDecals.ID = id;
      messageHideDecals.Center = center;
      messageHideDecals.Radius = radius;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageHideDecals);
    }

    public static void UpdateCockpitGlass(bool visible, string model, MatrixD worldMatrix, float dirtAlpha)
    {
      MyRenderMessageUpdateCockpitGlass updateCockpitGlass = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateCockpitGlass>(MyRenderMessageEnum.UpdateCockpitGlass);
      updateCockpitGlass.Visible = visible;
      updateCockpitGlass.Model = model;
      updateCockpitGlass.WorldMatrix = worldMatrix;
      updateCockpitGlass.DirtAlpha = dirtAlpha;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateCockpitGlass);
    }

    public static void AddBillboard(MyBillboard billboard)
    {
      MyUtils.AssertIsValid(billboard.Position0);
      MyUtils.AssertIsValid(billboard.Position1);
      MyUtils.AssertIsValid(billboard.Position2);
      MyUtils.AssertIsValid(billboard.Position3);
      MyRenderProxy.BillboardsWrite.Add(billboard);
    }

    public static void AddBillboards(List<MyBillboard> billboards)
    {
      ListExtensions.AddList<MyBillboard>(MyRenderProxy.BillboardsWrite, billboards);
    }

    public static void UpdateBillboardsColorize(bool enable, VRageMath.Color color, float distance, VRageMath.Vector3 normal)
    {
      MyRenderMessageUpdateBillboardsColorize billboardsColorize = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateBillboardsColorize>(MyRenderMessageEnum.UpdateBillboardsColorize);
      billboardsColorize.Enable = enable;
      billboardsColorize.Color = color;
      billboardsColorize.Distance = distance;
      billboardsColorize.Normal = normal;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) billboardsColorize);
    }

    public static void AddLineBillboardLocal(uint renderObjectID, string material, VRageMath.Color color, VRageMath.Vector3 localPos, VRageMath.Vector3 localDir, float length, float thickness, int priority = 0, bool near = false)
    {
      MyRenderMessageAddLineBillboardLocal lineBillboardLocal = MyRenderProxy.MessagePool.Get<MyRenderMessageAddLineBillboardLocal>(MyRenderMessageEnum.AddLineBillboardLocal);
      lineBillboardLocal.RenderObjectID = renderObjectID;
      lineBillboardLocal.Material = material;
      lineBillboardLocal.Color = color;
      lineBillboardLocal.LocalPos = localPos;
      lineBillboardLocal.LocalDir = localDir;
      lineBillboardLocal.Length = length;
      lineBillboardLocal.Thickness = thickness;
      lineBillboardLocal.Priority = priority;
      lineBillboardLocal.Near = near;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) lineBillboardLocal);
    }

    public static void AddPointBillboardLocal(uint renderObjectID, string material, VRageMath.Color color, VRageMath.Vector3 localPos, float radius, float angle, int priority = 0, bool colorize = false, bool near = false, bool lowres = false)
    {
      MyRenderMessageAddPointBillboardLocal pointBillboardLocal = MyRenderProxy.MessagePool.Get<MyRenderMessageAddPointBillboardLocal>(MyRenderMessageEnum.AddPointBillboardLocal);
      pointBillboardLocal.RenderObjectID = renderObjectID;
      pointBillboardLocal.Material = material;
      pointBillboardLocal.Color = color;
      pointBillboardLocal.LocalPos = localPos;
      pointBillboardLocal.Radius = radius;
      pointBillboardLocal.Angle = angle;
      pointBillboardLocal.Priority = priority;
      pointBillboardLocal.Colorize = colorize;
      pointBillboardLocal.Near = near;
      pointBillboardLocal.Lowres = lowres;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) pointBillboardLocal);
    }

    public static void AddBillboardViewProjection(int id, MyBillboardViewProjection billboardViewProjection)
    {
      MyBillboardViewProjection billboardViewProjection1;
      if (!MyRenderProxy.BillboardsViewProjectionWrite.TryGetValue(id, out billboardViewProjection1))
        MyRenderProxy.BillboardsViewProjectionWrite.Add(id, billboardViewProjection);
      else
        MyRenderProxy.BillboardsViewProjectionWrite[id] = billboardViewProjection;
    }

    public static void RemoveBillboardViewProjection(int id)
    {
      MyRenderProxy.BillboardsViewProjectionWrite.Remove(id);
    }

    public static void SetTextureIgnoreQuality(string path)
    {
      MyRenderMessageSetTextureIgnoreQuality textureIgnoreQuality = MyRenderProxy.MessagePool.Get<MyRenderMessageSetTextureIgnoreQuality>(MyRenderMessageEnum.SetTextureIgnoreQuality);
      textureIgnoreQuality.Path = path;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) textureIgnoreQuality);
    }

    public static void UpdateRenderQuality(MyRenderQualityEnum renderQuality, float lodTransitionDistanceNear, float lodTransitionDistanceFar, float lodTransitionDistanceBackgroundStart, float lodTransitionDistanceBackgroundEnd, float environmentLodTransitionDistance, float environmentLodTransitionDistanceBackground, bool enableCascadeBlending)
    {
      MyRenderMessageUpdateRenderQuality updateRenderQuality = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateRenderQuality>(MyRenderMessageEnum.UpdateRenderQuality);
      updateRenderQuality.RenderQuality = renderQuality;
      updateRenderQuality.LodTransitionDistanceNear = lodTransitionDistanceNear;
      updateRenderQuality.LodTransitionDistanceFar = lodTransitionDistanceFar;
      updateRenderQuality.LodTransitionDistanceBackgroundStart = lodTransitionDistanceBackgroundStart;
      updateRenderQuality.LodTransitionDistanceBackgroundEnd = lodTransitionDistanceBackgroundEnd;
      updateRenderQuality.EnvironmentLodTransitionDistance = environmentLodTransitionDistance;
      updateRenderQuality.EnvironmentLodTransitionDistanceBackground = environmentLodTransitionDistanceBackground;
      updateRenderQuality.EnableCascadeBlending = enableCascadeBlending;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) updateRenderQuality);
    }

    public static void TakeScreenshot(VRageMath.Vector2 sizeMultiplier, string pathToSave, bool debug, bool ignoreSprites, bool showNotification)
    {
      if (debug && pathToSave != null)
        throw new ArgumentException("When taking debug screenshot, path to save must be null, becase debug takes a lot of screenshots");
      MyRenderMessageTakeScreenshot messageTakeScreenshot = MyRenderProxy.MessagePool.Get<MyRenderMessageTakeScreenshot>(MyRenderMessageEnum.TakeScreenshot);
      messageTakeScreenshot.IgnoreSprites = ignoreSprites;
      messageTakeScreenshot.SizeMultiplier = sizeMultiplier;
      messageTakeScreenshot.PathToSave = pathToSave;
      messageTakeScreenshot.Debug = debug;
      messageTakeScreenshot.ShowNotification = showNotification;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageTakeScreenshot);
    }

    public static void RenderColoredTextures(List<renderColoredTextureProperties> texturesToRender)
    {
      MyRenderMessageRenderColoredTexture renderColoredTexture = MyRenderProxy.MessagePool.Get<MyRenderMessageRenderColoredTexture>(MyRenderMessageEnum.RenderColoredTexture);
      renderColoredTexture.texturesToRender = texturesToRender;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) renderColoredTexture);
    }

    public static void ScreenshotTaken(bool success, string filename, bool showNotification)
    {
      MyRenderMessageScreenshotTaken messageScreenshotTaken = MyRenderProxy.MessagePool.Get<MyRenderMessageScreenshotTaken>(MyRenderMessageEnum.ScreenshotTaken);
      messageScreenshotTaken.Success = success;
      messageScreenshotTaken.Filename = filename;
      messageScreenshotTaken.ShowNotification = showNotification;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) messageScreenshotTaken);
    }

    public static void ExportToObjComplete(bool success, string filename)
    {
      MyRenderMessageExportToObjComplete exportToObjComplete = MyRenderProxy.MessagePool.Get<MyRenderMessageExportToObjComplete>(MyRenderMessageEnum.ExportToObjComplete);
      exportToObjComplete.Success = success;
      exportToObjComplete.Filename = filename;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) exportToObjComplete);
    }

    public static void UpdateDistantImpostors(MyImpostorProperties[] impostorProperties)
    {
      MyRenderMessageUpdateDistantImpostors distantImpostors = MyRenderProxy.MessagePool.Get<MyRenderMessageUpdateDistantImpostors>(MyRenderMessageEnum.UpdateDistantImpostors);
      distantImpostors.ImpostorProperties = impostorProperties;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) distantImpostors);
    }

    public static uint CreateRenderCharacter(string debugName, string lod0, MatrixD worldMatrix, VRageMath.Color? diffuseColor, VRageMath.Vector3? colorMaskHSV, RenderFlags flags)
    {
      MyRenderMessageCreateRenderCharacter createRenderCharacter = MyRenderProxy.MessagePool.Get<MyRenderMessageCreateRenderCharacter>(MyRenderMessageEnum.CreateRenderCharacter);
      uint id = MyRenderProxy.m_render.GlobalMessageCounter++;
      createRenderCharacter.ID = id;
      createRenderCharacter.DebugName = debugName;
      createRenderCharacter.Model = lod0;
      createRenderCharacter.WorldMatrix = worldMatrix;
      createRenderCharacter.DiffuseColor = diffuseColor;
      createRenderCharacter.ColorMaskHSV = colorMaskHSV;
      createRenderCharacter.Flags = flags;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) createRenderCharacter);
      MyRenderProxy.UpdateRenderEntity(id, diffuseColor, colorMaskHSV, 0.0f);
      return id;
    }

    public static void SetCharacterSkeleton(uint characterID, MySkeletonBoneDescription[] skeletonBones, int[] skeletonIndices)
    {
      MyRenderMessageSetCharacterSkeleton characterSkeleton = MyRenderProxy.MessagePool.Get<MyRenderMessageSetCharacterSkeleton>(MyRenderMessageEnum.SetCharacterSkeleton);
      characterSkeleton.CharacterID = characterID;
      characterSkeleton.SkeletonBones = skeletonBones;
      characterSkeleton.SkeletonIndices = skeletonIndices;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) characterSkeleton);
    }

    public static bool SetCharacterTransforms(uint characterID, VRageMath.Matrix[] boneTransforms)
    {
      MyRenderMessageSetCharacterTransforms characterTransforms = MyRenderProxy.MessagePool.Get<MyRenderMessageSetCharacterTransforms>(MyRenderMessageEnum.SetCharacterTransforms);
      characterTransforms.CharacterID = characterID;
      if (characterTransforms.RelativeBoneTransforms == null || characterTransforms.RelativeBoneTransforms.Length < boneTransforms.Length)
      {
        characterTransforms.RelativeBoneTransforms = (VRageMath.Matrix[]) boneTransforms.Clone();
      }
      else
      {
        for (int index = 0; index < boneTransforms.Length; ++index)
          characterTransforms.RelativeBoneTransforms[index] = boneTransforms[index];
      }
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) characterTransforms);
      return false;
    }

    public static void DebugDrawLine3D(Vector3D pointFrom, Vector3D pointTo, VRageMath.Color colorFrom, VRageMath.Color colorTo, bool depthRead)
    {
      MyRenderMessageDebugDrawLine3D messageDebugDrawLine3D = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawLine3D>(MyRenderMessageEnum.DebugDrawLine3D);
      messageDebugDrawLine3D.PointFrom = pointFrom;
      messageDebugDrawLine3D.PointTo = pointTo;
      messageDebugDrawLine3D.ColorFrom = colorFrom;
      messageDebugDrawLine3D.ColorTo = colorTo;
      messageDebugDrawLine3D.DepthRead = depthRead;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawLine3D);
    }

    public static void DebugDrawLine2D(VRageMath.Vector2 pointFrom, VRageMath.Vector2 pointTo, VRageMath.Color colorFrom, VRageMath.Color colorTo, VRageMath.Matrix? projection = null)
    {
      MyRenderMessageDebugDrawLine2D messageDebugDrawLine2D = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawLine2D>(MyRenderMessageEnum.DebugDrawLine2D);
      messageDebugDrawLine2D.PointFrom = pointFrom;
      messageDebugDrawLine2D.PointTo = pointTo;
      messageDebugDrawLine2D.ColorFrom = colorFrom;
      messageDebugDrawLine2D.ColorTo = colorTo;
      messageDebugDrawLine2D.Projection = projection;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawLine2D);
    }

    public static void DebugDrawText2D(VRageMath.Vector2 screenCoord, string text, VRageMath.Color color, float scale, MyGuiDrawAlignEnum align = MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP)
    {
      MyRenderMessageDebugDrawText2D messageDebugDrawText2D = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawText2D>(MyRenderMessageEnum.DebugDrawText2D);
      messageDebugDrawText2D.Coord = screenCoord;
      messageDebugDrawText2D.Text = text;
      messageDebugDrawText2D.Color = color;
      messageDebugDrawText2D.Scale = scale;
      messageDebugDrawText2D.Align = align;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawText2D);
    }

    public static void DebugDrawText3D(Vector3D worldCoord, string text, VRageMath.Color color, float scale, bool depthRead, MyGuiDrawAlignEnum align = MyGuiDrawAlignEnum.HORISONTAL_LEFT_AND_VERTICAL_TOP, int customViewProjection = -1)
    {
      MyRenderMessageDebugDrawText3D messageDebugDrawText3D = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawText3D>(MyRenderMessageEnum.DebugDrawText3D);
      messageDebugDrawText3D.Coord = worldCoord;
      messageDebugDrawText3D.Text = text;
      messageDebugDrawText3D.Color = color;
      messageDebugDrawText3D.Scale = scale;
      messageDebugDrawText3D.DepthRead = depthRead;
      messageDebugDrawText3D.Align = align;
      messageDebugDrawText3D.CustomViewProjection = customViewProjection;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawText3D);
    }

    public static void DebugDrawSphere(Vector3D position, float radius, VRageMath.Color color, float alpha, bool depthRead, bool smooth = false, bool cull = true)
    {
      MyRenderMessageDebugDrawSphere messageDebugDrawSphere = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawSphere>(MyRenderMessageEnum.DebugDrawSphere);
      messageDebugDrawSphere.Position = position;
      messageDebugDrawSphere.Radius = radius;
      messageDebugDrawSphere.Color = color;
      messageDebugDrawSphere.Alpha = alpha;
      messageDebugDrawSphere.DepthRead = depthRead;
      messageDebugDrawSphere.Smooth = smooth;
      messageDebugDrawSphere.Cull = cull;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawSphere);
    }

    public static MyDebugDrawBatchAABB DebugDrawBatchAABB(MatrixD worldMatrix, VRageMath.Color color, bool depthRead, bool shaded)
    {
      return new MyDebugDrawBatchAABB(MyRenderProxy.PrepareDebugDrawTriangles(), ref worldMatrix, ref color, depthRead, shaded);
    }

    public static void DebugDrawAABB(BoundingBoxD aabb, VRageMath.Color color, float alpha, float scale, bool depthRead)
    {
      MyRenderMessageDebugDrawAABB messageDebugDrawAabb = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawAABB>(MyRenderMessageEnum.DebugDrawAABB);
      messageDebugDrawAabb.AABB = aabb;
      messageDebugDrawAabb.Color = color;
      messageDebugDrawAabb.Alpha = alpha;
      messageDebugDrawAabb.Scale = scale;
      messageDebugDrawAabb.DepthRead = depthRead;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawAabb);
    }

    public static void DebugDrawAxis(MatrixD matrix, float axisLength, bool depthRead)
    {
      MyRenderMessageDebugDrawAxis messageDebugDrawAxis = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawAxis>(MyRenderMessageEnum.DebugDrawAxis);
      messageDebugDrawAxis.Matrix = matrix;
      messageDebugDrawAxis.AxisLength = axisLength;
      messageDebugDrawAxis.DepthRead = depthRead;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawAxis);
    }

    public static void DebugDrawOBB(MyOrientedBoundingBoxD obb, VRageMath.Color color, float alpha, bool depthRead, bool smooth)
    {
      MatrixD fromQuaternion = MatrixD.CreateFromQuaternion(obb.Orientation);
      fromQuaternion.Right *= obb.HalfExtent.X * 2.0;
      fromQuaternion.Up *= obb.HalfExtent.Y * 2.0;
      fromQuaternion.Forward *= obb.HalfExtent.Z * 2.0;
      fromQuaternion.Translation = obb.Center;
      MyRenderProxy.DebugDrawOBB(fromQuaternion, color, alpha, depthRead, smooth, true);
    }

    public static void DebugDrawOBB(MatrixD matrix, VRageMath.Color color, float alpha, bool depthRead, bool smooth, bool cull = true)
    {
      MyRenderMessageDebugDrawOBB messageDebugDrawObb = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawOBB>(MyRenderMessageEnum.DebugDrawOBB);
      messageDebugDrawObb.Matrix = matrix;
      messageDebugDrawObb.Color = color;
      messageDebugDrawObb.Alpha = alpha;
      messageDebugDrawObb.DepthRead = depthRead;
      messageDebugDrawObb.Smooth = smooth;
      messageDebugDrawObb.Cull = cull;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawObb);
    }

    public static void DebugDrawCylinder(MatrixD worldMatrix, Vector3D vertexA, Vector3D vertexB, float radius, VRageMath.Color color, float alpha, bool depthRead, bool smooth)
    {
      VRageMath.Vector3 vector3 = (VRageMath.Vector3) (vertexB - vertexA);
      float yScale = vector3.Length();
      float num = 2f * radius;
      VRageMath.Matrix matrix1 = VRageMath.Matrix.Identity;
      matrix1.Up = vector3 / yScale;
      matrix1.Right = VRageMath.Vector3.CalculatePerpendicularVector(matrix1.Up);
      matrix1.Forward = VRageMath.Vector3.Cross(matrix1.Up, matrix1.Right);
      VRageMath.Matrix matrix2 = VRageMath.Matrix.CreateScale(num, yScale, num) * matrix1;
      matrix2.Translation = (VRageMath.Vector3) ((vertexA + vertexB) * 0.5);
      MyRenderProxy.DebugDrawCylinder((MatrixD) (VRageMath.Matrix) (matrix2 * worldMatrix), color, alpha, depthRead, smooth);
    }

    public static void DebugDrawCylinder(Vector3D position, VRageMath.Quaternion orientation, float radius, float height, VRageMath.Color color, float alpha, bool depthRead, bool smooth)
    {
      MatrixD fromQuaternion = MatrixD.CreateFromQuaternion(orientation);
      fromQuaternion.Right *= 2.0 * (double) radius;
      fromQuaternion.Forward *= 2.0 * (double) radius;
      fromQuaternion.Up *= (double) height;
      fromQuaternion.Translation = position;
      MyRenderProxy.DebugDrawCylinder(fromQuaternion, color, alpha, depthRead, smooth);
    }

    public static void DebugDrawCylinder(MatrixD matrix, VRageMath.Color color, float alpha, bool depthRead, bool smooth)
    {
      MyRenderMessageDebugDrawCylinder debugDrawCylinder = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawCylinder>(MyRenderMessageEnum.DebugDrawCylinder);
      debugDrawCylinder.Matrix = matrix;
      debugDrawCylinder.Color = color;
      debugDrawCylinder.Alpha = alpha;
      debugDrawCylinder.DepthRead = depthRead;
      debugDrawCylinder.Smooth = smooth;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) debugDrawCylinder);
    }

    public static void DebugDrawTriangle(Vector3D vertex0, Vector3D vertex1, Vector3D vertex2, VRageMath.Color color, bool smooth, bool depthRead)
    {
      MyRenderMessageDebugDrawTriangle debugDrawTriangle = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawTriangle>(MyRenderMessageEnum.DebugDrawTriangle);
      debugDrawTriangle.Vertex0 = vertex0;
      debugDrawTriangle.Vertex1 = vertex1;
      debugDrawTriangle.Vertex2 = vertex2;
      debugDrawTriangle.Color = color;
      debugDrawTriangle.DepthRead = depthRead;
      debugDrawTriangle.Smooth = smooth;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) debugDrawTriangle);
    }

    public static void DebugDrawPlane(Vector3D position, VRageMath.Vector3 normal, VRageMath.Color color, bool depthRead)
    {
      MyRenderMessageDebugDrawPlane messageDebugDrawPlane = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawPlane>(MyRenderMessageEnum.DebugDrawPlane);
      messageDebugDrawPlane.Position = position;
      messageDebugDrawPlane.Normal = normal;
      messageDebugDrawPlane.Color = color;
      messageDebugDrawPlane.DepthRead = depthRead;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawPlane);
    }

    public static IDrawTrianglesMessage PrepareDebugDrawTriangles()
    {
      MyRenderMessageDebugDrawTriangles debugDrawTriangles = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawTriangles>(MyRenderMessageEnum.DebugDrawTriangles);
      debugDrawTriangles.Indices.Clear();
      debugDrawTriangles.Vertices.Clear();
      return (IDrawTrianglesMessage) debugDrawTriangles;
    }

    public static void DebugDrawTriangles(IDrawTrianglesMessage msgInterface, MatrixD worldMatrix, VRageMath.Color color, bool depthRead, bool shaded)
    {
      MyRenderMessageDebugDrawTriangles debugDrawTriangles = (MyRenderMessageDebugDrawTriangles) msgInterface;
      debugDrawTriangles.Color = color;
      debugDrawTriangles.WorldMatrix = worldMatrix;
      debugDrawTriangles.DepthRead = depthRead;
      debugDrawTriangles.Shaded = shaded;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) debugDrawTriangles);
    }

    public static void DebugDrawCapsule(Vector3D p0, Vector3D p1, float radius, VRageMath.Color color, bool depthRead, bool shaded = false)
    {
      MyRenderMessageDebugDrawCapsule debugDrawCapsule = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawCapsule>(MyRenderMessageEnum.DebugDrawCapsule);
      debugDrawCapsule.P0 = p0;
      debugDrawCapsule.P1 = p1;
      debugDrawCapsule.Radius = radius;
      debugDrawCapsule.Color = color;
      debugDrawCapsule.DepthRead = depthRead;
      debugDrawCapsule.Shaded = shaded;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) debugDrawCapsule);
    }

    public static void DebugDrawModel(string model, MatrixD worldMatrix, VRageMath.Color color, bool depthRead)
    {
      MyRenderMessageDebugDrawModel messageDebugDrawModel = MyRenderProxy.MessagePool.Get<MyRenderMessageDebugDrawModel>(MyRenderMessageEnum.DebugDrawModel);
      messageDebugDrawModel.Model = model;
      messageDebugDrawModel.WorldMatrix = worldMatrix;
      messageDebugDrawModel.Color = color;
      messageDebugDrawModel.DepthRead = depthRead;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) messageDebugDrawModel);
    }

    public static void DebugCrashRenderThread()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageDebugCrashRenderThread>(MyRenderMessageEnum.DebugCrashRenderThread));
    }

    public static void CollectGarbage()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageCollectGarbage>(MyRenderMessageEnum.CollectGarbage));
    }

    public static void RestoreDXGISwapchainFullscreenMode()
    {
      MyRenderProxy.m_render.RestoreDXGISwapchainFullscreenMode();
    }

    public static void SpriteScissorPop()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageSpriteScissorPop>(MyRenderMessageEnum.SpriteScissorPop));
    }

    public static void SpriteScissorPush(VRageMath.Rectangle screenRectangle)
    {
      MyRenderMessageSpriteScissorPush spriteScissorPush = MyRenderProxy.MessagePool.Get<MyRenderMessageSpriteScissorPush>(MyRenderMessageEnum.SpriteScissorPush);
      spriteScissorPush.ScreenRectangle = screenRectangle;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) spriteScissorPush);
    }

    public static void RequestVideoAdapters()
    {
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageVideoAdaptersRequest>(MyRenderMessageEnum.VideoAdaptersRequest));
    }

    public static void SendVideoAdapters(MyAdapterInfo[] adapters)
    {
      MyRenderMessageVideoAdaptersResponse adaptersResponse = MyRenderProxy.MessagePool.Get<MyRenderMessageVideoAdaptersResponse>(MyRenderMessageEnum.VideoAdaptersResponse);
      adaptersResponse.Adapters = adapters;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) adaptersResponse);
    }

    public static void SendCreatedDeviceSettings(MyRenderDeviceSettings settings)
    {
      MyRenderMessageCreatedDeviceSettings createdDeviceSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageCreatedDeviceSettings>(MyRenderMessageEnum.CreatedDeviceSettings);
      createdDeviceSettings.Settings = settings;
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) createdDeviceSettings);
    }

    public static void SwitchDeviceSettings(MyRenderDeviceSettings settings)
    {
      MyRenderMessageSwitchDeviceSettings switchDeviceSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageSwitchDeviceSettings>(MyRenderMessageEnum.SwitchDeviceSettings);
      switchDeviceSettings.Settings = settings;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) switchDeviceSettings);
    }

    public static void SwitchRenderSettings(MyRenderQualityEnum quality, bool enableInterpolation)
    {
      MyRenderMessageSwitchRenderSettings switchRenderSettings = MyRenderProxy.MessagePool.Get<MyRenderMessageSwitchRenderSettings>(MyRenderMessageEnum.SwitchRenderSettings);
      switchRenderSettings.Quality = quality;
      switchRenderSettings.EnableInterpolation = enableInterpolation;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) switchRenderSettings);
    }

    public static void SwitchRenderSettings(MyRenderSettings1 settings)
    {
      MyRenderMessageSwitchRenderSettings1 switchRenderSettings1 = MyRenderProxy.MessagePool.Get<MyRenderMessageSwitchRenderSettings1>(MyRenderMessageEnum.SwitchRenderSettings1);
      switchRenderSettings1.Settings = settings;
      MyRenderProxy.EnqueueMessage((IMyRenderMessage) switchRenderSettings1);
    }

    public static void SendClipmapsReady()
    {
      MyRenderProxy.EnqueueOutputMessage((IMyRenderMessage) MyRenderProxy.MessagePool.Get<MyRenderMessageClipmapsReady>(MyRenderMessageEnum.ClipmapsReady));
    }
  }
}
