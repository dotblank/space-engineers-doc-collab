﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageDrawSprite
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;
using VRageRender.Graphics;

namespace VRageRender
{
  public class MyRenderMessageDrawSprite : IMyRenderMessage
  {
    public string Texture;
    public Color Color;
    public Rectangle? SourceRectangle;
    public RectangleF DestinationRectangle;
    public Vector2 Origin;
    public float Rotation;
    public Vector2 RightVector;
    public float Depth;
    public SpriteEffects Effects;
    public bool ScaleDestination;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.Draw;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.DrawSprite;
      }
    }
  }
}
