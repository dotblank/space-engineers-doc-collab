﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderSettings1
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;

namespace VRageRender
{
  public struct MyRenderSettings1 : IEquatable<MyRenderSettings1>
  {
    public MyAntialiasingMode AntialiasingMode;
    public MyShadowsQuality ShadowQuality;
    public bool MultithreadingEnabled;
    public bool InterpolationEnabled;
    public MyTextureQuality TextureQuality;
    public MyTextureAnisoFiltering AnisotropicFiltering;
    public MyFoliageDetails FoliageDetails;

    bool IEquatable<MyRenderSettings1>.Equals(MyRenderSettings1 other)
    {
      return this.Equals(ref other);
    }

    public bool Equals(ref MyRenderSettings1 other)
    {
      if (this.AntialiasingMode == other.AntialiasingMode && this.ShadowQuality == other.ShadowQuality && (this.MultithreadingEnabled == other.MultithreadingEnabled && this.InterpolationEnabled == other.InterpolationEnabled) && (this.TextureQuality == other.TextureQuality && this.AnisotropicFiltering == other.AnisotropicFiltering))
        return this.FoliageDetails == other.FoliageDetails;
      else
        return false;
    }
  }
}
