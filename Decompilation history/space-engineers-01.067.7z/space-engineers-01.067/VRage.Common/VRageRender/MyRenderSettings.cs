﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderSettings
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public class MyRenderSettings
  {
    public bool EnableHWOcclusionQueries = true;
    public bool EnableLightsRuntime = true;
    public bool EnableSpotLights = true;
    public bool EnablePointLights = true;
    public bool EnableLightGlares = true;
    public bool EnableSun = true;
    public bool EnableShadows = true;
    public bool EnableFog = true;
    private bool m_enableEnvironmentMapAmbient = true;
    private bool m_enableEnvironmentMapReflection = true;
    public bool EnablePerVertexVoxelAmbient = true;
    public bool[] FreezeCascade = new bool[4];
    public bool EnableStencilOptimization = true;
    public bool EnableStencilOptimizationLOD1 = true;
    public bool CheckDiffuseTextures = true;
    public bool EnableSpotShadows = true;
    public float InterpolationLagMs = 22f;
    public float LagFeedbackMult = 0.25f;
    public float DetailedTerrainRange = 40f;
    public float DetailedTerrainTransitionDistance = 25f;
    public bool GrassPostprocess = true;
    public float GrassPostprocessCloseDistance = 25f;
    public float GrassGeometryClippingDistance = 500f;
    public float GrassGeometryScalingNearDistance = 100f;
    public float GrassGeometryScalingFarDistance = 400f;
    public float GrassGeometryDistanceScalingFactor = 4f;
    public float CascadesSplit0 = 15f;
    public float CascadesSplit1 = 45f;
    public float CascadesSplit2 = 250f;
    public float CascadesSplit3 = 1000f;
    public bool EnableParallelRendering = true;
    public bool AmortizeBatchWork = true;
    public float RenderBatchSize = 100f;
    public bool LoopObjectThenPass = true;
    public bool RenderThreadAsWorker = true;
    public bool UpdateCascadesEveryFrame = true;
    public float Cascade1SmallSkip = 730f;
    public float Cascade2SmallSkip = 730f;
    public float Cascade3SmallSkip = 8000f;
    public bool EnableTonemapping = true;
    public float AdaptationTau = 0.3f;
    public float LuminanceExposure = 0.51f;
    public float Contrast = 3.0 / 500.0;
    public float BloomExposure = 0.5f;
    public float BloomMult = 0.25f;
    public float MiddleGreyCurveSharpness = 3f;
    public float MiddleGreyAt0 = 0.005f;
    public float BlueShiftRapidness = 0.01f;
    public float BlueShiftScale = 0.5f;
    public float EnvMult = 1f;
    public float FogDensity = 3.0 / 1000.0;
    public float FogMult = 0.295f;
    public float FogYOffset = 720f;
    public Vector4 FogColor = new Vector4(0.2352941f, 0.4666667f, 1f, 0.0f);
    public float WindStrength = 0.3f;
    public float FoliageLod0Distance = 25f;
    public float FoliageLod1Distance = 50f;
    public float FoliageLod2Distance = 100f;
    public float FoliageLod3Distance = 100f;
    public bool SkipLOD_NEAR;
    public bool SkipLOD_0;
    public bool SkipLOD_1;
    public bool SkipVoxels;
    public bool TearingTest;
    public bool MultimonTest;
    public bool ShowEnvironmentScreens;
    public bool ShowBlendedScreens;
    public bool ShowGreenBackground;
    public bool ShowLod1WithRedOverlay;
    public bool ShowEnhancedRenderStatsEnabled;
    public bool ShowResourcesStatsEnabled;
    public bool ShowTexturesStatsEnabled;
    public bool EnableAsteroidShadows;
    public bool DebugRenderClipmapCells;
    public bool ShowCascadeSplits;
    public bool ShadowInterleaving;
    public bool Wireframe;
    public bool ShowStencilOptimization;
    public bool CheckNormalTextures;
    public bool ShowSpecularIntensity;
    public bool ShowSpecularPower;
    public bool ShowEmissivity;
    public bool ShowReflectivity;
    public bool VisualizeOverdraw;
    public bool EnableCameraInterpolation;
    public bool EnableObjectInterpolation;
    public bool DisplayGbufferColor;
    public bool DisplayGbufferNormal;
    public bool DisplayGbufferGlossiness;
    public bool DisplayGbufferMetalness;
    public bool DisplayGbufferMaterialID;
    public bool DisplayAO;
    public bool DisplayEdgeMask;
    public bool DisplayAmbientDiffuse;
    public bool DisplayAmbientSpecular;
    public bool NightMode;
    public bool DisplayIDs;
    public bool DisplayAabbs;
    public bool FreezeTerrainQueries;
    public bool DisplayShadowsWithDebug;
    public bool ForceImmediateContext;
    public float Cascade0SmallSkip;
    public float Brightness;
    public float MiddleGrey;
    public float BacklightMult;
    public float WindAzimuth;
    public bool EnableFoliageDebug;
    public bool FreezeFoliageViewer;

    public bool EnableEnvironmentMapAmbient
    {
      get
      {
        return this.m_enableEnvironmentMapAmbient;
      }
      set
      {
        if (this.m_enableEnvironmentMapAmbient == value)
          return;
        this.m_enableEnvironmentMapAmbient = value;
        if (!value)
          return;
        MyRenderProxy.ResetEnvironmentProbes();
      }
    }

    public bool EnableEnvironmentMapReflection
    {
      get
      {
        return this.m_enableEnvironmentMapReflection;
      }
      set
      {
        if (this.m_enableEnvironmentMapReflection == value)
          return;
        this.m_enableEnvironmentMapReflection = value;
        if (!value)
          return;
        MyRenderProxy.ResetEnvironmentProbes();
      }
    }

    public bool FreezeCascade0
    {
      get
      {
        return this.FreezeCascade[0];
      }
      set
      {
        this.FreezeCascade[0] = value;
      }
    }

    public bool FreezeCascade1
    {
      get
      {
        return this.FreezeCascade[1];
      }
      set
      {
        this.FreezeCascade[1] = value;
      }
    }

    public bool FreezeCascade2
    {
      get
      {
        return this.FreezeCascade[2];
      }
      set
      {
        this.FreezeCascade[2] = value;
      }
    }

    public bool FreezeCascade3
    {
      get
      {
        return this.FreezeCascade[3];
      }
      set
      {
        this.FreezeCascade[3] = value;
      }
    }

    internal void Synchronize(MyRenderSettings settings)
    {
      this.EnableHWOcclusionQueries = settings.EnableHWOcclusionQueries;
      this.SkipLOD_NEAR = settings.SkipLOD_NEAR;
      this.SkipLOD_0 = settings.SkipLOD_0;
      this.SkipLOD_1 = settings.SkipLOD_1;
      this.SkipVoxels = settings.SkipVoxels;
      this.ShowEnvironmentScreens = settings.ShowEnvironmentScreens;
      this.ShowBlendedScreens = settings.ShowBlendedScreens;
      this.ShowGreenBackground = settings.ShowGreenBackground;
      this.ShowLod1WithRedOverlay = settings.ShowLod1WithRedOverlay;
      this.EnableLightsRuntime = settings.EnableLightsRuntime;
      this.ShowEnhancedRenderStatsEnabled = settings.ShowEnhancedRenderStatsEnabled;
      this.ShowResourcesStatsEnabled = settings.ShowResourcesStatsEnabled;
      this.ShowTexturesStatsEnabled = settings.ShowTexturesStatsEnabled;
      this.EnableSun = settings.EnableSun;
      this.EnableShadows = settings.EnableShadows;
      this.EnableAsteroidShadows = settings.EnableAsteroidShadows;
      this.EnableFog = settings.EnableFog;
      this.DebugRenderClipmapCells = settings.DebugRenderClipmapCells;
      this.EnableEnvironmentMapAmbient = settings.EnableEnvironmentMapAmbient;
      this.EnableEnvironmentMapReflection = settings.EnableEnvironmentMapReflection;
      this.EnablePerVertexVoxelAmbient = settings.EnablePerVertexVoxelAmbient;
      this.ShowCascadeSplits = settings.ShowCascadeSplits;
      this.ShadowInterleaving = settings.ShadowInterleaving;
      this.FreezeCascade[0] = settings.FreezeCascade[0];
      this.FreezeCascade[1] = settings.FreezeCascade[1];
      this.FreezeCascade[2] = settings.FreezeCascade[2];
      this.FreezeCascade[3] = settings.FreezeCascade[3];
      this.Wireframe = settings.Wireframe;
      this.EnableStencilOptimization = settings.EnableStencilOptimization;
      this.EnableStencilOptimizationLOD1 = settings.EnableStencilOptimizationLOD1;
      this.ShowStencilOptimization = settings.ShowStencilOptimization;
      this.CheckDiffuseTextures = settings.CheckDiffuseTextures;
      this.CheckNormalTextures = settings.CheckNormalTextures;
      this.ShowSpecularIntensity = settings.ShowSpecularIntensity;
      this.ShowSpecularPower = settings.ShowSpecularPower;
      this.ShowEmissivity = settings.ShowEmissivity;
      this.ShowReflectivity = settings.ShowReflectivity;
      this.EnableSpotShadows = settings.EnableSpotShadows;
      this.VisualizeOverdraw = settings.VisualizeOverdraw;
      this.MultimonTest = settings.MultimonTest;
      this.EnableCameraInterpolation = settings.EnableCameraInterpolation;
      this.EnableObjectInterpolation = settings.EnableObjectInterpolation;
      this.InterpolationLagMs = settings.InterpolationLagMs;
      this.LagFeedbackMult = settings.LagFeedbackMult;
      this.DisplayGbufferColor = settings.DisplayGbufferColor;
      this.DisplayGbufferNormal = settings.DisplayGbufferNormal;
      this.DisplayGbufferGlossiness = settings.DisplayGbufferGlossiness;
      this.DisplayGbufferMetalness = settings.DisplayGbufferMetalness;
      this.DisplayGbufferMaterialID = settings.DisplayGbufferMaterialID;
      this.DisplayAO = settings.DisplayAO;
      this.DisplayEdgeMask = settings.DisplayEdgeMask;
      this.DisplayAmbientDiffuse = settings.DisplayAmbientDiffuse;
      this.DisplayAmbientSpecular = settings.DisplayAmbientSpecular;
      this.NightMode = settings.NightMode;
      this.DisplayIDs = settings.DisplayIDs;
      this.DisplayAabbs = settings.DisplayAabbs;
      this.DetailedTerrainRange = settings.DetailedTerrainRange;
      this.DetailedTerrainTransitionDistance = settings.DetailedTerrainTransitionDistance;
      this.FreezeTerrainQueries = settings.FreezeTerrainQueries;
      this.GrassPostprocess = settings.GrassPostprocess;
      this.GrassPostprocessCloseDistance = settings.GrassPostprocessCloseDistance;
      this.GrassGeometryClippingDistance = settings.GrassGeometryClippingDistance;
      this.GrassGeometryScalingNearDistance = settings.GrassGeometryScalingNearDistance;
      this.GrassGeometryScalingFarDistance = settings.GrassGeometryScalingFarDistance;
      this.GrassGeometryDistanceScalingFactor = settings.GrassGeometryDistanceScalingFactor;
      this.WindStrength = settings.WindStrength;
      this.WindAzimuth = settings.WindAzimuth;
      this.DisplayShadowsWithDebug = settings.DisplayShadowsWithDebug;
      this.UpdateCascadesEveryFrame = settings.UpdateCascadesEveryFrame;
      this.CascadesSplit0 = settings.CascadesSplit0;
      this.CascadesSplit1 = settings.CascadesSplit1;
      this.CascadesSplit2 = settings.CascadesSplit2;
      this.CascadesSplit3 = settings.CascadesSplit3;
      this.EnableParallelRendering = settings.EnableParallelRendering;
      this.ForceImmediateContext = settings.ForceImmediateContext;
      this.RenderBatchSize = settings.RenderBatchSize;
      this.AmortizeBatchWork = settings.AmortizeBatchWork;
      this.LoopObjectThenPass = settings.LoopObjectThenPass;
      this.RenderThreadAsWorker = settings.RenderThreadAsWorker;
      this.Cascade0SmallSkip = settings.Cascade0SmallSkip;
      this.Cascade1SmallSkip = settings.Cascade1SmallSkip;
      this.Cascade2SmallSkip = settings.Cascade2SmallSkip;
      this.Cascade3SmallSkip = settings.Cascade3SmallSkip;
      this.EnableTonemapping = settings.EnableTonemapping;
      this.AdaptationTau = settings.AdaptationTau;
      this.LuminanceExposure = settings.LuminanceExposure;
      this.Contrast = settings.Contrast;
      this.Brightness = settings.Brightness;
      this.MiddleGrey = settings.MiddleGrey;
      this.BloomExposure = settings.BloomExposure;
      this.BloomMult = settings.BloomMult;
      this.MiddleGreyCurveSharpness = settings.MiddleGreyCurveSharpness;
      this.MiddleGreyAt0 = settings.MiddleGreyAt0;
      this.BlueShiftRapidness = settings.BlueShiftRapidness;
      this.BlueShiftScale = settings.BlueShiftScale;
      this.BacklightMult = settings.BacklightMult;
      this.EnvMult = settings.EnvMult;
      this.FogDensity = settings.FogDensity;
      this.FogMult = settings.FogMult;
      this.FogYOffset = settings.FogYOffset;
      this.FogColor = settings.FogColor;
      this.FoliageLod0Distance = settings.FoliageLod0Distance;
      this.FoliageLod1Distance = settings.FoliageLod1Distance;
      this.FoliageLod2Distance = settings.FoliageLod2Distance;
      this.FoliageLod3Distance = settings.FoliageLod3Distance;
      this.EnableFoliageDebug = settings.EnableFoliageDebug;
      this.FreezeFoliageViewer = settings.FreezeFoliageViewer;
    }

    internal bool IsDirty()
    {
      return true;
    }
  }
}
