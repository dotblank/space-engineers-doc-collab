﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessagePreloadTextures
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRageRender
{
  public class MyRenderMessagePreloadTextures : IMyRenderMessage
  {
    public string InDirectory;
    public bool Recursive;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.StateChangeOnce;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.PreloadTextures;
      }
    }
  }
}
