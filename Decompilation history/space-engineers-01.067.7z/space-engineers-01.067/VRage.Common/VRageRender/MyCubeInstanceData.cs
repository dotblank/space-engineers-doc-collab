﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyCubeInstanceData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace VRageRender
{
  public struct MyCubeInstanceData
  {
    private unsafe fixed byte m_bones[32];
    public Vector4 m_translationAndRot;
    public Vector4 ColorMaskHSV;

    public Matrix LocalMatrix
    {
      get
      {
        return Vector4.UnpackOrthoMatrix(ref this.m_translationAndRot);
      }
      set
      {
        this.m_translationAndRot = Vector4.PackOrthoMatrix(ref value);
      }
    }

    public Vector3 Translation
    {
      get
      {
        return new Vector3(this.m_translationAndRot);
      }
    }

    public Vector4 PackedOrthoMatrix
    {
      get
      {
        return this.m_translationAndRot;
      }
      set
      {
        this.m_translationAndRot = value;
      }
    }

    public unsafe float BoneRange
    {
      get
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
          return (float) ((Vector4UByte*) (numPtr + (new IntPtr(4) * sizeof (Vector4UByte)).ToInt64()))->W / 10f;
      }
      set
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
          ((Vector4UByte*) (numPtr + (new IntPtr(4) * sizeof (Vector4UByte)).ToInt64()))->W = (byte) ((double) value * 10.0);
      }
    }

    public unsafe bool EnableSkinning
    {
      get
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
          return (int) ((Vector4UByte*) (numPtr + (new IntPtr(3) * sizeof (Vector4UByte)).ToInt64()))->W != 0;
      }
      set
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
          ((Vector4UByte*) (numPtr + (new IntPtr(3) * sizeof (Vector4UByte)).ToInt64()))->W = value ? byte.MaxValue : (byte) 0;
      }
    }

    public unsafe Vector3UByte this[int index]
    {
      get
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
        {
          if (index == 8)
            return new Vector3UByte(((Vector4UByte*) numPtr)->W, ((Vector4UByte*) (numPtr + sizeof (Vector4UByte)))->W, ((Vector4UByte*) (numPtr + (new IntPtr(2) * sizeof (Vector4UByte)).ToInt64()))->W);
          else
            return *(Vector3UByte*) (numPtr + ((IntPtr) index * sizeof (Vector4UByte)).ToInt64());
        }
      }
      set
      {
        fixed (byte* numPtr = &this.m_bones.FixedElementField)
        {
          if (index == 8)
          {
            ((Vector4UByte*) numPtr)->W = value.X;
            ((Vector4UByte*) (numPtr + sizeof (Vector4UByte)))->W = value.Y;
            ((Vector4UByte*) (numPtr + (new IntPtr(2) * sizeof (Vector4UByte)).ToInt64()))->W = value.Z;
          }
          else
            *(Vector3UByte*) (numPtr + ((IntPtr) index * sizeof (Vector4UByte)).ToInt64()) = value;
        }
      }
    }

    public unsafe byte[] RawBones()
    {
      byte[] numArray = new byte[32];
      // ISSUE: reference to a compiler-generated field
      fixed (byte* numPtr = &this.m_bones.FixedElementField)
      {
        for (int index = 0; index < 32; ++index)
          numArray[index] = numPtr[index];
      }
      return numArray;
    }

    public unsafe void ResetBones()
    {
      // ISSUE: reference to a compiler-generated field
      fixed (byte* numPtr = &this.m_bones.FixedElementField)
      {
        *(ulong*) numPtr = 9259542123273814144UL;
        ((ulong*) numPtr)[1] = 36170086419038336UL;
        ((ulong*) numPtr)[2] = 9259542123273814144UL;
        ((ulong*) numPtr)[3] = 9259542123273814144UL;
      }
    }

    public unsafe void SetTextureOffset(Vector2 patternOffset)
    {
      // ISSUE: reference to a compiler-generated field
      fixed (byte* numPtr = &this.m_bones.FixedElementField)
      {
        ((Vector4UByte*) (numPtr + (new IntPtr(5) * sizeof (Vector4UByte)).ToInt64()))->W = (byte) ((double) patternOffset.X * (double) byte.MaxValue);
        ((Vector4UByte*) (numPtr + (new IntPtr(6) * sizeof (Vector4UByte)).ToInt64()))->W = (byte) ((double) patternOffset.Y * (double) byte.MaxValue);
      }
    }

    public unsafe float GetTextureOffset(int index)
    {
      // ISSUE: reference to a compiler-generated field
      fixed (byte* numPtr = &this.m_bones.FixedElementField)
        return (float) ((Vector4UByte*) (numPtr + ((IntPtr) (5 + index) * sizeof (Vector4UByte)).ToInt64()))->W / (float) byte.MaxValue;
    }

    public unsafe void SetColorMaskHSV(Vector4 colorMaskHSV)
    {
      this.ColorMaskHSV = colorMaskHSV;
      if ((double) colorMaskHSV.W >= 0.0)
        return;
      // ISSUE: reference to a compiler-generated field
      fixed (byte* numPtr = &this.m_bones.FixedElementField)
        ((Vector4UByte*) (numPtr + (new IntPtr(7) * sizeof (Vector4UByte)).ToInt64()))->W = (byte) 1;
      this.ColorMaskHSV.W = -this.ColorMaskHSV.W;
    }
  }
}
