﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRefreshRatePriorityComparer
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;

namespace VRageRender
{
  public class MyRefreshRatePriorityComparer : IComparer<MyDisplayMode>
  {
    private static float[] m_refreshRates = new float[5]
    {
      60f,
      75f,
      59f,
      72f,
      100f
    };

    public int Compare(MyDisplayMode x, MyDisplayMode y)
    {
      if (x.Width != y.Width)
        return x.Width.CompareTo(y.Width);
      if (x.Height != y.Height)
        return x.Height.CompareTo(y.Height);
      if ((double) x.RefreshRateF == (double) y.RefreshRateF)
        return 0;
      for (int index = 0; index < MyRefreshRatePriorityComparer.m_refreshRates.Length; ++index)
      {
        if ((double) x.RefreshRateF == (double) MyRefreshRatePriorityComparer.m_refreshRates[index])
          return -1;
        if ((double) y.RefreshRateF == (double) MyRefreshRatePriorityComparer.m_refreshRates[index])
          return 1;
      }
      return x.RefreshRate.CompareTo(y.RefreshRate);
    }
  }
}
