﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyTransparentMaterials
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRage.Collections;
using VRageMath;

namespace VRageRender
{
  public static class MyTransparentMaterials
  {
    private static readonly Dictionary<string, MyTransparentMaterial> m_materialsByName = new Dictionary<string, MyTransparentMaterial>();
    private static readonly MyTransparentMaterial ErrorMaterial = new MyTransparentMaterial("ErrorMaterial", "Textures\\FAKE.dds", 9999f, false, false, Color.Pink.ToVector4(), false, true, false, 0.0f, 1f, 4f, 1f, 0.0f);
    public static Action OnUpdate;

    public static DictionaryValuesReader<string, MyTransparentMaterial> Materials
    {
      get
      {
        return new DictionaryValuesReader<string, MyTransparentMaterial>(MyTransparentMaterials.m_materialsByName);
      }
    }

    public static int Count
    {
      get
      {
        return MyTransparentMaterials.m_materialsByName.Count;
      }
    }

    static MyTransparentMaterials()
    {
      MyTransparentMaterials.Clear();
    }

    public static MyTransparentMaterial GetMaterial(string materialName)
    {
      MyTransparentMaterial transparentMaterial;
      if (MyTransparentMaterials.m_materialsByName.TryGetValue(materialName, out transparentMaterial))
        return transparentMaterial;
      else
        return MyTransparentMaterials.ErrorMaterial;
    }

    public static bool ContainsMaterial(string materialName)
    {
      return MyTransparentMaterials.m_materialsByName.ContainsKey(materialName);
    }

    public static void AddMaterial(MyTransparentMaterial material)
    {
      MyTransparentMaterials.m_materialsByName[material.Name] = material;
    }

    public static void Clear()
    {
      MyTransparentMaterials.m_materialsByName.Clear();
      MyTransparentMaterials.AddMaterial(MyTransparentMaterials.ErrorMaterial);
    }

    public static void Update()
    {
      if (MyTransparentMaterials.OnUpdate == null)
        return;
      MyTransparentMaterials.OnUpdate();
    }
  }
}
