﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyAdapterInfo
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Diagnostics;

namespace VRageRender
{
  [DebuggerDisplay("DeviceName: '{DeviceName}', Description: '{Description}'")]
  public struct MyAdapterInfo
  {
    public string Name;
    public MyDisplayMode CurrentDisplayMode;
    public MyDisplayMode[] SupportedDisplayModes;
    public string DeviceName;
    public string Description;
    public bool HDRSupported;
    public int MaxTextureSize;
    public bool IsSupported;
    public bool Has512MBRam;
    public ulong VRAM;
    public bool MultithreadedRenderingSupported;
    public MyTextureQuality MaxTextureQualitySupported;
    public MyAntialiasingMode MaxAntialiasingModeSupported;

    public void LogInfo(Action<string> lineWriter)
    {
      lineWriter("Adapter: " + this.Name);
      lineWriter("Details: " + this.DeviceName);
      lineWriter("Description: " + this.Description);
    }

    public override string ToString()
    {
      return string.Format("DeviceName: '{0}', Description: '{1}'", (object) this.DeviceName, (object) this.Description);
    }
  }
}
