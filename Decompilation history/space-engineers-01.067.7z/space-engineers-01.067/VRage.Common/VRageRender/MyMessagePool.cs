﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyMessagePool
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRage;
using VRage.Collections;

namespace VRageRender
{
  public class MyMessagePool : Dictionary<int, MyConcurrentQueue<IMyRenderMessage>>
  {
    private FastResourceLock m_lock = new FastResourceLock();

    public MyMessagePool()
    {
      foreach (MyRenderMessageEnum renderMessageEnum in Enum.GetValues(typeof (MyRenderMessageEnum)))
        this.Add((int) renderMessageEnum, new MyConcurrentQueue<IMyRenderMessage>(0));
    }

    public void Clear(MyRenderMessageEnum message)
    {
      this[(int) message].Clear();
    }

    public T Get<T>(MyRenderMessageEnum renderMessageEnum) where T : class, IMyRenderMessage, new()
    {
      IMyRenderMessage instance;
      if (!this[(int) renderMessageEnum].TryDequeue(out instance))
        return Activator.CreateInstance<T>();
      else
        return (T) instance;
    }

    public void Return(IMyRenderMessage message)
    {
      MyConcurrentQueue<IMyRenderMessage> myConcurrentQueue = this[(int) message.MessageType];
      if (myConcurrentQueue.Count >= 2048)
        return;
      myConcurrentQueue.Enqueue(message);
    }
  }
}
