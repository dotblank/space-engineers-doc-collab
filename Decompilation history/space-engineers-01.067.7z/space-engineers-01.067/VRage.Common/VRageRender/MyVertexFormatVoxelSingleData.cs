﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyVertexFormatVoxelSingleData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRage.Common.Import;
using VRageMath;
using VRageMath.PackedVector;

namespace VRageRender
{
  public struct MyVertexFormatVoxelSingleData
  {
    private const int VOXEL_OFFSET = 32767;
    private const int VOXEL_MULTIPLIER = 8;
    private const float INV_VOXEL_MULTIPLIER = 0.125f;
    private const float VOXEL_COORD_EPSILON = 0.0625f;
    private const int AMBIENT_MULTIPLIER = 32767;
    private const float INV_AMBIENT_MULTIPLIER = 3.051851E-05f;
    public MyShort4 PackedPositionAndAmbient;
    private Byte4 m_normal;

    public Vector3 Position
    {
      get
      {
        return new Vector3((float) this.PackedPositionAndAmbient.X, (float) this.PackedPositionAndAmbient.Y, (float) this.PackedPositionAndAmbient.Z) / (float) short.MaxValue * 0.5f + 0.5f;
      }
      set
      {
        this.PackedPositionAndAmbient.X = (short) (((double) value.X * 2.0 - 1.0) * (double) short.MaxValue);
        this.PackedPositionAndAmbient.Y = (short) (((double) value.Y * 2.0 - 1.0) * (double) short.MaxValue);
        this.PackedPositionAndAmbient.Z = (short) (((double) value.Z * 2.0 - 1.0) * (double) short.MaxValue);
      }
    }

    public byte MaterialAlphaIndex
    {
      get
      {
        return VF_Packer.UnpackAlpha(this.PackedPositionAndAmbient.W);
      }
      set
      {
        this.PackedPositionAndAmbient.W = VF_Packer.PackAmbientAndAlpha(this.Ambient, value);
      }
    }

    public float Ambient
    {
      get
      {
        return VF_Packer.UnpackAmbient(this.PackedPositionAndAmbient.W);
      }
      set
      {
        this.PackedPositionAndAmbient.W = VF_Packer.PackAmbientAndAlpha(value, this.MaterialAlphaIndex);
      }
    }

    public Vector3 Normal
    {
      get
      {
        return VF_Packer.UnpackNormal(ref this.m_normal);
      }
      set
      {
        this.m_normal.PackedValue = VF_Packer.PackNormal(ref value);
      }
    }

    public Byte4 PackedNormal
    {
      get
      {
        return this.m_normal;
      }
      set
      {
        this.m_normal = value;
      }
    }
  }
}
