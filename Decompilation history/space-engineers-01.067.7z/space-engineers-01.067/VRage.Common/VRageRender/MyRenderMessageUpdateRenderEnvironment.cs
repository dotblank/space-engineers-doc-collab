﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageUpdateRenderEnvironment
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public class MyRenderMessageUpdateRenderEnvironment : IMyRenderMessage
  {
    public Vector3 SunDirection;
    public Color SunColor;
    public Color SunBackColor;
    public Color SunSpecularColor;
    public float SunIntensity;
    public float SunBackIntensity;
    public bool SunLightOn;
    public Color AmbientColor;
    public float AmbientMultiplier;
    public float EnvAmbientIntensity;
    public Color BackgroundColor;
    public string BackgroundTexture;
    public float SunSizeMultiplier;
    public float DistanceToSun;
    public Quaternion BackgroundOrientation;
    public string SunMaterial;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.StateChangeOnce;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.UpdateRenderEnvironment;
      }
    }
  }
}
