﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyModelData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace VRageRender
{
  public class MyModelData
  {
    public List<MySectionInfo> Sections = new List<MySectionInfo>();
    public List<int> Indices = new List<int>();
    public List<Vector3> Positions = new List<Vector3>();
    public List<Vector3> Normals = new List<Vector3>();
    public List<Vector3> Tangents = new List<Vector3>();
    public List<Vector2> TexCoords = new List<Vector2>();
    public BoundingBox AABB;

    public void Clear()
    {
      this.AABB = BoundingBox.CreateInvalid();
      this.Indices.Clear();
      this.Positions.Clear();
      this.Normals.Clear();
      this.Tangents.Clear();
      this.TexCoords.Clear();
    }
  }
}
