﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MySharedData
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using ParallelTasks;
using System.Collections.Generic;
using VRage;
using VRage.Collections;

namespace VRageRender
{
  public class MySharedData
  {
    private SpinLockRef m_lock = new SpinLockRef();
    private MySwapQueue<HashSet<uint>> m_outputVisibleObjects = MySwapQueue.Create<HashSet<uint>>();
    private MyMessageQueue m_outputRenderMessages = new MyMessageQueue();
    private MyUpdateData m_inputRenderMessages = new MyUpdateData();
    private MyRenderSettings m_inputRenderSettings = new MyRenderSettings();
    private MySwapQueue<MyBillboardBatch<MyBillboard>> m_inputBillboards = MySwapQueue.Create<MyBillboardBatch<MyBillboard>>();
    private MySwapQueue<MyBillboardBatch<MyTriangleBillboard>> m_inputTriangleBillboards = MySwapQueue.Create<MyBillboardBatch<MyTriangleBillboard>>();

    public MySwapQueue<MyBillboardBatch<MyBillboard>> Billboards
    {
      get
      {
        return this.m_inputBillboards;
      }
    }

    public MySwapQueue<MyBillboardBatch<MyTriangleBillboard>> TriangleBillboards
    {
      get
      {
        return this.m_inputTriangleBillboards;
      }
    }

    public MySwapQueue<HashSet<uint>> VisibleObjects
    {
      get
      {
        return this.m_outputVisibleObjects;
      }
    }

    public MyUpdateFrame CurrentUpdateFrame
    {
      get
      {
        return this.m_inputRenderMessages.CurrentUpdateFrame;
      }
    }

    public MyMessageQueue RenderOutputMessageQueue
    {
      get
      {
        return this.m_outputRenderMessages;
      }
    }

    public void BeforeUpdate()
    {
      using (this.m_lock.Acquire())
      {
        this.m_outputVisibleObjects.RefreshRead();
        this.m_outputRenderMessages.Commit();
      }
    }

    public void AfterUpdate(MyRenderSettings inputSettings, MyTimeSpan? updateTimestamp)
    {
      using (this.m_lock.Acquire())
      {
        if (updateTimestamp.HasValue)
          this.m_inputRenderMessages.CurrentUpdateFrame.UpdateTimestamp = updateTimestamp.Value;
        this.m_inputRenderMessages.CommitUpdateFrame();
        this.m_inputRenderSettings.Synchronize(inputSettings);
        this.m_inputBillboards.CommitWrite();
        this.m_inputBillboards.Write.Clear();
        this.m_inputTriangleBillboards.CommitWrite();
        this.m_inputTriangleBillboards.Write.Clear();
      }
    }

    public void BeforeRender(MyRenderSettings writeTo, MyTimeSpan? currentDrawTime)
    {
      using (this.m_lock.Acquire())
      {
        if (currentDrawTime.HasValue)
          MyRenderProxy.CurrentDrawTime = currentDrawTime.Value;
        writeTo.Synchronize(this.m_inputRenderSettings);
      }
    }

    public MyUpdateFrame GetRenderFrame(out bool isPreFrame)
    {
      using (this.m_lock.Acquire())
      {
        MyUpdateFrame renderFrame = this.m_inputRenderMessages.GetRenderFrame(out isPreFrame);
        if (!isPreFrame)
        {
          this.m_inputBillboards.RefreshRead();
          this.m_inputTriangleBillboards.RefreshRead();
        }
        return renderFrame;
      }
    }

    public void ReturnPreFrame(MyUpdateFrame frame)
    {
      this.m_inputRenderMessages.ReturnPreFrame(frame);
    }

    public void AfterRender()
    {
      using (this.m_lock.Acquire())
      {
        this.m_outputVisibleObjects.CommitWrite();
        this.m_outputVisibleObjects.Write.Clear();
      }
    }
  }
}
