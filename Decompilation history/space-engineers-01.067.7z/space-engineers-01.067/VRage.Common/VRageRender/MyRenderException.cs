﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderException
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;

namespace VRageRender
{
  public class MyRenderException : Exception
  {
    private MyRenderExceptionEnum m_type;

    public MyRenderExceptionEnum Type
    {
      get
      {
        return this.m_type;
      }
    }

    public MyRenderException(string message, MyRenderExceptionEnum type = MyRenderExceptionEnum.Unassigned)
      : base(message)
    {
      this.m_type = type;
    }
  }
}
