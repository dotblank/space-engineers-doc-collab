﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyDebugDrawBatchAABB
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageMath;

namespace VRageRender
{
  public struct MyDebugDrawBatchAABB : IDisposable
  {
    private IDrawTrianglesMessage m_msg;
    private MatrixD m_worldMatrix;
    private Color m_color;
    private bool m_depthRead;
    private bool m_shaded;

    internal MyDebugDrawBatchAABB(IDrawTrianglesMessage msg, ref MatrixD worldMatrix, ref Color color, bool depthRead, bool shaded)
    {
      this.m_msg = msg;
      this.m_worldMatrix = worldMatrix;
      this.m_color = color;
      this.m_depthRead = depthRead;
      this.m_shaded = shaded;
    }

    public void Add(ref BoundingBoxD aabb)
    {
      int vertexCount = this.m_msg.VertexCount;
      this.m_msg.AddVertex(new Vector3D(aabb.Min.X, aabb.Min.Y, aabb.Min.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Max.X, aabb.Min.Y, aabb.Min.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Min.X, aabb.Min.Y, aabb.Max.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Max.X, aabb.Min.Y, aabb.Max.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Min.X, aabb.Max.Y, aabb.Min.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Max.X, aabb.Max.Y, aabb.Min.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Min.X, aabb.Max.Y, aabb.Max.Z));
      this.m_msg.AddVertex(new Vector3D(aabb.Max.X, aabb.Max.Y, aabb.Max.Z));
      this.m_msg.AddIndex(vertexCount + 1);
      this.m_msg.AddIndex(vertexCount);
      this.m_msg.AddIndex(vertexCount + 2);
      this.m_msg.AddIndex(vertexCount + 1);
      this.m_msg.AddIndex(vertexCount + 2);
      this.m_msg.AddIndex(vertexCount + 3);
      this.m_msg.AddIndex(vertexCount + 4);
      this.m_msg.AddIndex(vertexCount + 5);
      this.m_msg.AddIndex(vertexCount + 6);
      this.m_msg.AddIndex(vertexCount + 6);
      this.m_msg.AddIndex(vertexCount + 5);
      this.m_msg.AddIndex(vertexCount + 7);
      this.m_msg.AddIndex(vertexCount);
      this.m_msg.AddIndex(vertexCount + 1);
      this.m_msg.AddIndex(vertexCount + 4);
      this.m_msg.AddIndex(vertexCount + 4);
      this.m_msg.AddIndex(vertexCount + 1);
      this.m_msg.AddIndex(vertexCount + 5);
      this.m_msg.AddIndex(vertexCount + 3);
      this.m_msg.AddIndex(vertexCount + 2);
      this.m_msg.AddIndex(vertexCount + 6);
      this.m_msg.AddIndex(vertexCount + 3);
      this.m_msg.AddIndex(vertexCount + 6);
      this.m_msg.AddIndex(vertexCount + 7);
      this.m_msg.AddIndex(vertexCount + 1);
      this.m_msg.AddIndex(vertexCount + 3);
      this.m_msg.AddIndex(vertexCount + 5);
      this.m_msg.AddIndex(vertexCount + 5);
      this.m_msg.AddIndex(vertexCount + 3);
      this.m_msg.AddIndex(vertexCount + 7);
      this.m_msg.AddIndex(vertexCount + 4);
      this.m_msg.AddIndex(vertexCount + 2);
      this.m_msg.AddIndex(vertexCount);
      this.m_msg.AddIndex(vertexCount + 4);
      this.m_msg.AddIndex(vertexCount + 6);
      this.m_msg.AddIndex(vertexCount + 2);
    }

    public void Dispose()
    {
      MyRenderProxy.DebugDrawTriangles(this.m_msg, this.m_worldMatrix, this.m_color, this.m_depthRead, this.m_shaded);
    }

    void IDisposable.Dispose()
    {
      this.Dispose();
    }
  }
}
