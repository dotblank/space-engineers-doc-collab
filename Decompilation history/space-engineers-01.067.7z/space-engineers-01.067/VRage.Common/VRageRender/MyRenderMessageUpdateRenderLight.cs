﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageUpdateRenderLight
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;
using VRageRender.Lights;

namespace VRageRender
{
  public class MyRenderMessageUpdateRenderLight : IMyRenderMessage
  {
    public uint ID;
    public LightTypeEnum Type;
    public Vector3D Position;
    public int ParentID;
    public float Offset;
    public Color Color;
    public Color SpecularColor;
    public float Falloff;
    public float Range;
    public float Intensity;
    public bool LightOn;
    public bool UseInForwardRender;
    public float ReflectorIntensity;
    public bool ReflectorOn;
    public Vector3 ReflectorDirection;
    public Vector3 ReflectorUp;
    public float ReflectorConeMaxAngleCos;
    public Color ReflectorColor;
    public float ReflectorRange;
    public float ReflectorFalloff;
    public string ReflectorTexture;
    public float ShadowDistance;
    public bool CastShadows;
    public bool GlareOn;
    public MyGlareTypeEnum GlareType;
    public float GlareSize;
    public float GlareQuerySize;
    public float GlareIntensity;
    public string GlareMaterial;
    public float GlareMaxDistance;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.StateChangeOnce;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.UpdateRenderLight;
      }
    }
  }
}
