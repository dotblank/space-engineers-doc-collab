﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderStats
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRage.Stats;

namespace VRageRender
{
  public static class MyRenderStats
  {
    public static readonly MyStats Generic = new MyStats();
    public static Dictionary<MyRenderStats.ColumnEnum, List<MyStats>> m_stats;

    static MyRenderStats()
    {
      MyRenderStats.Generic = new MyStats();
      MyRenderStats.m_stats = new Dictionary<MyRenderStats.ColumnEnum, List<MyStats>>((IEqualityComparer<MyRenderStats.ColumnEnum>) EqualityComparer<MyRenderStats.ColumnEnum>.Default)
      {
        {
          MyRenderStats.ColumnEnum.Left,
          new List<MyStats>()
          {
            MyRenderStats.Generic
          }
        },
        {
          MyRenderStats.ColumnEnum.Right,
          new List<MyStats>()
        }
      };
    }

    public static void SetColumn(MyRenderStats.ColumnEnum column, params MyStats[] stats)
    {
      List<MyStats> list;
      if (!MyRenderStats.m_stats.TryGetValue(column, out list))
      {
        list = new List<MyStats>();
        MyRenderStats.m_stats[column] = list;
      }
      list.Clear();
      ListExtensions.AddArray<MyStats>(list, stats);
    }

    public enum ColumnEnum
    {
      Left,
      Right,
    }
  }
}
