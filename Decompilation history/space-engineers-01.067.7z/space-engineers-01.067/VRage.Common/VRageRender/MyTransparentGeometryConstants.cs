﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyTransparentGeometryConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRageRender
{
  internal static class MyTransparentGeometryConstants
  {
    public const int MAX_TRANSPARENT_GEOMETRY_COUNT = 50000;
    public const int MAX_PARTICLES_COUNT = 2500;
    public const int MAX_NEW_PARTICLES_COUNT = 34999;
    public const int MAX_COCKPIT_PARTICLES_COUNT = 30;
    public const int TRIANGLES_PER_TRANSPARENT_GEOMETRY = 2;
    public const int VERTICES_PER_TRIANGLE = 3;
    public const int INDICES_PER_TRANSPARENT_GEOMETRY = 6;
    public const int VERTICES_PER_TRANSPARENT_GEOMETRY = 4;
    public const int MAX_TRANSPARENT_GEOMETRY_VERTICES = 200000;
    public const int MAX_TRANSPARENT_GEOMETRY_INDICES = 300000;
    public const float SOFT_PARTICLE_DISTANCE_SCALE_DEFAULT_VALUE = 0.5f;
    public const float SOFT_PARTICLE_DISTANCE_SCALE_FOR_HARD_PARTICLES = 1000f;
    public const float SOFT_PARTICLE_DISTANCE_DECAL_PARTICLES = 10000f;
  }
}
