﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyVertexFormatVoxelPositionWeights
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public struct MyVertexFormatVoxelPositionWeights
  {
    internal MyUShort4 m_positionMaterials;

    public Vector3 Position
    {
      get
      {
        return new Vector3((float) this.m_positionMaterials.X, (float) this.m_positionMaterials.Y, (float) this.m_positionMaterials.Z) / (float) ushort.MaxValue;
      }
      set
      {
        this.m_positionMaterials.X = (ushort) ((double) value.X * (double) ushort.MaxValue);
        this.m_positionMaterials.Y = (ushort) ((double) value.Y * (double) ushort.MaxValue);
        this.m_positionMaterials.Z = (ushort) ((double) value.Z * (double) ushort.MaxValue);
      }
    }

    public float Weight0
    {
      get
      {
        return (float) ((int) this.m_positionMaterials.W >> 10) / 63f;
      }
      set
      {
        this.m_positionMaterials.W = (ushort) ((int) this.m_positionMaterials.W & 1023 | (int) (ushort) ((double) value * 63.0) << 10);
      }
    }

    public float Weight1
    {
      get
      {
        return (float) ((int) this.m_positionMaterials.W >> 5 & 31) / 31f;
      }
      set
      {
        this.m_positionMaterials.W = (ushort) ((int) this.m_positionMaterials.W & 64543 | (int) (ushort) ((double) value * 31.0) << 5);
      }
    }

    public float Weight2
    {
      get
      {
        return (float) ((int) this.m_positionMaterials.W & 31) / 31f;
      }
      set
      {
        this.m_positionMaterials.W = (ushort) ((uint) this.m_positionMaterials.W & 65504U | (uint) (ushort) ((double) value * 31.0));
      }
    }
  }
}
