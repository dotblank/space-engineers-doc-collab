﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderQualityProfile
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageRender.Effects;
using VRageRender.Textures;

namespace VRageRender
{
  public class MyRenderQualityProfile
  {
    public MyRenderQualityEnum RenderQuality;
    public float LodTransitionDistanceNear;
    public float LodTransitionDistanceFar;
    public float LodTransitionDistanceBackgroundStart;
    public float LodTransitionDistanceBackgroundEnd;
    public float[] LodClipmapRanges;
    public float EnvironmentLodTransitionDistance;
    public float EnvironmentLodTransitionDistanceBackground;
    public TextureQuality TextureQuality;
    public MyEffectVoxelsTechniqueEnum VoxelsRenderTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsRenderTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsBlendedRenderTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsMaskedRenderTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsHoloRenderTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsStencilTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsSkinnedTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsInstancedTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsInstancedSkinnedTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsInstancedGenericTechnique;
    public MyEffectModelsDNSTechniqueEnum ModelsInstancedGenericMaskedTechnique;
    public int ShadowCascadeLODTreshold;
    public int ShadowMapCascadeSize;
    public int SecondaryShadowMapCascadeSize;
    public float ShadowBiasMultiplier;
    public float ShadowSlopeBiasMultiplier;
    public bool EnableCascadeBlending;
    public bool EnableHDR;
    public bool EnableSSAO;
    public bool EnableFXAA;
    public bool EnableEnvironmentals;
    public bool EnableGodRays;
    public bool UseNormals;
    public bool NeedReloadContent;
    public bool UseChannels;
    public float SpotShadowsMaxDistanceMultiplier;
    public bool LowResParticles;
    public bool EnableDistantImpostors;
    public bool EnableFlyingDebris;
    public bool EnableDecals;
    public float ExplosionDebrisCountMultiplier;
  }
}
