﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderConstants
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using VRageRender.Effects;
using VRageRender.Textures;

namespace VRageRender
{
  public static class MyRenderConstants
  {
    public static readonly int MAX_RENDER_ELEMENTS_COUNT = Environment.Is64BitProcess ? 131072 : 65536;
    public static readonly int DEFAULT_RENDER_MODULE_PRIORITY = 100;
    public static readonly int SPOT_SHADOW_RENDER_TARGET_COUNT = 16;
    public static readonly int ENVIRONMENT_MAP_SIZE = 128;
    public static readonly int MAX_OCCLUSION_QUERIES = 96;
    public static readonly int MIN_OBJECTS_IN_CULLING_STRUCTURE = 128;
    public static readonly int MAX_CULLING_OBJECTS = 64;
    public static readonly int MIN_PREFAB_OBJECTS_IN_CULLING_STRUCTURE = 32;
    public static readonly int MAX_CULLING_PREFAB_OBJECTS = 256;
    public static readonly int MIN_VOXEL_RENDER_CELLS_IN_CULLING_STRUCTURE = 2;
    public static readonly int MAX_CULLING_VOXEL_RENDER_CELLS = 128;
    public static float m_maxCullingPrefabObjectMultiplier = 1f;
    public static readonly float DISTANCE_CULL_RATIO = 100f;
    public static readonly float DISTANCE_LIGHT_CULL_RATIO = 40f;
    public static readonly int MAX_SHADER_BONES = 60;
    public static readonly MyRenderQualityProfile[] m_renderQualityProfiles = new MyRenderQualityProfile[Enum.GetValues(typeof (MyRenderQualityEnum)).Length];
    public const float MAX_GPU_OCCLUSION_QUERY_DISTANCE = 150f;
    public const int RENDER_STEP_IN_MILLISECONDS = 16;
    public const float RENDER_STEP_IN_SECONDS = 0.016f;

    public static MyRenderQualityProfile RenderQualityProfile { get; private set; }

    public static event EventHandler OnRenderQualityChange = null;

    static MyRenderConstants()
    {
      MyRenderConstants.m_renderQualityProfiles[0] = new MyRenderQualityProfile()
      {
        RenderQuality = MyRenderQualityEnum.NORMAL,
        LodTransitionDistanceNear = 150f,
        LodTransitionDistanceFar = 200f,
        LodTransitionDistanceBackgroundStart = 1000f,
        LodTransitionDistanceBackgroundEnd = 1100f,
        LodClipmapRanges = new float[6]
        {
          100f,
          300f,
          1000f,
          3000f,
          35000f,
          100000f
        },
        EnvironmentLodTransitionDistance = 200f,
        EnvironmentLodTransitionDistanceBackground = 300f,
        TextureQuality = TextureQuality.Half,
        VoxelsRenderTechnique = MyEffectVoxelsTechniqueEnum.Normal,
        ModelsRenderTechnique = MyEffectModelsDNSTechniqueEnum.Normal,
        ModelsBlendedRenderTechnique = MyEffectModelsDNSTechniqueEnum.NormalBlended,
        ModelsMaskedRenderTechnique = MyEffectModelsDNSTechniqueEnum.NormalMasked,
        ModelsHoloRenderTechnique = MyEffectModelsDNSTechniqueEnum.Holo,
        ModelsStencilTechnique = MyEffectModelsDNSTechniqueEnum.Stencil,
        ModelsSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.HighSkinned,
        ModelsInstancedTechnique = MyEffectModelsDNSTechniqueEnum.NormalInstanced,
        ModelsInstancedSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.NormalInstancedSkinned,
        ModelsInstancedGenericTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGeneric,
        ModelsInstancedGenericMaskedTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGenericMasked,
        ShadowCascadeLODTreshold = 3,
        ShadowMapCascadeSize = 1024,
        SecondaryShadowMapCascadeSize = 64,
        ShadowBiasMultiplier = 1f,
        ShadowSlopeBiasMultiplier = 2.5f,
        EnableCascadeBlending = false,
        EnableHDR = false,
        EnableSSAO = false,
        EnableFXAA = false,
        EnableEnvironmentals = false,
        EnableGodRays = false,
        UseNormals = true,
        NeedReloadContent = true,
        UseChannels = false,
        SpotShadowsMaxDistanceMultiplier = 1f,
        LowResParticles = true,
        EnableDistantImpostors = false,
        EnableFlyingDebris = false,
        EnableDecals = false,
        ExplosionDebrisCountMultiplier = 0.5f
      };
      MyRenderConstants.m_renderQualityProfiles[3] = new MyRenderQualityProfile()
      {
        RenderQuality = MyRenderQualityEnum.LOW,
        LodTransitionDistanceNear = 60f,
        LodTransitionDistanceFar = 80f,
        LodTransitionDistanceBackgroundStart = 300f,
        LodTransitionDistanceBackgroundEnd = 350f,
        LodClipmapRanges = new float[6]
        {
          60f,
          200f,
          500f,
          1500f,
          35000f,
          100000f
        },
        EnvironmentLodTransitionDistance = 10f,
        EnvironmentLodTransitionDistanceBackground = 20f,
        TextureQuality = TextureQuality.OneFourth,
        VoxelsRenderTechnique = MyEffectVoxelsTechniqueEnum.Low,
        ModelsRenderTechnique = MyEffectModelsDNSTechniqueEnum.Low,
        ModelsBlendedRenderTechnique = MyEffectModelsDNSTechniqueEnum.LowBlended,
        ModelsMaskedRenderTechnique = MyEffectModelsDNSTechniqueEnum.LowMasked,
        ModelsHoloRenderTechnique = MyEffectModelsDNSTechniqueEnum.Holo,
        ModelsStencilTechnique = MyEffectModelsDNSTechniqueEnum.StencilLow,
        ModelsSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.HighSkinned,
        ModelsInstancedTechnique = MyEffectModelsDNSTechniqueEnum.HighInstanced,
        ModelsInstancedSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.HighInstancedSkinned,
        ModelsInstancedGenericTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGeneric,
        ModelsInstancedGenericMaskedTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGenericMasked,
        ShadowCascadeLODTreshold = 3,
        ShadowMapCascadeSize = 512,
        SecondaryShadowMapCascadeSize = 32,
        ShadowBiasMultiplier = 1f,
        ShadowSlopeBiasMultiplier = 1f,
        EnableCascadeBlending = false,
        EnableHDR = false,
        EnableSSAO = false,
        EnableFXAA = false,
        EnableEnvironmentals = false,
        EnableGodRays = false,
        UseNormals = false,
        NeedReloadContent = true,
        UseChannels = false,
        SpotShadowsMaxDistanceMultiplier = 0.0f,
        LowResParticles = false,
        EnableDistantImpostors = false,
        EnableFlyingDebris = false,
        EnableDecals = false,
        ExplosionDebrisCountMultiplier = 0.0f
      };
      MyRenderConstants.m_renderQualityProfiles[1] = new MyRenderQualityProfile()
      {
        RenderQuality = MyRenderQualityEnum.HIGH,
        LodTransitionDistanceNear = 200f,
        LodTransitionDistanceFar = 250f,
        LodTransitionDistanceBackgroundStart = 1800f,
        LodTransitionDistanceBackgroundEnd = 2000f,
        LodClipmapRanges = new float[6]
        {
          150f,
          450f,
          1000f,
          3000f,
          35000f,
          100000f
        },
        EnvironmentLodTransitionDistance = 40f,
        EnvironmentLodTransitionDistanceBackground = 80f,
        TextureQuality = TextureQuality.Full,
        VoxelsRenderTechnique = MyEffectVoxelsTechniqueEnum.High,
        ModelsRenderTechnique = MyEffectModelsDNSTechniqueEnum.High,
        ModelsBlendedRenderTechnique = MyEffectModelsDNSTechniqueEnum.HighBlended,
        ModelsMaskedRenderTechnique = MyEffectModelsDNSTechniqueEnum.HighMasked,
        ModelsHoloRenderTechnique = MyEffectModelsDNSTechniqueEnum.Holo,
        ModelsStencilTechnique = MyEffectModelsDNSTechniqueEnum.Stencil,
        ModelsSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.HighSkinned,
        ModelsInstancedTechnique = MyEffectModelsDNSTechniqueEnum.HighInstanced,
        ModelsInstancedSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.HighInstancedSkinned,
        ModelsInstancedGenericTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGeneric,
        ModelsInstancedGenericMaskedTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGenericMasked,
        ShadowCascadeLODTreshold = 3,
        ShadowMapCascadeSize = 1024,
        SecondaryShadowMapCascadeSize = 64,
        ShadowBiasMultiplier = 0.5f,
        ShadowSlopeBiasMultiplier = 2.5f,
        EnableCascadeBlending = true,
        EnableHDR = true,
        EnableSSAO = true,
        EnableFXAA = true,
        EnableEnvironmentals = true,
        EnableGodRays = true,
        UseNormals = true,
        NeedReloadContent = false,
        UseChannels = true,
        SpotShadowsMaxDistanceMultiplier = 2.5f,
        LowResParticles = false,
        EnableDistantImpostors = true,
        EnableFlyingDebris = true,
        EnableDecals = true,
        ExplosionDebrisCountMultiplier = 0.8f
      };
      MyRenderConstants.m_renderQualityProfiles[2] = new MyRenderQualityProfile()
      {
        RenderQuality = MyRenderQualityEnum.EXTREME,
        LodTransitionDistanceNear = 1000f,
        LodTransitionDistanceFar = 1100f,
        LodTransitionDistanceBackgroundStart = 4200f,
        LodTransitionDistanceBackgroundEnd = 5000f,
        LodClipmapRanges = new float[6]
        {
          150f,
          450f,
          1000f,
          3000f,
          35000f,
          100000f
        },
        EnvironmentLodTransitionDistance = 50f,
        EnvironmentLodTransitionDistanceBackground = 100f,
        TextureQuality = TextureQuality.Full,
        VoxelsRenderTechnique = MyEffectVoxelsTechniqueEnum.Extreme,
        ModelsRenderTechnique = MyEffectModelsDNSTechniqueEnum.Extreme,
        ModelsBlendedRenderTechnique = MyEffectModelsDNSTechniqueEnum.ExtremeBlended,
        ModelsMaskedRenderTechnique = MyEffectModelsDNSTechniqueEnum.ExtremeMasked,
        ModelsHoloRenderTechnique = MyEffectModelsDNSTechniqueEnum.Holo,
        ModelsStencilTechnique = MyEffectModelsDNSTechniqueEnum.Stencil,
        ModelsSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.ExtremeSkinned,
        ModelsInstancedTechnique = MyEffectModelsDNSTechniqueEnum.ExtremeInstanced,
        ModelsInstancedSkinnedTechnique = MyEffectModelsDNSTechniqueEnum.ExtremeInstancedSkinned,
        ModelsInstancedGenericTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGeneric,
        ModelsInstancedGenericMaskedTechnique = MyEffectModelsDNSTechniqueEnum.InstancedGenericMasked,
        ShadowCascadeLODTreshold = 4,
        ShadowMapCascadeSize = 2048,
        SecondaryShadowMapCascadeSize = 128,
        ShadowBiasMultiplier = 0.5f,
        ShadowSlopeBiasMultiplier = 1f,
        EnableCascadeBlending = true,
        EnableHDR = true,
        EnableSSAO = true,
        EnableFXAA = true,
        EnableEnvironmentals = true,
        EnableGodRays = true,
        UseNormals = true,
        NeedReloadContent = false,
        UseChannels = true,
        SpotShadowsMaxDistanceMultiplier = 3f,
        LowResParticles = false,
        EnableDistantImpostors = true,
        EnableFlyingDebris = true,
        EnableDecals = true,
        ExplosionDebrisCountMultiplier = 3f
      };
      MyRenderConstants.RenderQualityProfile = MyRenderConstants.m_renderQualityProfiles[0];
    }

    public static void SwitchRenderQuality(MyRenderQualityEnum renderQuality)
    {
      MyRenderConstants.RenderQualityProfile = MyRenderConstants.m_renderQualityProfiles[(int) renderQuality];
      if (MyRenderConstants.OnRenderQualityChange == null)
        return;
      MyRenderConstants.OnRenderQualityChange((object) renderQuality, (EventArgs) null);
    }
  }
}
