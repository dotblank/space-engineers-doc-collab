﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyAnimatedPropertyTransparentMaterial
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Xml;
using VRage.Common.Animations;

namespace VRageRender
{
  public class MyAnimatedPropertyTransparentMaterial : MyAnimatedProperty<MyTransparentMaterial>
  {
    public MyAnimatedPropertyTransparentMaterial()
    {
    }

    public MyAnimatedPropertyTransparentMaterial(string name)
      : this(name, (MyAnimatedProperty<MyTransparentMaterial>.InterpolatorDelegate) null)
    {
    }

    public MyAnimatedPropertyTransparentMaterial(string name, MyAnimatedProperty<MyTransparentMaterial>.InterpolatorDelegate interpolator)
      : base(name, interpolator)
    {
    }

    protected override void Init()
    {
      this.Interpolator = new MyAnimatedProperty<MyTransparentMaterial>.InterpolatorDelegate(MyTransparentMaterialInterpolator.Switch);
      base.Init();
    }

    public override IMyConstProperty Duplicate()
    {
      MyAnimatedPropertyTransparentMaterial transparentMaterial = new MyAnimatedPropertyTransparentMaterial(this.Name);
      this.Duplicate((IMyConstProperty) transparentMaterial);
      return (IMyConstProperty) transparentMaterial;
    }

    public override void SerializeValue(XmlWriter writer, object value)
    {
      writer.WriteValue(((MyTransparentMaterial) value).Name);
    }

    public override void DeserializeValue(XmlReader reader, out object value)
    {
      base.DeserializeValue(reader, out value);
      value = (object) MyTransparentMaterials.GetMaterial((string) value);
    }

    protected override bool EqualsValues(object value1, object value2)
    {
      return ((MyTransparentMaterial) value1).Name == ((MyTransparentMaterial) value2).Name;
    }
  }
}
