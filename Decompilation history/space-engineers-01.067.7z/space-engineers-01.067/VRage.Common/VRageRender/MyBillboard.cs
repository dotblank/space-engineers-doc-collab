﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyBillboard
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using VRageMath;

namespace VRageRender
{
  public class MyBillboard : IComparable
  {
    public int ParentID = -1;
    public List<MyBillboard> ContainedBillboards = new List<MyBillboard>();
    public string Material;
    public float BlendTextureRatio;
    public string BlendMaterial;
    public Vector3D Position0;
    public Vector3D Position1;
    public Vector3D Position2;
    public Vector3D Position3;
    public Color Color;
    public Vector2 UVOffset;
    public float DistanceSquared;
    public float Size;
    public float Reflectivity;
    public bool EnableColorize;
    public bool Near;
    public bool Lowres;
    public int Priority;
    public int CustomViewProjection;

    public int CompareTo(object compareToObject)
    {
      MyBillboard myBillboard = (MyBillboard) compareToObject;
      if (this.CustomViewProjection != myBillboard.CustomViewProjection)
        return this.CustomViewProjection.CompareTo(myBillboard.CustomViewProjection);
      if (this.Priority == myBillboard.Priority)
        return myBillboard.DistanceSquared.CompareTo(this.DistanceSquared);
      else
        return this.Priority.CompareTo(myBillboard.Priority);
    }
  }
}
