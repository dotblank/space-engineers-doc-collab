﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.IMyRender
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using SharpDX;
using System;
using VRage;
using VRageMath;
using VRageRender.Profiler;

namespace VRageRender
{
  public interface IMyRender
  {
    string RootDirectory { get; set; }

    string RootDirectoryEffects { get; set; }

    string RootDirectoryDebug { get; set; }

    MyRenderSettings Settings { get; }

    MySharedData SharedData { get; }

    MyTimeSpan CurrentDrawTime { get; set; }

    MyViewport MainViewport { get; }

    Vector2I BackBufferResolution { get; }

    MyMessageQueue OutputQueue { get; }

    uint GlobalMessageCounter { get; set; }

    MyRenderDeviceSettings CreateDevice(IntPtr windowHandle, MyRenderDeviceSettings? settingsToTry);

    void DisposeDevice();

    long GetAvailableTextureMemory();

    MyRenderDeviceCooperativeLevel TestDeviceCooperativeLevel();

    bool ResetDevice();

    void DrawBegin();

    void DrawEnd();

    bool SettingsChanged(MyRenderDeviceSettings settings);

    void ApplySettings(MyRenderDeviceSettings settings);

    void RestoreDXGISwapchainFullscreenMode();

    void Present();

    void ClearBackbuffer(ColorBGRA clearColor);

    void LoadContent(MyRenderQualityEnum quality);

    void UnloadContent();

    void UnloadData();

    void ReloadContent(MyRenderQualityEnum quality);

    void EnqueueMessage(IMyRenderMessage message, bool limitMaxQueueSize);

    void ProcessMessages();

    void EnqueueOutputMessage(IMyRenderMessage message);

    void ResetEnvironmentProbes();

    MyRenderProfiler GetRenderProfiler();

    void Draw(bool draw = true);

    bool IsVideoValid(uint id);

    VideoState GetVideoState(uint id);
  }
}
