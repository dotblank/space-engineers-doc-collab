﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderDeviceSettings
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;

namespace VRageRender
{
  public struct MyRenderDeviceSettings : IEquatable<MyRenderDeviceSettings>
  {
    public int AdapterOrdinal;
    public MyWindowModeEnum WindowMode;
    public int BackBufferWidth;
    public int BackBufferHeight;
    public int RefreshRate;
    public bool VSync;

    public MyRenderDeviceSettings(int adapter, MyWindowModeEnum windowMode, int width, int height, int refreshRate, bool vsync)
    {
      this.AdapterOrdinal = adapter;
      this.WindowMode = windowMode;
      this.BackBufferWidth = width;
      this.BackBufferHeight = height;
      this.RefreshRate = refreshRate;
      this.VSync = vsync;
    }

    bool IEquatable<MyRenderDeviceSettings>.Equals(MyRenderDeviceSettings other)
    {
      return this.Equals(ref other);
    }

    public bool Equals(ref MyRenderDeviceSettings other)
    {
      if (this.AdapterOrdinal == other.AdapterOrdinal && this.WindowMode == other.WindowMode && (this.BackBufferWidth == other.BackBufferWidth && this.BackBufferHeight == other.BackBufferHeight) && this.RefreshRate == other.RefreshRate)
        return this.VSync == other.VSync;
      else
        return false;
    }
  }
}
