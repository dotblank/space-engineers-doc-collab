﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageUpdateModelProperties
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public class MyRenderMessageUpdateModelProperties : IMyRenderMessage
  {
    public uint ID;
    public int LOD;
    public string Model;
    public int MeshIndex;
    public string MaterialName;
    public bool? Enabled;
    public Color? DiffuseColor;
    public float? SpecularPower;
    public float? SpecularIntensity;
    public float? Emissivity;

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.StateChangeOnce;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.UpdateModelProperties;
      }
    }
  }
}
