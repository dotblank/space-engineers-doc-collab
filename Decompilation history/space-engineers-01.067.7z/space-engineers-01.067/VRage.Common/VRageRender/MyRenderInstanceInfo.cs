﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderInstanceInfo
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRageRender
{
  public struct MyRenderInstanceInfo
  {
    public readonly uint InstanceBufferId;
    public readonly int InstanceStart;
    public readonly int InstanceCount;
    public readonly float MaxViewDistance;
    public readonly MyInstanceFlagsEnum Flags;

    public bool CastShadows
    {
      get
      {
        return (this.Flags & MyInstanceFlagsEnum.CastShadows) != (MyInstanceFlagsEnum) 0;
      }
    }

    public bool ShowLod1
    {
      get
      {
        return (this.Flags & MyInstanceFlagsEnum.ShowLod1) != (MyInstanceFlagsEnum) 0;
      }
    }

    public bool EnableColorMask
    {
      get
      {
        return (this.Flags & MyInstanceFlagsEnum.EnableColorMask) != (MyInstanceFlagsEnum) 0;
      }
    }

    public MyRenderInstanceInfo(uint instanceBufferId, int instanceStart, int instanceCount, float maxViewDistance, MyInstanceFlagsEnum flags)
    {
      this.Flags = flags;
      this.InstanceBufferId = instanceBufferId;
      this.InstanceStart = instanceStart;
      this.InstanceCount = instanceCount;
      this.MaxViewDistance = maxViewDistance;
    }

    public MyRenderInstanceInfo(uint instanceBufferId, int instanceStart, int instanceCount, bool castShadows, bool showLod1, float maxViewDistance, bool enableColorMaskHsv)
    {
      this.Flags = (MyInstanceFlagsEnum) ((int) (byte) ((castShadows ? 1 : 0) | (showLod1 ? 2 : 0)) | (enableColorMaskHsv ? 4 : 0));
      this.InstanceBufferId = instanceBufferId;
      this.InstanceStart = instanceStart;
      this.InstanceCount = instanceCount;
      this.MaxViewDistance = maxViewDistance;
    }
  }
}
