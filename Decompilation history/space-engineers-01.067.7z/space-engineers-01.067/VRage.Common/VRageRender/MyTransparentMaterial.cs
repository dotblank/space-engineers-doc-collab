﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyTransparentMaterial
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public class MyTransparentMaterial
  {
    public Vector4 Color = Vector4.One;
    public readonly string Name;
    public readonly string Texture;
    public readonly bool CanBeAffectedByOtherLights;
    public readonly bool AlphaMistingEnable;
    public readonly bool IgnoreDepth;
    public readonly bool NeedSort;
    public readonly bool UseAtlas;
    public readonly float AlphaMistingStart;
    public readonly float AlphaMistingEnd;
    public readonly float SoftParticleDistanceScale;
    public readonly float Emissivity;
    public readonly float AlphaSaturation;
    public Vector2 UVOffset;
    public Vector2 UVSize;
    public float Reflectivity;
    public object RenderTexture;

    public MyTransparentMaterial(string Name, string Texture, float SoftParticleDistanceScale, bool CanBeAffectedByOtherLights, bool AlphaMistingEnable, Vector4 Color, bool IgnoreDepth = false, bool NeedSort = true, bool UseAtlas = false, float Emissivity = 0.0f, float AlphaMistingStart = 1f, float AlphaMistingEnd = 4f, float AlphaSaturation = 1f, float Reflectivity = 0.0f)
    {
      this.Name = Name;
      this.Texture = Texture;
      this.SoftParticleDistanceScale = SoftParticleDistanceScale;
      this.CanBeAffectedByOtherLights = CanBeAffectedByOtherLights;
      this.AlphaMistingEnable = AlphaMistingEnable;
      this.IgnoreDepth = IgnoreDepth;
      this.NeedSort = NeedSort;
      this.UseAtlas = UseAtlas;
      this.Emissivity = Emissivity;
      this.AlphaMistingStart = AlphaMistingStart;
      this.AlphaMistingEnd = AlphaMistingEnd;
      this.AlphaSaturation = AlphaSaturation;
      this.Color = Color;
      this.Reflectivity = Reflectivity;
      this.UVOffset = new Vector2(0.0f, 0.0f);
      this.UVSize = new Vector2(1f, 1f);
    }
  }
}
