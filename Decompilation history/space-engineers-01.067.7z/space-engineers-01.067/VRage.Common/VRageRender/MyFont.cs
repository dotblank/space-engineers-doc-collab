﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyFont
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using SysUtils.Utils;
using VRage.Common.Utils;
using VRageMath;

namespace VRageRender
{
  public class MyFont
  {
    private static readonly MyFont.KernPairComparer m_kernPairComparer = new MyFont.KernPairComparer();
    protected readonly Dictionary<int, MyFont.MyBitmapInfo> m_bitmapInfoByID = new Dictionary<int, MyFont.MyBitmapInfo>();
    protected readonly Dictionary<char, MyFont.MyGlyphInfo> m_glyphInfoByChar = new Dictionary<char, MyFont.MyGlyphInfo>();
    protected readonly Dictionary<MyFont.KernPair, sbyte> m_kernByPair = new Dictionary<MyFont.KernPair, sbyte>((IEqualityComparer<MyFont.KernPair>) MyFont.m_kernPairComparer);
    public bool KernEnabled = true;
    protected const char REPLACEMENT_CHARACTER = '□';
    protected const char ELLIPSIS = '…';
    public const char NEW_LINE = '\n';
    protected readonly string m_fontDirectory;
    protected string path;
    public int Spacing;
    public float Depth;

    public int Baseline { get; private set; }

    public int LineHeight { get; private set; }

    public MyFont(string fontFilePath, int spacing = 1)
    {
      MyLog.Default.WriteLine("MyFont.Ctor - START");
      using (MyLog.Default.IndentUsing(LoggingOptions.MISC_RENDER_ASSETS))
      {
        this.Spacing = spacing;
        MyLog.Default.WriteLine("Font filename: " + fontFilePath);
        this.path = Path.Combine(MyFileSystem.ContentPath, fontFilePath);
        if (!File.Exists(this.path))
          throw new Exception(string.Format("Unable to find font path '{0}'.", (object) this.path));
        this.m_fontDirectory = Path.GetDirectoryName(this.path);
        this.LoadFontXML();
        MyLog.Default.WriteLine("FontFilePath: " + this.path);
        MyLog.Default.WriteLine("LineHeight: " + (object) this.LineHeight);
        MyLog.Default.WriteLine("Baseline: " + (object) this.Baseline);
        MyLog.Default.WriteLine("KernEnabled: " + (object) (bool) (this.KernEnabled ? 1 : 0));
      }
      MyLog.Default.WriteLine("MyFont.Ctor - END");
    }

    public Vector2 MeasureString(StringBuilder text, float scale)
    {
      scale *= 0.7783784f;
      float num1 = 0.0f;
      char chLeft = char.MinValue;
      float num2 = 0.0f;
      int num3 = 1;
      for (int index = 0; index < text.Length; ++index)
      {
        char c = text[index];
        if ((int) c == 10)
        {
          ++num3;
          num1 = 0.0f;
          chLeft = char.MinValue;
        }
        else if (this.CanWriteOrReplace(ref c))
        {
          MyFont.MyGlyphInfo myGlyphInfo = this.m_glyphInfoByChar[c];
          if (this.KernEnabled)
          {
            num1 += (float) this.CalcKern(chLeft, c);
            chLeft = c;
          }
          num1 += (float) myGlyphInfo.pxAdvanceWidth;
          if (index < text.Length - 1)
            num1 += (float) this.Spacing;
          if ((double) num1 > (double) num2)
            num2 = num1;
        }
      }
      return new Vector2(num2 * scale, (float) (num3 * this.LineHeight) * scale);
    }

    protected bool CanWriteOrReplace(ref char c)
    {
      if (!this.m_glyphInfoByChar.ContainsKey(c))
      {
        if (!this.CanUseReplacementCharacter(c))
          return false;
        c = '□';
      }
      return true;
    }

    public int ComputeCharsThatFit(StringBuilder text, float scale, float maxTextWidth)
    {
      scale *= 0.7783784f;
      maxTextWidth /= scale;
      float num = 0.0f;
      char chLeft = char.MinValue;
      for (int index = 0; index < text.Length; ++index)
      {
        char c = text[index];
        if (this.CanWriteOrReplace(ref c))
        {
          MyFont.MyGlyphInfo myGlyphInfo = this.m_glyphInfoByChar[c];
          if (this.KernEnabled)
          {
            num += (float) this.CalcKern(chLeft, c);
            chLeft = c;
          }
          num += (float) myGlyphInfo.pxAdvanceWidth;
          if (index < text.Length - 1)
            num += (float) this.Spacing;
          if ((double) num > (double) maxTextWidth)
            return index;
        }
      }
      return text.Length;
    }

    protected float ComputeScaledAdvanceWithKern(char c, char cLast, float scale)
    {
      MyFont.MyGlyphInfo myGlyphInfo = this.m_glyphInfoByChar[c];
      float num1 = 0.0f;
      if (this.KernEnabled)
      {
        int num2 = this.CalcKern(cLast, c);
        num1 += (float) num2 * scale;
      }
      return num1 + (float) myGlyphInfo.pxAdvanceWidth * scale;
    }

    protected bool CanUseReplacementCharacter(char c)
    {
      if (!char.IsWhiteSpace(c))
        return !char.IsControl(c);
      else
        return false;
    }

    protected int CalcKern(char chLeft, char chRight)
    {
      sbyte num;
      this.m_kernByPair.TryGetValue(new MyFont.KernPair(chLeft, chRight), out num);
      return (int) num;
    }

    private void LoadFontXML()
    {
      XmlDocument xmlDocument = new XmlDocument();
      using (Stream inStream = MyFileSystem.OpenRead(this.path))
        xmlDocument.Load(inStream);
      this.LoadFontXML(xmlDocument.ChildNodes);
    }

    private void LoadFontXML(XmlNodeList xnl)
    {
      foreach (XmlNode n in xnl)
      {
        if (n.Name == "font")
        {
          this.Baseline = int.Parse(MyFont.GetXMLAttribute(n, "base"));
          this.LineHeight = int.Parse(MyFont.GetXMLAttribute(n, "height"));
          this.LoadFontXML_font(n.ChildNodes);
        }
      }
    }

    private void LoadFontXML_font(XmlNodeList xnl)
    {
      foreach (XmlNode xmlNode in xnl)
      {
        if (xmlNode.Name == "bitmaps")
          this.LoadFontXML_bitmaps(xmlNode.ChildNodes);
        if (xmlNode.Name == "glyphs")
          this.LoadFontXML_glyphs(xmlNode.ChildNodes);
        if (xmlNode.Name == "kernpairs")
          this.LoadFontXML_kernpairs(xmlNode.ChildNodes);
      }
    }

    private void LoadFontXML_bitmaps(XmlNodeList xnl)
    {
      foreach (XmlNode n in xnl)
      {
        if (n.Name == "bitmap")
        {
          string xmlAttribute1 = MyFont.GetXMLAttribute(n, "id");
          string xmlAttribute2 = MyFont.GetXMLAttribute(n, "name");
          string[] strArray = MyFont.GetXMLAttribute(n, "size").Split('x');
          MyFont.MyBitmapInfo myBitmapInfo;
          myBitmapInfo.strFilename = xmlAttribute2;
          myBitmapInfo.nX = int.Parse(strArray[0]);
          myBitmapInfo.nY = int.Parse(strArray[1]);
          this.m_bitmapInfoByID[int.Parse(xmlAttribute1)] = myBitmapInfo;
        }
      }
    }

    private void LoadFontXML_glyphs(XmlNodeList xnl)
    {
      foreach (XmlNode n in xnl)
      {
        if (n.Name == "glyph")
        {
          string xmlAttribute1 = MyFont.GetXMLAttribute(n, "ch");
          string xmlAttribute2 = MyFont.GetXMLAttribute(n, "bm");
          string xmlAttribute3 = MyFont.GetXMLAttribute(n, "loc");
          string xmlAttribute4 = MyFont.GetXMLAttribute(n, "size");
          string xmlAttribute5 = MyFont.GetXMLAttribute(n, "aw");
          string xmlAttribute6 = MyFont.GetXMLAttribute(n, "lsb");
          if (xmlAttribute3 == "")
            xmlAttribute3 = MyFont.GetXMLAttribute(n, "origin");
          string[] strArray1 = xmlAttribute3.Split(',');
          string[] strArray2 = xmlAttribute4.Split('x');
          this.m_glyphInfoByChar[xmlAttribute1[0]] = new MyFont.MyGlyphInfo()
          {
            nBitmapID = ushort.Parse(xmlAttribute2),
            pxLocX = ushort.Parse(strArray1[0]),
            pxLocY = ushort.Parse(strArray1[1]),
            pxWidth = byte.Parse(strArray2[0]),
            pxHeight = byte.Parse(strArray2[1]),
            pxAdvanceWidth = byte.Parse(xmlAttribute5),
            pxLeftSideBearing = sbyte.Parse(xmlAttribute6)
          };
        }
      }
    }

    private void LoadFontXML_kernpairs(XmlNodeList xnl)
    {
      foreach (XmlNode n in xnl)
      {
        if (n.Name == "kernpair")
          this.m_kernByPair[new MyFont.KernPair(MyFont.GetXMLAttribute(n, "left")[0], MyFont.GetXMLAttribute(n, "right")[0])] = sbyte.Parse(MyFont.GetXMLAttribute(n, "adjust"));
      }
    }

    private static string GetXMLAttribute(XmlNode n, string strAttr)
    {
      XmlAttribute xmlAttribute = n.Attributes.GetNamedItem(strAttr) as XmlAttribute;
      if (xmlAttribute != null)
        return xmlAttribute.Value;
      else
        return "";
    }

    protected struct MyGlyphInfo
    {
      public ushort nBitmapID;
      public ushort pxLocX;
      public ushort pxLocY;
      public byte pxWidth;
      public byte pxHeight;
      public byte pxAdvanceWidth;
      public sbyte pxLeftSideBearing;
    }

    protected struct MyBitmapInfo
    {
      public string strFilename;
      public int nX;
      public int nY;
    }

    protected struct KernPair
    {
      public char Left;
      public char Right;

      public KernPair(char l, char r)
      {
        this.Left = l;
        this.Right = r;
      }
    }

    protected class KernPairComparer : IComparer<MyFont.KernPair>, IEqualityComparer<MyFont.KernPair>
    {
      public int Compare(MyFont.KernPair x, MyFont.KernPair y)
      {
        if ((int) x.Left != (int) y.Left)
          return x.Left.CompareTo(y.Left);
        else
          return x.Right.CompareTo(y.Right);
      }

      public bool Equals(MyFont.KernPair x, MyFont.KernPair y)
      {
        if ((int) x.Left == (int) y.Left)
          return (int) x.Right == (int) y.Right;
        else
          return false;
      }

      public int GetHashCode(MyFont.KernPair x)
      {
        return x.Left.GetHashCode() ^ x.Right.GetHashCode();
      }
    }
  }
}
