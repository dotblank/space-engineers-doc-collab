﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyRenderMessageDebugDrawTriangles
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace VRageRender
{
  public class MyRenderMessageDebugDrawTriangles : IMyRenderMessage, IDrawTrianglesMessage
  {
    public List<int> Indices = new List<int>();
    public List<Vector3D> Vertices = new List<Vector3D>();
    public Color Color;
    public MatrixD WorldMatrix;
    public bool DepthRead;
    public bool Shaded;

    public int VertexCount
    {
      get
      {
        return this.Vertices.Count;
      }
    }

    MyRenderMessageType IMyRenderMessage.MessageClass
    {
      get
      {
        return MyRenderMessageType.Draw;
      }
    }

    MyRenderMessageEnum IMyRenderMessage.MessageType
    {
      get
      {
        return MyRenderMessageEnum.DebugDrawTriangles;
      }
    }

    public void AddIndex(int index)
    {
      this.Indices.Add(index);
    }

    public void AddVertex(Vector3D position)
    {
      this.Vertices.Add(position);
    }

    public void AddTriangle(ref Vector3D v0, ref Vector3D v1, ref Vector3D v2)
    {
      int count = this.Vertices.Count;
      this.Indices.Add(count);
      this.Indices.Add(count + 1);
      this.Indices.Add(count + 2);
      this.Vertices.Add(v0);
      this.Vertices.Add(v1);
      this.Vertices.Add(v2);
    }
  }
}
