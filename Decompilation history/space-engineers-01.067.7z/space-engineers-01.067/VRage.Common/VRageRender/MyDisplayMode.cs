﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyDisplayMode
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Diagnostics;

namespace VRageRender
{
  [DebuggerDisplay("{Width}x{Height}@{RefreshRate}Hz")]
  public struct MyDisplayMode
  {
    public int Width;
    public int Height;
    public int RefreshRate;
    public int? RefreshRateDenominator;
    public float AspectRatio;

    public float RefreshRateF
    {
      get
      {
        if (!this.RefreshRateDenominator.HasValue)
          return (float) this.RefreshRate;
        else
          return (float) this.RefreshRate / (float) this.RefreshRateDenominator.Value;
      }
    }

    public MyDisplayMode(int width, int height, int refreshRate, int? refreshRateDenominator = null)
    {
      this.Width = width;
      this.Height = height;
      this.RefreshRate = refreshRate;
      this.RefreshRateDenominator = refreshRateDenominator;
      this.AspectRatio = (float) width / (float) height;
    }

    public override string ToString()
    {
      if (this.RefreshRateDenominator.HasValue)
        return string.Format("{0}x{1}@{2}Hz", (object) this.Width, (object) this.Height, (object) (float) ((double) this.RefreshRate / (double) this.RefreshRateDenominator.Value));
      else
        return string.Format("{0}x{1}@{2}Hz", (object) this.Width, (object) this.Height, (object) this.RefreshRate);
    }
  }
}
