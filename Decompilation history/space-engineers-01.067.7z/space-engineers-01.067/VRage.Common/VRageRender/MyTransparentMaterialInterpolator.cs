﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyTransparentMaterialInterpolator
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

namespace VRageRender
{
  public static class MyTransparentMaterialInterpolator
  {
    public static void Switch(ref MyTransparentMaterial val1, ref MyTransparentMaterial val2, float time, out MyTransparentMaterial value)
    {
      value = (double) time < 0.5 ? val1 : val2;
    }
  }
}
