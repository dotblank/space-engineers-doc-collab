﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.MyBillboardViewProjection
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using VRageMath;

namespace VRageRender
{
  public struct MyBillboardViewProjection
  {
    public MatrixD View;
    public Matrix ViewAtZero;
    public Matrix Projection;
    public MyViewport Viewport;
    public Vector3D CameraPosition;
    public bool DepthRead;
    public float FarPlane;
  }
}
