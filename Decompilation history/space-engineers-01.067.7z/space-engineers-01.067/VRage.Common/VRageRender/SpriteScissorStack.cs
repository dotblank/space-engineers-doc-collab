﻿// Decompiled with JetBrains decompiler
// Type: VRageRender.SpriteScissorStack
// Assembly: VRage.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9B95DD31-5265-474F-A3A1-473B0C270A79
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace VRageRender
{
  public class SpriteScissorStack
  {
    private Stack<Rectangle> m_rectangleStack = new Stack<Rectangle>();

    public bool Empty
    {
      get
      {
        return this.m_rectangleStack.Count == 0;
      }
    }

    public void Push(Rectangle scissorRect)
    {
      if (!this.Empty)
      {
        Rectangle rectangle = this.m_rectangleStack.Peek();
        Rectangle.Intersect(ref scissorRect, ref rectangle, out scissorRect);
      }
      this.m_rectangleStack.Push(scissorRect);
    }

    public void Pop()
    {
      if (this.Empty)
        return;
      this.m_rectangleStack.Pop();
    }

    public RectangleF? Peek()
    {
      if (this.Empty)
        return new RectangleF?();
      Rectangle rectangle = this.m_rectangleStack.Peek();
      return new RectangleF?(new RectangleF((float) rectangle.X, (float) rectangle.Y, (float) rectangle.Width, (float) rectangle.Height));
    }

    public void Cut(ref RectangleF destination, ref RectangleF source)
    {
      if (this.Empty)
        return;
      RectangleF other = destination;
      Rectangle rectangle = this.m_rectangleStack.Peek();
      RectangleF rectangleF = new RectangleF((float) rectangle.X, (float) rectangle.Y, (float) rectangle.Width, (float) rectangle.Height);
      RectangleF.Intersect(ref destination, ref rectangleF, out destination);
      if (destination.Equals(other))
        return;
      Vector2 vector2_1 = source.Size / other.Size;
      Vector2 vector2_2 = destination.Size - other.Size;
      Vector2 vector2_3 = destination.Position - other.Position;
      source.Position += vector2_3 * vector2_1;
      source.Size += vector2_2 * vector2_1;
    }
  }
}
