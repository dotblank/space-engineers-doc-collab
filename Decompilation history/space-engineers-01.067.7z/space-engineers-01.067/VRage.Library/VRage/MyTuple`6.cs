﻿// Decompiled with JetBrains decompiler
// Type: VRage.MyTuple`6
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F987C912-6032-4943-850E-69DEE0217B30
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Library.dll

using System.Runtime.InteropServices;

namespace VRage
{
  [StructLayout(LayoutKind.Sequential, Pack = 4)]
  public struct MyTuple<T1, T2, T3, T4, T5, T6>
  {
    public T1 Item1;
    public T2 Item2;
    public T3 Item3;
    public T4 Item4;
    public T5 Item5;
    public T6 Item6;

    public MyTuple(T1 item1, T2 item2, T3 item3, T4 item4, T5 item5, T6 item6)
    {
      this.Item1 = item1;
      this.Item2 = item2;
      this.Item3 = item3;
      this.Item4 = item4;
      this.Item5 = item5;
      this.Item6 = item6;
    }
  }
}
