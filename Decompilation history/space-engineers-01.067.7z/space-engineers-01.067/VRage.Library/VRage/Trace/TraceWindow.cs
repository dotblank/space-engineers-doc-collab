﻿// Decompiled with JetBrains decompiler
// Type: VRage.Trace.TraceWindow
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F987C912-6032-4943-850E-69DEE0217B30
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Library.dll

namespace VRage.Trace
{
  public enum TraceWindow
  {
    Default,
    Saving,
    ParallelParticles,
    Server,
    EntityId,
    Multiplayer,
    MultiplayerFiltered,
    MultiplayerAlerts,
    Analytics,
    Navigation,
  }
}
