﻿// Decompiled with JetBrains decompiler
// Type: VRage.Trace.ITrace
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F987C912-6032-4943-850E-69DEE0217B30
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\VRage.Library.dll

namespace VRage.Trace
{
  public interface ITrace
  {
    void Watch(string name, object value);

    void Send(string msg, string comment = null);
  }
}
