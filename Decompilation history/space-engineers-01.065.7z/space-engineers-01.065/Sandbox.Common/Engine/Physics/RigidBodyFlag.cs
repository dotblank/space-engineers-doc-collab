﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Engine.Physics.RigidBodyFlag
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using System;

namespace Sandbox.Engine.Physics
{
  [Flags]
  public enum RigidBodyFlag
  {
    RBF_DEFAULT = 0,
    RBF_KINEMATIC = 2,
    RBF_STATIC = 4,
    RBF_DISABLE_COLLISION_RESPONSE = 64,
    RBF_DOUBLED_KINEMATIC = 128,
    RBF_BULLET = 256,
    RBF_DEBRIS = 512,
    RBF_KEYFRAMED_REPORTING = 1024,
  }
}
