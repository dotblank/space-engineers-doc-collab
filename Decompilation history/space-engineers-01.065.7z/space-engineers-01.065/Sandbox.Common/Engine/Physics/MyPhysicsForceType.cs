﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Engine.Physics.MyPhysicsForceType
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

namespace Sandbox.Engine.Physics
{
  public enum MyPhysicsForceType : byte
  {
    APPLY_WORLD_IMPULSE_AND_WORLD_ANGULAR_IMPULSE,
    ADD_BODY_FORCE_AND_BODY_TORQUE,
    APPLY_WORLD_FORCE,
  }
}
