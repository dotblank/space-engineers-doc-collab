﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMyMultiplayer
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.Common.ObjectBuilders;
using System.Collections.Generic;

namespace Sandbox.ModAPI
{
  public interface IMyMultiplayer
  {
    bool MultiplayerActive { get; }

    bool IsServer { get; }

    ulong ServerId { get; }

    ulong MyId { get; }

    string MyName { get; }

    IMyPlayerCollection Players { get; }

    bool IsServerPlayer(IMyNetworkClient player);

    void SendEntitiesCreated(List<MyObjectBuilder_EntityBase> objectBuilders);
  }
}
