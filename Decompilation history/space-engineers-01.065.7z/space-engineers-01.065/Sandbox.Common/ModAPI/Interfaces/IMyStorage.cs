﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Interfaces.IMyStorage
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using VRage.Common.Voxels;
using VRageMath;

namespace Sandbox.ModAPI.Interfaces
{
  public interface IMyStorage
  {
    Vector3I Size { get; }

    void OverwriteAllMaterials(byte materialIndex);

    void ReadRange(MyStorageDataCache target, MyStorageDataTypeFlags dataToRead, int lodIndex, Vector3I lodVoxelRangeMin, Vector3I lodVoxelRangeMax);

    void WriteRange(MyStorageDataCache source, MyStorageDataTypeFlags dataToWrite, Vector3I voxelRangeMin, Vector3I voxelRangeMax);
  }
}
