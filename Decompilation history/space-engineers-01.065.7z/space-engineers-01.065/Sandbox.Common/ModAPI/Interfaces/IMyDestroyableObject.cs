﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Interfaces.IMyDestroyableObject
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.Common.ObjectBuilders.Definitions;

namespace Sandbox.ModAPI.Interfaces
{
  public interface IMyDestroyableObject
  {
    float Integrity { get; }

    void OnDestroy();

    void DoDamage(float damage, MyDamageType damageType, bool sync);
  }
}
