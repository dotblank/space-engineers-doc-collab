﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Interfaces.ITerminalProperty`1
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.ModAPI.Ingame;

namespace Sandbox.ModAPI.Interfaces
{
  public interface ITerminalProperty<TValue> : ITerminalProperty
  {
    TValue GetValue(IMyCubeBlock block);

    void SetValue(IMyCubeBlock block, TValue value);

    TValue GetDefaultValue(IMyCubeBlock block);

    TValue GetMininum(IMyCubeBlock block);

    TValue GetMaximum(IMyCubeBlock block);
  }
}
