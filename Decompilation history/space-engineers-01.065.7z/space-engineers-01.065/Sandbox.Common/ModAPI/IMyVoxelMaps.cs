﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMyVoxelMaps
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.ModAPI.Interfaces;
using System;
using System.Collections.Generic;
using VRageMath;

namespace Sandbox.ModAPI
{
  public interface IMyVoxelMaps
  {
    void Clear();

    bool Exist(IMyVoxelMap voxelMap);

    IMyVoxelMap GetOverlappingWithSphere(ref BoundingSphereD sphere);

    IMyVoxelMap GetVoxelMapWhoseBoundingBoxIntersectsBox(ref BoundingBoxD boundingBox, IMyVoxelMap ignoreVoxelMap);

    void GetInstances(List<IMyVoxelMap> outInstances, Func<IMyVoxelMap, bool> collect = null);

    IMyStorage CreateStorage(Vector3I size);
  }
}
