﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Ingame.IMySlimBlock
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using System.Collections.Generic;
using VRageMath;

namespace Sandbox.ModAPI.Ingame
{
  public interface IMySlimBlock
  {
    float AccumulatedDamage { get; }

    float BuildIntegrity { get; }

    float BuildLevelRatio { get; }

    float CurrentDamage { get; }

    float DamageRatio { get; }

    IMyCubeBlock FatBlock { get; }

    bool HasDeformation { get; }

    bool IsDestroyed { get; }

    bool IsFullIntegrity { get; }

    bool IsFullyDismounted { get; }

    float MaxDeformation { get; }

    float MaxIntegrity { get; }

    bool ShowParts { get; }

    bool StockpileAllocated { get; }

    bool StockpileEmpty { get; }

    Vector3I Position { get; }

    IMyCubeGrid CubeGrid { get; }

    void GetMissingComponents(Dictionary<string, int> addToDictionary);

    void UpdateVisual();
  }
}
