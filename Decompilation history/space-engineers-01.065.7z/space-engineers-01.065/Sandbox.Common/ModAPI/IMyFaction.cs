﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMyFaction
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.Common;
using VRage.Collections;

namespace Sandbox.ModAPI
{
  public interface IMyFaction
  {
    long FactionId { get; }

    string Tag { get; }

    string Name { get; }

    string Description { get; }

    string PrivateInfo { get; }

    bool AutoAcceptMember { get; }

    bool AutoAcceptPeace { get; }

    DictionaryReader<long, MyFactionMember> Members { get; }

    DictionaryReader<long, MyFactionMember> JoinRequests { get; }

    bool IsFounder(long playerId);

    bool IsLeader(long playerId);

    bool IsMember(long playerId);

    bool IsNeutral(long playerId);
  }
}
