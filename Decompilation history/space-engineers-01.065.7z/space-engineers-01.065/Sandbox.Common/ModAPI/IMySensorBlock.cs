﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMySensorBlock
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using System;

namespace Sandbox.ModAPI
{
  public interface IMySensorBlock : Sandbox.ModAPI.Ingame.IMySensorBlock, Sandbox.ModAPI.Ingame.IMyFunctionalBlock, Sandbox.ModAPI.Ingame.IMyTerminalBlock, Sandbox.ModAPI.Ingame.IMyCubeBlock, IMyEntity
  {
    event Action<bool> StateChanged;
  }
}
