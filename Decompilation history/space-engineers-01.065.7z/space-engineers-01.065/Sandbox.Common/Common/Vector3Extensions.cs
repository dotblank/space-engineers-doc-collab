﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.Vector3Extensions
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using VRageMath;

namespace Sandbox.Common
{
  public static class Vector3Extensions
  {
    public static Vector3 Project(this Vector3 projectedOntoVector, Vector3 projectedVector)
    {
      return Vector3.Dot(projectedVector, projectedOntoVector) / projectedOntoVector.LengthSquared() * projectedOntoVector;
    }
  }
}
