﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.Localization.MyLanguagesEnum
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

namespace Sandbox.Common.Localization
{
  public enum MyLanguagesEnum : byte
  {
    [MyLanguageDescription("en", 1f)] English,
    [MyLanguageDescription("cs-CZ", 0.95f)] Czech,
    [MyLanguageDescription("sk-SK", 0.95f)] Slovak,
    [MyLanguageDescription("de", 0.85f)] German,
    [MyLanguageDescription("ru", 1f)] Russian,
    [MyLanguageDescription("es", 1f)] Spanish_Spain,
    [MyLanguageDescription("fr", 1f)] French,
    [MyLanguageDescription("it", 1f)] Italian,
    [MyLanguageDescription("da", 1f)] Danish,
    [MyLanguageDescription("nl", 1f)] Dutch,
    [MyLanguageDescription("is-IS", 1f)] Icelandic,
    [MyLanguageDescription("pl-PL", 1f)] Polish,
    [MyLanguageDescription("fi", 1f)] Finnish,
    [MyLanguageDescription("hu-HU", 0.85f)] Hungarian,
    [MyLanguageDescription("pt-BR", 1f)] Portuguese_Brazil,
    [MyLanguageDescription("et-EE", 1f)] Estonian,
    [MyLanguageDescription("no", 1f)] Norwegian,
    [MyLanguageDescription("es-MX", 1f)] Spanish_HispanicAmerica,
    [MyLanguageDescription("sv", 0.9f)] Swedish,
    [MyLanguageDescription("ca-ES", 0.85f)] Catalan,
    [MyLanguageDescription("hr-HR", 0.9f)] Croatian,
    [MyLanguageDescription("ro", 0.85f)] Romanian,
    [MyLanguageDescription("uk", 1f)] Ukrainian,
    [MyLanguageDescription("tr-TR", 1f)] Turkish,
    [MyLanguageDescription("lv", 0.87f)] Latvian,
  }
}
