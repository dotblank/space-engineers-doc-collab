﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.MyEngineConstants
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

namespace Sandbox.Common
{
  public class MyEngineConstants
  {
    public const float UPDATE_STEPS_PER_SECOND = 60f;
    public const float UPDATE_STEP_SIZE_IN_SECONDS = 0.01666667f;
    public const int UPDATE_STEP_SIZE_IN_MILLISECONDS = 16;
  }
}
