﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_MedicalRoom
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;

namespace Sandbox.Common.ObjectBuilders
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_MedicalRoom : MyObjectBuilder_FunctionalBlock
  {
    [ProtoMember(1)]
    public ulong SteamUserId;
    [ProtoMember(2)]
    public string IdleSound;
    [ProtoMember(3)]
    public string ProgressSound;
  }
}
