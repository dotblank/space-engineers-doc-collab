﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.VRageData.MyObjectBuilder_TransparentMaterials
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;
using System.Xml.Serialization;

namespace Sandbox.Common.ObjectBuilders.VRageData
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_TransparentMaterials : MyObjectBuilder_Base
  {
    [XmlArrayItem("TransparentMaterial")]
    [ProtoMember(1)]
    public MyObjectBuilder_TransparentMaterial[] Materials;
  }
}
