﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_FactionChatItem
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  [MyObjectBuilderDefinition]
  public class MyObjectBuilder_FactionChatItem : MyObjectBuilder_Base
  {
    [XmlAttribute("t")]
    [ProtoMember(1)]
    public string Text;
    [XmlElement(ElementName = "I")]
    [ProtoMember(2)]
    public long IdentityIdUniqueNumber;
    [XmlElement(ElementName = "T")]
    [ProtoMember(3)]
    public long TimestampMs;
    [ProtoMember(4)]
    [DefaultValue(null)]
    [XmlElement(ElementName = "PTST")]
    public List<long> PlayersToSendToUniqueNumber;
    [XmlElement(ElementName = "IAST")]
    [DefaultValue(null)]
    [ProtoMember(5)]
    public List<bool> IsAlreadySentTo;
  }
}
