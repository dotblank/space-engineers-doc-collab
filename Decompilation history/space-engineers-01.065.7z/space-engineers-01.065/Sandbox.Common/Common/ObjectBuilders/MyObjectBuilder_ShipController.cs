﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_ShipController
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders.Definitions;
using System.ComponentModel;

namespace Sandbox.Common.ObjectBuilders
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_ShipController : MyObjectBuilder_TerminalBlock
  {
    [DefaultValue(true)]
    [ProtoMember(2)]
    public bool ControlThrusters = true;
    [ProtoMember(5)]
    [DefaultValue(null)]
    public SerializableDefinitionId? SelectedGunId = new SerializableDefinitionId?();
    [ProtoMember(1)]
    public bool UseSingleWeaponMode;
    [ProtoMember(3)]
    [DefaultValue(false)]
    public bool ControlWheels;
    [ProtoMember(4)]
    public MyObjectBuilder_Toolbar Toolbar;

    public override void Remap(IMyRemapHelper remapHelper)
    {
      base.Remap(remapHelper);
      if (this.Toolbar == null)
        return;
      this.Toolbar.Remap(remapHelper);
    }
  }
}
