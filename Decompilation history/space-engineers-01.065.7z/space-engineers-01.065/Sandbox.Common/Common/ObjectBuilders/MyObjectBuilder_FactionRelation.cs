﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_FactionRelation
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  public struct MyObjectBuilder_FactionRelation
  {
    [ProtoMember(1)]
    public long FactionId1;
    [ProtoMember(2)]
    public long FactionId2;
    [ProtoMember(3)]
    public MyRelationsBetweenFactions Relation;
  }
}
