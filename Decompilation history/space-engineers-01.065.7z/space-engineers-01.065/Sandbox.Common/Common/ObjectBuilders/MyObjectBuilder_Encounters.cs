﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_Encounters
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using System.Collections.Generic;
using VRage.Serialization;
using VRageMath;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  [MyObjectBuilderDefinition]
  public class MyObjectBuilder_Encounters : MyObjectBuilder_Base
  {
    [ProtoMember(1)]
    public HashSet<MyEncounterId> SavedEcounters;
    [ProtoMember(2)]
    public SerializableDictionary<MyEncounterId, Vector3D> MovedOnlyEncounters;
  }
}
