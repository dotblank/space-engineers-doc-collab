﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyOrientation
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using System.Xml.Serialization;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  public struct MyOrientation
  {
    [ProtoMember(1)]
    [XmlAttribute]
    public float Yaw;
    [XmlAttribute]
    [ProtoMember(2)]
    public float Pitch;
    [XmlAttribute]
    [ProtoMember(3)]
    public float Roll;

    public MyOrientation(float yaw, float pitch, float roll)
    {
      this.Yaw = yaw;
      this.Pitch = pitch;
      this.Roll = roll;
    }
  }
}
