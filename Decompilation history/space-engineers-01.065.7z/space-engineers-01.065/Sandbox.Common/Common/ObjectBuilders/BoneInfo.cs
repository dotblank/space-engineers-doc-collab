﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.BoneInfo
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders.VRageData;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  public struct BoneInfo
  {
    [ProtoMember(1)]
    public SerializableVector3I BonePosition;
    [ProtoMember(2)]
    public SerializableVector3UByte BoneOffset;
  }
}
