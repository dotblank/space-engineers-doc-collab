﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_Projector
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using VRageMath;

namespace Sandbox.Common.ObjectBuilders
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_Projector : MyObjectBuilder_FunctionalBlock
  {
    [ProtoMember(1)]
    public MyObjectBuilder_CubeGrid ProjectedGrid;
    [ProtoMember(2)]
    public Vector3I ProjectionOffset;
    [ProtoMember(3)]
    public Vector3I ProjectionRotation;
    [ProtoMember(4)]
    public bool KeepProjection;

    public override void Remap(IMyRemapHelper remapHelper)
    {
      base.Remap(remapHelper);
      if (this.ProjectedGrid == null)
        return;
      this.ProjectedGrid.Remap(remapHelper);
    }
  }
}
