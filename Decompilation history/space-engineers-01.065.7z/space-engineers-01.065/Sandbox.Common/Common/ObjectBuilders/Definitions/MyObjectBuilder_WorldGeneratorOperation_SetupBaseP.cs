﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.Definitions.MyObjectBuilder_WorldGeneratorOperation_SetupBasePrefab
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Common.ObjectBuilders.VRageData;
using System.Xml.Serialization;
using VRageMath;

namespace Sandbox.Common.ObjectBuilders.Definitions
{
  [XmlType("SetupBasePrefab")]
  [MyObjectBuilderDefinition]
  public class MyObjectBuilder_WorldGeneratorOperation_SetupBasePrefab : MyObjectBuilder_WorldGeneratorOperation
  {
    [XmlAttribute]
    [ProtoMember(1)]
    public string PrefabFile;
    [ProtoMember(2)]
    public SerializableVector3 Offset;
    [ProtoMember(3)]
    [XmlAttribute]
    public string AsteroidName;
    [ProtoMember(4)]
    [XmlAttribute]
    public string BeaconName;

    public bool ShouldSerializeOffset()
    {
      return (Vector3) this.Offset != Vector3.Zero;
    }

    public bool ShouldSerializeBeaconName()
    {
      return !string.IsNullOrEmpty(this.BeaconName);
    }
  }
}
