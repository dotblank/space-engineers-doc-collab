﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.Definitions.BlueprintItem
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;
using System.Xml.Serialization;

namespace Sandbox.Common.ObjectBuilders.Definitions
{
  [ProtoContract]
  public class BlueprintItem
  {
    [XmlIgnore]
    [ProtoMember(1)]
    public SerializableDefinitionId Id;
    [XmlAttribute]
    [ProtoMember(2)]
    public string Amount;

    [XmlAttribute]
    public string TypeId
    {
      get
      {
        return this.Id.TypeId.ToString();
      }
      set
      {
        this.Id.TypeId = MyObjectBuilderType.ParseBackwardsCompatible(value);
      }
    }

    [XmlAttribute]
    public string SubtypeId
    {
      get
      {
        return this.Id.SubtypeId;
      }
      set
      {
        this.Id.SubtypeId = value;
      }
    }
  }
}
