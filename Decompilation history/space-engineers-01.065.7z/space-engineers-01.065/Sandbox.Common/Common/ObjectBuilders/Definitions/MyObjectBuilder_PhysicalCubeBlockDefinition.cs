﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.Definitions.MyObjectBuilder_PhysicalCubeBlockDefinition
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;
using System.ComponentModel;

namespace Sandbox.Common.ObjectBuilders.Definitions
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_PhysicalCubeBlockDefinition : MyObjectBuilder_PhysicalItemDefinition
  {
    [ProtoMember(1)]
    [DefaultValue(null)]
    public string CubeBlockSubtypeId;
    [DefaultValue(null)]
    [ProtoMember(2)]
    public string OreSubtypeId;
    [ProtoMember(3)]
    [DefaultValue(null)]
    public string PhysicalToolSubtypeId;
  }
}
