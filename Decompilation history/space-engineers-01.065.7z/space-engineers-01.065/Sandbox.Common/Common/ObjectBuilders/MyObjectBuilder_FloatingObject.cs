﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_FloatingObject
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;
using System.ComponentModel;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  [MyObjectBuilderDefinition]
  public class MyObjectBuilder_FloatingObject : MyObjectBuilder_EntityBase
  {
    [ProtoMember(1)]
    public MyObjectBuilder_InventoryItem Item;
    [DefaultValue(null)]
    [ProtoMember(2)]
    public string OreSubtypeId;
  }
}
