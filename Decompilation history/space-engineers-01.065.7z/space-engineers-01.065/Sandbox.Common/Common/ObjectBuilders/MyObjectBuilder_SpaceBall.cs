﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_SpaceBall
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  [MyObjectBuilderDefinition]
  public class MyObjectBuilder_SpaceBall : MyObjectBuilder_FunctionalBlock
  {
    [ProtoMember(1)]
    public float VirtualMass = 100f;
    [ProtoMember(2)]
    public float Friction = 0.5f;
    [ProtoMember(3)]
    public float Restitution = 0.5f;
    [ProtoMember(4)]
    public bool EnableBroadcast = true;
  }
}
