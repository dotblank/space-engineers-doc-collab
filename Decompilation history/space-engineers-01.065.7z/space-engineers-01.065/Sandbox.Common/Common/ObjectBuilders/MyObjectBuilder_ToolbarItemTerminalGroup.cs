﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_ToolbarItemTerminalGroup
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using ProtoBuf;

namespace Sandbox.Common.ObjectBuilders
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_ToolbarItemTerminalGroup : MyObjectBuilder_ToolbarItemTerminal
  {
    public long GridEntityId;
    [ProtoMember(1)]
    public long BlockEntityId;
    [ProtoMember(2)]
    public string GroupName;

    public override void Remap(IMyRemapHelper remapHelper)
    {
      if (this.BlockEntityId == 0L)
        return;
      this.BlockEntityId = remapHelper.RemapEntityId(this.BlockEntityId);
    }
  }
}
