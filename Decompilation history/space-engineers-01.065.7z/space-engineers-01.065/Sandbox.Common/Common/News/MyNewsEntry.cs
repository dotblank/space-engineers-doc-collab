﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.News.MyNewsEntry
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using System.Xml.Serialization;

namespace Sandbox.Common.News
{
  public class MyNewsEntry
  {
    [XmlAttribute(AttributeName = "public")]
    public bool Public = true;
    [XmlAttribute(AttributeName = "title")]
    public string Title;
    [XmlAttribute(AttributeName = "date")]
    public string Date;
    [XmlAttribute(AttributeName = "version")]
    public string Version;
    [XmlText]
    public string Text;
  }
}
