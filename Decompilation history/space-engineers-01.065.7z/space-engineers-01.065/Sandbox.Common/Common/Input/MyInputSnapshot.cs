﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.Input.MyInputSnapshot
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 5A6CB767-C876-4B9F-8270-94D7B74A4437
// Assembly location: D:\test\Sandbox.Common.dll

using Sandbox.Common;
using System.Collections.Generic;
using System.Reflection;
using VRageMath;

namespace Sandbox.Common.Input
{
  [Obfuscation(Exclude = true, Feature = "cw symbol renaming")]
  public class MyInputSnapshot
  {
    public MyMouseSnapshot MouseSnapshot { get; set; }

    public List<Keys> KeyboardSnapshot { get; set; }

    public MyJoystickStateSnapshot JoystickSnapshot { get; set; }

    public int SnapshotTimestamp { get; set; }

    public Vector2 MouseCursorPosition { get; set; }
  }
}
