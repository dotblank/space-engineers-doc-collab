﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyCompany("Keen Software House")]
[assembly: ComVisible(false)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: AssemblyProduct("Sandbox")]
[assembly: AssemblyTrademark("Space Engineers")]
[assembly: Guid("29613bf2-9a4d-46f5-a737-53a0f78dcec5")]
[assembly: Extension]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("Sandbox.Common")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
