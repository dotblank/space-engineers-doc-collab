﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.VRageData.MyObjectBuilder_TransparentMaterials
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;
using System.Xml.Serialization;

namespace Sandbox.Common.ObjectBuilders.VRageData
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_TransparentMaterials : MyObjectBuilder_Base
  {
    [ProtoMember(1)]
    [XmlArrayItem("TransparentMaterial")]
    public MyObjectBuilder_TransparentMaterial[] Materials;
  }
}
