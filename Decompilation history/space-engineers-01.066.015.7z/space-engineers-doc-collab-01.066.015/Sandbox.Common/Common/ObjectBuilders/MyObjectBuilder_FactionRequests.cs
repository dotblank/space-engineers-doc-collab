﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Common.ObjectBuilders.MyObjectBuilder_FactionRequests
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using ProtoBuf;
using System.Collections.Generic;

namespace Sandbox.Common.ObjectBuilders
{
  [ProtoContract]
  public struct MyObjectBuilder_FactionRequests
  {
    [ProtoMember(1)]
    public long FactionId;
    [ProtoMember(2)]
    public List<long> FactionRequests;
  }
}
