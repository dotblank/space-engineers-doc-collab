﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Engine.Physics.MyPhysicsForceType
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

namespace Sandbox.Engine.Physics
{
  public enum MyPhysicsForceType : byte
  {
    APPLY_WORLD_IMPULSE_AND_WORLD_ANGULAR_IMPULSE,
    ADD_BODY_FORCE_AND_BODY_TORQUE,
    APPLY_WORLD_FORCE,
  }
}
