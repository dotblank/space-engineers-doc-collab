﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Interfaces.IMyInventory
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using Sandbox.Common.ObjectBuilders;
using Sandbox.Common.ObjectBuilders.Definitions;
using System.Collections.Generic;
using VRage;
using VRageMath;

namespace Sandbox.ModAPI.Interfaces
{
  public interface IMyInventory
  {
    bool IsFull { get; }

    Vector3 Size { get; }

    MyFixedPoint CurrentMass { get; }

    MyFixedPoint MaxVolume { get; }

    MyFixedPoint CurrentVolume { get; }

    IMyInventoryOwner Owner { get; }

    bool IsItemAt(int position);

    bool CanItemsBeAdded(MyFixedPoint amount, SerializableDefinitionId contentId);

    bool ContainItems(MyFixedPoint amount, MyObjectBuilder_PhysicalObject ob);

    MyFixedPoint GetItemAmount(SerializableDefinitionId contentId, MyItemFlags flags = MyItemFlags.None);

    bool TransferItemTo(IMyInventory dst, int sourceItemIndex, int? targetItemIndex = null, bool? stackIfPossible = null, MyFixedPoint? amount = null);

    bool TransferItemFrom(IMyInventory sourceInventory, int sourceItemIndex, int? targetItemIndex = null, bool? stackIfPossible = null, MyFixedPoint? amount = null);

    List<IMyInventoryItem> GetItems();

    IMyInventoryItem GetItemByID(uint id);

    IMyInventoryItem FindItem(SerializableDefinitionId contentId);

    bool IsConnectedTo(IMyInventory dst);
  }
}
