﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMySensorBlock
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using System;

namespace Sandbox.ModAPI
{
  public interface IMySensorBlock : Sandbox.ModAPI.Ingame.IMySensorBlock, Sandbox.ModAPI.Ingame.IMyFunctionalBlock, Sandbox.ModAPI.Ingame.IMyTerminalBlock, Sandbox.ModAPI.Ingame.IMyCubeBlock, IMyEntity
  {
    event Action<bool> StateChanged;
  }
}
