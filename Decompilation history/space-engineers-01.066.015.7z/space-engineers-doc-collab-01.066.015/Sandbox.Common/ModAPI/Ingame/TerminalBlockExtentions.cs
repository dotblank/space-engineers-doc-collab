﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Ingame.TerminalBlockExtentions
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4DE4FF21-FB6F-425F-A186-B73142DACE15
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\Bin64\Sandbox.Common.dll

using Sandbox.ModAPI.Interfaces;

namespace Sandbox.ModAPI.Ingame
{
  public static class TerminalBlockExtentions
  {
    public static void ApplyAction(this IMyTerminalBlock block, string actionName)
    {
      block.GetActionWithName(actionName).Apply((IMyCubeBlock) block);
    }

    public static bool HasAction(this IMyTerminalBlock block, string Action)
    {
      return block.GetActionWithName(Action) != null;
    }

    public static bool HasInventory(this IMyTerminalBlock block)
    {
      return block is IMyInventoryOwner;
    }

    public static IMyInventory GetInventory(this IMyTerminalBlock block, int index)
    {
      if (TerminalBlockExtentions.HasInventory(block))
        return ((IMyInventoryOwner) block).GetInventory(index);
      else
        return (IMyInventory) null;
    }

    public static int GetInventoryCount(this IMyTerminalBlock block)
    {
      if (TerminalBlockExtentions.HasInventory(block))
        return ((IMyInventoryOwner) block).InventoryCount;
      else
        return 0;
    }

    public static bool GetUseConveyorSystem(this IMyTerminalBlock block)
    {
      if (TerminalBlockExtentions.HasInventory(block))
        return ((IMyInventoryOwner) block).UseConveyorSystem;
      else
        return false;
    }

    public static void SetUseConveyorSystem(this IMyTerminalBlock block, bool use)
    {
      if (!TerminalBlockExtentions.HasInventory(block))
        return;
      ((IMyInventoryOwner) block).UseConveyorSystem = use;
    }
  }
}
