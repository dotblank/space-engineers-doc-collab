﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("VRage.Library")]
[assembly: AssemblyCompany("Keen Software House")]
[assembly: AssemblyTrademark("VRage")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Extension]
[assembly: Guid("c8af46e0-adb3-437e-8251-0e5bc827cbb4")]
[assembly: AssemblyTitle("VRage.Library")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
