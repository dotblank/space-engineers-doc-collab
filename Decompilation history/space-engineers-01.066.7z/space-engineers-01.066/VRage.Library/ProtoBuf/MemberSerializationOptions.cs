﻿// Decompiled with JetBrains decompiler
// Type: ProtoBuf.MemberSerializationOptions
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;

namespace ProtoBuf
{
  [Flags]
  public enum MemberSerializationOptions
  {
    None = 0,
    Packed = 1,
    Required = 2,
    AsReference = 4,
    DynamicType = 8,
    OverwriteList = 16,
    AsReferenceHasValue = 32,
  }
}
