﻿// Decompiled with JetBrains decompiler
// Type: ProtoBuf.Serializers.ISerializerProxy
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

namespace ProtoBuf.Serializers
{
  internal interface ISerializerProxy
  {
    IProtoSerializer Serializer { get; }
  }
}
