﻿// Decompiled with JetBrains decompiler
// Type: ProtoBuf.Compiler.CodeLabel
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System.Reflection.Emit;

namespace ProtoBuf.Compiler
{
  internal struct CodeLabel
  {
    public readonly Label Value;
    public readonly int Index;

    public CodeLabel(Label value, int index)
    {
      this.Value = value;
      this.Index = index;
    }
  }
}
