﻿// Decompiled with JetBrains decompiler
// Type: ProtoBuf.ServiceModel.ProtoBehaviorAttribute
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace ProtoBuf.ServiceModel
{
  [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
  public sealed class ProtoBehaviorAttribute : Attribute, IOperationBehavior
  {
    void IOperationBehavior.AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
    {
    }

    void IOperationBehavior.ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
    {
      new ProtoOperationBehavior(operationDescription).ApplyClientBehavior(operationDescription, clientOperation);
    }

    void IOperationBehavior.ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
    {
      new ProtoOperationBehavior(operationDescription).ApplyDispatchBehavior(operationDescription, dispatchOperation);
    }

    void IOperationBehavior.Validate(OperationDescription operationDescription)
    {
    }
  }
}
