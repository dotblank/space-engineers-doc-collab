﻿// Decompiled with JetBrains decompiler
// Type: ProtoBuf.WireType
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

namespace ProtoBuf
{
  public enum WireType
  {
    None = -1,
    Variant = 0,
    Fixed64 = 1,
    String = 2,
    StartGroup = 3,
    EndGroup = 4,
    Fixed32 = 5,
    SignedVariant = 8,
  }
}
