﻿// Decompiled with JetBrains decompiler
// Type: System.Reflection.Obfuscator
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System.Collections;
using System.Linq;

namespace System.Reflection
{
  public static class Obfuscator
  {
    public const bool EnableAttributeCheck = true;
    public const string NoRename = "cw symbol renaming";

    public static bool CheckAttribute(this MemberInfo member)
    {
      foreach (ObfuscationAttribute obfuscationAttribute in Enumerable.OfType<ObfuscationAttribute>((IEnumerable) member.GetCustomAttributes(typeof (ObfuscationAttribute), false)))
      {
        if (obfuscationAttribute.Feature == "cw symbol renaming" && obfuscationAttribute.Exclude)
          return true;
      }
      return false;
    }
  }
}
