﻿// Decompiled with JetBrains decompiler
// Type: VRage.Utils.Disposable
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Diagnostics;

namespace VRage.Utils
{
  public class Disposable : IDisposable
  {
    public Disposable(bool collectStack = false)
    {
    }

    ~Disposable()
    {
      Trace.Fail("Dispose not called!", string.Format("Dispose was not called for '{0}'", (object) this.GetType().FullName));
    }

    public virtual void Dispose()
    {
      GC.SuppressFinalize((object) this);
    }
  }
}
