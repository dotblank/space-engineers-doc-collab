﻿// Decompiled with JetBrains decompiler
// Type: VRage.Collections.MySwapQueue
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;

namespace VRage.Collections
{
  public class MySwapQueue
  {
    public static MySwapQueue<T> Create<T>() where T : class, new()
    {
      return new MySwapQueue<T>(Activator.CreateInstance<T>(), Activator.CreateInstance<T>(), Activator.CreateInstance<T>());
    }
  }
}
