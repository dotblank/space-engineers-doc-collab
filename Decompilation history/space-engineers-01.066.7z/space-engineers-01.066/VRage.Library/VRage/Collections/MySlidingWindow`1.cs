﻿// Decompiled with JetBrains decompiler
// Type: VRage.Collections.MySlidingWindow`1
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;

namespace VRage.Collections
{
  public class MySlidingWindow<T>
  {
    private MyQueue<T> m_items;
    public int Size;
    public T DefaultValue;
    public Func<MyQueue<T>, T> AverageFunc;

    public T Average
    {
      get
      {
        if (this.m_items.Count == 0)
          return this.DefaultValue;
        else
          return this.AverageFunc(this.m_items);
      }
    }

    public T Last
    {
      get
      {
        if (this.m_items.Count <= 0)
          return this.DefaultValue;
        else
          return this.m_items[this.m_items.Count - 1];
      }
    }

    public MySlidingWindow(int size, Func<MyQueue<T>, T> avg, T defaultValue = null)
    {
      this.AverageFunc = avg;
      this.Size = size;
      this.DefaultValue = defaultValue;
      this.m_items = new MyQueue<T>(size + 1);
    }

    public void Add(T item)
    {
      this.m_items.Enqueue(item);
      this.RemoveExcess();
    }

    public void Clear()
    {
      this.m_items.Clear();
    }

    private void RemoveExcess()
    {
      while (this.m_items.Count > this.Size)
        this.m_items.Dequeue();
    }
  }
}
