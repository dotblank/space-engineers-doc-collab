﻿// Decompiled with JetBrains decompiler
// Type: VRage.Serialization.IAssignableFrom`1
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

namespace VRage.Serialization
{
  public interface IAssignableFrom<T>
  {
    void AssignFrom(T value);
  }
}
