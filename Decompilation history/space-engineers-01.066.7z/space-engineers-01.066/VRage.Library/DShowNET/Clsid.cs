﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.Clsid
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  public class Clsid
  {
    public static readonly Guid SystemDeviceEnum = new Guid(1656642832, (short) 24811, (short) 4560, (byte) 189, (byte) 59, (byte) 0, (byte) 160, (byte) 201, (byte) 17, (byte) 206, (byte) 134);
    public static readonly Guid FilterGraph = new Guid(3828804531U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid CaptureGraphBuilder2 = new Guid(3213342433U, (ushort) 35879, (ushort) 4560, (byte) 179, (byte) 240, (byte) 0, (byte) 170, (byte) 0, (byte) 55, (byte) 97, (byte) 197);
    public static readonly Guid SampleGrabber = new Guid(3253993632U, (ushort) 16136, (ushort) 4563, (byte) 159, (byte) 11, (byte) 0, (byte) 96, (byte) 8, (byte) 3, (byte) 158, (byte) 55);
    public static readonly Guid DvdGraphBuilder = new Guid(4240528055U, (ushort) 62322, (ushort) 4560, (byte) 142, (byte) 0, (byte) 0, (byte) 192, (byte) 79, (byte) 215, (byte) 192, (byte) 139);
  }
}
