﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.MediaSubType
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  public class MediaSubType
  {
    public static readonly Guid YUYV = new Guid(1448695129, (short) 0, (short) 16, (byte) sbyte.MinValue, (byte) 0, (byte) 0, (byte) 170, (byte) 0, (byte) 56, (byte) 155, (byte) 113);
    public static readonly Guid IYUV = new Guid(1448433993, (short) 0, (short) 16, (byte) sbyte.MinValue, (byte) 0, (byte) 0, (byte) 170, (byte) 0, (byte) 56, (byte) 155, (byte) 113);
    public static readonly Guid DVSD = new Guid(1146312260, (short) 0, (short) 16, (byte) sbyte.MinValue, (byte) 0, (byte) 0, (byte) 170, (byte) 0, (byte) 56, (byte) 155, (byte) 113);
    public static readonly Guid RGB1 = new Guid(3828804472U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB4 = new Guid(3828804473U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB8 = new Guid(3828804474U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB565 = new Guid(3828804475U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB555 = new Guid(3828804476U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB24 = new Guid(3828804477U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid RGB32 = new Guid(3828804478U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid Avi = new Guid(3828804488U, (ushort) 21071, (ushort) 4558, (byte) 159, (byte) 83, (byte) 0, (byte) 32, (byte) 175, (byte) 11, (byte) 167, (byte) 112);
    public static readonly Guid Asf = new Guid(1035472784U, (ushort) 37906, (ushort) 4561, (byte) 173, (byte) 237, (byte) 0, (byte) 0, (byte) 248, (byte) 117, (byte) 75, (byte) 153);
  }
}
