﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.VideoInfoHeader
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  [StructLayout(LayoutKind.Sequential)]
  public class VideoInfoHeader
  {
    public DsRECT SrcRect;
    public DsRECT TagRect;
    public int BitRate;
    public int BitErrorRate;
    public long AvgTimePerFrame;
    public DsBITMAPINFOHEADER BmiHeader;
  }
}
