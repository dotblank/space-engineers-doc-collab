﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.FilterCategory
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  public class FilterCategory
  {
    public static readonly Guid AudioInputDevice = new Guid(869902178U, (ushort) 37064, (ushort) 4560, (byte) 189, (byte) 67, (byte) 0, (byte) 160, (byte) 201, (byte) 17, (byte) 206, (byte) 134);
    public static readonly Guid VideoInputDevice = new Guid(2248913680U, (ushort) 23809, (ushort) 4560, (byte) 189, (byte) 59, (byte) 0, (byte) 160, (byte) 201, (byte) 17, (byte) 206, (byte) 134);
  }
}
