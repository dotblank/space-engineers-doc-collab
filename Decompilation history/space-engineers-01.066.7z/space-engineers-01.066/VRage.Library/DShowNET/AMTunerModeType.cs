﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.AMTunerModeType
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  [Flags]
  public enum AMTunerModeType
  {
    Default = 0,
    TV = 1,
    FMRadio = 2,
    AMRadio = 4,
    Dss = 8,
  }
}
