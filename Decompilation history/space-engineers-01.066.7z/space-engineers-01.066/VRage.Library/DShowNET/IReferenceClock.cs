﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.IReferenceClock
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [Guid("56a86897-0ad4-11ce-b03a-0020af0ba770")]
  [ComVisible(true)]
  [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  [ComImport]
  public interface IReferenceClock
  {
    [MethodImpl(MethodImplOptions.PreserveSig)]
    int GetTime(out long pTime);

    [MethodImpl(MethodImplOptions.PreserveSig)]
    int AdviseTime(long baseTime, long streamTime, IntPtr hEvent, out int pdwAdviseCookie);

    [MethodImpl(MethodImplOptions.PreserveSig)]
    int AdvisePeriodic(long startTime, long periodTime, IntPtr hSemaphore, out int pdwAdviseCookie);

    [MethodImpl(MethodImplOptions.PreserveSig)]
    int Unadvise(int dwAdviseCookie);
  }
}
