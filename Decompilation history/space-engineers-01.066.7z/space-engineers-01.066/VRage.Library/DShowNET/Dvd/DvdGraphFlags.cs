﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.Dvd.DvdGraphFlags
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;

namespace DShowNET.Dvd
{
  [Flags]
  public enum DvdGraphFlags
  {
    Default = 0,
    HwDecPrefer = 1,
    HwDecOnly = 2,
    SwDecPrefer = 4,
    SwDecOnly = 8,
    NoVpe = 256,
  }
}
