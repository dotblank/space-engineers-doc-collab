﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.Dvd.DvdAudioAttr
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System.Runtime.InteropServices;

namespace DShowNET.Dvd
{
  [ComVisible(false)]
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct DvdAudioAttr
  {
    public DvdAudioAppMode appMode;
    public int appModeData;
    public DvdAudioFormat audioFormat;
    public int language;
    public DvdAudioLangExt languageExtension;
    public bool hasMultichannelInfo;
    public int frequency;
    public byte quantization;
    public byte numberOfChannels;
    public short dummy;
    public int res1;
    public int res2;
  }
}
