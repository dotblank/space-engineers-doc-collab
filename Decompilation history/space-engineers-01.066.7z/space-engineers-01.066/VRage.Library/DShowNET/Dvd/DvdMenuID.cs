﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.Dvd.DvdMenuID
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

namespace DShowNET.Dvd
{
  public enum DvdMenuID
  {
    Title = 2,
    Root = 3,
    Subpicture = 4,
    Audio = 5,
    Angle = 6,
    Chapter = 7,
  }
}
