﻿// Decompiled with JetBrains decompiler
// Type: DShowNET.FormatType
// Assembly: VRage.Library, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0B597F39-75D0-4C76-A728-D6F8B4CB3407
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\VRage.Library.dll

using System;
using System.Runtime.InteropServices;

namespace DShowNET
{
  [ComVisible(false)]
  public class FormatType
  {
    public static readonly Guid None = new Guid(258217942U, (ushort) 49944, (ushort) 4560, (byte) 164, (byte) 63, (byte) 0, (byte) 160, (byte) 201, (byte) 34, (byte) 49, (byte) 150);
    public static readonly Guid VideoInfo = new Guid(89694080U, (ushort) 50006, (ushort) 4558, (byte) 191, (byte) 1, (byte) 0, (byte) 170, (byte) 0, (byte) 85, (byte) 89, (byte) 90);
    public static readonly Guid VideoInfo2 = new Guid(4146755232U, (ushort) 60170, (ushort) 4560, (byte) 172, (byte) 228, (byte) 0, (byte) 0, (byte) 192, (byte) 204, (byte) 22, (byte) 186);
    public static readonly Guid WaveEx = new Guid(89694081U, (ushort) 50006, (ushort) 4558, (byte) 191, (byte) 1, (byte) 0, (byte) 170, (byte) 0, (byte) 85, (byte) 89, (byte) 90);
    public static readonly Guid MpegVideo = new Guid(89694082U, (ushort) 50006, (ushort) 4558, (byte) 191, (byte) 1, (byte) 0, (byte) 170, (byte) 0, (byte) 85, (byte) 89, (byte) 90);
    public static readonly Guid MpegStreams = new Guid(89694083U, (ushort) 50006, (ushort) 4558, (byte) 191, (byte) 1, (byte) 0, (byte) 170, (byte) 0, (byte) 85, (byte) 89, (byte) 90);
    public static readonly Guid DvInfo = new Guid(89694084U, (ushort) 50006, (ushort) 4558, (byte) 191, (byte) 1, (byte) 0, (byte) 170, (byte) 0, (byte) 85, (byte) 89, (byte) 90);
  }
}
