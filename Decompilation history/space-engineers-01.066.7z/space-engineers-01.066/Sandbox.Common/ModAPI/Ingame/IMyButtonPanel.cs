﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Ingame.IMyButtonPanel
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9FFB867-6B77-43C8-B7DB-350DC275FCC1
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\Sandbox.Common.dll

using Sandbox.ModAPI;

namespace Sandbox.ModAPI.Ingame
{
  public interface IMyButtonPanel : IMyTerminalBlock, IMyCubeBlock, IMyEntity
  {
    bool AnyoneCanUse { get; }
  }
}
