﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.Ingame.IMyProjector
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9FFB867-6B77-43C8-B7DB-350DC275FCC1
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\Sandbox.Common.dll

namespace Sandbox.ModAPI.Ingame
{
  public interface IMyProjector
  {
    int ProjectionOffsetX { get; }

    int ProjectionOffsetY { get; }

    int ProjectionOffsetZ { get; }

    int ProjectionRotX { get; }

    int ProjectionRotY { get; }

    int ProjectionRotZ { get; }
  }
}
