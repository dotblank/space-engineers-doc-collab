﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMyIdentity
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9FFB867-6B77-43C8-B7DB-350DC275FCC1
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\Sandbox.Common.dll

using VRageMath;

namespace Sandbox.ModAPI
{
  public interface IMyIdentity
  {
    long PlayerId { get; }

    string DisplayName { get; }

    string Model { get; }

    Vector3? ColorMask { get; }

    bool IsDead { get; }
  }
}
