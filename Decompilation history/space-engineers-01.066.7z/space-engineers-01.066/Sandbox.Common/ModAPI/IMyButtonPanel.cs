﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.ModAPI.IMyButtonPanel
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9FFB867-6B77-43C8-B7DB-350DC275FCC1
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\Sandbox.Common.dll

using System;

namespace Sandbox.ModAPI
{
  public interface IMyButtonPanel : Sandbox.ModAPI.Ingame.IMyButtonPanel, Sandbox.ModAPI.Ingame.IMyTerminalBlock, Sandbox.ModAPI.Ingame.IMyCubeBlock, IMyEntity
  {
    event Action<int> ButtonPressed;
  }
}
