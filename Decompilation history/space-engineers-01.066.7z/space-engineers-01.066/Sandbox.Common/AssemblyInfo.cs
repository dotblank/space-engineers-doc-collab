﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyProduct("Sandbox")]
[assembly: AssemblyCompany("Keen Software House")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Keen Software House 2013")]
[assembly: AssemblyTrademark("Space Engineers")]
[assembly: Guid("29613bf2-9a4d-46f5-a737-53a0f78dcec5")]
[assembly: AssemblyDescription("")]
[assembly: Extension]
[assembly: AssemblyTitle("Sandbox.Common")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
