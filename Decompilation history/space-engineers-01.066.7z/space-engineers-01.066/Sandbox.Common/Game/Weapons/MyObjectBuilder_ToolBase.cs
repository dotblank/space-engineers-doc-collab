﻿// Decompiled with JetBrains decompiler
// Type: Sandbox.Game.Weapons.MyObjectBuilder_ToolBase
// Assembly: Sandbox.Common, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9FFB867-6B77-43C8-B7DB-350DC275FCC1
// Assembly location: D:\Games\Steam Library\SteamApps\common\SpaceEngineers\DedicatedServer64\Sandbox.Common.dll

using ProtoBuf;
using Sandbox.Common.ObjectBuilders;

namespace Sandbox.Game.Weapons
{
  [MyObjectBuilderDefinition]
  [ProtoContract]
  public class MyObjectBuilder_ToolBase : MyObjectBuilder_DeviceBase
  {
  }
}
